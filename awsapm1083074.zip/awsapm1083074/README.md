# governance-intake

Conversational governance intake agent for Elevance Health. A submitter
describes a project in plain language; the agent determines which governance
teams must review it (deterministic rule engine), consolidates the overlapping
team questionnaires into a deduplicated set of questions, collects the answers
in a single conversation, requires a solution/data-flow diagram, and files one
governance ticket.

LLM reasoning runs through the **EHAP** gateway (Elevance Horizon) to Claude.
Routing and question deduplication are deterministic, config-driven, and auditable.

- **Backend** = Python 3.12 + [uv]. Runs the API on port 8000.
- **Frontend** = Node 18+ (React + Vite). Talks to the backend's `/api`.

[uv]: https://docs.astral.sh/uv/

---

# Getting Started (quick)

The fastest path to a running app, in PowerShell. Start the backend first:

```powershell
uv sync --all-extras --system-certs
Copy-Item .env.example .env                 # fill in EHAP creds, or set DEV=true
uv run uvicorn governance_intake.server:app --host 0.0.0.0 --port 8000
```

Then, in a second terminal, the frontend:

```powershell
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**. (`DEV=true` in `.env` lets you run without real
EHAP credentials for local work.)

For the full step-by-step (including SageMaker and troubleshooting), see the
detailed walkthrough below. For backend dev workflow (tests, the eval suite,
linting) see [backend/README.md](backend/README.md). For frontend dev workflow
see [frontend/README.md](frontend/README.md).

---

# Quickstart on macOS / Linux

```bash
uv sync --all-extras  --system-certs                       # 1. install
uv run uvicorn governance_intake.server:app --port 8000    # 2. backend
cd frontend && npm install && npm run dev                  # 3. frontend (new terminal)
```

Open the Vite URL it prints (usually http://localhost:5173) and click
**"Preview questionnaire (sample project)"** in the header — that opens the
full post-dedup questionnaire on a bundled sample project with **no LLM
configured at all** (routing and dedup are deterministic). The chat flow and
the AI pre-fill additionally need a provider: real EHAP credentials, the
local `ehap-mock`, or `EHAP_PROVIDER=anthropic` + `ANTHROPIC_API_KEY`
(see `.env.example`).

**Troubleshooting — `ModuleNotFoundError: No module named 'governance_intake'`
on macOS:** some uv/CPython combinations mark every file in `.venv` with the
macOS `hidden` file flag, and Python ≥3.12.13 silently skips hidden `.pth`
files, which breaks the editable install. Fix once with:

```bash
chflags -R nohidden .venv
uv sync --all-extras --reinstall-package governance-intake
```
# Run locally on Windows

Two parts: start the **backend** (steps 1-4), then the **frontend** (steps 5-7).
Keep both running.

## Step 1 — Install the backend dependencies

From the repo root, in PowerShell:

```powershell
uv sync --all-extras
```

If you don't have `uv`: `pip install uv` (or `python -m pip install uv`) first.
If Python itself is missing, install Python 3.12+ (or `uv python install 3.12`).

**If this fails with `invalid peer certificate` / `UnknownIssuer`** (the
corporate TLS proxy), tell uv to use the Windows certificate store, then retry:

```powershell
setx UV_SYSTEM_CERTS true          # persists for NEW terminals
$env:UV_SYSTEM_CERTS = "true"      # applies to the CURRENT terminal
uv sync --all-extras
```

## Step 2 — Configure your `.env`

```powershell
Copy-Item .env.example .env
notepad .env
```

Fill in the EHAP credentials (required for the chat to work):

```
EHAP_URL=https://api.horizon.elevancehealth.com
EHAP_CLIENT_ID=<your id>
EHAP_CLIENT_SECRET=<your secret>
EHAP_MODEL_ID=anthropic:claude-sonnet-4-6
```

Defaults use no AWS (in-memory sessions, local-disk uploads), so nothing else
is needed to run.

### TLS verification for the EHAP gateway (⚠️ open handover item)

Requests to the gateway verify the server's TLS certificate by default (this
is the secure default; earlier revisions disabled verification, which a
security scan correctly flagged). The gateway host presents a
**corporate/internal CA-signed certificate** that is not in the default system
trust store, so out of the box you will hit:

```
SSLError: ... certificate verify failed: self-signed certificate in certificate chain
```

Resolve it with one of these `.env` (or environment) settings:

```
# Preferred — verify against the corporate CA bundle (keeps TLS secure):
EHAP_CA_BUNDLE=/path/to/corporate-root-ca.pem

# Dev/demo escape hatch only — disables verification (insecure, logs a warning).
# Do NOT use for the pilot or production; it re-opens the security finding.
EHAP_TLS_VERIFY=false
```

## Step 3 — Start the backend

```powershell
uv run uvicorn governance_intake.server:app --host 0.0.0.0 --port 8000
```

Leave this terminal running. You should see `Application startup complete`.

## Step 4 — Verify the backend

Open http://localhost:8000/api/health in a browser — you should get a small
JSON payload. The API is up.

## Step 5 — Install the frontend dependencies

Open a **second** PowerShell terminal:

```powershell
cd frontend
npm install
```

`frontend/` ships without `node_modules/` — `npm install` creates them (and
`package-lock.json`); versions are pinned in `package.json`.

**If this fails with a certificate error** (`SELF_SIGNED_CERT_IN_CHAIN` /
`UNABLE_TO_GET_ISSUER_CERT`), point Node at the corporate root CA, then retry:

```powershell
$env:NODE_EXTRA_CA_CERTS = "C:\path\to\corp-root-ca.pem"
npm install
```

(Or use the internal registry: `npm config set registry https://<internal-npm-mirror>`.)

## Step 6 — Start the frontend

```powershell
npm run dev
```

Vite prints `Local: http://localhost:5173/`.

## Step 7 — Open the app

Go to **http://localhost:5173** (not :8000 — that's the API). The dev server
proxies `/api` to the backend, so both terminals must stay running.

### Using it

1. Describe your project in plain language, e.g. *"An AI assistant that
   summarizes Medicare claims for case managers, going to production, uses
   vendor Acme AI, processes PHI, deploys to our Gold cloud tier."*
2. Answer the follow-ups — the right sidebar fills in (Routing Fields, then
   Activated Teams) as triage completes (Phase 1 → Phase 2).
3. Answer the consolidated review questions (Phase 2).
4. When prompted, drag a **`.pptx`** diagram into the Attachments panel.
5. Type "done" — the agent files one governance **ticket** (green panel).

---

# Run on SageMaker

The SageMaker notebook (Amazon Linux) can't reliably build the React app, so
the pattern is: **build the UI on Windows, ship the build output, and let the
backend serve it on a single port.** No Node needed on SageMaker.

## Step 1 — Build the frontend on Windows

On your Windows machine (after `npm install`, Step 5 above):

```powershell
cd frontend
npm run build          # produces frontend/dist
```

## Step 2 — Get the repo (including `frontend/dist`) onto SageMaker

Zip the repo with `frontend/dist` included and upload it to the notebook, or
`git clone` and copy the built `frontend/dist` over. Either way, SageMaker must
have `frontend/dist` present (it will not be rebuilt there).

## Step 3 — Install the backend dependencies (SageMaker terminal)

```bash
pip install uv          # if uv isn't already available
uv sync --all-extras
```

## Step 4 — Configure `.env`

```bash
cp .env.example .env
# edit .env and set EHAP_CLIENT_ID / EHAP_CLIENT_SECRET
```

## Step 5 — Start the backend serving the built UI

Point `INTAKE_UI_DIST` at the build output so one process serves both API and
UI on port 8000:

```bash
export INTAKE_UI_DIST=frontend/dist
uv run uvicorn governance_intake.server:app --host 0.0.0.0 --port 8000
```

## Step 6 — Open it through the notebook proxy

Use the Jupyter proxy path (note the trailing slash):

```
https://<your-notebook-name>.notebook.<region>.sagemaker.aws/proxy/8000/
```

The UI uses relative asset/API paths, so it works behind the `/proxy/8000/`
prefix without a rebuild.

---

# Troubleshooting

| Symptom | Cause / Fix |
|---------|-------------|
| `make: The term 'make' is not recognized` | Windows has no `make`. Use the `uv run ...` commands (see [backend/README.md](backend/README.md)) directly. |
| `SSLError: ... certificate verify failed: self-signed certificate in certificate chain` (calls to the EHAP gateway) | The gateway uses a corporate/internal CA not in the default trust store. Set `EHAP_CA_BUNDLE` to the corporate CA `.pem` (preferred), or `EHAP_TLS_VERIFY=false` for local work only. See "TLS verification for the EHAP gateway" above — obtaining the CA bundle is an open handover item. |

CI is **managed externally** (Terraform Enterprise, VCS-driven off Bitbucket) —
there are intentionally no in-repo CI pipeline files.

---

# Reference

## Project structure

```
governance-intake/
├── backend/
│   ├── src/governance_intake/     # application package
│   │   ├── server.py              # FastAPI app (governance_intake.server:app)
│   │   ├── handler.py             # phase orchestration (routing -> Q&A -> ticket)
│   │   ├── intake_agent.py        # agent factories + prompts + extraction models
│   │   ├── ehap_model.py          # EHAP gateway client (Strands model)
│   │   ├── rule_engine.py         # deterministic team routing
│   │   ├── question_dedup.py      # question consolidation across teams
│   │   ├── form_mapper.py         # fan one answer out to every team's form
│   │   ├── gap_detector.py        # required-question gap detection
│   │   ├── schema_check.py        # routing-field completeness
│   │   ├── session.py             # session store (memory / DynamoDB)
│   │   ├── attachments.py         # attachment storage (local / S3)
│   │   ├── ticket_creator.py      # ticket assembly
│   │   ├── verify.py              # scripted end-to-end verification
│   │   └── data/                  # config: rules, questionnaires, dedup mapping
│   └── tests/                     # unit/ (no LLM/AWS) + integration/ (EHAP)
├── frontend/                      # React + Vite + Tailwind UI
├── infra/terraform/               # NEW resource snippets to merge into TFE repo
├── docs/adr/                      # architecture decision records
└── pyproject.toml  .env.example  .gitignore
```

## How it works

1. **Routing (Phase 1)** — the agent gathers routing fields from conversation;
   `rule_engine` maps them to activated governance teams.
2. **Consolidated Q&A (Phase 2)** — `question_dedup` collapses the activated
   teams' overlapping questions into canonical questions; the agent asks each
   once and `form_mapper` fans the answer out to every team's form.
3. **Attachment** — a solution/data-flow diagram (`.pptx`) is required.
4. **Ticket** — `ticket_creator` assembles one governance ticket; `session`
   persists state.

## Post-dedup experience (form-first)

Alongside the chat flow, `/api/post-dedup/*` serves the form-first
post-activation experience (`postdedup_api.py`): create a session from a
STATE envelope (`state_adapter.py` owns that boundary), render the full
consolidated question set with source badges, run the grounded LLM pre-fill
(`prefill.py` — proposals cite a verbatim quote from what the submitter said
and are re-verified deterministically; nothing commits without an explicit
accept), and submit through the same deterministic completeness gate and
ticket fan-out. In the UI, sessions in Phase 2 get an **"Open full
questionnaire"** button. Design and semantics:
`docs/POST_DEDUP_EXPERIENCE_PLAN.md`; dedup corpus audit: `docs/DEDUP_AUDIT.md`.

## Infrastructure

Managed with **Terraform via self-hosted Terraform Enterprise**
(`cps-terraform.anthem.com`), VCS-driven off the `np01` branch. The customer
repo owns `provider.tf` (Vault auth) and the workspace backend. `infra/terraform/`
here contains only the **new** resources this app adds (a DynamoDB sessions
table and an S3 attachments bucket) as snippets to merge into that repo. See
`infra/terraform/TRANSPLANT.md`.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).
