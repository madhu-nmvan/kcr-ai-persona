# Contributing

## Development setup

```bash
make install          # uv sync --all-extras
cp .env.example .env  # fill in EHAP credentials
```

Optionally install the git hooks locally (they also run in `make hooks`):

```bash
uv run pre-commit install
```

If your environment uses centrally managed git hooks (e.g. git-defender),
skip `pre-commit install` and rely on `make hooks` instead — it runs the same
checks without touching `.git/hooks/`.

## Before you push

Run the quality gate:

```bash
make hooks     # ruff lint + format + mypy
make test      # unit tests
```

`make all` additionally runs the ASH security scan.

## Standards

- **Package manager:** uv. All config in `pyproject.toml`. No `requirements.txt`.
- **Layout:** `src/` layout under `backend/src/governance_intake/`. Tests mirror
  `unit/` and `integration/`.
- **Lint/format:** ruff (line length 120, rules `E,W,F,I,B,S,UP`).
- **Types:** mypy strict on the package.
- **Tests:** pytest. Mark EHAP/external tests with `@pytest.mark.integration`
  so `make test` (which excludes them) stays fast and offline.

## Commit conventions

[Conventional Commits](https://www.conventionalcommits.org/): `type(scope): subject`.

Common types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `ci`, `build`.

- Imperative mood ("add" not "added"), no trailing period, concise subject.
- Keep commits atomic (one logical change each).

## Branching & CI

- Work branches merge into `np01` (the branch the Terraform Enterprise
  workspace is wired to). Merges to `np01` trigger TFE runs for infra.
- CI is managed externally; there are no in-repo pipeline files. Run the
  quality gate locally before pushing.

## Infrastructure changes

Terraform for **new** resources goes in `infra/terraform/` as snippets to be
merged into the customer's TFE-managed repo. Do not add a `provider.tf` or a
backend block here — the customer repo owns those (Vault auth + TFE backend).
See `infra/terraform/TRANSPLANT.md`.
