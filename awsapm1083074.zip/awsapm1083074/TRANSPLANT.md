# Transplanting this repo into `AWSAPM1083074`

This folder is a **staging** copy of the structured repository. The real home
is the customer's Bitbucket repo `AWSAPM1083074` (on the customer machine),
whose existing `.tf` files are the source of truth. Follow these steps there.

## What to bring over

Copy everything from this folder into the root of `AWSAPM1083074`, EXCEPT:

- **Terraform** — do not copy `infra/terraform/` over the customer's `.tf`
  wholesale. Instead follow `infra/terraform/TRANSPLANT.md`: add only
  `intake_sessions.tf` and `intake_attachments.tf` alongside the existing
  `provider.tf` / `dynamodb.tf` / `s3.tf`, and keep the customer's
  `provider.tf` and backend/Vault config.
- **`.gitignore`** — merge entries into the existing `.gitignore` rather than
  replacing it (keep any customer-specific ignores).
- **`README.md`** — merge, don't clobber, if the customer repo already has one.

Everything else drops in cleanly:

```
backend/                 # the governance_intake package + tests
frontend/                # React + Vite UI (run npm install on the target)
pyproject.toml           # uv project config
Makefile
.pre-commit-config.yaml
.env.example
docs/adr/001-project-setup.md
CONTRIBUTING.md
CHANGELOG.md
```

Note: `frontend/` intentionally ships **without** `node_modules/` or a
`package-lock.json`. Run `npm install` in `frontend/` on the target to
generate the lockfile and dependencies (versions are pinned in
`package.json`).

## Layout note

The existing customer `.tf` files sit at the repo root. This repo keeps
Terraform under `infra/terraform/`. Two options:

1. **Keep the customer's flat layout** — put `intake_sessions.tf` /
   `intake_attachments.tf` at the repo root next to the existing `.tf`, and
   don't create `infra/terraform/`. Simplest; no TFE working-directory change.
2. **Move to `infra/terraform/`** — relocate the existing `.tf` there too and
   set the TFE workspace "Terraform Working Directory" to `infra/terraform`.
   Cleaner long-term, but coordinate the workspace setting change.

Pick one before merging; don't split `.tf` across both locations.

## Steps

1. On the customer machine, create a work branch off `np01`.
2. Copy the backend/tooling/docs files in (per "What to bring over").
3. Merge Terraform per `infra/terraform/TRANSPLANT.md`.
4. `make install` then `make hooks` and `make test` to confirm the Python side
   builds and passes locally.
5. Fill in `.env` from `.env.example` (EHAP creds) and `make run` to smoke-test.
6. Commit (Conventional Commits) and open a PR into `np01`. The merge triggers
   the TFE run for the new infra.

## Not included (optional, bring later if needed)

- **Offline data-extraction tools** (`intake-agent/tools/`) — used to
  regenerate the `data/` JSON from source questionnaires; depends on
  openpyxl/python-docx and the source documents. Add under `backend/scripts/`
  if you need to regenerate the rules/questionnaires.
