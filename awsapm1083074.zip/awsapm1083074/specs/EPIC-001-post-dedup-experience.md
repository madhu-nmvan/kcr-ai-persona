# SPEC: Post-Dedup Question Experience (Governance Intake)

> Synthesized retroactively (2026-07-16) from authoritative sources because no
> backlog epic existed when implementation began. Sources, in order of
> authority: the **Thursday stand-up transcript** (ownership split + scope
> decisions), `handoff.md`, `docs/POST_DEDUP_EXPERIENCE_PLAN.md`,
> `docs/DEDUP_AUDIT.md`, and the external companion artifact spec
> (https://claude.ai/code/artifact/c148cb82-2a68-4b8c-8e18-9603d0f39b3a).
> The transcript is the source of truth for **scope and phase boundary**; the
> artifact is the source of truth for the STATE contract shape.

## 1. Epic Reference

- **Epic/Story ID**: EPIC-001 (synthesized; no backlog item existed at implementation time)
- **Title**: Post-Dedup Question Experience — Jaz's lane
- **Backlog link**: none (gap — see R0 and Open Question #1)
- **Stories covered**:
  - STORY-001: Present the deduplicated, activated-team question set as a form (not a chatbot)
  - STORY-002: Per-question source-provenance badges (visual proof of dedup)
  - STORY-003: Deterministic completeness → Submit → existing ticket fan-out
  - STORY-004: Before/after stats strip (raw → consolidated → answered)
  - STORY-005 (Phase B, deferred): LLM prefill of answers from what the user already said
  - STORY-006 (Phase B, deferred): Question ordering / coverage intelligence
  - STORY-007 (Phase B, deferred): QA/counselor advisory final-pass agent
- **Original acceptance criteria** (from the transcript, verbatim intent):
  - AC1: "FOR DEMO: just show all of the questions after dedup for now." (Jeremy; Jaz: "okay, yeah, I got it.")
  - AC2: Present as a **form**, not a chatbot — each question carries a source/symbol you can highlight to see "exactly what questions from what teams this question is answering."
  - AC3: "The question order/coverage intelligence **can come later**." (Phase B is explicitly deferred.)
  - AC4: Assume **three inputs already exist**: activated teams (deterministically determined), the chat transcript, and the trigger-question answers. One of those tells you which questions to show.
  - AC5: Do **not** re-run dedup — the corpus is already deduplicated; grab the questions for the activated teams.
  - AC6: Do not touch the ingestion/trigger flow (Dan's lane) or the dedup corpus (Jeremy's lane).

## 2. Overview

When a governance-intake submitter has finished the pre-activation ingestion,
the system has (a) deterministically activated the governance teams that must
review the project, (b) a chat transcript, and (c) the answers to the trigger
questions. This epic delivers the **post-activation experience**: it takes the
already-deduplicated question set for the activated teams and presents it as a
single consolidated **form** — each question annotated with the team
question-ids it satisfies (the visual proof that 30 overlapping questionnaires
collapsed into one). The user answers once; a deterministic completeness check
gates Submit; Submit fans answers back out to every team's form via the
existing ticket path. The business value is the Friday VP demo's headline:
"before = duplicate questions across 30 teams; after = one clean, deduped,
partly-answered form."

## 3. Requirements

Requirements are tagged **[A]** (Phase A — demo scope, agreed) or **[B]**
(Phase B — deferred by the transcript, "can come later"). The tag is the
contract the design-review measures against.

- **R0** *(process)*: A spec exists in `specs/` before implementation is
  considered spec-covered. Source: CLAUDE.md ("The spec is ALWAYS the source of
  truth; read it first"). **Status: retroactively satisfied by this file.**
- **R1 [A]**: Given a STATE envelope carrying the three inputs, produce the
  consolidated pending-question set for exactly the activated teams, using the
  existing dedup mapping — no re-dedup. Source: AC1, AC4, AC5.
- **R2 [A]**: Each pending question exposes its `sources` (`[{team, question_id}]`,
  current max fan-out 4); the UI renders these as badges with team/question-id
  on hover. Source: AC2.
- **R3 [A]**: The experience is a form, rendered beside (not replacing) the
  existing chat pane, which becomes an assist pane. Source: AC2, transcript
  ("form-first UX; chat is an assist pane").
- **R4 [A]**: Completeness is a **pure deterministic** check (all canonicals
  answered AND no required gaps); Submit is gated by it and, when blocked,
  returns the gap list and creates nothing. Source: AC-implied, handoff §3,
  lessons.md.
- **R5 [A]**: On a passing completeness check, Submit reuses the existing
  `create_ticket` fan-out — no new ticketing path. Source: AC6, handoff §6.
- **R6 [A]**: A stats strip reports raw → consolidated → answered counts.
  Source: transcript (Gan's "before/after duplicate" headline), handoff §6.
- **R7 [A]**: The experience tolerates contentless activated teams (e.g.
  Clinical Partnership Review activates with zero questions) without error.
  Source: handoff §7.
- **R8 [A]**: A single adapter module (`state_adapter`) is the only code that
  translates between the external STATE envelope and internal session names;
  Jeremy predicted an input mismatch, so the boundary must be one seam.
  Source: transcript ("be very prepared for an input mismatch"), handoff §5.
- **R9 [B]**: LLM prefill proposes answers from the transcript/trigger fields,
  each proposal grounded (its quote must appear in the claimed source) and
  **never silently committed** (staged as `proposed`, requires explicit accept).
  Source: transcript (Jeremy: "feed them into the LLM first with whatever the
  user has said already and pre-populate whatever we can") — endorsed but
  sequenced after the demo form. Marked [B] because it depends on Jeremy's
  extraction prompt/contract, which does not yet exist.
- **R10 [B]**: Question ordering / coverage intelligence — order questions so
  earlier answers imply later ones, minimizing questions asked. Source: AC3,
  transcript (Jeremy: "that's the second phase… order questions so they flow…
  can come later").
- **R11 [B]**: Optional QA/counselor final-pass agent returns ≤N advisory
  clarifications; never blocks Submit. Source: Jaz's meeting notes, transcript
  ("this QA/counselor agent could be a valuable last step").

## 4. Technical Design

### High-Level Approach

Everything integrates behind the spec-§5 STATE envelope through one adapter.
Routing/dedup stay deterministic and config-driven; the LLM is confined to
prefill and QA-review, both behind a provider seam and both grounded/advisory.
The frontend is a new `postdedup/` feature tree beside the legacy chat `App`.

### Files and Modules Affected

| File/Module | Change Type | Phase | Description |
|-------------|-------------|-------|-------------|
| `backend/src/governance_intake/state_adapter.py` | New | A | STATE ↔ session translation (the single seam, R8) |
| `backend/src/governance_intake/postdedup.py` | New | A | Service layer: begin_session, record_answers, completeness, submit, stats (R1,R4,R5,R6,R7) |
| `backend/src/governance_intake/postdedup_api.py` | New | A | FastAPI router (R1–R6) |
| `frontend/src/postdedup/PostDedupView.jsx` | New | A | Grouped form + source badges + stats + submit (R2,R3,R6) |
| `frontend/src/postdedup/api.js` | New | A | API client (project convention: no inline fetch) |
| `backend/src/governance_intake/prefill.py` | New | **B** | Grounded LLM prefill (R9) |
| `backend/src/governance_intake/question_order.py` | New | **B** | Deterministic ordering + fill-in loop (R10) |
| `backend/src/governance_intake/qa_review.py` | New | **B** | Advisory final-pass agent (R11) |
| `backend/src/governance_intake/llm_provider.py` | New | **B** | Provider seam — **overlaps Jeremy's EHAP-contract lane** (see Risk) |
| `ehap-mock/`, `test_ehap_mock_wire.py` | New | **B** | EHAP wire mock — **overlaps Jeremy's lane** (see Risk) |
| `backend/scripts/audit_dedup.py`, `docs/DEDUP_AUDIT.md` | New | pre-work | Corpus/dedup audit (handoff step 2) |

### Data Model Changes

No schema migrations. Adds a session in `asking_questions` state seeded from
STATE; introduces `q["prefill"]` (`status: proposed`) as staged, non-committing
proposals (Phase B). The known naming mismatch (`text` vs `canonical_question`)
is owned entirely by the adapter.

### API Changes

New `POST /api/post-dedup/sessions`, `GET .../sessions/{id}`, `POST .../answers`,
`POST .../submit`, `GET .../stats` **[A]**; `POST .../prefill`,
`.../prefill/decisions`, `.../qa-review` **[B]**; `GET .../sessions/{id}/envelope`
**[A]** — emits Jeremy's `FormFillerEnvelope` for round-tripping through
`/api/formfiller/fill` (see ADR-004).

**Contract update (2026-07-17):** the external contract is now Jeremy's
`FormFillerEnvelope` (`{triggers, governance}`, PR #13), not the placeholder.
`state_adapter` ingests and emits it; the placeholder shape is retained
additively. See ADR-004.

### Key Architectural Decisions

| Decision | Rationale | Alternatives Considered |
|----------|-----------|-------------------------|
| One adapter seam for the STATE contract | Jeremy predicted an input mismatch; localize churn | Spread parsing across modules (rejected) |
| Prefill grounded + never auto-committed | Auditable governance; lessons.md | Trust LLM answers (rejected) |
| Reuse existing `create_ticket` | AC6 — don't rebuild ticketing | New submit path (rejected) |
| Build Phase B now (prefill/order/QA) | handoff §6 "production-final, no demo compromise" | **Defer per transcript AC3 (this is the contested decision the design-review must adjudicate)** |

## 5. Bolts (Decomposed Units of Work)

### Bolt A: STATE adapter + service layer + API (Phase A core)
- **Requirements**: R1, R4, R5, R6, R7, R8
- **Files**: `state_adapter.py`, `postdedup.py`, `postdedup_api.py` + their unit tests
- **Depends on**: none
- **Inputs**: STATE envelope (three inputs), existing dedup mapping + `IntakeData`
- **Outputs**: consolidated question set, completeness flag, submit fan-out, stats
- **Completion criteria**: pending set = activated teams' canonicals; completeness pure; submit-with-gaps creates nothing; contentless team tolerated

### Bolt B: Form UI + source badges + stats (Phase A UI)
- **Requirements**: R2, R3, R6
- **Files**: `frontend/src/postdedup/*`, `App.jsx` mount point
- **Depends on**: Bolt A (API)
- **Inputs**: session envelope + stats from Bolt A
- **Outputs**: grouped form beside chat pane, badges, stats strip, submit button
- **Completion criteria**: badges show team/question-id; form renders; submit reflects completeness flag

### Bolt C: Grounded prefill (Phase B — deferred)
- **Requirements**: R9
- **Files**: `prefill.py`, `llm_provider.py` + tests
- **Depends on**: Bolt A, **Jeremy's EHAP contract + extraction prompt (not yet delivered)**
- **Completion criteria**: ungrounded proposals dropped + counted; proposals never satisfy completeness

### Bolt D: Ordering + QA (Phase B — deferred)
- **Requirements**: R10, R11
- **Files**: `question_order.py`, `qa_review.py` + tests
- **Depends on**: Bolt A, Bolt C
- **Completion criteria**: deterministic order; QA returns ≤N advisories; never blocks submit

## 6. Acceptance Tests

| Requirement | Test | Happy Path | Error Paths | Edge Cases |
|-------------|------|------------|-------------|------------|
| R1 | `test_postdedup` begin_session | activated teams → their canonicals | unknown team surfaced | contentless team |
| R2 | badge render | sources → badges | missing sources | fan-out 4 |
| R4 | completeness pure | all answered → true | gap → false | cleared answer reopens |
| R5 | submit fan-out | pass → ticket | gaps → no ticket | — |
| R6 | stats | raw/consolidated/answered | — | zero-question team |
| R7 | contentless team | flows through | — | Clinical Partnership Review |
| R8 | adapter tolerance | dict/str teams, agent/assistant roles | missing sections | naming mismatch |
| R9 | prefill grounding | grounded staged | ungrounded dropped | empty answer rejected |
| R10 | ordering | fan-out order stable | — | corpus-order tiebreak |
| R11 | qa_review | ≤N concerns | never blocks | no answered questions |

## 7. Completion Criteria

### Per Bolt
- Bolt A: R1/R4/R5/R6/R7/R8 tests pass both ways; `make test` green
- Bolt B: badges + form + stats render; submit gated by completeness
- Bolt C/D: Phase-B tests pass **and must not run/fail under `INTAKE_SKIP_LLM=1`** (offline convention)

### Overall
- [ ] All Phase-A Bolt criteria met
- [x] `make test` green (140 passing) — **but see Risk: 9 tests fail if `INTAKE_SKIP_LLM=1`**
- [ ] No regressions in existing suite
- [ ] Code reviewed and approved
- [x] Documentation updated (plan, audit, README)

## 8. Open Questions

| # | Question | Owner | Deadline | Resolution |
|---|----------|-------|----------|------------|
| 1 | No backlog epic/story exists; should one be created to back this spec? | Jaz | before merge | Pending |
| 2 | Real EHAP data contract shape (Jeremy "attacking it first") | Jeremy | pre-integration | **Resolved** — `FormFillerEnvelope` (#13); adapter ingests/emits it (ADR-004) |
| 3 | Does Phase B belong in this PR at all, given AC3 defers it? | Jaz/Jeremy | design-review | **Resolved** — keep it (owner directive); off demo path, foundation for the end-goal (ADR-003 Resolution) |
| 4 | `review_phase` 1 vs 2 semantics | Gan | — | Pending |
| 5 | LEGALDGP over-extraction (#6–#9) — corpus owner | Jeremy | — | Filed |

## 9. Out of Scope

- Ingestion / trigger-question UI (Dan's lane) — AC6.
- Re-running or changing the dedup corpus/mapping (Jeremy's lane) — AC5, AC6.
- The real EHAP data contract (Jeremy's lane) — the provider seam/mock built
  here is **arguably out of this lane** and flagged as a risk.

## 10. Risks and Mitigations

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Phase B built despite AC3 deferral → wasted effort if scope reverts | High | Med | design-review to adjudicate; keep Phase B behind flag/module boundary so it can be excised cleanly |
| `llm_provider`/`ehap-mock` collide with Jeremy's EHAP contract | Med | Med | Confine to prefill/QA; adapter absorbs shape; be ready to delete on his contract landing |
| Elaborate 1,600-item UI over a corpus that is ~17% heading-noise | Med | Med | audit filed (#6–#9); UI renders whatever exists, blocks on nothing — acceptable but low ROI until cleanup |
| 9 tests fail under `INTAKE_SKIP_LLM=1` (project's own offline flag) | High | Low | make Phase-B tests inject fakes without the env short-circuit, or skip explicitly |
| Spec written after code (R0) | Realized | Low | this file; create backing backlog item (OQ#1) |
