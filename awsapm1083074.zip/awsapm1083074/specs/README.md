# Specs

One `SPEC.md`-style file per epic, named `EPIC-<NNN>-<slug>.md`. Format is
the 10-section epic-to-spec template: Epic Reference, Overview, Requirements
(tagged by phase), Technical Design, Bolts (decomposed units of work),
Acceptance Tests, Completion Criteria, Open Questions, Out of Scope, Risks
and Mitigations.

`EPIC-001-post-dedup-experience.md` is the current example — written
retroactively (implementation started before a backlog epic existed), which
is itself flagged inside as requirement **R0**: *"A spec exists in `specs/`
before implementation is considered spec-covered."* New work should have its
spec land here **before** the build starts, not after.

Distinct from `docs/`: `docs/` holds contracts, plans, and audits (reference
material describing how something works or what was found); `specs/` holds
the requirements-and-acceptance-criteria contract a piece of work is being
built and reviewed against.
