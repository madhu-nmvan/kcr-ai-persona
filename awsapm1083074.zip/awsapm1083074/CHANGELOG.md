# Changelog

All notable changes to this project are documented here. The format is based
on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial structured repository: `src/` layout under
  `backend/src/governance_intake/`, uv-managed `pyproject.toml`, `Makefile`,
  pre-commit hooks, ruff + mypy config, pytest scaffolding.
- Backend intake agent: conversational routing, deterministic team routing,
  question deduplication + fan-out, gap detection, attachment handling, and
  ticket assembly, backed by the EHAP LLM gateway.
- Pure-function unit tests covering the deterministic pipeline.
- `infra/terraform/` new-resource snippets (DynamoDB sessions table, S3
  attachments bucket) plus `TRANSPLANT.md` for merging into the customer's
  Terraform Enterprise repo.
- ADR 001 documenting the project structure and environment decisions.

### Notes
- Migrated from the `intake-agent` prototype. Flat `src/` became the
  `governance_intake` package; `requirements.txt` dependencies moved into
  `pyproject.toml`; config data is bundled under the package.
- No in-repo CI pipelines: CI/CD is managed externally (Terraform Enterprise,
  VCS-driven off Bitbucket `np01`).
