# Session Tasks

Realign post-dedup experience to Jeremy's #13 `FormFillerEnvelope` contract
(demo). Additive — no restart, no deletes (owner directive: respect the work).

- [x] `state_adapter.py`: parse `FormFillerEnvelope` on input (additive; placeholder path kept)
- [x] `state_adapter.py`: `envelope_from_session` emitting `{triggers, governance}`
- [x] `postdedup.begin_session`: seed prior governance answers from the envelope
- [x] `postdedup_api.py`: `GET /sessions/{id}/envelope` round-trip endpoint
- [x] `frontend/postdedup/sampleState.js`: real FormFillerEnvelope sample
- [x] Tests: adapter + API both-ways for the envelope path (149 green)
- [x] Docs: spec §4/§8, ADR-003 resolution, ADR-004, DEMO_PLAN, lessons
- [x] Verify: `make test` green + offline end-to-end round-trip
- [ ] Drive UI in-browser against the new sample envelope (needs `make run` + vite)
- [ ] (Jeremy) reconcile #13↔#16; decide demo UI (Jaz JSX vs #16 TS)
