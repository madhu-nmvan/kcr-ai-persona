# Lessons Learned

Persistent lessons for this project. Review at the start of every session.
After any user correction or a mistake worth not repeating, add an entry.

## Format

```
### <short title>
- **Context:** when this comes up
- **Lesson:** what to do (or avoid)
- **Why:** the reasoning / what went wrong
```

## Lessons

### Keep routing and dedup deterministic
- **Context:** implementing or changing intake logic
- **Lesson:** routing (rule_engine) and question dedup stay config-driven and pure; the LLM is only for conversation, prefill, and QA-review.
- **Why:** governance decisions must be auditable and reproducible, not model-dependent.

### Pre-existing strict-mypy debt
- **Context:** running `make type-check` or `make hooks`
- **Lesson:** the package is NOT currently mypy-clean (~44 strict errors, mostly `server.py` / `verify.py` missing return annotations). Don't treat these as regressions you introduced, and don't scope-creep into fixing them. `make test` (unit) is green.
- **Why:** the quality-gate hooks only run ruff (per-edit) + `make test` (on stop) so pre-existing type debt doesn't block every session.

### Build to the team-agreed scope and the real contract — check teammates' PRs first
- **Context:** starting a lane that has upstream/sibling dependencies (a shared data contract, another dev's UI)
- **Lesson:** the stand-up transcript is the scope source of truth. It scoped the demo to "just show the deduped questions" and deferred ordering/prefill intelligence ("can come later"). A personal "production-final, no demo compromise" directive over-built ~50% of the branch (Phase B) and built against a *placeholder* contract while a teammate (Jeremy #13) shipped the real `FormFillerEnvelope`. Before building: read open PRs (`gh pr list/diff`) to find the real contract and avoid duplicating a teammate's work.
- **Why:** duplicated the fill engine (Jaz `prefill.py` vs Jeremy `form_filler_agent.py`), built a placeholder envelope superseded by his real one, and collided with Dan's #16 TS UI. Re-aligning to the real contract at the adapter boundary (additive, keep the work) was the fix — not a rewrite.
