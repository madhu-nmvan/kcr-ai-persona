# PCSR Security Review — Elevance AI Governance Hub

## Repo: elevance-health-ai-gov-hub-main (repo-internal / FDE deliverable)

**Ticket**: N/A — documenting for FDE engagement record  
**Repo**: elevance-health-ai-gov-hub-main (internal, not published)  
**Review Type**: repo-internal (FDE deliverable, not going public)  
**Reviewer**: Vanessa Jacobs (Security Guardian)  
**Tech Lead**: Hayley Park (parhyunj)  
**Date**: July 24, 2026  

---

## Context

This is an FDE (Forward Deployed Engineer) engagement deliverable for Elevance Health. The customer decided to proceed with another vendor for production deployment. This PCSR documents what security controls AWS would have required if we were deploying this system to production. The repo remains internal to AWS — no public or reusable-asset publication is planned.

The assessment is informed by the full Pre-Deployment Security Assessment (33 findings: 4 Critical, 9 High, 14 Medium, 6 Low) completed on the same date, with tech lead (Hayley Park) review of H5 (LLM trust-boundary) and ISO 42005 items.

---

## Summary

The AI Governance Hub is a conversational intake application (Python 3.12/FastAPI + React/Vite + Terraform/AWS) that routes AI projects to governance review teams via LLM-assisted conversation (Claude via LLM Gateway). Sessions stored in DynamoDB, attachments in S3. Data classified as PHI-adjacent (tagged compliance = "PHI" in Terraform).

The repo is well-structured, properly attributed, and includes comprehensive documentation. It is explicitly a demo/pilot build (demo_mode=True hard-coded) with production controls intentionally deferred.

---

## Findings

### IP Headers — PASS

All 80+ code files (Python and TypeScript) carry the standard AWS copyright header:
```
# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content
# under the AWS Enterprise Agreement or AWS Customer Agreement (as applicable)
# and is provided under the AWS Intellectual Property License.
```
Verified via ripgrep across all .py, .ts, .tsx, .js files. Complete coverage.

### LICENSE — PASS

LICENSE file present at repo root. Standard AWS Intellectual Property License (Enterprise Agreement / Customer Agreement variant) with appropriate disclaimers and GenAIIC reusable asset permissions clause.

### NOTICE File — PASS

NOTICE file present with explicit GenAIIC reusable assets program disclaimer. States content is "for informational and demonstration purposes only."

### README Disclaimer — PASS (fix applied)

"Not for production" disclaimer added to README.md after the title, referencing MVP_SECURITY_HARDENING.docx and the Pre-Deployment FDE Security Assessment. Applied July 24, 2026.

### Sensitive Data / Secrets — PASS

No hardcoded AWS access keys, private keys, passwords, customer PII, or account IDs in code. Secrets referenced via environment variables. Credential placeholders use `[REDACTED_PASSWORD]`. Clean.

### Customer Infrastructure References — ADVISORY (acceptable for internal FDE)

Terraform files contain hardcoded Elevance infrastructure IDs:
- VPC: `vpc-093a6c8844c18280d`
- Subnets: `subnet-0cc25fcafc0aa60d9`, `subnet-0083f9e27f6ef667f`
- Security Group: `sg-01a49d1463918fc6f`

Acceptable for internal FDE deliverable (customer-provided). Would block if scope changed to public/RA.

### AI Model/Tool References — PASS (Reference only)

- Anthropic Claude: Runtime API via LLM Gateway. No model weights bundled.
- strands-agents: AWS-native SDK. No concern.
- fastembed: Runtime dependency. No bundled model artifacts.

Classification: Reference only. No distribution. No policy action.

### Security Scan Results — N/A

ASH/DSR not available in session. Repo has ruff + bandit + mypy + pre-commit configured as static analysis pipeline. Full security assessment (33 findings) covers the scope ASH/DSR would identify.

Manual scan commands for record:
```
ash --source-dir /path/to/elevance-health-ai-gov-hub-main
dsr-cli scan --source /path/to/elevance-health-ai-gov-hub-main
```

### Code Quality / Security Posture — ADVISORY (production gaps documented)

Full Pre-Deployment Security Assessment identified production blockers (authentication, authorization, rate limiting, prompt injection hardening, LLM trust-boundary). All documented in accompanying security deliverables with 23-item remediation roadmap (P0/P1/P2).

Tech lead accepted mitigations:
- H5 (field overwrite/misrouting): Compensating control = full-submission visibility for reviewers independent of routing. Formalized as design requirement for review phase.
- ISO 42005: Impact assessment recommendation accepted. Intake payload is project metadata, not PHI directly; assessment should center misrouting harm + downstream PHI consequence.

---

## Fixes Applied

| Fix | File | Status |
|-----|------|--------|
| README "Not for Production" disclaimer | README.md | Applied |

---

## Status: CONDITIONAL APPROVAL (Internal FDE Deliverable)

**Approved for**: Internal FDE engagement record. Handover to customer/next vendor with accompanying security documentation.

**Conditions**:
1. Accompanying security documentation ships with the repo (Pre-Deployment FDE Security Assessment + MVP_SECURITY_HARDENING.docx)
2. If scope changes to public/RA: must parameterize infra IDs, run ASH/DSR, verify dependency licenses, generate SBOM
3. Not approved for production deployment, public publication, or reusable asset classification in current state

---

Security Guardian conditionally approved for internal FDE engagement record.

-- Vanessa Jacobs, Security Guardian  
   July 24, 2026
