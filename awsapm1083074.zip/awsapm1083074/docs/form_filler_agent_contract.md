# FormFillerAgent — data contract

Status: **draft, not yet an ADR**. Lives here (not `docs/adr/`) because it's still
open for revision once Gan's EHAP input contract is confirmed (see Jaz's
"Demo Plan & Ownership Spec", §8, open item "EHAP input contract"). Once
decided, promote the relevant parts into `docs/adr/`.

## Why this shape

Source: Jaz's "Demo Plan & Ownership Spec — Deduplicated Question Experience"
(§5 Data contract) plus a design discussion with Flare. Two premises this
contract depends on, both verified against the current `np01_rnp` code before
committing to this shape:

- **Team activation is monotonic** — once `rule_engine.evaluate_rules()`
  activates a team, no later answer de-activates it. Verified: all 28 current
  rules use only monotonic operators (`equals`, `in`, `contains`, `any_of`,
  `truthy`, `all`, `any`, `at_least`); the DSL's `not` operator exists but is
  unused. **This is a property of the current rule set, not an engine
  invariant** — if a future rule uses `not` or an exact/upper-bound operator,
  monotonicity breaks. Any PR adding a new operator or a rule using `not`
  must re-verify this before the "show governance questions before all
  trigger fields are answered" behavior is trusted.
- **Triggers and governance questions are already distinct shapes** in the
  codebase (`RoutingFields` Pydantic model vs. `question_dedup`'s canonical
  dicts) — this contract's two-collection split matches the grain of the
  existing code, it isn't a new abstraction on top of it.

## Envelope

The FormFillerAgent is a pure function: `(FormFillerEnvelope) -> FormFillerEnvelope`.
Same shape in and out — the agent receives whatever's been filled in so far
(by a human or a prior agent call) and returns the same envelope with any
newly-fillable blanks completed.

```
FormFillerEnvelope
├── triggers:   list[TriggerField]       # fixed ~40 items, one per RoutingFields field, present from turn 1
└── governance: list[GovernanceQuestion] # grows as teams activate; [] until the first team activates
```

### Base fields (shared by both item types)

| field        | type                              | meaning |
|--------------|------------------------------------|---------|
| `id`         | `str`                              | trigger: the `RoutingFields` attribute name (e.g. `involves_ai_ml_llm`). governance: `canonical_id` (e.g. `DEDUP.AI_SOLUTION_BE`). |
| `text`       | `str`                              | the question text shown to the user. |
| `value`      | `bool \| str \| list[str] \| None` | `None` = unanswered. Type constrained per-field by `intake_schema.json` (triggers) or free text (governance) — this envelope doesn't re-enforce that, `schema_check.py` / existing validation still owns it. |
| `origin`     | `"user" \| "agent" \| None`        | `None` iff `value is None`. Who supplied the current value. |
| `confidence` | `int \| None` (0–5)                | Set only when `origin == "agent"`. `None` for user-provided or blank items. |

### `GovernanceQuestion` adds

| field     | type                              | meaning |
|-----------|------------------------------------|---------|
| `sources` | `list[{team: str, question_id: str}]` | passthrough, unchanged from today's `question_dedup.build_pending_questions` output — which team questions this canonical answers. **Not** related to `origin` above; don't confuse "which team asked this" with "who answered this."|

Note: today's canonical shape also carries an `answered: bool` flag alongside
`answer`. This envelope drops it — `value is not None` is equivalent and
having two sources of truth for the same fact is how `answered=True,
answer=None` bugs happen. The integration boundary code (wherever we
convert `question_dedup`'s current output into this envelope) is responsible
for this reconciliation; don't assume the field names already match 1:1 —
verify against `question_dedup.py`'s actual current output before writing
the adapter (confirmed during investigation: current code uses
`canonical_question`, not `text`, and does carry the redundant `answered`
flag — this contract intentionally renames/drops those at the boundary, the
adapter is not a no-op passthrough).

## The one invariant that matters

**The agent may only set `value` on items where `value` is currently `None`.
Any item with a non-`None` value in the input MUST come back byte-identical
in the output.** The agent never edits or overwrites an existing answer,
regardless of that answer's `origin`. This is what makes the round-trip
safe to call repeatedly as more of the form fills in, and it's the single
thing the sanity-integration test must assert.

## Confidence, and the "highly confident" instruction

Instruction to the model (paraphrased): *"If you are highly confident an
answer to a blank question is already present in the payload (chat
transcript / already-answered fields), fill it in."* Two decisions on top of
that instruction, both borrowed from a working pattern already in
`~/Projects/Personal/ei/` (`human-extraction.ts:367-371`: integer confidence
0–5, hard skip if `<= 2`):

1. **Confidence is an integer 0–5, not a bare boolean self-report.** A
   discrete score is calibratable (we can look at outcomes and move the
   threshold) in a way "the model said it was confident" isn't.
2. **The agent applies its own threshold internally and only fills when it
   clears the bar** — it must leave `value: None` rather than fill a
   low-confidence guess. But when it *does* fill, it still reports the raw
   score (not just a boolean "was confident enough"), so we have calibration
   data and can tune the bar later without re-running anything. This also
   satisfies Jaz's spec requirement that pre-filled answers carry visible
   provenance and are never silently committed (§4 Phase A, item 4).

## Explicitly out of scope for this contract / this pass

- Live EHAP wiring. No `.env` / EHAP credentials exist in this dev
  environment as of this doc — confirmed by checking for `awsapm1083074/.env`
  before writing this. The sanity integration must use a stubbed/fake model
  call behind a swappable interface, not a real EHAP request.
- Embeddings-based fuzzy matching (the tactic `question_dedup` borrowed from
  `ei`'s entity-dedup). Doesn't apply here — `canonical_id` matching is
  already deterministic; there's no "which existing item does this loosely
  match" problem in fill-in, only "is this specific item still blank."
- Removing the Phase 1 → Phase 2 gate in `handler.py` itself. That's a
  follow-on change once this contract is validated, not part of this pass.
