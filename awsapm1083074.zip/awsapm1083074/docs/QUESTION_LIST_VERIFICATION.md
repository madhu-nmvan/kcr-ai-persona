# Question-List Verification — independent re-ingest of the docx + xlsx

Compiled 2026-07-15. An independent verification pass that re-parsed both
source documents from scratch (`Enhanced ELV Gov_Requirements_AI PRODUCTION.docx`
via `word/document.xml`; `Gov Team Reqs by Service Catalog Types.xlsx` via
openpyxl) and cross-checked them against this branch — including the
live-form second pass (`govhub_catalog_fields.json`, commits `95a108d`–`ad09f13`).

Companion to `TRIGGER_RULES_INTEGRATION.md` (which records what was changed and
why) and `DATA_GAPS.md` (source-availability gaps). This doc records what an
outside re-ingest confirms is **correct**, and the three things still **open**.

## Confirmed correct on this branch

The re-parse agrees with the work already merged here:

- The docx coded-ID extraction is accurate — an independent census of the docx
  found exactly the 33 IDs already in `coverage_report.json`; no miss, no phantom.
- **AI Program Office** gating on `ai_ml_llm_business_use_case_fit` matches the
  docx trigger text (`document.xml` paras 274/276: *"…AND Is this the right use
  of AI for the Business Use case"*). The retired `business_use_case` had no
  source in either the docx or the live form.
- **Enterprise Architecture** → `new_altered_business_proccess` (GI.16) is
  correct; it had been a copy of EDA ARB's D.1/D.4 conditions.
- **DUE** `within_data_use_release_policy == false` matches D.8 (*"compliance? =
  NO"*).
- Removing the `matches` operator (a misread of GI.1's own prompt wording) and
  the four field-type corrections (bool/array/enum vs the real widgets) all
  check out against `govhub_catalog_fields.json`.

## Open item 1 — 13 of 30 teams have rules; 17 are unroutable

`trigger_rules.json` defines **13** teams. The docx "Governance Teams Trigger
Logic" section defines trigger conditions for **30**. The 17 without a rule:
Anthem FEP, Clinical Partnership Review, Compliance-Technology, Corporate
Communications, EDOM, ESG, FGS Home Office, Legal-Data Gov & Privacy, Legal-IP,
Legal-Tech-Novel/High-Risk, Legal-Tech-Commercialization, NGS, OCCO, OAGC,
On-Prem/Private Hosting, PCI, WellPoint Federal.

This is a **rules gap, not a data gap.** The gating fields for these teams exist
in *both* `intake_schema.json` (currently `required:false`) *and* the live form.
Verified mappings:

| Missing team | docx trigger | Field (in schema + live form) |
|---|---|---|
| EDOM | PI.4 OR PI.11 OR PI.12 OR MPI.1 OR MPI.13 OR MPI.18 | `vendor_data_access`, `involves_contacting_delegates_vendors_behalf_EH`, `risk_of_heath_care_fraud_waste_abuse`, `impacts_members_providers`, `violates_CMS_state_program_requirements`, `involves_digital_health_member_outcomes` |
| Clinical Partnership Review | PI.8 | `use_of_clinical_data` |
| Compliance-Technology | any TWO of GI.13 / PI.1 / D.3 / D.9 / AI.1 / 2× NEW | `regulatory_reputational_risks`, `changes_regulated_functions`, `potential_for_compliance_issue` (+ existing) — needs a **count/threshold** operator |
| Corporate Communications | GI.1=Prod AND (MPI.4 OR MPI.5) | `stakeholder_value`, `abrasive_to_providers_customers_members` |
| Legal - Data Gov & Privacy | D.6 OR D.9 | `sending_receiving_protected_information`, `PHI_PI_PFI_use` |
| Legal - IP | GI.9 OR GI.10 | `manners_of_use`, `new_novel_PI_use` |
| Legal-Tech-Novel/High-Risk | GI.11 OR GI.12 OR GI.16 | `new_novel_technology`, `high_risk_use_potential`, `new_or_different_deployment_type`, `new_altered_business_proccess` |
| Legal-Tech-Commercialization | GI.9 | `manners_of_use` (questionnaire is TBD in docx) |
| OCCO | GI.1=Prod AND MPI.1 AND MPI.9 | `impacts_members_providers`, `consumer_impacts` |
| On-Prem/Private Hosting | GI.1=Prod AND D.3∈{Cloud Instance, Kyndryl} | `target_deployment_hosting`, `level_of_development` |
| PCI | D.5 | `use_of_payment_information_data` |
| ESG | new-software / gov-request-type / unapproved-software / vendor-service | `new_software`, `newly_deployed_software`, `what_type_technology_gov_request`, `use_of_previously_unapproved_software`, `vendor_provided_service` |
| Anthem FEP / WellPoint Federal | GI.1=Prod AND LOB.1=FEP / WellPoint | `deployment_line_of_business` |
| NGS / FGS Home Office | GI.1=Prod AND LOB.1=NGS / FGS | `lines_of_business_for_deployment` (⚠ `deployment_line_of_business` enum has no NGS/FGS) |
| OAGC | offshore-resource usage | **no field exists** — blocked, needs a new offshore field |

16 of the 17 are addable today with existing fields; only **OAGC** lacks a
schema field. This directly answers the open question in
`TRIGGER_RULES_INTEGRATION.md` §2/§5.4 ("are the 23 relaxed fields deep-dive or
routing?"): per the docx, they are **routing inputs for teams that don't have a
rule yet** — not team-specific deep-dive questions.

## Open item 2 — the five "absent" coded IDs are not one bucket

`TRIGGER_RULES_INTEGRATION.md` §5.5 lists `GI.15, MPI.13, MPI.18, PI.11, PI.12`
as absent from the live GovHub form, with an open question on where they live
(re-verified here: none of the five appears in `govhub_catalog_fields.json`).
The docx resolves four of them:

- **MPI.13, MPI.18, PI.11, PI.12 are EDOM's complete trigger set**
  (`extracted_questions/edom/questions.txt`). EDOM's questionnaire is a separate
  *"Pre-delegation checklist – Nintex Forms for SharePoint Lists"* — which is
  why they are not on the main GovHub catalog item. The action is to add an
  EDOM rule (see item 1), not to chase these across GovHub catalog items.
- **GI.15** is the only genuine unknown — it appears nowhere in the docx, the
  xlsx, or the live form. It exists only as a numbering-gap inference in
  `DATA_GAPS.md` §1. Escalate GI.15 alone to [Elevance].

## Open item 3 — xlsx per-team questionnaires still un-ingested

The live-form pass validated *routing fields*. The Tier-2 questionnaire content
in the xlsx per-team tabs is still not reconciled into `questionnaires.json`,
which is docx-only and sparse. Magnitude of the gap (xlsx AI-Production question
count vs `questionnaires.json`):

| Team | questionnaires.json | xlsx tab |
|---|---|---|
| Privacy | 0 | 36 |
| ESG | 0 | 148 |
| RAI | 0 | 73 |
| OCCO | 3 | 53 |
| Security-VSRM | 0 | 47 |
| On-Prem/Private Hosting | 0 | 36 |
| Legal - Data Gov & Privacy | 0 | 805 |

The xlsx marking convention is "applies to AI Production **unless** the
AI-Production cell says `N/A`" (per the TEMPLATE tab note: the AI-PROD column is
the superset of a team's questions). This is `DATA_GAPS.md` §4, still open — the
single largest body of un-ingested questions. It should be stated explicitly as
out of scope for the current guardrails PR so "questions are comprehensive" is
not over-claimed.

## Bottom line

The field-shape and trigger-bug corrections on this branch stand on their own
and are correct. The question set is **not yet comprehensive**: 16 governance
teams have no routing rule despite their gating fields already being collected
(item 1), and the xlsx questionnaire body is un-ingested (item 3). Items 1–2
are the natural next branch.
