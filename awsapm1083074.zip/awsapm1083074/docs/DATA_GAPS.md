# Data Gaps — Governance Hub Question Extraction

Compiled 2026-07-13 by Jeremy.Scherer (AWS). Every item below is
grounded in a specific file/paragraph/cell reference — none of this is
guessed. This is the punch list for [AWS] / Elevance follow-up, not an engineering TODO.

## 1. Missing master intake forms (the big one)

The docx's "Governance Teams Trigger Logic" section cites 33 unique coded
question IDs across 9 families (`GI`, `D`, `PI`, `MPI`, `LOB`, `AI`, `DU`,
`RBI`, `V`) — e.g. `PI.8`, `GI.1`, `MPI.9`. Every citation carries its full
question text inline (confirmed: `GI.1`'s wording is byte-identical across
all 11 of its citations), so what we extracted is accurate as far as it goes.

But the numbering proves each family is bigger than what's cited:

| Family | IDs we have | Gaps this proves |
|---|---|---|
| `GI` | 1, 9–13, 16 | 2–8, 14, 15 missing |
| `D` | 1, 3–9 | 2 missing |
| `PI` | 1, 4, 4a, 8, 11, 12 | 2, 3, 5, 6, 7, 9, 10 missing |
| `MPI` | 1, 4, 5, 9, 13, 18 | most of 2–17 missing |
| `LOB` | 1, 3 | 2 missing |

We do not have the master forms these IDs are drawn from. The doc's own
citations name two likely candidates, repeated dozens of times:
- **"current state GovHub intake form"**
- **"RAI vendor questionnaire"**

Neither is in this snapshot. `intake_schema.json` (14 fields) covers roughly
half of the 33 cited IDs — see `EXTRACTION_MANIFEST.md` for the exact
mapping. Everything downstream (`rule_engine.py`, and the goal of "ask every
question every activated team cares about") is blocked on getting these two
source documents from [Elevance]. This is not fixable by better parsing.

## 2. Missing team-specific reference docs

Cited by name in the doc, not present in this snapshot. [Elevance] to produce or confirm each:
- `OAGC Intake Questionnaire - Existing 05052026.xlsx` (doc says 259
  questions, filtered by Business Owner)
- `IAM AI TGov Checklist V2.0.docx` (Security – Identity and Access
  Management's only cited source; we do have 10 questions transcribed
  inline in the docx itself, so this may be redundant, not blocking)
- `Privacy Law Questions for New or Changing Projects involving Data
  2026 05 06.docx` (Legal - Data Governance & Privacy's cited source)
- `GOV Teams Standard Questions - AI Production Scenario.xlsx` — cited in
  the doc's own intro (para 9) as *the* reference spreadsheet, but the file
  we were given is named `Gov Team Reqs by Service Catalog Types.xlsx`.
  Unclear if this is the same file renamed, or we're missing a file.

## 3. Team taxonomy has no single source of truth

Four sources, four different counts, none authoritative:

| Source | Count |
|---|---|
| `trigger_rules.json` | 15 ([AWS] assessment: early draft, pre-dates the 2026-06-26 meeting with Elevance; background context only, not authoritative) |
| docx headings (trigger logic / questionnaire / screenshot sections) | 30 distinct trigger-logic headings |
| xlsx team tabs | 29 |
| Raw ticket log (`Raw Data` sheet, `Program` column) | 76 unique values (noisy — LOB sub-splits, encoding mojibake, ticket-routing artifacts, not necessarily distinct governance bodies) |
| [Elevance], verbally, 2026-06-26 meeting | 36 |

Full crosswalk is in `questions/team_roster.json`. Specific unresolved
conflicts — each needs an [Elevance] decision on team boundaries:
- **FGS / FEP / WellPoint / NGS**: 4 distinct trigger-logic headings with
  4 distinct trigger conditions, but they share ONE xlsx tab
  (`FGS-FEP-WellPoint`) and ONE questionnaire text block (30 HIPAA/PHI
  questions, undifferentiated by team). The questionnaire heading itself
  contains the aside "*Wellpoint Federal Solutions (formerly entered as
  National Government Solutions (NGS))*" — suggesting NGS may have been
  renamed/merged into WellPoint Federal, but trigger logic still treats
  them as 4 separate entities. Needs an [Elevance] call on whether this is 1
  team, 2, or 4 for folder/dedup purposes.
- **ESG / ESGEVAL**: ESGEVAL has its own xlsx tab and its own screenshot
  heading, but no independent trigger-logic heading at all — we don't know
  what activates it, or whether it's always co-activated with ESG.
- **Security – Identity and Access Management**: full 10-question
  questionnaire and its own xlsx tab (`SecIAM`), but **zero** trigger-logic
  heading anywhere in the doc. We don't know what activates this team.
  Confirmed absent, not an extraction miss.
- **Clinical Partnership Review**: no xlsx tab at all. Its only real
  question is the one embedded in its trigger condition (`PI.8`); its
  "questionnaire" text is just "uses the Procurement-SIR and GOV records."
  May be a lightweight/delegated team, not a full worksheet-owning one.
- **Cloud Intake-Adoption NEXTGEN**: has its own xlsx tab with no
  corresponding docx heading anywhere. Possible undocumented successor
  process to "Cloud Intake / Cloud Adoption."
- **Legal-Tech-Commercialization**: questionnaire section is explicit —
  *"TBD – Team is drafting – followed up on 4/30. Awaiting Legal-Tech
  leader-approved question list."* Genuinely no data, not a gap in our
  extraction. [Elevance] to supply once the team's list is finalized.

`questions/team_roster.json` also lists 20 raw-ticket-log `Program` values
(`raw_ticket_log_unmapped.candidates`) that don't map to any of the 30
docx headings — e.g. `AI Security Office`, `Cybersecurity Threat Management`,
`Offshore Oversight Committee (OOC)`, `Medicaid Offshore Compliance (MOGC)`,
`Privacy - PIA`. These are plausible candidates for closing the gap toward
the 36-team count [Elevance] cited verbally, or may just be noisy ticket-routing sub-categories. Not reconciled
— needs [Elevance] / [AWS] follow-up.

## 4. Unvalidated volume anomaly

`Legal-DataGovPrivacy`'s xlsx tab has 805 question-matrix rows (row 16
onward), vs. 1–150 for every other team. [AWS] manual review confirmed it's real
(has internal sections, not a merged-cell artifact), but it has not been
diffed against the docx's much shorter "Legal - Data Governance & Privacy"
questionnaire text (5 questions). Two lists, unreconciled — needs a
dedicated pass before this team enters the dedup stage, or its 805 rows will
dominate/skew everything.

## 5. Screenshot-only teams (OCR piloted; excluded from Tier-2 dedup for now)

20 images across 7 team folders (`questions/<slug>/images/`) had no
authoritative inline text — the "text" under their headings was a pointer to
an external system, not real question content. OCR transcription (two
independent models, cross-read) is now complete for all 20 images; 3 of the
20 image pairs showed large item-count divergence and were
reviewed manually — all 3 confirmed correct as transcribed, no fixes needed.
Pre-OCR, the pointer text per team was:

| Team | Images | What the "text" section actually says |
|---|---|---|
| Cloud Intake / Cloud Adoption | 2 | "Cloud Request - Central Intake" (pointer) |
| Enterprise Standards Governance (ESG) | 3 | "ESG Home - Enterprise Standards Governance" (pointer) |
| ESG Evaluation (ESGEVAL) | 2 | shares ESG's pointer text |
| LPAC Business Unit Regulatory Review | 6 | "LPAC BU Regulatory Review Intake Form - Power Apps" (pointer) |
| On-Prem/Private Hosting | 2 | "Service Catalog - Governance Hub" (pointer) |
| Security – VSRM (vendor only) | 2 | "Service Catalog - IT ServiceConnect" (pointer) |
| OCCO | 3 | Has 3 real text questions too — images here are genuinely "reference only," redundant with text |

Doc's own section heading: *"Other Gov Team Intake Form Screen Shots –
Reference Only, Not Comprehensive"* — the author is telling us these aren't
guaranteed complete even after OCR.

**Decision (Gan, 2026-07-14):** these OCR transcripts are "interesting, but
not something we have to consider" for the first dedup pass. Confirmed why
that's reasonable, not just expedient: several transcribed fields are closed
dropdowns with no visible option list (e.g. OCCO's "Frequency of Outreach" —
transcript notes "Empty dropdown, no value selected") — the transcript
correctly captures that a field exists, but not what it can be answered with.
Feeding that into dedup would embed a question with an unknown answer domain.
For now: Tier-2 dedup runs on `record.json`/`questions.txt` text content only
for all 32 teams (including these 7, which do have some real text — see OCCO
above). Screenshot content stays out of the dedup input and out of
`questionnaires.json` until someone does a dedicated review pass. Flagged
per-team in `team_roster.json`'s `notes` field for these 7 teams so this
doesn't get silently forgotten.
