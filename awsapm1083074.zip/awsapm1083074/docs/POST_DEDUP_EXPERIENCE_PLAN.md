# Post-Dedup Experience — Implementation Plan

**Lane:** Jaz (post-activation / post-dedup experience). **Branch:** `feature/post-dedup-experience`.
**Scope directive:** production-final, not the 48-hour demo cut. Spec §4 Phase A **and** Phase B.
**Companion docs:** `docs/DEDUP_AUDIT.md` (pre-work audit), the shared demo-plan/ownership spec (artifact), `handoff.md`.

## 1. Contract position

This lane assumes three inputs exist (stand-up contract): **activated teams**,
**chat transcript**, **trigger-question answers**. Everything integrates behind
the spec §5 STATE envelope through a single adapter module — when Jeremy's real
EHAP data contract lands, only `state_adapter.py` changes.

STATE envelope (spec §5, placeholder until Jeremy confirms):

```json
{
  "messages":        [ {"role": "user|agent", "content": "..."} ],
  "trigger":         { "fields": { ... }, "complete": false },
  "activated_teams": [ {"team": "...", "review_phase": 1} ],
  "governance":      { "questions": [ ... ], "complete": false }
}
```

Known naming mismatch owned by the adapter: the spec's canonical question
object uses `text`; `question_dedup.build_pending_questions` emits
`canonical_question`. The envelope speaks spec names; the session dict keeps
internal names. Nothing outside the adapter translates.

## 2. Backend modules (all new, flat in `governance_intake/`, matching repo idiom)

| Module | Responsibility |
|---|---|
| `state_adapter.py` | Pure. `session_inputs_from_state(state)` → tolerant parse of the three inputs (accepts team lists as dicts or strings, `agent`/`assistant` roles, missing sections). `state_from_session(sess, data)` → spec-§5 envelope with deterministic `complete` flags. |
| `postdedup.py` | Service layer. `begin_session(store, data, state)` creates a session directly in `asking_questions` from the three inputs (derives activated teams via `evaluate_rules` when the state doesn't carry them); `record_answers` (set/edit/clear + refresh `team_forms`/gaps); `completeness` (deterministic: all canonicals answered AND no required gaps — same semantics as the existing full-mode gate); `submit` (gate → existing `create_ticket` fan-out; refusal returns the gap list); `stats` (raw vs consolidated vs pre-filled vs answered). |
| `prefill.py` | LLM pre-fill with a **deterministic grounding gate**. Proposals batch over unanswered questions (chunked, scales to 1,600). Each proposal must carry provenance `{kind: transcript\|trigger_field\|prior_answer, ref, quote}`; a pure function verifies the quote actually appears in the claimed source and **rejects ungrounded proposals before they reach the session**. Proposals are stored as `q["prefill"]` with `status: proposed` — never `answered`. Explicit accept (per-question or bulk) moves them into `answer` with `answer_origin: "prefill"`. Dismiss is recorded. `INTAKE_SKIP_LLM=1` → no-op. |
| `question_order.py` | Phase B. Deterministic ordering: highest fan-out canonicals first within category/team groups (one answer covers the most team fields and gives later prefill passes the most grounding), stable tiebreak on corpus order. Pure + tested; the fill-in loop (`prefill` with `prior_answer` provenance) re-runs after answer batches so earlier answers imply later ones. |
| `qa_review.py` | Phase B. Optional final-pass agent: reviews answered questions, returns ≤ N advisory clarifications (structured output). Never blocks submit; off under `INTAKE_SKIP_LLM`. |
| `llm_provider.py` | Provider seam for the EHAP requirement: `EHAP_PROVIDER=ehap` (default → existing `get_ehap_model()`, point `EHAP_URL` at `ehap-mock` for local wiring) or `anthropic` (dev; `ANTHROPIC_API_KEY`, strands AnthropicModel). Auto-falls back to anthropic when EHAP creds are absent but a key is present. Only new code (prefill/QA) uses this seam; the existing chat flow is untouched. |
| `postdedup_api.py` | FastAPI `APIRouter` mounted by `server.py`: `POST /api/post-dedup/sessions` (from STATE), `GET .../sessions/{id}` (envelope + stats), `POST .../answers`, `POST .../prefill`, `POST .../prefill/decisions`, `POST .../qa-review`, `POST .../submit`, `GET .../stats`. Works on any session in `asking_questions`, including ones arriving through the existing chat flow. |

Not touched: routing phase, chat handler paths, demo mode, Dan's trigger UI,
the dedup corpus/mapping (audit issues #6–#7 are the corpus owner's).
`preseed_map.json`'s stale mechanism (#8) is superseded by `prefill.py`;
removal happens in a follow-up once this lands.

## 3. Semantics that must hold (each gets both-ways tests)

1. Pre-fills are **never silently committed**: a proposed prefill does not set
   `answered`, does not appear in `team_forms`, does not satisfy completeness.
2. Grounding is deterministic: an LLM proposal whose quote does not appear in
   the claimed source is dropped (and counted in stats as rejected).
3. Completeness and submit are pure checks; submit with gaps returns the gaps
   and creates nothing.
4. Answer edits after acceptance always win over prefill values; clearing an
   answer reopens the question and its team-form fields.
5. Contentless activated teams (Clinical Partnership Review) flow through
   every endpoint and the UI without error.
6. Team names join by exact string (documented hazard) — adapter validates
   unknown team names and surfaces them rather than dropping silently.

## 4. Frontend (`frontend/src/postdedup/`)

New component tree beside the existing chat App (which remains the assist
pane), rendered when a full-mode session is in `asking_questions`:

- **Grouped form**: sections per team (singletons) + a "Shared questions"
  section per category for cross-team canonicals; sections collapsed by
  default with counts; **lazy mount** of section bodies (IntersectionObserver
  + chunked rendering) so 1,600 questions never hit the DOM at once.
- **Source badges** per question from `sources` (max fan-out 4 today), with
  the exact team/question-ids on hover — the visual proof of dedup.
- **Prefill display**: proposed answers visually distinct ("from your
  description", provenance quote shown), accept / edit / dismiss; bulk accept
  per section.
- **Stats strip**: raw → consolidated → pre-filled → answered.
- **Submit**: enabled by the deterministic completeness flag; gap panel when
  blocked.

## 5. Testing & verification

- Unit tests per module (fires/doesn't-fire style both ways), FastAPI
  `TestClient` for the router, fake model injection for prefill/QA (no
  network); suite stays green via
  `PYTHONPATH=backend/src uv run --extra dev pytest backend/tests/unit`.
- `verify.py` gains a post-dedup pure-pipeline leg (STATE → session → answers
  → completeness → submit) under `INTAKE_SKIP_LLM=1`.
- Integration (marked `integration`): prefill against `ehap-mock` for the
  EHAP wire shape, and against Anthropic when a key is present.

## 6. Increments (one focused commit each)

1. Plan (this doc). 2. `state_adapter` + tests. 3. `postdedup` service +
tests. 4. `prefill` + grounding + tests. 5. `llm_provider` + pyproject extra.
6. API router + tests. 7. `question_order` + fill-in loop + tests.
8. `qa_review` + tests. 9. `verify.py` leg. 10. Frontend. 11. Doc updates.
