# Verification Report — EPIC-001 Post-Dedup Experience

**Date:** 2026-07-17 · **Spec:** `specs/EPIC-001-post-dedup-experience.md`
**Scope:** Phase A (demo) requirements R1–R8 after the realignment to Jeremy's
`FormFillerEnvelope` (ADR-004). Phase B (R9–R11) noted, not gated. Offline only.

## Layer 1 — Automated Gates

| Gate | Result |
|---|---|
| Unit tests (`pytest -m "not integration"`) | **PASS** — 149 passed, 3 deselected |
| Lint (`ruff`, changed files) | **PASS** — all checks passed |
| Type check (`mypy`, changed modules: state_adapter, postdedup, postdedup_api) | **PASS** — no issues (pre-existing debt in server.py/verify.py is out of scope, `tasks/lessons.md`) |

## Layer 3 — Traceability Matrix (Phase A)

| Req | Description | Implemented in | Tested by | Status |
|---|---|---|---|---|
| R1 | Consolidated deduped set for activated teams; no re-dedup; teams derive from triggers | `postdedup.begin_session`; `question_dedup.build_pending_questions`; `state_adapter._inputs_from_form_filler_envelope` | `test_state_adapter.py::test_begin_session_from_form_filler_envelope_activates_teams`; `test_postdedup_api.py::test_create_from_form_filler_envelope_activates_and_dedups` | **PASS** |
| R2 | `sources`/`source_teams` per question; badges rendered | `question_dedup.py:59-68`; `PostDedupView.jsx` `SourceBadges` (L69-89, L123) "1 answer → N forms"; `state_adapter` carries `sources` both shapes | `test_envelope_from_session_emits_contract_shape` (sources field); existing dedup tests | **PASS** (data + UI; UI not unit-tested) |
| R3 | Form beside chat (assist pane); JSX per convention | `frontend/src/postdedup/PostDedupView.jsx` | manual/browser | **PASS (code)** — needs in-browser drive |
| R4 | Deterministic completeness; submit-with-gaps creates nothing; edits/clears reopen | `postdedup.completeness`, `record_answers` | `test_postdedup.py::test_answer_and_clear_round_trip`, `::test_submit_refuses_while_incomplete_and_creates_nothing`, `::test_user_edit_over_accepted_prefill_flips_origin` | **PASS** |
| R5 | Submit reuses existing `create_ticket` fan-out; pptx required | `postdedup.submit` → `ticket_creator.create_ticket` | `test_postdedup.py::test_full_answer_then_submit_fans_out`, `::test_submit_requires_pptx_attachment` | **PASS** |
| R6 | Before/after stats (raw → consolidated → answered) | `postdedup.stats`; `PostDedupView.jsx` L279-280 | `test_postdedup.py::test_stats_counts_prefill_lifecycle`; `test_postdedup_api.py::test_create_returns_envelope_completeness_and_stats` | **PASS** |
| R7 | Tolerates contentless activated teams (Clinical Partnership Review) | `postdedup.completeness` (vacuous-complete); `state_adapter` | `test_postdedup.py::test_contentless_only_session_submits_vacuously`; `test_state_adapter.py::test_contentless_only_session_is_vacuously_complete` | **PASS** |
| R8 | Single adapter seam; now speaks Jeremy's `FormFillerEnvelope` both ways (placeholder retained) | `state_adapter.py` (`session_inputs_from_state`, `_inputs_from_form_filler_envelope`, `envelope_from_session`); `postdedup_api.py` `GET .../envelope` | `test_state_adapter.py` (9 envelope tests, both ways); `test_postdedup_api.py::test_envelope_endpoint_returns_contract_shape` | **PASS** |

**Phase A: 8/8 requirements satisfied in code; 7/8 unit-verified (R3 is UI, verified by shape + needs a browser drive).**

## Phase B (retained, not gated for demo)

| Req | Implemented in | Tested by | Note |
|---|---|---|---|
| R9 grounded prefill | `prefill.py` | `test_prefill.py` | Retained; at integration defers to Jeremy's `fill_form` (round-trip wired via `/envelope`) |
| R10 ordering | `question_order.py` | `test_question_order.py` | Retained; benign reorder in `begin_session`; foundation for the end-goal |
| R11 QA pass | `qa_review.py` | `test_qa_review.py` | Retained; advisory, never blocks submit |

**Known fragility (carried, not blocking):** `test_prefill.py` / `test_qa_review.py`
fail if `INTAKE_SKIP_LLM=1` is set in the environment (they inject fake agents but
the modules short-circuit on the flag). They pass under `make test` (which does not
set it). Fix later: inject fakes without the env short-circuit.

## Overall verdict

**PASS for the demo (Phase A).** The lane consumes and emits the real #13
contract, the deduped-list + source-badges + before/after-stats + deterministic
submit all verified offline. Remaining before showtime is operational, not code:
drive the UI in a browser against the new sample envelope, and Jeremy reconciles
#13 ↔ #16 and picks the demo UI.
