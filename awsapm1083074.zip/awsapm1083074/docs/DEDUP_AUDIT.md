# Dedup & Corpus Audit — 2026-07-16

Pre-work for the post-dedup experience (handoff step 2): verify the dedup
mapping and question corpus before building on them. All numbers below are
reproducible via `python backend/scripts/audit_dedup.py` (read-only,
exits non-zero on hard integrity failures).

## Verdict

**The mapping is internally sound and current — safe to build on.** The
suspected staleness ("mapping predates the xlsx-primary merge") is
**disproven**. The low measured reduction (8–10%) is real and is caused by
(a) corpus extraction defects and (b) conservative clustering thresholds,
not by a broken or outdated mapping.

## Evidence

### Integrity (hard checks) — all pass

| Check | Result |
|---|---|
| Mapping sources referencing nonexistent (team, question_id) | **0** dangling |
| Sources claimed by more than one canonical | **0** double-covered |
| Normalized exact-duplicate texts NOT merged by the mapping | **0** |
| Near-duplicate pairs (token Jaccard ≥ 0.75) not merged | 9, **0 cross-team** |

The mapping also references xlsx-only teams (`ESG Evaluation (ESGEVAL)`,
`Offshore Advisory and Governance Committee (OAGC)`), which only exist
post-merge. Its own `description` records generation over "the
xlsx-primary-merged per-team question sets". It is current.

### Coverage (why reduction is only ~10%)

- Corpus: **1,828 questions across 32 teams**. Mapping: **118 canonicals
  covering 310 sources** (66 cross-team, max fan-out 4). All-teams
  consolidation: 1,828 → 1,636 (**10.5%**).
- **11 of 32 teams have zero presence in the mapping**: Clinical
  Partnership Review (0 questions — expected), Compliance-Technology,
  Corporate Communications, DUE, EDA ARB, Enterprise Architecture,
  Legal - IP, **RAI (73 q)**, **Security – IAM (12 q)**, **Security-ESA
  (44 q)**, **Security-InfoSec (25 q)**. The three Security teams plus
  Security-VSRM plausibly overlap semantically; at the current
  `low_threshold=0.85` (all-MiniLM-L6-v2 cosine) none of it clusters.
- There is essentially no *lexical* duplication left to find (0 exact,
  9 near-dup pairs all intra-team). Any further reduction must come from
  *semantic* clustering (lower threshold + human review) and from cleaning
  the corpus itself.

### Corpus extraction defects (the real problem)

- **303 heading-like "questions"** (heuristic: short unpunctuated noun
  phrases, no interrogative/imperative opener) across 22 teams. Worst:
  Legal - Data Governance & Privacy (**68**, e.g. `LEGALDGP.X1` "Intake,
  ownership, and threshold scoping", `LEGALDGP.X403` "Downstream
  mapping"), ESG (34), EDOM (32), Cloud Adoption (31), Procurement (20).
  These are section headers captured as questions and inflate every count.
- **29 corpus questions contain leaked reviewer commentary** ("should be
  collected by TGOV/GovHub teams and shared with us", "we can carry over
  from the current state", …).
- **3 canonical texts are contaminated** by that commentary because the
  generator picks the *longest* cluster member as canonical — e.g.
  `DEDUP.AI_SOLUTION_BE` ends with "In the RAI vendor questionnaire. This
  would be covered in the member & provider impact questions we can carry
  over from the current state."
- `category` is `"general"` for all 118 canonicals (generator never
  implemented it), so category-based grouping only works for runtime
  singletons.

### Adjacent defects found while auditing

- `preseed_map.json` is entirely stale (already documented in
  `docs/TRIGGER_RULES_INTEGRATION.md` §3): dead `DEDUP.*` targets and
  renamed routing fields make `_preseed_from_routing` a silent no-op.
- Frontend `AttachmentPanel` keys on `a.s3_key`; the backend attachment
  record field is `key` (`attachments.py`).

## Recommendations (owners per handoff §5/§7)

1. **Corpus owner (Jeremy):** source-review pass on extraction — drop or
   re-classify heading rows, strip reviewer commentary. The audit script's
   heuristics give a worklist. This alone removes ~17% of the corpus noise.
2. **After cleanup:** regenerate the mapping, experimenting with
   `--low-threshold` below 0.85 with human review of new clusters, to pull
   the 11 absent teams (especially the four Security teams and RAI) into
   the mapping.
3. Canonical-text selection should prefer the *cleanest* member (or a
   rewritten text), not the longest.
4. The post-dedup experience treats all of this as data: it renders
   whatever mapping/corpus exists and improves automatically as they do.
   No code in this lane blocks on corpus cleanup.

GitHub issues filed from this audit are cross-referenced on the issues
themselves (label/timestamp 2026-07-16).
