# Prompt eval harness — design contract

Status: **draft, not yet an ADR.** Extends the existing `@pytest.mark.integration`
convention (`backend/tests/integration/`, `make test-integration`) rather than
introducing a new framework or execution model. Rationale for rolling this by
hand instead of adopting DeepEval or similar: our surface is two structured
extraction/fill-in prompts (`intake_agent.py`'s `extract_routing_fields` /
`extract_answer_batch`, and `form_filler_agent.py`'s `fill_form`) with an
already-deterministic acceptance boundary (Pydantic schema + the
FormFillerAgent invariant). Most of what needs checking is a plain assertion;
the few genuinely open-ended checks get a narrow hand-written judge call
through the existing `ehap_model.py` client, not a general eval framework.

## Why "punt the golden dataset"

Hand-authoring a rigorously-curated golden corpus (exact expected values,
manually vetted) is slow to bootstrap and brittle against prompt wording
changes. Instead: a capable agent generates a batch of realistic,
human-shaped scenarios up front — varied submitter descriptions, deliberately
ambiguous/conflicting inputs, "looks inferable but isn't actually grounded"
traps — playing the same adversarial-QA role a human tester would. This
becomes the working case set: regenerable, explicitly labeled as AI-authored
rather than hand-vetted ground truth, good enough for "did I just break
something" dev confidence. Not a substitute for a rigorously-maintained golden
set if this project later needs one (e.g. compliance sign-off on prompt
behavior) — that's a bigger, separate investment.

## EvalCase schema

```json
{
  "id": "string, unique within the file",
  "agent": "intake_agent | form_filler_agent",
  "description": "one-line human-readable summary of what this case probes",
  "input": "agent-specific — see below",
  "checks": ["Check, see below"]
}
```

- `intake_agent` input: the free-text submitter message(s) that would be
  passed into `extract_routing_fields` (single string, or a list of turns if
  the function accepts multi-turn — confirm the actual signature before
  building the runner, don't assume).
- `form_filler_agent` input: a `FormFillerEnvelope` exactly per
  `docs/form_filler_agent_contract.md`.

### Check — deterministic (no model call, plain code assertion)

```json
{ "type": "field_equals",        "field_id": "...", "expected": <value> }
{ "type": "field_null",          "field_id": "..." }
{ "type": "field_not_null",      "field_id": "..." }
{ "type": "origin_equals",       "field_id": "...", "expected": "user | agent | null" }
{ "type": "confidence_at_least", "field_id": "...", "expected": <int 0-5> }
{ "type": "confidence_at_most",  "field_id": "...", "expected": <int 0-5> }
```

Use these for anything with a factual right answer: "this blank must NOT be
filled" (grounding-trap cases), "if filled, confidence must clear N."

### Check — judge (one model call, for genuinely open-ended text)

```json
{ "type": "judge", "field_id": "...", "rubric": "plain-English description of what an acceptable answer looks like AND what would count as a hallucination/red flag for this specific case" }
```

Backed by a `judge_answer(question_text, submitted_value, rubric) ->
{accept: bool, reason: str}` function, prompted to act as a careful,
skeptical-but-fair QA reviewer — not a rubber stamp, not needlessly pedantic.
Use ONLY where a deterministic check genuinely can't capture correctness
(e.g. "is this a reasonable paraphrase of the AI approach" — no fixed string
is right, but a human reviewer would clearly recognize a bad answer).

## Division of labor

1. **Case generation (one-time-ish, produces checked-in fixtures):** Beta
   generates `backend/tests/integration/fixtures/generated/{intake_agent,
   form_filler_agent}_cases.json` — realistic + adversarial scenarios per the
   schema above. Regenerable; not hand-vetted ground truth; say so in a
   header comment in the generated files.
2. **Harness scaffold (real code, testable without any live model):** a
   backend engineer builds the pytest runner
   (`backend/tests/integration/test_prompt_evals.py`, marked
   `@pytest.mark.integration`), the deterministic check evaluators, the
   `judge_answer()` helper wired through `ehap_model.py` (checking first
   whether a model override is even possible per-call — if EHAP only exposes
   one configured model, the judge just uses that one; no fabricated "slow
   tier" inside the shipped repo), and a `StubJudge` (mirrors
   `StubFormFillerModel`'s pattern) so the harness's plumbing is testable
   without live EHAP credentials, which don't exist in this dev environment.
3. Wiring `make test-integration` already covers running this (same marker,
   same target) — add `make eval` as a plain alias only if it reads more
   clearly, not required.

## Honest limitation

No `.env` / EHAP credentials exist in this dev environment (confirmed
previously for the FormFillerAgent work). The harness scaffold can be proven
correct against the `StubJudge` here; the real judge-through-EHAP path cannot
be smoke-tested end-to-end until credentials exist. State this plainly, don't
claim more than what's actually verified.
