# Extraction Manifest — how we got here, and how to redo it

## What ran

`backend/scripts/extract_questions.py` — pure Python, stdlib only
(`zipfile`, `re`, `html`, `json`), **zero LLM calls**. Reads
`word/document.xml` and `word/_rels/document.xml.rels` directly out of the
source `.docx` zip; no `python-docx` dependency. Deterministic:
same input → byte-identical output every run (verified by re-running after
a bugfix — see below).

Run with:
```
# place the governance requirements .docx in backend/scripts/source/ first
python3 backend/scripts/extract_questions.py
```

## What it does

1. Splits `document.xml` paragraphs into the doc's 3 top-level (Heading1)
   sections: "Governance Teams Trigger Logic", "Questionnaires by
   Governance Team", "Other Gov Team Intake Form Screen Shots".
2. Within each section, groups paragraphs under their Heading2 (team name).
3. For every team listed in `backend/src/governance_intake/data/team_roster.json`,
   pulls the matching heading's text (trigger logic + questionnaire) and
   image list (screenshots), keyed by the exact heading strings recorded in
   the roster's `docx_trigger_heading` / `docx_questionnaire_heading` /
   `docx_screenshot_heading` fields.
4. Writes `data/extracted_questions/<slug>/questions.txt` (human-readable),
   `record.json` (structured, with paragraph-index provenance), and copies
   any screenshot images to `data/extracted_questions/<slug>/images/`.
5. Writes `data/extracted_questions/coverage_report.json` — one row per
   team, with paragraph counts, embedded question-ID list, image count, and
   an `has_any_content` / `needs_ocr` flag.

## Known bugs found and fixed during the original run

First run: XML entity references (`&amp;`) inside `<w:t>` text were never
un-escaped, so team names containing `&` (`"Legal - Data Governance &
Privacy"`, `"Procurement & Legal-Procurement (vendor only)"`) failed to
match the roster's plain-`&` strings and came back empty. Fixed by wrapping
the extracted text in `html.unescape()`.

Second issue, roster-side not script-side: `team_roster.json` originally had
placeholder strings like `"(bundled into FGS/FEP/WellPoint heading)"` in
`docx_questionnaire_heading` for Anthem FEP, FGS Home Office, National
Government Solutions (NGS), WellPoint Federal, and ESG Evaluation
(ESGEVAL) — instead of the actual combined heading text. This silently
orphaned the 30-question HIPAA/PHI block those 4 teams share (and ESG's
block for ESGEVAL). Fixed by replacing the placeholders with the exact
heading strings, confirmed by re-running and checking the resulting
`anthem_federal_employees_program_fep/questions.txt` (now contains all 30
questions).

Both fixes are already applied in the current `team_roster.json` and
`extract_questions.py` — nothing further to do here, this section is a
record for whoever picks this up later.

## Current output census (after fixes)

- 32 team folders under `data/extracted_questions/` (one per
  `team_roster.json` entry — 30 canonical docx-trigger-logic teams, plus
  ESGEVAL and Security-IAM which have questionnaires but no trigger heading)
- 0 teams with zero content
- 20 screenshot images identified across 7 teams (Cloud Intake/Adoption,
  ESG, ESGEVAL, LPAC BU Regulatory Review, On-Prem/Private Hosting,
  Security VSRM, OCCO) — see "OCR pilot status" below; the images
  themselves and their transcripts are **not** included in this delivery
- 33 unique coded question IDs found embedded in trigger-logic text
  (`GI`, `D`, `PI`, `MPI`, `LOB`, `AI`, `DU`, `RBI`, `V` families — see
  `DATA_GAPS.md` §1 for which IDs are missing within each family)

Full per-team detail: `data/extracted_questions/coverage_report.json`.

## OCR pilot status (screenshot-only teams)

A two-model transcription approach was piloted end-to-end on all 20
screenshot images (the 7 teams above): each image was independently
transcribed by two different model backends against an identical prompt
contract, then the two outputs were compared. The approach worked —
independent lenses agreed on content in the large majority of cases, and
caught the same real anomalies in the source forms independently (e.g. a
literal duplicate state-code entry in one form). 3 of the 20 image pairs
showed a large item-count divergence; manual review confirmed one side was
fully correct in each case, with no data loss.

**Not included in this delivery**: the raw per-image transcripts, the
screenshot images themselves, and a reconciled per-team merge of the OCR
output into `questions.txt` / `record.json`. The pilot proves the method
works; turning it into production output (reconciling both model outputs
into one final answer per image, then merging into each team's
`extracted_questions/<slug>/` folder) is follow-on work, not yet done.
Re-run the pilot against the full image set once ready to productionize —
the prompt contract that produced clean, converged output is documented
separately (ask for it if the transcription agent definitions weren't
carried over with this drop).

## `intake_schema.json` coverage of the 33 coded IDs

For whoever eventually expands `intake_schema.json` / `trigger_rules.json`
to the full 30-team taxonomy — here's the current mapping, so it isn't
re-derived from scratch:

| Coded ID | intake_schema.json field |
|---|---|
| `GI.1` | `level_of_development` |
| `AI.1` | `involves_ai_ml_llm` |
| `D.3` | `cloud_environment` |
| `D.6`, `D.9` | `data_types` |
| `PI.1` | `uses_vendor` |
| `PI.4` | `vendor_access_phi` |
| `LOB.1` | `lines_of_business` |
| `MPI.1` | `member_provider_impact` |

**Not represented in `intake_schema.json` at all**: `D.1, D.4, D.5, D.7,
D.8, DU.2, RBI.7, V.3, GI.9–GI.16 (6 distinct IDs), MPI.4, MPI.5, MPI.9,
MPI.13, MPI.18, PI.4a, PI.8, PI.11, PI.12, LOB.3`.

## Redo procedure when more source data arrives

If/when [AWS] or Elevance supplies the missing master forms (see
`DATA_GAPS.md` §1–2):

1. Place the new source file(s) in `backend/scripts/source/`.
2. If it resolves a coded-ID family gap (e.g. the full current-state GovHub
   intake form defining `PI.1`–`PI.12`), add the new question text directly
   to `intake_schema.json` / a new `question_bank.json` — this script
   doesn't need to change, since coded-ID definitions aren't sourced from
   the docx alone, they're the union of docx citations + the master form.
3. If it resolves a team-taxonomy conflict (e.g. confirms FGS/FEP/WellPoint/
   NGS are 1 team or 4), edit `team_roster.json` directly — `status` field
   goes from `conflict` to `mapped`, update `notes`.
4. Re-run `backend/scripts/extract_questions.py`. It's idempotent — safe to
   re-run any time the roster or source docx changes; it fully regenerates
   `data/extracted_questions/<slug>/` from scratch each time (no
   incremental/manual state to lose).
5. Diff `coverage_report.json` before/after to confirm the new data actually
   changed something (paragraph counts, embedded IDs, or image counts
   should shift for the affected team(s)).

## What this manifest does NOT cover

- The xlsx per-team question matrices (`Gov Team Reqs by Service Catalog
  Types.xlsx`, tabs like `AI Program Office` row 16+) — not yet diffed
  against the docx-extracted text. That's the Tier-1 reconciliation pass
  flagged in `DATA_GAPS.md` §4, still open.
- Production OCR transcription of the 20 screenshot images — piloted
  successfully (see "OCR pilot status" above) but not productionized or
  merged into team output.
- Any deduplication / canonicalization into Tier-2 "unified questions" —
  not started. This manifest only covers getting Tier-1 (team-original,
  as-written) questions out of the source documents.
