# ADR-003: Phase B (prefill / ordering / QA) built despite transcript deferral

## Status
Proposed — **CONTESTED** (this ADR exists to force the decision, not to bless it)

## Date
2026-07-16

## Context
The Thursday stand-up scoped the deliverable unambiguously:
> "FOR DEMO: just show all of the questions after dedup for now. The question
> order/coverage intelligence can come later." (Jeremy; Jaz: "okay, yeah, I got it.")

`handoff.md` §6 then recorded a different directive, from Jaz to the agent:
> "do not scope this down to the demo … production-final … No demo-deadline
> compromises."

Acting on the handoff, Phase B was implemented in full: `prefill.py`,
`question_order.py`, `qa_review.py`, `llm_provider.py`, `ehap-mock/`, and EHAP
wire tests — roughly half of the ~3,763-line branch.

## Decision (as-built)
Build Phase B now, behind module boundaries, so it is production-ready when the
demo scope is lifted.

## Alternatives Considered
### Alternative A: Ship Phase A only for the demo, defer Phase B (transcript scope)
- **Pros**: matches the agreed scope; less surface to break before a VP demo;
  no dependency on Jeremy's not-yet-existing EHAP contract; nothing to throw away.
- **Cons**: Phase B work happens later.
- **Why the transcript chose it**: prefill quality and ordering both depend on
  Jeremy's extraction prompt and data contract, which do not exist yet.

## Consequences
### Positive
- If scope is lifted, Phase B is already done and tested.
### Negative
- ~50% of the branch is effort the team did not ask to see Friday.
- Phase B depends on Jeremy's EHAP contract; parts may be reworked or discarded
  when it lands (see ADR-004).
- **Boundary defect**: Phase B is NOT cleanly excisable. `postdedup.begin_session`
  (Phase A) calls `question_order.order_pending_questions` (Phase B, R10) on the
  critical path, and `stats`/`submit` reference prefill fields. Reverting to
  demo-only is not a clean file delete.
### Risks
- Reviewers conflate "lots of code + green tests" with "on-scope"; this ADR
  exists so the scope decision is explicit, not implicit.

## Reversibility
Medium. `prefill`/`qa_review`/`llm_provider`/`ehap-mock` are import-isolated;
`question_order` is wired into the Phase-A path but is harmless (a reorder, not
new questions).

## Resolution (2026-07-17)
Owner directive: **respect the work — do not remove Phase B or do major
refactoring.** Phase B stays in the branch. The demo follows the transcript
(a plain deduped list); Phase B is not exercised by the demo path but is
retained as the foundation for the documented end-goal (spec R10/R11: order
questions so earlier answers imply later ones, ask one-by-one, minimize the
set). The scope concern is resolved not by deletion but by (a) aligning the
input/output contract to Jeremy's real `FormFillerEnvelope` (see ADR-004) so
prefill can defer to his `fill_form` at integration, and (b) leaving ordering
in place as a benign reorder. Superseded on the delete/split point by ADR-004.

## References
- Spec R9/R10/R11, Open Question #3; transcript AC3; handoff.md §6; ADR-004.

## Update (2026-07-17, Sisyphus + Flare, overnight reconciliation)

This ADR's resolution treats Phase A's determinism as the settled part —
"routing and completeness are deterministic" is daplan's own §7 "Decided"
line, unlike Phase B which this ADR exists to contest. **ADR-006 puts a
demo_mode exception into that Phase A completeness/submit gate itself**
(the post-dedup submit gate couldn't otherwise complete against a
realistic activation profile). That's a new contest on ground this ADR
treated as settled, made without Jaz. See ADR-006 — flagged Proposed,
needs his sign-off specifically, not a rubber stamp.
