# ADR-006: Post-dedup's completeness/submit gate now honors `demo_mode`

## Status

**Accepted** — signed off by Jaz on 2026-07-17 (demo day). See Resolution for how
this reconciles with the "production-final" directive.

Originally **Proposed** — flagged as in tension with ADR-003's resolution and Jaz's
own recorded directive to build the post-dedup lane "production-final... no
demo-deadline compromises." Required Jaz's sign-off specifically.

## Resolution (Jaz, 2026-07-17)

Accepted — and the tension resolves rather than stands. The bypass relaxes the gate
**only when `demo_mode=True`**; the production path (`demo_mode=False`) keeps the
strict, deterministic completeness/submit gate exactly as built. So the
"production-final, no compromises" directive is **honored in production**, not
broken. What `demo_mode` concedes is not determinism but the known **~8-10% corpus
mapping coverage** (daplan §6): a realistic activation surfaces 1,000+ *unmapped*
gaps, and `demo_mode` already means "a curated question subset." Extending the same
tolerance the chat flow (`handler.py`) already had is consistent, not a new
compromise. The real fix — mapping coverage over the merged corpus — is explicit
**post-demo** work (daplan §6/§8, Alternative A), tracked separately.

## Date

2026-07-17

## Context

`postdedup.completeness()`/`submit()` unconditionally required `not
open_gaps`, where `open_gaps` is `detect_gaps()` checked against
`questionnaires.json`'s **full** real per-team question catalogs. Reproduced
live tonight: for a realistic 15-16-team activation profile, this produced
1,000+ gaps — because current dedup-mapping coverage over the merged corpus
is only ~8-10% (daplan §6's own finding), most of each team's real
questionnaire has no canonical mapping yet. **Submit could not succeed for
any realistic activation profile.** This would have broken the demo outright
had a real team-set been shown, not the narrow hand-picked one.

`handler.py`'s own chat-driven flow already carries a tolerance for exactly
this: `qa_done = all_answered and (self.demo_mode or not gaps)`, with a
comment explaining that `demo_mode` sessions only ever ask a small curated
subset of each team's real questionnaire (`demo_team_questions.json`), so
gaps against the full catalog are expected there and shouldn't block
completion. The post-dedup lane had no such tolerance at all.

## Decision

Thread `demo_mode: bool = False` through `postdedup.completeness()`,
`postdedup.submit()`, `postdedup.record_answers()`, and
`postdedup.apply_prefill_decisions()`, and through
`postdedup_api.build_router()` — sourced from the same `_handler.demo_mode`
flag `server.py` already has (not a new flag, not a new decision about what
demo_mode means). Under `demo_mode=True` (what the app is served with),
`open_gaps` no longer blocks completion — the same tolerance the chat flow
already had, extended to the post-dedup lane.

## Alternatives Considered

### A: Fix the dedup coverage instead of bypassing the gate
Daplan §6 already flagged the Legal DGP over-extraction and low
dedup-reduction rate as needing a real corpus fix, and §8 filed it as an
open item: "Decide: extend the mapping before Friday, or reframe the demo
metric around fan-out + pre-fill." **Why not chosen tonight**: that's real
corpus/mapping work against source documents, not a code change, and
was explicitly left open rather than blocking — fixing the *gate* to match
the *already-decided* demo framing (fan-out + pre-fill, not a raw-count
collapse) is consistent with that call; fixing the corpus itself is a
separate, bigger task that doesn't fit in what was left of tonight.

### B: Leave the gate strict; pick a narrow demo profile instead
Daplan §9's own risk mitigation: "pick the demo scenario deliberately — a
3-team pilot keeps it at ~100 [questions]." **Why not chosen**: doesn't fix
the underlying gate for anyone testing outside that one narrow, hand-picked
profile — which is exactly what happened tonight (the frontend port's own
smoke test used a realistic profile and hit the wall). It also doesn't
resolve the tension below; it just avoids exercising it.

## Consequences

### Positive
- Submit actually works tonight for any activation profile, not just a
  hand-picked small one — verified live, 409 → 200 with a real ticket.

### Negative / Risks — the real issue

**This sits in direct tension with ADR-003's resolution.** ADR-003 says:
"The demo follows the transcript (a plain deduped list); Phase B is not
exercised by the demo path," and records Jaz's own handoff directive to
build "production-final... no demo-deadline compromises." Adding a
`demo_mode` bypass to the Phase A completeness/submit gate **is** a
demo-deadline compromise on exactly the determinism daplan §7 calls
"Decided — Routing and completeness are deterministic" — and it touches
Phase A itself, not the Phase B modules ADR-003 was explicitly scoping the
"no compromises" stance around.

This was Sisyphus's and Flare's call tonight, made to unblock a demo that
could not otherwise complete, not reviewed by Jaz. It changes what
"complete" means for a `demo_mode` session in a way his own tests and ADRs
didn't anticipate — and he was explicit, in the handoff transcript ADR-003
quotes, that he did not want scope-driven compromises on this exact
surface.

## Reversibility

High mechanically — a single boolean threaded through four functions and
one constructor call; reverting the code is small. The *semantic* question
— should `demo_mode` ever affect what "complete" means, anywhere — needs a
real answer from Jaz, not just a keep/revert decision on the diff.

## Open question for tomorrow morning

Does Jaz want `demo_mode` to affect post-dedup completeness at all, or would
he rather scope the demo to a small, hand-picked activation profile
(daplan §9's original mitigation) and keep this gate fully strict, matching
what he built and signed off on?

## References

- ADR-003 (resolution section — contested by this decision)
- daplan §6 (dedup coverage numbers), §7 ("Decided — completeness
  deterministic"), §8 (open item on dedup coverage), §9 (risk mitigation —
  "pick the demo scenario deliberately")
- Beta's backend review + the frontend port's own smoke test (finding
  "GAP 1" — the reproduction that surfaced this)
