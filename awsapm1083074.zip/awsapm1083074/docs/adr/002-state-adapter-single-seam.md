# ADR-002: One adapter as the single STATE-contract translation seam

## Status
Accepted

## Date
2026-07-16

## Context
The post-dedup lane consumes three inputs (activated teams, chat transcript,
trigger answers) that arrive as an external STATE envelope owned by Jeremy,
whose real shape does not yet exist. In the stand-up Jeremy explicitly predicted
"an input mismatch." The spec canonical question object uses `text`; the internal
`build_pending_questions` emits `canonical_question`.

## Decision
Route all STATE↔session translation through `state_adapter.py`. The envelope
speaks spec names; the session dict keeps internal names; nothing outside the
adapter translates. Tolerant parsing (team lists as dicts or strings,
`agent`/`assistant` roles, missing sections) lives here and only here.

## Alternatives Considered
### Alternative A: Parse STATE inline where needed
- **Cons**: shape churn spreads through every module when Jeremy's contract lands.
- **Why not chosen**: guarantees a painful migration on a predicted change.

## Consequences
### Positive
- When the real contract lands, only `state_adapter.py` changes.
- Unknown team names surface (`unknown_teams`) rather than dropping silently.
### Negative
- One more indirection for readers.
### Risks
- Adapter is only as good as the guessed envelope; mitigated by 99% test coverage.

## Reversibility
Trivial — inline the parse if the contract stabilizes. Low cost.

## References
- Spec R8; handoff.md §5; transcript ("be very prepared for an input mismatch").
