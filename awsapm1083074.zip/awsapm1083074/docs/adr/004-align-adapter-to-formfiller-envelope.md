# ADR-004: Align the STATE adapter to Jeremy's FormFillerEnvelope (dual-shape, no import coupling)

## Status
Accepted

## Date
2026-07-17

## Context
The post-dedup lane was built against a *placeholder* STATE envelope
(`{messages, trigger, activated_teams, governance:{questions}}`). Jeremy's
PR #13 then published the real contract, `FormFillerEnvelope`
(`docs/form_filler_agent_contract.md`): `{triggers: [...], governance: [...]}`
with items `{id, text, value, origin, confidence}` (+ `sources` on governance),
`value is None` meaning unanswered, and **no** carried team list (teams derive
from trigger values via the rule engine — his progressive activation). His
`form_filler_agent.py` lives only on #13, not yet merged to `np01_rnp`.

The owner directive: realign to #13, respect existing work, no major refactor,
and stay independent of Dan's #16 (an unagreed TS UI rebuild).

## Decision
Make `state_adapter.py` speak the FormFillerEnvelope **by contract (plain
dicts)**, additively:
- `session_inputs_from_state` detects the envelope structurally (`triggers`/
  `governance` as lists) and parses it: triggers → `trigger_fields`,
  answered governance → `governance_answers` (origin mapped), teams left to
  downstream rule-engine derivation. The placeholder path is untouched.
- `begin_session` seeds `governance_answers` onto the freshly-built pending set
  via a local helper — decoupled from Jeremy's `build_pending_questions`
  `prior_answers` parameter (which isn't on this branch yet).
- New `envelope_from_session` emits the exact `{triggers, governance}` shape
  for round-tripping through his `/api/formfiller/fill`; exposed at
  `GET /api/post-dedup/sessions/{id}/envelope`.
- Provenance maps both ways: session `answer_origin` "user"/"prefill" ↔
  envelope `origin` "user"/"agent"; an accepted grounded prefill emits
  `confidence: 4` (the grounding gate already verified its quote verbatim).

## Alternatives Considered
### A: Import `form_filler_agent.FormFillerEnvelope` and validate against it
- **Why not**: couples this branch to an unmerged one; blocks independent
  demo. Deferred: when #13 lands, `FormFillerEnvelope(**envelope_from_session(...))`
  validates directly.
### B: Replace the placeholder path entirely
- **Why not**: breaks existing tests and the working `_view`/frontend the night
  before the demo. The owner asked to respect the work.

## Consequences
### Positive
- The lane now consumes and emits the real contract; integration with #13 is a
  merge-time formality (shape already matches, verified end-to-end).
- Additive: 149 unit tests green, existing placeholder behavior preserved.
### Negative / Risks
- Two envelope shapes accepted on input until the placeholder is retired
  (documented; detection is unambiguous).
- Confidence for accepted prefills is a fixed 4, not a model score — fine until
  prefill defers to Jeremy's confidence-producing `fill_form`.

## Reversibility
High. Drop the FormFillerEnvelope branch + `envelope_from_session` to revert to
placeholder-only. Swapping to his Pydantic models later is a localized change.

## References
- `docs/form_filler_agent_contract.md` (PR #13); spec R8; ADR-002, ADR-003;
  `docs/DEMO_PLAN.md`.

## Update (2026-07-17, Sisyphus + Flare, overnight reconciliation)

Two things this ADR's Context/Decision assumed have since changed:

1. **"His progressive activation"** (Context, line 16) referred to
   `feature/form-filler-agent`'s `_sync_activated_teams` as an established
   part of the real contract. It wasn't reviewed, was never in `np01_rnp`
   or #16, and has been dropped entirely — see ADR-007. The envelope's "no
   carried team list, teams derive from trigger values via the rule engine"
   design point still stands on its own merits (it's just a pure-function
   derivation, independent of whether activation happens progressively or
   all at once); the parenthetical justification citing progressive
   activation as precedent no longer applies.
2. **"Stay independent of Dan's #16"** (Context, owner directive) has been
   reversed — the post-dedup lane now runs inside #16's TypeScript shell on
   #16's own session, not independently. See ADR-005 (Proposed — this was
   also not reviewed with Jaz before landing).

This ADR's actual decision (speak `FormFillerEnvelope` by contract at the
`state_adapter.py` boundary, additively) is unaffected and stays Accepted —
only the two contextual assumptions above are stale.
