# ADR-005: Collapse post-dedup onto a single shared session; retire the manual toggle for an automatic phase-triggered handoff

## Status

**Accepted** — ratified by Jaz on 2026-07-17 (demo day), after review. Supersedes
the "stay independent of #16" stance in ADR-004 (see Resolution).

Originally **Proposed** — a unilateral call made overnight by Sisyphus + Flare while
reconciling three branches for the demo. Not reviewed by Dan or Jaz at the time.

## Resolution (Jaz, 2026-07-17)

Accepted. ADR-004's independence-from-#16 was a *build-time* strategy to avoid
coupling the post-dedup lane to an unmerged branch; that reason lapsed the moment
all three branches merged into `np01_rnp`. The single-session collapse matches the
originally-agreed §2 single-STATE flow, ships the more complete dashboard as *the*
post-routing surface, and is the path verified live end-to-end twice. Open
questions #1 (keep Dan's per-team flow reachable?) and #2 (the bridge's
preview-a-different-project capability) are acknowledged as **post-demo** items,
not demo blockers — Dan's code remains present-but-unreachable, so either is
recoverable. Finding **I2** (SessionStore `get`/`put` has no concurrency contract)
is accepted as a **known, deferred risk**: the demo flow is sequential
(ingest → auto-handoff → dashboard, single surface at a time), so concurrent
writes don't arise on the scripted path; hardening the store's concurrency
contract is post-demo work (ties to open question #3).

## Date

2026-07-17

## Context

Going into tonight, three branches disagreed on how "the deduped-question
experience" should be reached:

- **Jaz's post-dedup lane** (#12/#18) created a brand-new session
  (`postdedup.begin_session` → `session.new_session()`) bridged from a
  snapshot of the chat session's STATE, reached by a manual "Preview
  questionnaire" / view-toggle button in the old chat-only `App.jsx`. ADR-004
  explicitly chose to build this *independent* of Dan's #16: "couples this
  branch to an unmerged one; blocks independent demo."
- **Dan's ingestion UI** (#16) rewrote the frontend to TypeScript with its
  own, simpler per-team `WorkflowPanel` flow (`TeamQuestionsStep` →
  `AttachmentStep` → a separate submit step), operating in-place on the
  *same* session ingestion produced — no bridge, no second session.
- Both approaches, independently, turned out to share the exact same backend
  `SessionStore` already (Jaz's own comment in `server.py`: "sessions
  reaching asking_questions via chat are also addressable here") — the
  two-session model was never structurally required, just how the lane
  happened to be built while working independently of #16.

Reconciling all three into one demo-ready app before Friday made the
three-way independence (correct for building overnight in parallel) no
longer viable for what ships.

## Decision

1. Post-dedup's routes operate on the **same session id** ingestion
   produces. No bridged snapshot session. `handler.py`'s
   `_enter_asking_phase` now supplies everything post-dedup's routes need at
   the moment the gate fires (`order_pending_questions()`, eager
   `open_gaps` via `detect_gaps()`).
2. The manual toggle button is retired. Jaz's `PostDedupView.jsx` is ported
   into Dan's TypeScript shell as `PostDedupDashboard`, mounted
   **automatically** the instant session phase leaves
   `collecting_routing_info` — no user click.
3. Dan's per-team/attachment/submit `WorkflowPanel` steps are **superseded**,
   not augmented, by this dashboard for that phase —
   `computeSteps()` collapses them into one synthetic "Governance review"
   step. That code is not deleted, just unreachable once routing completes.
4. Post-dedup's phase gate (`_require_phase`) widened to tolerate
   `collecting_attachments` alongside `asking_questions`, because chat can
   now independently advance the *same* session past `asking_questions`
   while the dashboard is open (a direct consequence of #1).

## Alternatives Considered

### A: Keep the two-session bridge; wire the toggle button into Dan's new TS shell instead of retiring it
- **Pros**: zero backend change; respects ADR-004's explicit
  independence-from-#16 choice.
- **Cons**: ships two different answering surfaces (Dan's simpler per-team
  fields vs. Jaz's richer dashboard) side by side for the same demo — likely
  confusing on stage. Also doesn't match daplan §2's flow diagram, which
  describes one STATE object both UIs read/write, not a bridged second
  session.

### B: Ship Dan's #16 UI only for the demo; shelve Jaz's dashboard, prefill accept/reject, QA review, and ordering entirely (unreachable, not deleted)
- **Pros**: fastest; zero UI-merge risk.
- **Cons**: throws away real, tested, more feature-complete work for the
  actual demo. Jaz's dashboard is what actually satisfies daplan's
  dedup-form spec (source badges, before/after stats strip) — Dan's
  per-team steps don't have that.

### Why the chosen path instead
Matches the originally agreed §2 flow diagram (one STATE object, not a
bridge) and ships the more complete experience. But it **directly reverses
ADR-004's explicit "stay independent of Dan's #16" stance** — that
independence was the right call for building two branches in parallel
overnight; it stopped being the right call once both had to ship together
as one app tomorrow. Whether reversing it was actually correct, versus
something that should have been a joint call, is exactly what's still open.

## Consequences

### Positive
- One coherent app: no duplicate ticket-creation or attachment-upload code
  paths, no second session id for the UI or the user to track.
- Matches the documented flow diagram instead of two independently-evolved
  interpretations of it.

### Negative / Risks
- **Made without Dan or Jaz in the room.** Dan's simpler per-team
  `WorkflowPanel`/`AttachmentStep`/submit-step code is now dead code on the
  post-routing path. If either of them intended it to stay reachable — a
  fallback, a different demo scenario, a deliberate simplicity choice — that
  intent is now silently gone, not discussed away.
- The phase-gate widening means post-dedup's routes enforce a looser
  invariant than Jaz originally wrote (`_require_phase(sess, PHASE_ASKING)`
  exactly). Verified safe for the two known phases tonight; not audited
  against any phase that gets added later.
- Session-collapse also surfaced (see Beta's review, finding I2) that the
  shared `SessionStore`'s `get`/`put` has no concurrency contract — two
  surfaces writing the same session concurrently can silently drop an
  answer. That risk didn't exist when the lanes were on separate sessions;
  it's a direct cost of this decision, currently unmitigated.

## Reversibility

Medium. The session-collapse itself (`order_pending_questions` +
`open_gaps` in `_enter_asking_phase`) is a small, isolated diff — easy to
revert. Re-splitting the dashboard back into a separately-toggled view is a
bigger frontend revert (would need to resurrect the bridge/session-creation
call). Dan's dead per-team code is still present and working, so reverting
to "toggle between two experiences" doesn't require rewriting it from
scratch.

## Open questions for tomorrow morning

1. Do we actually want **one** consolidated dashboard as the sole
   post-routing experience, or should Dan's simpler per-team flow stay
   reachable for some scenario neither of us knew about?
2. Was retiring the toggle/bridge correct, or did it remove something
   intentional about session isolation (e.g. letting someone preview the
   dedup form on a *different* project than the one they're actively
   answering, which the bridge uniquely allowed)?
3. Does the phase-gate widening need tightening once the concurrency
   contract (Beta's I2) is settled — or does settling I2 make this question
   moot?

## References

- ADR-004 (this proposal reverses its "stay independent of #16" decision)
- Jaz's Demo Plan & Ownership Spec §2 (single STATE object flow)
- Beta's `backend-three-diff-reconciliation` review (I2, and the GAP2
  finding from the frontend port's own smoke test)
