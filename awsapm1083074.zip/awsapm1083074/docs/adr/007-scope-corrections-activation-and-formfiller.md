# ADR-007: Scope corrections — drop progressive team activation, defer the real FormFillerModel past the demo

## Status

Accepted — decided directly by Flare, on the record, during tonight's
reconciliation. Not a Sisyphus/Beta judgment call; recorded here for
traceability, not for debate.

## Date

2026-07-17

## Context

Two scope questions came up while reconciling #13/#16/#18 tonight, both
resolved directly by the accountable owner rather than left ambiguous:

1. `feature/form-filler-agent` had grown an undocumented
   `_sync_activated_teams` behavior — recomputing activated teams and
   pending governance questions progressively on every routing turn,
   instead of gating them behind `all_routing_fields_present()` the way
   daplan §2 and every other branch (`np01_rnp`, #16) does. It was added
   while building the FormFillerAgent scaffolding, scoped to
   `demo_mode=False` only, and never reconciled against the actual agreed
   plan.
2. Whether to build the real, EHAP-backed `FormFillerModel` (today:
   `StubFormFillerModel`, returns `"stub-filled answer"`) before tomorrow's
   demo, or ship on Jaz's already-working `prefill.py` instead.

## Decision

1. **Drop `_sync_activated_teams` entirely.** It never matched the agreed
   plan (daplan §2's single gate: all 40 routing fields, then the rule
   engine activates every team at once), was never present on `np01_rnp` or
   #16, and was scope drift from building the FormFillerAgent scaffolding —
   not a deliberate, reviewed improvement. `_enter_asking_phase`'s non-demo
   branch now matches #16's own version of the same function exactly.
2. **Ship tomorrow's demo on Jaz's `prefill.py`** (already working,
   verbatim-quote grounding gate, merged via #12/#18/#16). The real
   `FormFillerModel` stays a stub. Flare's own framing, verbatim: *"We
   proceed with Jaz's working system. After we ship a working solution, we
   assess what we would GAIN by pivoting to FormFillerModel."* — explicitly
   open that the answer might be "nothing": the FormFillerAgent
   envelope/contract work may have been built before anyone had actually
   read what Jaz's system already did.

## Alternatives Considered

### (for #2) Build a real `FormFillerModel` tonight, wire it in ahead of the demo
**Why not chosen**: Jaz's `prefill.py` already does the job — grounded LLM
pre-fill, tested, working against the real dashboard, verified live tonight
(real batched Anthropic calls through the EHAP simulator, real accept/dismiss
flow). There was no evidence the FormFillerModel's confidence-score approach
adds anything `prefill.py`'s verbatim-quote-grounding gate doesn't already
cover. Building it anyway, without that evidence, would have repeated the
exact "engineered before understood" pattern this decision exists to name
and avoid — and ADR-003 already documents this project hitting that pattern
once tonight from the other direction (Phase B built ahead of agreed scope).

## Consequences

### Positive
- Less code shipped before anyone confirmed it's needed.
- Matches the actual agreed plan (daplan §2) instead of a branch-local
  deviation that was never reviewed.

### Negative / Follow-up
- The FormFillerAgent contract/stub/eval-harness work (#13) still merged as
  real, tested infrastructure — it's not exercised by tomorrow's demo path.
  Whether it's worth finishing is an explicit post-demo decision this ADR
  deliberately does not answer.
- `_sync_activated_teams`'s test file (`test_handler.py`, 4 tests covering
  partial activation, answer preservation, accumulation, and demo no-op) was
  deleted along with the method. If progressive activation turns out to be
  wanted later, it needs to be rebuilt and re-reviewed, not restored — its
  removal here was because it was never agreed, not because progressive
  activation is a bad idea in general.

## Reversibility

High on both counts. `_sync_activated_teams` is fully deleted (its
rationale is preserved here and in git history, not just gone) — reviving
progressive activation means rewriting and re-reviewing it, not
re-enabling a flag. The `FormFillerModel` work is dormant, not destroyed,
and can be picked up post-demo with no rework of tonight's reconciliation —
Jaz's `state_adapter.py` already speaks the `FormFillerEnvelope` shape at
its boundary (ADR-004) specifically so this swap-in stays cheap whenever it
happens.

## References

- Jaz's Demo Plan & Ownership Spec §2 (the single-gate flow), §4 Phase B
  framing
- `docs/form_filler_agent_contract.md`
- ADR-003 (parallel "built ahead of the agreed scope" pattern — same
  lesson, opposite branch)
- ADR-004 (`envelope_from_session`/`FormFillerEnvelope` boundary that keeps
  a future real `FormFillerModel` swap-in cheap)
