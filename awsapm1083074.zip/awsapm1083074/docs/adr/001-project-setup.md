# ADR 001: Project structure and environment setup

## Status

Accepted

## Context

The governance intake agent began as a prototype (`intake-agent`) with a flat
`src/` module layout, `requirements.txt`/pip, a bundled React UI, and local
Terraform samples. We are moving it into a structured, collaboration-ready
repository to be retrofitted into the customer's existing repo (`AWSAPM1083074`)
so multiple engineers can work on it and it can be productionalized with less
rework.

The customer environment imposes specific constraints:

- **Source control:** Bitbucket.
- **CI/CD & infra:** self-hosted **Terraform Enterprise** at
  `cps-terraform.anthem.com`, VCS-driven, auto-triggering on merge to the
  `np01` branch. There is no separate application CI system in scope.
- **Terraform auth:** the existing `provider.tf` authenticates via **Vault**;
  the TFE workspace owns state and the backend.
- **Local execution:** Python tests run locally (no in-repo pipelines).

## Decision

1. **Adopt the repo-init production-ready standards** for the Python backend:
   uv + `pyproject.toml`, `src/` layout, ruff (lint + format), mypy strict,
   pytest, pre-commit hooks, a Makefile task interface, and ASH for security
   scanning.
2. **Package name `governance_intake`** under `backend/src/`. The flat
   prototype modules became a real package; config JSON is bundled under
   `governance_intake/data/` and resolved relative to the package.
3. **No in-repo CI pipeline files.** CI/CD is externally managed. `make hooks`
   and `make test` are the local quality gate. Merges to `np01` drive TFE runs.
4. **Terraform: customer repo is the source of truth.** This repo contributes
   only the **new** resources the app needs (a DynamoDB sessions table and an
   S3 attachments bucket) as snippets under `infra/terraform/`, to be merged
   into the customer's TFE-managed repo. We do not define `provider.tf` or a
   backend/`cloud` block here — the customer repo owns Vault auth and the TFE
   workspace configuration. The TFE workspace working directory should point at
   the merged Terraform location.
5. **Frontend deferred.** The React UI stays in a separate tree for now. The
   server can serve a built frontend if `INTAKE_UI_DIST` is set.
6. **No AWS required by default.** Sessions default to in-memory and
   attachments to local disk; DynamoDB/S3 are opt-in once provisioned via TFE.

## Consequences

- **Easier:** consistent onboarding, automated quality gates, absolute imports
  that work identically locally and in containers, a clear place for infra and
  docs, and a low-friction path from prototype to production.
- **Harder / follow-ups:**
  - mypy strict on code migrated from an untyped prototype may require
    incremental typing or per-module overrides; these are documented where
    applied.
  - The Terraform merge is a manual step on the customer machine (see
    `infra/terraform/TRANSPLANT.md`): reconcile resource-name collisions with
    the existing `s3.tf`/`dynamodb.tf`, keep the customer's `provider.tf`, and
    confirm the `module.mandatory_tags` reference resolves in that workspace.
  - The frontend is not yet integrated into the repo's build.
