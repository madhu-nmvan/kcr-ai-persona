# Trigger-Logic Completion — Design Decisions, Assumptions & Open Items

Compiled 2026-07-15. This is the transparency doc for the engineering-team
review of the trigger-logic expansion on branch
`feature/complete-team-trigger-rules` (forked from `np01_rnp`). It records
**every** design decision, assumption, and open question so the team can judge
whether the approach is in the right direction — not just what changed.

Companion to `TRIGGER_RULES_INTEGRATION.md` (the prior guardrails pass),
`QUESTION_LIST_VERIFICATION.md` (the independent re-ingest that scoped this
work), and `DATA_GAPS.md` (source-availability gaps). Where those docs left an
open item, this doc says what was done about it.

Everything here traces to a specific source: a team's
`extracted_questions/<slug>/questions.txt` trigger block (itself extracted from
the DOCX §5 trigger-logic section), a field in `intake_schema.json` /
`govhub_catalog_fields.json`, or the `Gov Team Reqs by Service Catalog
Types.xlsx`. No trigger condition is guessed.

---

## 1. Scope and headline outcome

**Goal (this branch): 100%-correct trigger logic.** The DOCX defines trigger
conditions for **30** governance teams. Before this work `trigger_rules.json`
encoded **13**. It now encodes **29** — the 13 pre-existing plus **16 new** —
leaving exactly **1 blocked** (OAGC, no source field). `rule_engine.py` gained
one new DSL operator (`at_least`). `intake_schema.json` grew from 23 to **40**
required Phase-1 fields; `RoutingFields` + the Phase-1 prompt in
`intake_agent.py` were resynced to match.

**Not in scope (this branch): question coverage (Goal 2).** Per the 2026-07-15
decision, the XLSX per-team questionnaire ingestion is owned by a separate
teammate. That work **already landed** on `np01_rnp` (commits `033b64d`
"Extract per-team questions from the Gov Team Reqs xlsx" and `e7b268a` "Merge
xlsx-primary questions into the dedup generator"), which is why this branch was
forked from `np01_rnp` rather than continuing the old feature branch — so the
trigger logic sits on top of the real question data. See §7.

**Verification:** `uv run pytest backend/tests/unit` → **70 passed** (was 17
at the start; the delta is new per-rule tests plus the teammate's dedup tests
now sharing the branch). End-to-end routing confirmed via `verify.py`'s pure
pipeline (`INTAKE_SKIP_LLM=1`): 40/40 required fields resolvable, 19 teams
activate for the bundled Medicare-claims scenario, no rule-eval errors.

---

## 2. What was implemented (with source citations)

Each rule is `review_phase: 1` unless noted (see §4 for the phase rationale).
"Source" is the team's `extracted_questions/<slug>/questions.txt` trigger
block; coded IDs (`PI.8`, `GI.9`, …) are the DOCX's own citation scheme.

### 2.1 The one new operator — `at_least`

Compliance-Technology is the only team whose DOCX trigger is a **count**, not a
boolean combination: *"If any TWO of these questions = YES, then trigger."*
None of the existing operators (`equals/in/contains/any_of/truthy/all/any/not`)
express a threshold, so a minimal new operator was added to the DSL:

```
{"at_least": [n, [cond, ...]]}   ->  at least n of the conditions are true
```

Declared in `trigger_rules.json`'s `operators` block and the `rule_engine.py`
docstring; implemented next to `all`/`any`. It composes with existing
conditions (each element is a full DSL condition), so it needed no special
casing. This is the only DSL surface-area change.

### 2.2 The 16 new rules

| Team | Phase | DOCX trigger (source) | Encoding |
|---|---|---|---|
| EDOM | 1 | PI.4 OR PI.11 OR PI.12 OR MPI.1 OR MPI.13 OR MPI.18 | `any` of the 6 mapped fields = true |
| Clinical Partnership Review | 1 | PI.8 = YES | `truthy: use_of_clinical_data` |
| Corporate Communications | 1 | GI.1=Prod AND (MPI.4 OR MPI.5) | `all[Prod, any[stakeholder_value, abrasive…]]` |
| Legal - Data Governance & Privacy | 1 | D.6 OR D.9 | `any[sending_receiving_protected_information, PHI_PI_PFI_use]` |
| Legal - Intellectual Property (IP) | 1 | GI.9 OR GI.10 | `any[any_of manners_of_use[…], new_novel_PI_use]` |
| Legal-Tech-Novel or High Risk Tech | 1 | GI.11 OR GI.12 OR GI.16 | `any[new_novel_technology, high_risk_use_potential, new_or_different_deployment_type, new_altered_business_proccess]` |
| Legal-Tech-Commercialization | 1 | GI.9 | `any_of manners_of_use[…]` |
| OCCO | 1 | GI.1=Prod AND MPI.1 AND MPI.9 | `all[Prod, impacts_members_providers, truthy consumer_impacts]` |
| On-Prem/Private Hosting | 1 | GI.1=Prod AND D.3 ∈ {Cloud Instance, Kyndryl} | `all[Prod, any_of target_deployment_hosting[Cloud Instance, Kyndryl]]` |
| Payment Card Industry (PCI) | 1 | D.5 = YES | `equals use_of_payment_information_data true` |
| Anthem Federal Employees Program (FEP) | 1 | GI.1=Prod AND LOB.1=FEP | `all[Prod, equals deployment_line_of_business "FEP"]` |
| WellPoint Federal | 1 | GI.1=Prod AND LOB.1=WellPoint | `all[Prod, equals deployment_line_of_business "WellPoint Federal"]` |
| National Government Solutions (NGS) | 1 | GI.1=Prod AND LOB.1=NGS | `all[Prod, any_of lines_of_business_for_deployment["Commercial NGS"]]` |
| Federal Government Solutions (FGS) Home Office | 1 | GI.1=Prod AND LOB.1=FGS | `all[Prod, any_of lines_of_business_for_deployment["Commercial – FGS"]]` |
| Compliance-Technology | 1 | any TWO of {GI.13, PI.1, D.3, D.9, AI.1, +2 NEW} = YES | `at_least[2, […7 conditions…]]` |
| Enterprise Standards Governance (ESG) | 1 | (New SW OR Newly-deployed SW) AND (Pilot/PROD) AND (unapproved SW OR vendor service) | `all[any[…], in[…], any[…]]` — **flagged, see §5** |

EDOM field map (all six already in `intake_schema.json`): PI.4→`vendor_data_access`,
PI.11→`involves_contacting_delegates_vendors_behalf_EH`,
PI.12→`risk_of_heath_care_fraud_waste_abuse`, MPI.1→`impacts_members_providers`,
MPI.13→`violates_CMS_state_program_requirements`,
MPI.18→`involves_digital_health_member_outcomes`.

Compliance-Technology's 7 conditions: GI.13→`regulatory_reputational_risks`,
PI.1→`vendor_use`, D.3→`truthy target_deployment_hosting`, D.9→`PHI_PI_PFI_use`,
AI.1→`involves_ai_ml_llm`, NEW→`changes_regulated_functions`,
NEW→`potential_for_compliance_issue`.

### 2.3 Required-field promotion + agent resync

Per the established convention (a field is `required:true` if a trigger reads it
or it's session identity — see `TRIGGER_RULES_INTEGRATION.md` §2/§5.4), the new
rules' inputs were promoted from `required:false`. **17** were promoted (see
§3.3 for why only 17 of 21); `intake_schema.json` now has 40 required fields.
`RoutingFields` in `intake_agent.py` was extended to exactly those 40 fields,
and `ROUTING_SYSTEM_PROMPT` gained topic bullets for the new subjects so Phase 1
actually collects them (otherwise the Phase-1 → Phase-2 gate could never be
satisfied).

---

## 3. Design decisions and rationale

### 3.1 Reuse the existing DSL; add exactly one operator

15 of the 16 rules were expressible with operators already in the file. Only
Compliance-Technology's "any TWO" needed new capability, so `at_least` is the
only addition. No rule was reshaped to avoid an operator, and no speculative
operators were added. This keeps the DSL small and the diff auditable.

### 3.2 Citations live in the docs, not inline in the JSON

The DOCX/XLSX citation for every rule is in this doc's §2.2 table (and the prior
docs), **not** as a `_source` key inside `trigger_rules.json`. Rationale: the
existing rules carry no inline annotation, and the team's established citation
pattern is the markdown docs (`TRIGGER_RULES_INTEGRATION.md` cites
`document.xml` paragraphs in tables). An early draft added `_source` keys; they
were removed to match convention. **Open for discussion** if the team prefers
inline provenance.

### 3.3 "Required" only where every project can answer

Blindly promoting all 21 rule-consumed fields to `required:true` would have made
Phase 1 **uncompletable**, because 4 of them are conditional enums with no valid
answer for a typical project:

| Field | Why it can't be universally required | Kept |
|---|---|---|
| `deployment_line_of_business` | enum {FEP, WellPoint Federal} — a Medicare project has no valid value | `required:false` |
| `use_of_clinical_data` | enum {Care Mgmt, Outreach, Engagement} — no "none" option | `required:false` |
| `what_type_technology_gov_request` | enum {Pilot, PROD} — excludes POC projects | `required:false` |
| `consumer_impacts` | array; an empty selection ("no consumer impact") is indistinguishable from "unanswered", which `missing_required_fields` treats as incomplete | `required:false` |

The other **17** (15 booleans + `manners_of_use`, which has an explicit "Not
applicable", + `vendor_provided_service`, which has "None") **are** universally
answerable and were promoted. The 4 conditional fields stay wired as routing
inputs (present in `RoutingFields` and the Phase-1 prompt), so their teams still
activate when the agent collects them — they just don't block the gate. This is
a deliberate deviation from the strict convention; see §5 for the [Elevance]
follow-up on `required_when`.

### 3.4 `review_phase` — no source defines it; assigned by convention

**Neither the DOCX nor the XLSX contains a review-phase concept.** Verified: the
DOCX has zero occurrences of "phase/tier/wave"; the XLSX per-team engagement
column ("No / Informed / Approver") does **not** separate the existing
phase-1/phase-2 split (both AI Program Office (phase 1) and EDA ARB (phase 2)
are "Approver"). The existing `review_phase: 2` set — **EDA ARB, Enterprise
Architecture, Security-ESA, Security-VSRM** — is an AWS workflow convention:
**enterprise-architecture and security-architecture review boards** that engage
after initial routing.

All 16 new teams were assigned **phase 1** by direct source-internal analogy to
their existing phase-1 siblings, none being an arch/security board:
- On-Prem/Private Hosting ← Cloud Adoption (both D.3 hosting-target gates)
- Legal-IP / Legal-Tech-Novel / Legal-Tech-Commercialization ← Legal Tech-AI
- PCI / Compliance-Technology ← Security-InfoSec (compliance/security *gates*)
- EDOM / Clinical / Corp Comms / OCCO / ESG / the 4 LOB teams ← routing/regulatory gates

This matches what the user asked for (all phase 1 for now) but is grounded in
the pattern rather than a blind default. See §5 for the [Elevance] confirmation
and the arguable promotions (On-Prem, ESG).

### 3.5 Team-name keys use canonical roster names

The pre-existing rules use short names ("DUE", "EDA ARB", "Legal Tech-AI",
"BU/Regulatory"); the new rules use the `team_roster.json` `canonical_name`
strings ("Legal - Data Governance & Privacy", "Anthem Federal Employees Program
(FEP)", …) because those match the `questionnaires.json` team keys, which is
what makes the Phase-2 fan-out find each team's questions. Confirmed working:
every new team with questionnaire content fans out correctly. The pre-existing
short-name divergence is a latent inconsistency (the trigger→questionnaire join
relies on exact string match); flagged in §5.

### 3.6 Fan-out test reconciled with delegated teams

The teammate's `test_fan_out_fills_every_configured_team_form` asserted
`{teams with a filled form} == set(team_names)` — valid when every activated
team had questionnaire content. My rules can activate **Clinical Partnership
Review**, a delegated team whose only real question is its PI.8 trigger itself
(0 questions in `questionnaires.json`, per `DATA_GAPS.md` §3). The assertion was
refined to "every activated team **that has questionnaire content** gets a
filled form", preserving intent while correctly allowing contentless delegated
teams. `gaps == []` still holds.

---

## 4. Assumptions baked into specific rules

Each of these is a judgment where the source was less than fully explicit. Every
one is pinned by a test so a change is deliberate and visible.

1. **D.3 "any EXCEPT No Data Center Deployment Location"** (Compliance-Tech) →
   `{"truthy": "target_deployment_hosting"}` (a non-empty hosting list). The
   live form's D.3 has no "No Data Center" option in the schema enum, so any
   selection = a real hosting target.
2. **GI.9** (Legal-IP, Legal-Tech-Commercialization) → `any_of manners_of_use`
   over the four "access/data-flow" options, treating "Not applicable" as the
   only non-triggering value.
3. **MPI.9** (OCCO) → `truthy consumer_impacts` — any non-empty consumer-impact
   selection = YES, since the enum options *are* exactly the MPI.9 list.
4. **PI.8** (Clinical) → `truthy use_of_clinical_data` — the enum has no "none"
   value, so any selected value = YES.
5. **NGS / FGS line-of-business values.** The DOCX trigger text says
   "Commercial NGS" and "Federal Government Services (FGS)"; the schema enum has
   `"Commercial NGS"` (exact) and `"Commercial – FGS"` (looser match to "FGS").
   FEP/WellPoint route via the separate `deployment_line_of_business` enum
   because `lines_of_business_for_deployment` has no FEP/WellPoint value (per
   `QUESTION_LIST_VERIFICATION.md` item 1's ⚠). These mappings are the best
   available match, not exact source strings — see §5.
6. **FEP vs WellPoint are mutually exclusive** (single-select
   `deployment_line_of_business`), so no single intake can activate both. Tests
   cover each independently.
7. **ESG's AND/OR grouping** — the single biggest assumption; see §5.

---

## 5. Open items for the engineering team / [Elevance]

Ranked roughly by how much they could change the solution.

1. **ESG trigger grouping — [Elevance].** ESG's DOCX trigger is a flat OR/AND
   list whose operator precedence is genuinely ambiguous. Encoded reading:
   `(new_software OR newly_deployed_software) AND (request type ∈ {Pilot,PROD})
   AND (unapproved software OR vendor_provided_service ∈ {Existing,New})`. The
   grouping is my best reading, not a source-confirmed fact. Confirm the
   intended nesting.
2. **OAGC — blocked, needs a new field — [Elevance]/[AWS].** OAGC triggers on
   nearshore/offshore-resource usage. **No offshore field exists** in
   `intake_schema.json` or the live form. No rule was written (would require
   inventing a field). Needs an offshore-usage field added to the intake before
   OAGC can route. This is the only 1 of 30 teams still unroutable.
3. **`review_phase` assignment — [Elevance].** Confirm the "phase-2 =
   enterprise-arch/security-architecture review boards" convention (§3.4), and
   whether any new team should be promoted to phase 2. The two arguable
   candidates: **On-Prem/Private Hosting** and **ESG (standards board)**. All 16
   are phase 1 today.
4. **40 required Phase-1 fields — conversational-UX risk — [Elevance].**
   `TRIGGER_RULES_INTEGRATION.md` §4 already flagged 23 blocking topics as a lot
   for a "talk like a colleague" flow; this raises it to 40. Two questions: (a)
   is asking a requester to cover 40 topics acceptable, or should some be
   inferred / made optional? (b) The 4 conditional fields held at
   `required:false` (§3.3) would be better modeled with `required_when` (e.g.
   ask `deployment_line_of_business` only when a federal LOB is in play) —
   worth adding if the schema/gate supports conditional requirement cleanly.
5. **GI.15 — genuine unknown — [Elevance].** Appears nowhere in the DOCX, XLSX,
   or live form; exists only as a numbering-gap inference (`DATA_GAPS.md` §1).
   Escalate on its own; not actioned here (per `QUESTION_LIST_VERIFICATION.md`
   item 2, MPI.13/MPI.18/PI.11/PI.12 were resolved as EDOM's trigger set).
6. **NGS/FGS/FEP LOB value matching — [Elevance].** Confirm the enum-value
   mappings in §4 item 5, especially "Commercial – FGS" as the encoding of the
   FGS trigger, and whether the `lines_of_business_for_deployment` /
   `deployment_line_of_business` split is the intended model.
7. **Team-name key convention — [AWS].** Reconcile the pre-existing short names
   (`DUE`, `EDA ARB`, …) with the canonical roster names used by the new rules
   and by `questionnaires.json`. Today the trigger→questionnaire join is by
   exact string; a rename table or a single canonical scheme would remove the
   latent fragility (§3.5).
8. **Inline provenance — team preference.** Whether to add `_source` citation
   keys to `trigger_rules.json` (§3.2). Currently citations are docs-only, per
   convention.

---

## 6. What was intentionally NOT done

- **No OAGC rule** — blocked on a missing source field (§5 item 2). Flagged, not
  faked.
- **No GI.15 action** — genuine unknown, escalated not invented (§5 item 5).
- **No question-coverage / questionnaire ingestion** — Goal 2 is the teammate's
  domain and already merged on `np01_rnp` (§1, §7). This branch deliberately
  touches no `questionnaires.json` / dedup content.
- **No `preseed_map.json` fix** — `TRIGGER_RULES_INTEGRATION.md` §3 flags it as
  fully stale; it's a separate content pass and out of scope here.
- **No `matches`/regex or other speculative operators** — only `at_least`, which
  a real rule needs (§3.1).
- **No change to the pre-existing 13 rules or their phases** — untouched;
  this is purely additive to the trigger set.
- **ESGEVAL and Security-IAM have no rule** — by design: neither has a
  trigger-logic heading in the DOCX (`DATA_GAPS.md` §3), so there is no source
  condition to encode. They are not among the 30 trigger-logic teams.

---

## 7. Branch / migration note

- Work was authored as 5 commits on the old `feature/trigger-rules-guardrails`.
  That branch had already been merged into `np01_rnp`, after which a teammate
  added the XLSX question ingestion and a data regeneration on top of
  `np01_rnp`.
- To land on current reality, a fresh branch **`feature/complete-team-trigger-rules`**
  was forked from `origin/np01_rnp` and the 5 commits cherry-picked onto it,
  plus 1 integration commit (§3.6). The only merge conflict was the
  `test_pipeline.py` fan-out assertion; all rule/schema/engine files were
  conflict-free (the teammate touched none of them).
- Result: a fully up-to-date branch off `np01_rnp` carrying **both** the
  teammate's question data **and** this trigger logic, `70 passed`, ready for
  review before merge back into `np01_rnp`.

Commits (newest first): `Reconcile fan-out test…`, `Promote universally-answerable
trigger inputs…`, `Add ESG rule (flagged grouping)`, `Add at_least + Compliance-
Technology`, `Add 13 Wave-1 rules`, `Add EDOM rule`.
