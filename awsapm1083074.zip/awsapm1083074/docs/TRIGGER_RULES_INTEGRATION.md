# Trigger Rules & Intake Schema Integration — Findings and Decisions

Compiled 2026-07-15 by Jeremy.Scherer (AWS). Every item below is grounded
in a specific file/line reference against the current repo contents — none
of this is guessed. This is the punch list for [AWS] / [Elevance]
follow-up covering the two zero-review merges into the shared data layer
(`trigger_rules.json` + `intake_schema.json` rewrite, and the Tier-2
question-dedup work), not an engineering TODO.

## 1. trigger_rules.json / intake_schema.json integration bugs (found and fixed)

`backend/src/governance_intake/data/trigger_rules.json` shipped as invalid
JSON — a missing comma inside the `DUE` team's `when` clause — so
`json.load` would have raised on every server and test startup before any
rule ever evaluated. Beyond the parse error, several rule conditions used
the wrong DSL operator shape for the field's actual type. The DSL supported
by `rule_engine.py` is declared in the file's own `operators` block; the
mismatches were:

| Bug | DSL intent | Wrong shape used | Count | Fix |
|---|---|---|---|---|
| List-valued field, wrong op | `any_of` (`[field, [values]]` — value intersects the field's list) | `any` (which expects a list of *conditions*, not `[field, [values]]`) | 5 | Switched to `any_of` |
| Scalar field, wrong op | `equals` (`[field, value]`) | `in` given a bare string instead of a list of options | 3 | Switched to `equals` |
| Text "mentions new" check | (no existing op fit) | `contains` + `pattern` combination — not a real DSL op; typed `contans` once | 3 | New `matches` op (see below) |
| Condition slot | a DSL condition object | a JSON-schema-style validation block (`required` / `pattern` / `minLength` keys) | 1 | Replaced with a real DSL condition |
| Stale field name | current schema field | `uses_vendor` — renamed to `vendor_use` in the schema rewrite, no longer defined in `intake_schema.json` | 1 | Repointed to `vendor_use` |

To express the genuine "does this text mention the word *new*" checks,
`backend/src/governance_intake/rule_engine.py` gained a `matches`
operator, now declared in `trigger_rules.json`'s `operators` block:

```
"matches": "[field, pattern] -> re.search(pattern, str(field)) is not None"
```

All fixes are in place and corroborated by the current file: the five
corrected `any_of` conditions read `data_solution_types`,
`has_business_received_communication`, and `vendor_data_access` (`DUE`),
`vendor_data_access` (`Security-VSRM`), and `lines_of_business_for_deployment`
(`BU/Regulatory`); the three `matches` conditions all use the pattern
`\b[Nn][Ee][Ww]\b` against `new_functionality` (`DUE`, `Security-InfoSec`,
`Security-ESA`); `Cloud Adoption` now uses `in` correctly against a list of
options for `target_deployment_hosting`; and `Procurement` checks
`vendor_use`. All 13 teams defined in `trigger_rules.json` evaluate without
error.

Update (second pass, 2026-07-15): the `matches` operator described above,
and all three of its usages, were removed once cross-checked against the
live GovHub intake form — see §5. All three usages tested
`new_functionality` for the substring "new", which turned out to be a
misreading of `GI.1`'s own question wording rather than a real condition;
`rule_engine.py` no longer defines `matches`, and it is gone from
`trigger_rules.json`'s `operators` block. This paragraph remains an
accurate record of what was found and fixed at the time — the fix itself
did not survive the second pass.

Tag: **[AWS]** — implementation-level fix, no further action needed;
informational record only.

## 2. intake_schema.json required-field scope mismatch

The schema rewrite defines 46 routing fields in
`backend/src/governance_intake/data/intake_schema.json`. Only 23 are marked
`"required": true`, and those 23 are exactly the routing-gate contract that
Phase 1 enforces: `schema_check.py`'s `missing_required_fields` blocks the
Phase 1 → Phase 2 transition on any field with `"required": true` (or a
satisfied `required_when`) that is still absent. The 23 required fields —
21 read by `trigger_rules.json` conditions plus `project_name` /
`project_description`, which are session identity, not trigger inputs — are:

| # | Field | Type | Schema description (verbatim) |
|---|---|---|---|
| 1 | `project_name` | string | Short project name. |
| 2 | `project_description` | string | 1-2 sentence description of what the project does. |
| 3 | `involves_ai_ml_llm` | bool | Does the project use AI, ML, or LLM technology? |
| 4 | `new_use_of_ai` | bool | Is this project identified as a project with new use of artificial intelligence? |
| 5 | `level_of_development` | enum: POC / Pilot / Production | Maturity stage of the project. |
| 6 | `new_functionality` | string | What is the new functionality the project provides? |
| 7 | `target_deployment_hosting` | enum: ElevanceHealth Hosted / ElevanceHealth Cloud Instance / Kyndryl Managed | What are the target/deployment hosting environment(s) for this request? |
| 8 | `vendor_use` | bool | Does the project use a vendor to either support development or to deliver the solution (e.g. contractors, consultants, SaaS provider, cloud service provider, AI service (LLMs))? |
| 9 | `PHI_PI_PFI_use` | bool | Does the project collect or use PHI, PI or PFI data? |
| 10 | `stakeholder_value` | bool | Does this project request have a significant benefit to any stakeholders? |
| 11 | `abrasive_to_providers_customers_members` | bool | Will this request be abrasive to providers, customers, or members? |
| 12 | `data_solution_types` | array of string (unique) | What data will the solution leverage for training, input, or access in any way? Please select all that apply. |
| 13 | `new_or_different_deployment_type` | bool | Will this project deploy something in a new or unique way that differs from its original or traditional intent or purpose? |
| 14 | `has_business_received_communication` | array of string (unique) | Is it identified that business received a communication in any manner from a regulator or lawyer? Please select all that apply. |
| 15 | `vendor_data_access` | array of string (unique) | Does the project identify that vendors/delegates will have access to Private Health Information (PHI), Protected Information (PI), Private Financial Information (PFI), or any other sensitive information? |
| 16 | `external_data_release` | bool | Does the project include an external data release? |
| 17 | `within_data_use_release_policy` | bool | Is the project within the compliance of the Data Use and Release policy (DU & RP)? |
| 18 | `accesses_enterprise_data_platforms` | bool | Does this request entail access to enterprise data platforms? |
| 19 | `architectural_material_change` | bool | Will the project request require creation or migration of databases or material change to existing architecture? |
| 20 | `sending_receiving_protected_information` | bool | Does this projecc send or receive Protected Information from external entities? |
| 21 | `lines_of_business_for_deployment` | array of string (unique) | Please identify the specific lines of business for deployment of the solution (Choose any of the following). |
| 22 | `identify_vendors_to_PI` | string | Which vendor(s) have access to Protected Information? |
| 23 | `business_use_case` | bool | Does the project include a clear business usecase? |

Descriptions are quoted verbatim, including source typos left intact (e.g.
`projecc` in #20) and the unmatched paren in `data_solution_types`'
first option `"MCID (Master Consumer Identifier"` — verbatim source data,
not corrected here.

The remaining 23 fields arrived `"required": true` in the merged rewrite
and have been relaxed to `"required": false` (field *definitions* retained).
As `"required": true` in the Phase-1 gate they would have blocked every
session from ever reaching Phase 2, since `rule_engine.py` reads none of
them for team activation and they read as team-specific deep-dive
compliance questions rather than universal routing-gate questions:

| Field | Type | Note |
|---|---|---|
| `ai_ml_llm_business_use_case_fit` | bool | |
| `deployment_line_of_business` | enum: FEP / WellPoint Federal | |
| `use_of_clinical_data` | enum: Care Management / Outreach Program Enrollment / Engagement | |
| `regulatory_reputational_risks` | bool | |
| `changes_regulated_functions` | bool | |
| `potential_for_compliance_issue` | bool | |
| `new_altered_business_proccess` | bool | |
| `involves_contacting_delegates_vendors_behalf_EH` | bool | |
| `risk_of_heath_care_fraud_waste_abuse` | bool | |
| `impacts_members_providers` | bool | |
| `violates_CMS_state_program_requirements` | bool | |
| `involves_digital_health_member_outcomes` | bool | |
| `new_software` | bool | |
| `newly_deployed_software` | bool | |
| `what_type_technology_gov_request` | enum: Pilot / PROD | |
| `use_of_previously_unapproved_software` | bool | |
| `vendor_provided_service` | enum: Existing / New / None | |
| `manners_of_use` | array of string (unique) | |
| `new_novel_PI_use` | bool | |
| `new_novel_technology` | bool | |
| `high_risk_use_potential` | bool | |
| `consumer_impacts` | array of string (unique) | |
| `use_of_payment_information_data` | bool | |

**Resolved: `business_use_case`.** The `AI Program Office` rule activates
when `involves_ai_ml_llm` **and** `business_use_case` are both true, or
when `new_use_of_ai` **and** `business_use_case` are both true — so this
field is a real trigger input, not a team-specific deep-dive question. In
the merged rewrite it carried no `"required"` key at all (silently
optional despite gating a trigger). Per the same rule applied to the other
22 required fields ("required if a trigger reads it, or it's session
identity"), it has been set `"required": true` here and added to
`RoutingFields` in `intake_agent.py` (section 4) — `AI Program Office` now
activates deterministically whenever its documented conditions are met,
confirmed via `verify.py`'s pure-function pipeline.

Update (second pass, 2026-07-15): the resolution above did not survive
contact with the live GovHub form. `business_use_case` turned out not to
be a real trigger input after all — `AI Program Office`'s condition was
repointed to `ai_ml_llm_business_use_case_fit` instead, the closer textual
match to the docx's actual trigger wording — so `business_use_case` is
`"required": false` again, and `ai_ml_llm_business_use_case_fit` is now
`"required": true`. `new_functionality` also dropped to
`"required": false` (it was only ever read by the now-removed `matches`
branches — see §1 / §5), replaced in the required set by
`new_altered_business_proccess` (now read by `Enterprise Architecture`).
Net count is still 23 required fields. See §5 for the current
authoritative list and full rationale; the table above is left as an
accurate record of the first pass's state, not the current state.

Open question:
- Are the remaining 23 relaxed fields genuinely meant to be asked of every
  requester up front — in which case the real GovHub intake form should
  confirm that, and `trigger_rules.json` may be missing rules that consume
  them — or are they per-team deep-dive questions that belong in
  `questionnaires.json` (this repo's Phase-2 per-team question bank)? Tag:
  **[Elevance]** to confirm intent against the real form; **[AWS]** to
  migrate the 23 into `questionnaires.json` once confirmed, if that is the
  answer.

Cross-reference: `docs/DATA_GAPS.md` section 1 already flags that the master
GovHub intake form itself has not been supplied — this is the same
underlying gap surfacing again from the schema side.

## 3. preseed_map.json is fully stale

`backend/src/governance_intake/data/preseed_map.json` maps Phase-1 routing
answers onto Phase-2 canonical dedup questions so a routing answer
auto-fills the matching detailed question at the phase transition
(`handler.py`'s `_preseed_from_routing`). All 9 of its mappings are dead
against the current data layer:

| routing_field | Target | Target status | routing_field status |
|---|---|---|---|
| `project_description` | `DEDUP.PROJECT` | Missing from `dedup_mapping.json` | Exists in schema |
| `data_types` | `DEDUP.DATA_TYPES` | Missing from `dedup_mapping.json` | Gone (renamed) |
| `vendor_name` | `DEDUP.VENDOR` | Missing from `dedup_mapping.json` | Gone (renamed) |
| `externally_connected` | `DEDUP.EXTERNAL_CONN` | Missing from `dedup_mapping.json` | Gone (renamed) |
| `external_ingress` | `DEDUP.EXTERNAL_INGRESS` | Missing from `dedup_mapping.json` | Gone (renamed) |
| `cloud_environment` | `DEDUP.CLOUD_TIER` | Missing from `dedup_mapping.json` | Gone (renamed) |
| `level_of_development` | source `AIPO.3` | Exists in `questionnaires.json` | Exists in schema |
| `lines_of_business` | source `BUR.1` | Missing from `questionnaires.json` | Gone (renamed) |
| `offshore_resources` | source `OFF.1` | Missing from `questionnaires.json` | Gone (renamed) |

The 6 `DEDUP.*` targets it names do not exist. `dedup_mapping.json`'s real
30 canonical IDs — produced by the Tier-2 dedup extraction — use a
different naming scheme entirely (e.g. `DEDUP.PHI_ENCRYPTED_BOTH`,
`DEDUP.WHO_AUTHORIZED_ACCESS`, `DEDUP.AI_SOLUTION_MAKE`). Of the 3 mappings
that target a `source_question_id`, only `AIPO.3` still exists in
`questionnaires.json`; `BUR.1` and `OFF.1` are absent. Additionally, 7 of
the 9 `routing_field` names referenced (`data_types`, `vendor_name`,
`externally_connected`, `external_ingress`, `cloud_environment`,
`lines_of_business`, `offshore_resources`) no longer exist in
`intake_schema.json` after the rename — only `project_description` and
`level_of_development` remain.

Net effect: this is a silent no-op today, not a crash.
`_preseed_from_routing` skips any mapping whose `routing_field` is absent
from the collected fields, and any mapping whose target ID isn't found in
the pending questions — so every one of the 9 mappings is skipped. The
auto-fill feature is effectively dead. It is only reachable via the
non-demo flow (`demo_mode=False`); the default demo flow does not call it.

Fixing this needs a content pass matching the 22 current routing fields
against the 30 real canonical dedup questions where a genuine
correspondence exists. It was not attempted here: it requires judgment
about which routing answer legitimately pre-fills which detailed question,
not a mechanical rename. Tag: **[AWS]** follow-up.

## 4. intake_agent.py resynced

The `RoutingFields` pydantic model in
`backend/src/governance_intake/intake_agent.py` that drives live LLM
extraction, and its accompanying Phase-1 system prompt, still targeted the
pre-rewrite placeholder schema (`docs/DATA_GAPS.md` records the prior
`intake_schema.json` as 14 fields). The stale model carried field names
that no longer exist in the rewritten schema — `uses_vendor`,
`vendor_name`, `data_types`, `cloud_environment`, `externally_connected`,
`external_ingress`, `esg_posture`, `offshore_resources`,
`lines_of_business`, `member_provider_impact`, `vendor_access_phi` — so
extraction produced keys the rule engine never reads and omitted the real
required fields. The model and prompts have been resynced to the 23 real
required fields listed in section 2 (including `business_use_case`, added
to both the schema and the model in the same pass — see section 2's
resolved note).

Flag for **[Elevance]**: asking a requester to naturally cover 23 topics in
a short conversational flow is a materially bigger ask than the original
set. The Phase-1 prompt's stated goal is to "Talk like a helpful colleague,
not a form. Keep replies short (2-4 sentences)." Worth a product-side
sanity check on whether that conversational UX still holds up at 23
blocking topics, or whether some of the 23 should be reconsidered as
optional or inferred rather than gating Phase 1.

## 5. Second pass: validated against the live GovHub intake form

Compiled 2026-07-15 by Jeremy.Scherer (AWS), same day as sections 1-4, after
the actual live GovHub ServiceNow catalog item ("TGOV Catalog Item -
Governance Hub") was obtained, saved as HTML, and parsed deterministically
into `backend/src/governance_intake/data/govhub_catalog_fields.json` — 135
fields, 118 carrying a coded ID (`GI.1`, `D.3`, `PI.4a`, etc.) that lines up
with the docx's own citation scheme. Per an explicit decision: the docx
describes how the team understands the intake today; the live form is now
the authoritative source for exact field type and behavior wherever the
two disagree. Everything below was re-checked against that file (and, for
the DATA_GAPS.md cross-reference, against the raw source HTML directly),
not carried over from the first pass unverified.

### 5.1 `GI.1` and the `matches` operator

The live form's `GI.1` ("What is this new functionality or other
development request for (POC, Pilot, Production)?") is a strict
single-select `choice` field with exactly three options — "Proof of
Concept...", "Pilot...", "Production..." — and no free-text component. The
`matches(new_functionality, "new")` OR-branches added in section 1's first
pass, meant to formalize a "mentions the word new" check against `GI.1`,
were themselves based on a misreading: the word "new" in "what is this
**new** functionality" is wording inside the question's own prompt text,
not a condition the form ever asks the requester to answer. All three
usages (`Security-InfoSec`, `Security-ESA`, `DUE`) have been removed;
each of those rules now checks only `{"equals": ["level_of_development",
"Production"]}`. With no genuine use case left, the `matches` operator
itself has been removed from `rule_engine.py` and from
`trigger_rules.json`'s `operators` doc block, rather than kept as
speculative unused capability.

Tag: **[AWS]** — implementation-level fix, corroborated against the live
form; no further action needed.

### 5.2 Field-type mismatches found against the live form (4, fixed)

Cross-referencing every trigger-backing field's real widget type (from
`govhub_catalog_fields.json`) against `intake_schema.json` found four
mismatches:

| Field | Was | Live-form field | Fix |
|---|---|---|---|
| `target_deployment_hosting` | `type: enum` (scalar) | `D.3`, `widget_type: glide_list`, `multi_select: true` | `type: array, uniqueItems: true`, same 3 option values |
| `vendor_data_access` | `type: array` (options: PHI / PI / Other Sensitive Info) | `PI.4`, `widget_type: choice`, options `["Yes","No"]` | `type: bool` |
| `has_business_received_communication` | `type: array` (options: Regulator / Lawyer) | `LOB.3`, `widget_type: choice`, options `["Yes","No"]` | `type: bool` |
| `identify_vendors_to_PI` | `type: string` (free text) | `PI.4a`, `widget_type: glide_list`, `multi_select: true`, options AJAX-loaded (not statically enumerable) | `type: array, uniqueItems: true`, no fixed `enums` (options are dynamic vendor names) |

All 4 confirmed against `intake_schema.json`'s current field definitions.

Tag: **[AWS]** — implementation-level fix, corroborated against the live
form; no further action needed.

### 5.3 Trigger condition corrections

- **`AI Program Office`**: both OR-branches' second clause was repointed
  from `business_use_case` to `ai_ml_llm_business_use_case_fit` — the
  docx's trigger clause ("Is this the right use of AI for the Business Use
  case") maps to the fit-assessment field, not the existence-of-a-use-case
  field. Confirmed: the live form has **no** field matching either wording
  of that clause at all — searched `govhub_catalog_fields.json` for
  "business use case" / "right use" / "fit" in every field label, no hit.
  This may be a reviewer-side judgment call rather than a
  requester-facing question, so the fix is a best-textual-match against
  the two schema fields available, not a live-form-confirmed fact. Tag:
  **[Elevance]** — confirm whether this clause should be a
  requester-facing routing field at all, and if so, whether it needs its
  own live-form field.
- **`DUE`**: `within_data_use_release_policy` had inverted polarity — the
  docx says `DUE` triggers when the project is **not** within Data Use and
  Release Policy compliance (`= NO`); the rule read
  `{"equals": ["within_data_use_release_policy", true]}`. Fixed to
  `{"equals": ["within_data_use_release_policy", false]}`, confirmed
  against `data_use_enablement_due`'s extracted trigger text ("`D.8` ...
  compliance? = NO").
- **`Cloud Adoption`**: was missing a `level_of_development == "Production"`
  AND-clause the docx requires alongside the hosting-target check (its own
  extracted trigger text ANDs `D.3` with `GI.1 = Production`). Added; the
  rule's `when` is now `all: [` hosting `any_of`, `level_of_development ==
  "Production" ]`.
- **`Enterprise Architecture`**: was using `EDA ARB`'s conditions
  (`accesses_enterprise_data_platforms` / `architectural_material_change`)
  — a copy-paste bug, not its own condition. Its extracted trigger text
  cites only `GI.16`; the live form's `GI.16` ("Will this request enable
  new/altered business process and/or capabilities?") is a plain Yes/No
  field that maps directly to the schema's `new_altered_business_proccess`.
  Fixed to `{"equals": ["new_altered_business_proccess", true]}`. `EDA ARB`
  itself was already correct and is unchanged.

Tag: **[AWS]** for all four — implementation fixes, corroborated against
the live form or the docx's own extracted trigger text; **[Elevance]**
carried forward on `AI Program Office` only, per above.

### 5.4 Required-field rebalancing

Same rule as section 2 ("required" only if a trigger reads it, or it's
session identity): `business_use_case` (no longer read by any trigger) →
`false`; `new_functionality` (only ever read by the now-removed `matches`
branches) → `false`; `ai_ml_llm_business_use_case_fit` (now read by `AI
Program Office`) → `true`; `new_altered_business_proccess` (now read by
`Enterprise Architecture`) → `true`. Net required-field count is unchanged
at 23. Read directly from the current `intake_schema.json`, the
authoritative 23 are: `PHI_PI_PFI_use`,
`abrasive_to_providers_customers_members`,
`accesses_enterprise_data_platforms`, `ai_ml_llm_business_use_case_fit`,
`architectural_material_change`, `data_solution_types`,
`external_data_release`, `has_business_received_communication`,
`identify_vendors_to_PI`, `involves_ai_ml_llm`, `level_of_development`,
`lines_of_business_for_deployment`, `new_altered_business_proccess`,
`new_or_different_deployment_type`, `new_use_of_ai`,
`project_description`, `project_name`,
`sending_receiving_protected_information`, `stakeholder_value`,
`target_deployment_hosting`, `vendor_data_access`, `vendor_use`,
`within_data_use_release_policy`. This supersedes section 2's table for
current state (section 2 remains an accurate record of the first pass).

Verified end-to-end via manual smoke test: all 13 teams in
`trigger_rules.json` still activate against a realistic fully-populated
fields dict using the new types (`target_deployment_hosting` /
`identify_vendors_to_PI` as lists, `vendor_data_access` /
`has_business_received_communication` as bools, no `business_use_case` /
`new_functionality`, includes `ai_ml_llm_business_use_case_fit` /
`new_altered_business_proccess`); empty fields activate nothing; `DUE`
specifically verified to **not** fire when the project is policy-compliant
(the polarity fix).

Tag: **[AWS]** — implementation-level fix, verified; no further action
needed.

### 5.5 `DATA_GAPS.md` §1 coded-ID resolution

`EXTRACTION_MANIFEST.md` lists 24 docx-cited coded IDs that were, before
this extraction, "not represented in `intake_schema.json` at all": `D.1,
D.4, D.5, D.7, D.8, DU.2, RBI.7, V.3, GI.9, GI.10, GI.11, GI.12, GI.13,
GI.16, MPI.4, MPI.5, MPI.9, MPI.13, MPI.18, PI.4a, PI.8, PI.11, PI.12,
LOB.3`. Adding the two further `GI`-family numbering gaps `DATA_GAPS.md`
§1 separately flags within that same family (`GI.14`, `GI.15` — neither
cited anywhere in the extracted per-team trigger text) gives a 26-ID set.
Checked each against `govhub_catalog_fields.json`'s `coded_id` values: 21
now resolve to a real live-form field — `D.1, D.4, D.5, D.7, D.8, DU.2,
RBI.7, V.3, GI.9, GI.10, GI.11, GI.12, GI.13, GI.14, GI.16, MPI.4, MPI.5,
MPI.9, PI.4a, PI.8, LOB.3`. The remaining 5 — `GI.15, MPI.13, MPI.18,
PI.11, PI.12` — are confirmed genuinely absent from this specific catalog
item, not an extraction miss: a raw substring search directly against the
saved source HTML (`backend/scripts/source/govhub_form/TGOV Catalog Item -
Governance Hub.html`) finds none of the 5 literal ID strings anywhere in
the page.

Open question: whether those 5 IDs live on a different GovHub catalog item
or workflow step than the one captured, or genuinely no longer exist on
the live form. Tag: **[Elevance]** to confirm.
