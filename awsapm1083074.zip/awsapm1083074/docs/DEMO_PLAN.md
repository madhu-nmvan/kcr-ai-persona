# Demo Plan — Post-Dedup Experience (aligned to Jeremy's #13, independent of Dan's #16)

**Date:** 2026-07-16 · **Demo:** tomorrow (VP/C-suite) · **Owner:** Jaz
**Source of truth:** stand-up transcript (scope) + Jeremy's `docs/form_filler_agent_contract.md` (data contract, PR #13).

## Decisions locked this session

1. **Contract = Jeremy's `FormFillerEnvelope` (#13), not the #12 placeholder.**
   Jeremy built his contract *from Jaz's spec* and left the session/UI
   integration to this lane. We conform to `triggers`/`governance` with
   `id/text/value/origin/confidence` + `sources`.
2. **Dan's #16 is NOT an agreed base.** It unilaterally migrates the frontend to
   TypeScript (violates CLAUDE.md "no TypeScript") and its per-team layout does
   not render the dedup story. We do **not** rebase onto it. Jaz's post-dedup
   surface stays plain **JSX** (convention-compliant). UI-ownership overlap with
   Dan is a coordination item for Jeremy, not a blocker.
3. **Phase B stays deferred** (transcript AC3). Prefill is delegated to Jeremy's
   `fill_form`; ordering/QA agent are out for the demo.

## Keep / Rework from PR #12

Owner directive (2026-07-17): **respect the work — nothing is deleted.** The
realignment is additive at the contract boundary. Phase B is retained (it is
the foundation for the documented end-goal), just not exercised by the demo.

| Module | Action | Status | Why |
|---|---|---|---|
| `postdedup.py` (completeness, submit, stats, record_answers) | **Keep** | done | Builds on `build_pending_questions` (shape unchanged in #13); deterministic gate is demo-critical |
| `PostDedupView.jsx` (form + source badges + before/after stats) | **Keep** | done | The differentiated demo surface; the "money shot" #13+#16 don't render. Stays JSX (CLAUDE.md convention) |
| `docs/DEDUP_AUDIT.md` + `audit_dedup.py` | **Keep** | done | Standalone value; feeds Jeremy's corpus cleanup (#6–#9) |
| `specs/EPIC-001-*.md` | **Keep** | done | Already delivered value (Jeremy's contract cites it) |
| `state_adapter.py` | **Rework (additive)** | ✅ done | Now parses Jeremy's `FormFillerEnvelope` on input + emits it via `envelope_from_session`; placeholder path retained. See ADR-004 |
| `postdedup.begin_session` | **Rework (additive)** | ✅ done | Seeds prior governance answers from the envelope, decoupled from his `build_pending_questions` signature |
| `postdedup_api.py` | **Extend** | ✅ done | Added `GET /sessions/{id}/envelope` round-trip endpoint |
| `sampleState.js` | **Rework** | ✅ done | Now a real FormFillerEnvelope so the demo posts the actual contract |
| `prefill.py` | **Keep, defer at integration** | branch-retained | Works offline for the demo's prefilled-with-provenance; at integration, prefill defers to Jeremy's `fill_form` (envelope round-trip is wired) |
| `question_order.py`, `qa_review.py` | **Keep (Phase B)** | branch-retained | The end-goal foundation (order-to-imply, one-by-one, QA pass). Off the demo path; ordering is a benign reorder |
| `llm_provider.py` seam | **Keep, reconcile at merge** | branch-retained | Endorsed by WORKFLOW.md; conflicts with #13/#16 on `intake_agent.py` — Jeremy reconciles at the Bitbucket merge |
| `ehap-mock/` + wire tests | **Keep** | branch-retained | Redundant with Jeremy's `StubFormFillerModel` but harmless; retire post-merge if duplicative |

## The demo deliverable (smallest path to the transcript's goal)

A post-dedup form surface that, given Jeremy's envelope:
1. Renders the **consolidated deduped** question set — each canonical **once**.
2. Shows **source badges** per question (`source_teams`, hover → `sources[{team, question_id}]`) — the visual proof that N team questionnaires collapsed into one. *(Transcript AC2; Gan's headline.)*
3. Shows a **before/after stat** (raw team-question count → consolidated count).
4. Shows prefilled answers with provenance (`origin=agent`, `confidence`), editable, never silently committed.
5. Deterministic completeness → submit → existing ticket fan-out.

## Concrete steps

1. ✅ **`state_adapter.py`** parses `FormFillerEnvelope` in and emits it out (`envelope_from_session`); `answered` dropped at the boundary, `sources` kept; placeholder path retained. Tests added (both ways).
2. ✅ **`begin_session`** seeds prior governance answers from the envelope (decoupled helper). Phase B **retained** (owner directive); ordering left as a benign reorder.
3. ✅ **Round-trip wired**: `GET /sessions/{id}/envelope` emits the contract shape to POST to Jeremy's `/api/formfiller/fill`. (Full prefill-defers-to-fill_form swap happens at integration, once #13 is on `np01_rnp`.)
4. ✅ **`sampleState.js`** is now a real FormFillerEnvelope; `PostDedupView.jsx` (badges + before/after stat) verified against the shape via `_view`.
5. ✅ **Verified**: 149 unit tests green (`pytest -m "not integration"`); offline end-to-end (envelope → 8 teams → 1013 deduped questions → contract envelope out → agent-fill round-trip re-seeds).

### Remaining before the demo (needs a running app / teammate coordination)
- Drive the UI end-to-end in the browser (`make run` + `cd frontend && npm run dev`) against the new sample envelope — confirm badges + before/after stat + prefilled-provenance render.
- Jeremy: reconcile #13 ↔ #16 on `handler.py`/`intake_agent.py`/`server.py`; decide the demo UI (Jaz JSX vs Dan #16 TS).

## Open coordination items (need Jeremy, not blocking Jaz's build)

- Which UI ships for the demo — Jaz's JSX post-dedup surface vs Dan's #16 3-column TS. (User: #16 not agreed.)
- #13 and #16 conflict with each other on `handler.py`/`intake_agent.py`/`server.py` — Jeremy (lead) reconciles before any combined merge.
- `/api/formfiller/fill` is stub-backed; real EHAP model is Jeremy's follow-up.

## Explicitly out of scope for the demo
Real EHAP wiring · question ordering intelligence · QA/counselor agent · frontend TS migration · corpus cleanup (#6–#9).
