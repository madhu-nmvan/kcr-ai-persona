# Terraform — infra/terraform

Snippets for the self-hosted Terraform Enterprise workspace
(`cps-terraform.anthem.com`, VCS-driven off `np01`) that backs the intake
agent. This is **not** a standalone root module — see
[`TRANSPLANT.md`](TRANSPLANT.md) for the merge procedure into the customer's
real TFE-managed repo.

## Additive resources (this app's own infra)

| File | Adds |
|---|---|
| `dynamodb.tf` | `aws_dynamodb_table.intake_sessions` (`govhub-intake-sessions`) — one item per conversation session |
| `s3.tf` | `aws_s3_bucket.intake_attachments` (`govhub-intake-attachments`) + versioning/SSE/public-access-block/CORS — solution-diagram and supporting-doc uploads |

These two are what actually get merged into the customer repo per
`TRANSPLANT.md`.

**Naming note:** `TRANSPLANT.md`'s merge steps refer to these by the names
`intake_sessions.tf` / `intake_attachments.tf` (distinct filenames chosen not
to collide with the customer's own `.tf`). The files are checked in here as
`dynamodb.tf` / `s3.tf` instead — same resources, different filenames. Rename
on merge to match `TRANSPLANT.md`'s instructions, or reconcile the doc to the
actual filenames, before relying on the doc's copy-step wording literally.

## The other four files

`provider.tf`, `lambda.tf`, `notebook.tf`, `sagemaker.tf` are **not** part of
the additive merge above — `TRANSPLANT.md` explicitly says this repo adds no
`provider.tf` (the customer workspace owns Vault auth/backend), and the root
[`README.md`](../../README.md#infrastructure) describes this folder as
containing "only the new resources this app adds" (the two files above).

**Open item:** these four files are nonetheless present on disk and
undocumented by any doc in this repo. `docs/adr/001-project-setup.md`
mentions "the existing `provider.tf`" in passing (consistent with them being
a local snapshot of the customer's pre-existing TFE resources, kept for
context/local `terraform validate`), but nothing confirms that read or
explains why `lambda.tf` / `notebook.tf` / `sagemaker.tf` are here. Confirm
intent (keep as reference, or remove as stale) before the next transplant —
don't assume either way from this README alone.
