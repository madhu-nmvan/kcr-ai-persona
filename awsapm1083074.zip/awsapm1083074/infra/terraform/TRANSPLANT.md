# Terraform transplant / merge guide

These files are **additive resources** the intake agent needs. They are meant
to be merged into the customer's existing Terraform Enterprise (TFE) repo
(`AWSAPM1083074`) — they are **not** a standalone Terraform root.

| File | Adds |
|------|------|
| `intake_sessions.tf`     | `aws_dynamodb_table.intake_sessions` (`govhub-intake-sessions`, PAY_PER_REQUEST, streams on) + outputs |
| `intake_attachments.tf`  | `aws_s3_bucket.intake_attachments` (`govhub-intake-attachments`) + versioning, SSE, public-access-block, CORS + outputs |

## What this repo intentionally does NOT contain

- **No `provider.tf`** — the customer repo owns it (Vault auth).
- **No backend / `cloud {}` block** — the TFE workspace owns state.
- **No region / variables** — inherited from the customer workspace.

Do not add any of the above here; they would conflict with the customer repo.

## Merge steps (on the customer machine, in `AWSAPM1083074`)

1. **Copy the two files** into the same directory as the existing `.tf` files
   (where `provider.tf`, `dynamodb.tf`, `s3.tf` live). The filenames are
   distinct (`intake_sessions.tf`, `intake_attachments.tf`) so they will not
   overwrite the existing `dynamodb.tf` / `s3.tf`.

2. **Check for resource-name collisions.** Terraform keys resources by
   `type.name`, not by filename. Confirm the existing repo has no
   `aws_dynamodb_table "intake_sessions"` or `aws_s3_bucket "intake_attachments"`.
   If it does, rename the ones added here.

3. **Check the bucket name is globally unique.** `govhub-intake-attachments`
   may already be taken or may not match the customer's naming standard.
   Adjust the `bucket = "..."` value (and keep the app's
   `INTAKE_ATTACHMENTS_BUCKET` env in sync).

4. **Confirm `module.mandatory_tags.tags` resolves.** Both files reference it
   the way the repo's existing resources do. If the module is named
   differently in this workspace, update the `tags =` line to match.

5. **Confirm the TFE workspace working directory.** If you place the app's
   Terraform under a subdirectory, set the workspace's "Terraform Working
   Directory" accordingly. If you merge these files into the existing flat
   layout, no change is needed.

6. **Plan via TFE.** Commit to a work branch and merge to `np01` — the
   VCS-driven workspace will trigger a `plan`. Review the plan (expect: one new
   DynamoDB table, one new S3 bucket + its config resources) before `apply`.

## IAM (managed by the customer)

The role the app runs under (e.g. the SageMaker execution role) needs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "IntakeSessionsReadWrite",
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:UpdateItem",
        "dynamodb:DeleteItem", "dynamodb:Scan", "dynamodb:Query",
        "dynamodb:DescribeTable", "dynamodb:BatchGetItem", "dynamodb:BatchWriteItem"
      ],
      "Resource": [
        "arn:aws:dynamodb:*:*:table/govhub-intake-sessions",
        "arn:aws:dynamodb:*:*:table/govhub-intake-sessions/index/*"
      ]
    },
    {
      "Sid": "IntakeAttachmentsReadWrite",
      "Effect": "Allow",
      "Action": ["s3:PutObject", "s3:GetObject", "s3:HeadObject"],
      "Resource": "arn:aws:s3:::govhub-intake-attachments/*"
    },
    {
      "Sid": "IntakeAttachmentsListBucket",
      "Effect": "Allow",
      "Action": "s3:ListBucket",
      "Resource": "arn:aws:s3:::govhub-intake-attachments"
    }
  ]
}
```

## Application config after apply

The app defaults to no AWS (in-memory sessions, local-disk attachments). To use
the provisioned resources, set:

```bash
export INTAKE_SESSION_BACKEND=dynamodb
export INTAKE_DDB_TABLE=govhub-intake-sessions
export INTAKE_DDB_REGION=us-east-1          # match the workspace region
# leave INTAKE_DDB_AUTO_CREATE unset/0 - the table is TFE-managed

export INTAKE_ATTACHMENTS_BACKEND=s3
export INTAKE_ATTACHMENTS_BUCKET=govhub-intake-attachments
export INTAKE_ATTACHMENTS_REGION=us-east-1
```
