# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

# ========== Variables (auto-populated from TFE workspace) ==========
variable "apm-id" {}
variable "application-name" {}
variable "app-support-dl" {}
variable "app-servicenow-group" {}
variable "business-division" {}
variable "company" {}
variable "costcenter" {}
variable "PatchGroup" {}
variable "PatchWindow" {}
variable "workspace" {}
variable "elvh-apm-id" {}
variable "elvh-app-env" {}
variable "elvh-app-servicenow-group" {}
variable "elvh-app-support-dl" {}
variable "elvh-application-name" {}
variable "elvh-business-division" {}
variable "elvh-ci-owner" {}
variable "elvh-company" {}
variable "elvh-costcenter" {}
variable "elvh-infra-env" {}
variable "elvh-workspace" {}

# ========== Mandatory Tags ==========
module "mandatory_tags" {
  source  = "cps-terraform.anthem.com/CORP/terraform-aws-mandatory-tags-v2/aws"
  version = "0.0.3"

  apm-id               = var.apm-id
  application-name     = var.application-name
  app-support-dl       = var.app-support-dl
  app-servicenow-group = var.app-servicenow-group
  business-division    = var.business-division
  company              = var.company
  compliance           = "PHI"
  costcenter           = var.costcenter
  environment          = "SIT"
  PatchGroup           = "Default"
  PatchWindow          = "Default"
  workspace            = var.workspace

  elvh-apm-id               = var.elvh-apm-id
  elvh-app-env              = var.elvh-app-env
  elvh-app-servicenow-group = var.elvh-app-servicenow-group
  elvh-app-support-dl       = var.elvh-app-support-dl
  elvh-application-name     = var.elvh-application-name
  elvh-business-division    = var.elvh-business-division
  elvh-ci-owner             = var.elvh-ci-owner
  elvh-company              = var.elvh-company
  elvh-costcenter           = var.elvh-costcenter
  elvh-infra-env            = var.elvh-infra-env
  elvh-workspace            = var.elvh-workspace

  tags = {}
}

# ========== IAM Role ==========
# NOTE: source might need to be cps-terraform-dev.anthem.com if prod doesn't have this module
module "iam-role" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-iam-role/aws"

  iam_role_name             = "sagemaker_govhub_execution"
  role_description          = "SageMaker execution role for Governance Hub"
  managed_policy_arns       = ["arn:aws:iam::aws:policy/AmazonSageMakerFullAccess"]
  assume_role_service_names = ["sagemaker.amazonaws.com", "s3.amazonaws.com", "kms.amazonaws.com", "elasticfilesystem.amazonaws.com"]

  tags = module.mandatory_tags.tags
}

# ========== SageMaker Domain ==========
module "sagemaker_domain" {
  source  = "cps-terraform.anthem.com/CORP/terraform-aws-sagemaker-domain/aws"
  version = "1.0.0"

  create_sagemaker_domain                  = true
  sagemaker_domain_name                    = "gov-automation-studio-v2"
  sagemaker_domain_auth_mode               = "IAM"
  sagemaker_domain_vpc_id                  = "vpc-093a6c8844c18280d"
  sagemaker_domain_subnet_ids              = ["subnet-0cc25fcafc0aa60d9", "subnet-0083f9e27f6ef667f"]
  sagemaker_domain_kms_key_id              = module.kms-key.kms_arn["elasticfilesystem"]
  sagemaker_domain_app_network_access_type = "VpcOnly"
  sagemaker_app_security_group_management  = "Service"

  default_user_settings = [
    {
      execution_role = module.iam-role.iamrole_arn
    }
  ]

  tags = module.mandatory_tags.tags
}

resource "aws_sagemaker_user_profile" "default" {
  domain_id         = module.sagemaker_domain.domain_id
  user_profile_name = "aws-ai-gov-automate"

  user_settings {
    execution_role = module.iam-role.iamrole_arn
  }

  tags = module.mandatory_tags.tags
}

module "kms-key" {
  source  = "cps-terraform.anthem.com/CORP/terraform-aws-kms-service/aws"
  version = "1.0.6"

  description   = "KMS Key for SageMaker"
  service_name  = ["s3", "sagemaker", "elasticfilesystem"]
  kms_alias_name = "sagemaker-govhub"
  tags          = module.mandatory_tags.tags
}