# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

module "iam-notebook" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-iam-role/aws"

  tags                      = module.mandatory_tags.tags
  iam_role_name             = "SageMakerNotebook-GovHub"
  role_description          = "SageMaker notebook for governance hub dev"
  assume_role_service_names = ["sagemaker.amazonaws.com"]
  aws_create_iam_role       = true
  managed_policy_arns       = ["arn:aws:iam::aws:policy/AmazonSageMakerFullAccess"]
  max_session_duration      = "25000"
}

module "sagemaker-notebook" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-sagemaker-notebook-instance/aws"

  tags            = module.mandatory_tags.tags
  name            = "govhub-dev"
  role_arn        = module.iam-notebook.iamrole_arn
  instance_type   = "ml.t3.medium"
  subnet_id       = "subnet-0cc25fcafc0aa60d9"
  security_groups = ["sg-01a49d1463918fc6f"]
  kms_key_id      = module.kms-key.key_id["sagemaker"]
  platform_identifier = "notebook-al2-v3"
}