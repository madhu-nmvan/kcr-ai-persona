# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

module "lambda-role" {
  source = "cps-terraform.anthem.com/CORP/terraform-aws-iam-role/aws"

  iam_role_name             = "lambda_govhub_execution"
  role_description          = "Lambda execution role for Governance Hub"
  managed_policy_arns       = ["arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"]
  assume_role_service_names = ["lambda.amazonaws.com"]

  tags = module.mandatory_tags.tags
}

data "archive_file" "lambda_zip" {
  type        = "zip"
  output_path = "${path.module}/lambda.zip"

  source {
    content  = <<EOF
def lambda_handler(event, context):
    a = event.get('a', 0)
    b = event.get('b', 0)
    return {'statusCode': 200, 'body': a + b}
EOF
    filename = "lambda_function.py"
  }
}

resource "aws_lambda_function" "test" {
  function_name    = "govhub-test-add"
  role             = module.lambda-role.iamrole_arn
  runtime          = "python3.12"
  handler          = "lambda_function.lambda_handler"
  filename         = data.archive_file.lambda_zip.output_path
  source_code_hash = data.archive_file.lambda_zip.output_base64sha256
  tags             = module.mandatory_tags.tags
}