# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

########################################################################
# S3 bucket for governance intake attachments (solution/data-flow diagrams,
# supporting PPTX/PDF/DOCX docs, etc.).
#
# Objects are keyed as:
#   {session_id}/{uuid}__{original_filename}
#
# The application uploads via presigned PUT URLs (browser -> S3 directly),
# so the FastAPI process never buffers file bytes. See src/attachments.py.
########################################################################

resource "aws_s3_bucket" "intake_attachments" {
  bucket = "govhub-intake-attachments"
  tags   = module.mandatory_tags.tags
}

resource "aws_s3_bucket_versioning" "intake_attachments" {
  bucket = aws_s3_bucket.intake_attachments.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "intake_attachments" {
  bucket = aws_s3_bucket.intake_attachments.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "intake_attachments" {
  bucket                  = aws_s3_bucket.intake_attachments.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Presigned URLs are generated with a short expiry (see attachments.py), so
# CORS only needs to allow the browser's direct PUT from wherever the UI is
# served. Tighten allowed_origins to the real app domain once known;
# wildcard is fine for the SageMaker-notebook-proxy demo phase.
resource "aws_s3_bucket_cors_configuration" "intake_attachments" {
  bucket = aws_s3_bucket.intake_attachments.id

  cors_rule {
    allowed_methods = ["PUT", "GET"]
    allowed_origins = ["*"]
    allowed_headers = ["*"]
    max_age_seconds = 3000
  }
}

# Optional: expire attachments after N days if the customer wants automatic
# cleanup of demo/pilot data. Commented out by default — enable if needed.
# resource "aws_s3_bucket_lifecycle_configuration" "intake_attachments" {
#   bucket = aws_s3_bucket.intake_attachments.id
#   rule {
#     id     = "expire-after-90-days"
#     status = "Enabled"
#     expiration {
#       days = 90
#     }
#   }
# }

output "intake_attachments_bucket_name" {
  value       = aws_s3_bucket.intake_attachments.bucket
  description = "S3 bucket name for intake attachments."
}

output "intake_attachments_bucket_arn" {
  value       = aws_s3_bucket.intake_attachments.arn
  description = "ARN of the intake attachments bucket."
}
