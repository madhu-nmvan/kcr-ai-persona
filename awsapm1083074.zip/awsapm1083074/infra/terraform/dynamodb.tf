# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

########################################################################
# DynamoDB table for the AI Governance Intake Agent.
#
# Stores one item per conversation session:
#   session_id (PK, S) - unique per session, e.g. "sess-1b5718ba"
# All other session state (chat history, routing fields, activated teams,
# focus team, pending questions, ticket) is packed into a single JSON blob
# in the "data" attribute at write time by the application code. Top-level
# scalar attributes (user_id, phase, updated_at, summary) are also written
# so the history-sidebar scan stays cheap without needing a full-item read.
########################################################################

resource "aws_dynamodb_table" "intake_sessions" {
  name         = "govhub-intake-sessions"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "session_id"

  attribute {
    name = "session_id"
    type = "S"
  }

  # Streams enabled so a future workflow-management agent can react to
  # session state changes (SLA nudges, phase-complete notifications, etc.)
  # without polling.
  stream_enabled   = true
  stream_view_type = "NEW_AND_OLD_IMAGES"

  # Enable if the customer requires PITR on this table.
  # point_in_time_recovery {
  #   enabled = true
  # }

  # Enable if the customer's SSE-KMS policy requires customer-managed keys.
  # server_side_encryption {
  #   enabled     = true
  #   kms_key_arn = data.aws_kms_key.by_alias.arn
  # }

  tags = module.mandatory_tags.tags
}

output "intake_sessions_table_name" {
  value       = aws_dynamodb_table.intake_sessions.name
  description = "DynamoDB table name for intake agent sessions."
}

output "intake_sessions_table_arn" {
  value       = aws_dynamodb_table.intake_sessions.arn
  description = "ARN of the intake sessions table."
}

output "intake_sessions_table_stream_arn" {
  value       = aws_dynamodb_table.intake_sessions.stream_arn
  description = "Stream ARN for downstream consumers (e.g. workflow agents)."
}
