# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""prefill: grounding gate, proposal staging, skip-LLM behavior."""

from __future__ import annotations

import pytest

from governance_intake.handler import IntakeData
from governance_intake.postdedup import begin_session
from governance_intake.prefill import (
    PrefillBatch,
    PrefillProposal,
    PrefillProvenance,
    ground,
    propose_prefills,
    run_prefill,
)


@pytest.fixture(scope="module")
def data() -> IntakeData:
    return IntakeData()


class FakeAgent:
    """Returns a canned PrefillBatch; records the prompts it was given."""

    def __init__(self, batches):
        self.batches = list(batches)
        self.prompts = []

    def structured_output(self, model_cls, prompt):
        assert model_cls is PrefillBatch
        self.prompts.append(prompt)
        return self.batches.pop(0) if self.batches else PrefillBatch()


def _proposal(cid, answer, kind, ref, quote):
    return PrefillProposal(
        canonical_id=cid,
        answer=answer,
        provenance=PrefillProvenance(kind=kind, ref=ref, quote=quote),
    )


# ---------------------------------------------------------------------------
# ground()
# ---------------------------------------------------------------------------

MESSAGES = ["We process Medicare claims with an LLM hosted on AWS Bedrock."]
FIELDS = {"involves_ai_ml_llm": True, "cloud_provider": "AWS", "lobs": ["Medicare", "Medicaid"]}
PRIOR = {"DEDUP.X": "The model is retrained quarterly."}


def test_transcript_quote_must_appear_verbatim():
    ok = _proposal("Q1", "AWS Bedrock", "transcript", "0", "hosted on AWS Bedrock")
    bad = _proposal("Q1", "Azure", "transcript", "0", "hosted on Azure")
    assert ground(ok, MESSAGES, FIELDS, PRIOR)
    assert not ground(bad, MESSAGES, FIELDS, PRIOR)


def test_transcript_grounding_is_case_and_whitespace_insensitive():
    p = _proposal("Q1", "x", "transcript", "0", "  Hosted On   aws bedrock ")
    assert ground(p, MESSAGES, FIELDS, PRIOR)


def test_trigger_field_grounding_checks_field_and_value():
    ok = _proposal("Q1", "AWS", "trigger_field", "cloud_provider", "AWS")
    missing = _proposal("Q1", "AWS", "trigger_field", "nonexistent_field", "AWS")
    mismatched = _proposal("Q1", "GCP", "trigger_field", "cloud_provider", "GCP")
    assert ground(ok, MESSAGES, FIELDS, PRIOR)
    assert not ground(missing, MESSAGES, FIELDS, PRIOR)
    assert not ground(mismatched, MESSAGES, FIELDS, PRIOR)


def test_boolean_and_list_field_values_ground_naturally():
    yes = _proposal("Q1", "Yes", "trigger_field", "involves_ai_ml_llm", "yes")
    lob = _proposal("Q1", "Medicare", "trigger_field", "lobs", "Medicare")
    assert ground(yes, MESSAGES, FIELDS, PRIOR)
    assert ground(lob, MESSAGES, FIELDS, PRIOR)


def test_prior_answer_grounding():
    ok = _proposal("Q2", "Quarterly", "prior_answer", "DEDUP.X", "retrained quarterly")
    unknown = _proposal("Q2", "Quarterly", "prior_answer", "DEDUP.NOPE", "retrained quarterly")
    assert ground(ok, MESSAGES, FIELDS, PRIOR)
    assert not ground(unknown, MESSAGES, FIELDS, PRIOR)


def test_trivially_short_quotes_are_rejected():
    p = _proposal("Q1", "x", "transcript", "0", "We")
    assert not ground(p, MESSAGES, FIELDS, PRIOR)


# ---------------------------------------------------------------------------
# propose_prefills
# ---------------------------------------------------------------------------

OPEN = [
    {"canonical_id": "Q1", "canonical_question": "Where is the model hosted?"},
    {"canonical_id": "Q2", "canonical_question": "What data is processed?"},
]


def test_ungrounded_proposals_are_dropped_and_counted():
    fake = FakeAgent(
        [
            PrefillBatch(
                proposals=[
                    _proposal("Q1", "AWS Bedrock", "transcript", "0", "hosted on AWS Bedrock"),
                    _proposal("Q2", "Fabricated", "transcript", "0", "text never said"),
                ]
            )
        ]
    )
    proposals, rejected = propose_prefills(OPEN, MESSAGES, FIELDS, PRIOR, agent_factory=lambda: fake)
    assert [p.canonical_id for p in proposals] == ["Q1"]
    assert rejected == 1


def test_proposals_for_unknown_questions_are_rejected():
    fake = FakeAgent(
        [PrefillBatch(proposals=[_proposal("NOT_OPEN", "x", "transcript", "0", "Medicare claims")])]
    )
    proposals, rejected = propose_prefills(OPEN, MESSAGES, FIELDS, PRIOR, agent_factory=lambda: fake)
    assert proposals == [] and rejected == 1


def test_empty_answer_proposals_are_rejected():
    fake = FakeAgent(
        [PrefillBatch(proposals=[_proposal("Q1", "   ", "transcript", "0", "Medicare claims")])]
    )
    proposals, rejected = propose_prefills(OPEN, MESSAGES, FIELDS, PRIOR, agent_factory=lambda: fake)
    assert proposals == [] and rejected == 1


def test_batching_splits_llm_calls():
    fake = FakeAgent([PrefillBatch(), PrefillBatch()])
    propose_prefills(OPEN, MESSAGES, FIELDS, PRIOR, batch_size=1, agent_factory=lambda: fake)
    assert len(fake.prompts) == 2
    assert "Q1" in fake.prompts[0] and "Q1" not in fake.prompts[1]
    assert "Q2" in fake.prompts[1]


def test_skip_llm_env_short_circuits(monkeypatch):
    monkeypatch.setenv("INTAKE_SKIP_LLM", "1")
    boom = lambda: (_ for _ in ()).throw(AssertionError("must not be called"))  # noqa: E731
    proposals, rejected = propose_prefills(OPEN, MESSAGES, FIELDS, PRIOR, agent_factory=boom)
    assert proposals == [] and rejected == 0


def test_no_grounding_material_short_circuits():
    boom = lambda: (_ for _ in ()).throw(AssertionError("must not be called"))  # noqa: E731
    proposals, rejected = propose_prefills(OPEN, [], {}, {}, agent_factory=boom)
    assert proposals == [] and rejected == 0


# ---------------------------------------------------------------------------
# run_prefill (session-level)
# ---------------------------------------------------------------------------


def test_run_prefill_stages_proposals_without_committing(data):
    sess = begin_session(
        "sess-p",
        "u1",
        {
            "activated_teams": ["AI Program Office"],
            "messages": [{"role": "user", "content": "The model version number is v2.3."}],
        },
        data,
    )
    target = sess["pending_questions"][0]
    fake = FakeAgent(
        [
            PrefillBatch(
                proposals=[
                    _proposal(
                        target["canonical_id"], "v2.3", "transcript", "0",
                        "The model version number is v2.3.",
                    )
                ]
            )
        ]
        # remaining batches: empty PrefillBatch via FakeAgent default
    )
    summary = run_prefill(sess, agent_factory=lambda: fake)
    assert summary["proposed"] == 1
    assert target["prefill"]["status"] == "proposed"
    assert target["prefill"]["provenance"]["kind"] == "transcript"
    assert not target["answered"]  # staged, not committed


def test_run_prefill_skips_answered_and_already_proposed(data):
    sess = begin_session(
        "sess-q", "u1",
        {"activated_teams": ["AI Program Office"],
         "messages": [{"role": "user", "content": "hello world content"}]},
        data,
    )
    q0, q1 = sess["pending_questions"][:2]
    q0["answered"], q0["answer"] = True, "done"
    q1["prefill"] = {"answer": "x", "provenance": {}, "status": "dismissed"}

    seen = {}

    class RecordingAgent:
        def structured_output(self, model_cls, prompt):
            seen["prompt"] = prompt
            return PrefillBatch()

    run_prefill(sess, agent_factory=RecordingAgent)
    open_section = seen["prompt"].split("Submitter's messages")[0]
    assert q0["canonical_id"] not in open_section
    assert q1["canonical_id"] not in open_section
    # The answered question feeds the prior-answers grounding section instead.
    assert f"[{q0['canonical_id']}] done" in seen["prompt"]


def test_run_prefill_accumulates_rejected_count(data):
    sess = begin_session(
        "sess-r", "u1",
        {"activated_teams": ["AI Program Office"],
         "messages": [{"role": "user", "content": "some real content here"}]},
        data,
    )
    cid = sess["pending_questions"][0]["canonical_id"]
    fake = FakeAgent(
        [PrefillBatch(proposals=[_proposal(cid, "made up", "transcript", "0", "never said this")])]
    )
    summary = run_prefill(sess, agent_factory=lambda: fake)
    assert summary["proposed"] == 0 and summary["rejected"] == 1
    assert sess["prefill_rejected_count"] == 1
