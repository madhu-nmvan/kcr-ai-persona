# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Same-team duplicate consolidation.

Covers the case where a single canonical question consolidates two or more
*source* questions that all belong to the *same* team (as opposed to the
more common cross-team consolidation exercised in test_pipeline.py). The
mechanism under test:

  - question_dedup.build_pending_questions only filters a canonical's sources
    by whether their team is activated; it does not care whether those
    sources share a team or span several.
  - form_mapper.map_answers_to_team_forms writes one answer into every listed
    source's team_forms[team][question_id] slot, so answering a single
    same-team canonical must back-fill *both* of that team's original
    question IDs.

Test 1 anchors this against the real, shipped dedup_mapping.json (regression
guard). Tests 2 and 3 use a hand-built minimal fixture to isolate the
mechanism itself from whatever the real config currently contains.
"""

from __future__ import annotations

from collections import Counter

import pytest

from governance_intake.form_mapper import map_answers_to_team_forms
from governance_intake.gap_detector import detect_gaps
from governance_intake.handler import IntakeData
from governance_intake.question_dedup import build_pending_questions


@pytest.fixture(scope="module")
def data() -> IntakeData:
    return IntakeData()


def test_real_dedup_mapping_has_a_same_team_canonical(data: IntakeData) -> None:
    """
    Regression anchor against the real, shipped dedup_mapping.json: at least
    one canonical entry must consolidate 2+ sources that share a team.

    Written as a structural property (not pinned to specific canonical IDs)
    so it survives an upcoming regeneration of dedup_mapping.json with
    different/renumbered canonical entries -- if the underlying capability
    ever regresses (e.g. someone "fixes" the dedup script to only cluster
    across teams), this test catches it regardless of which IDs exist.
    """
    canonical_questions = data.dedup_mapping["canonical_questions"]

    def has_same_team_duplicate(entry: dict) -> bool:
        team_counts = Counter(src["team"] for src in entry.get("sources", []))
        return any(count >= 2 for count in team_counts.values())

    same_team_entries = [c for c in canonical_questions if has_same_team_duplicate(c)]
    assert same_team_entries, (
        "expected at least one canonical entry whose sources share a team, "
        "found none in the current dedup_mapping.json"
    )


def _synthetic_config() -> tuple[dict, dict]:
    """Minimal hand-built dedup_mapping + questionnaires for one team,
    TestTeam, whose two distinct required questions (TT.1, TT.2) are
    clustered as a same-team duplicate under one canonical."""
    questionnaires = {
        "teams": {
            "TestTeam": {
                "questions": [
                    {"id": "TT.1", "text": "Is this a duplicate question A?", "required": True},
                    {"id": "TT.2", "text": "Is this a duplicate question B?", "required": True},
                ]
            }
        }
    }
    dedup_mapping = {
        "canonical_questions": [
            {
                "canonical_id": "DEDUP.TEST_SAME_TEAM",
                "canonical_question": "Is this a duplicate question?",
                "category": "general",
                "sources": [
                    {"team": "TestTeam", "question_id": "TT.1", "match_type": "exact"},
                    {"team": "TestTeam", "question_id": "TT.2", "match_type": "exact"},
                ],
            }
        ]
    }
    return questionnaires, dedup_mapping


def test_same_team_duplicate_answer_satisfies_both_source_questions() -> None:
    """
    Answering the single consolidated canonical for a same-team duplicate
    must fan out to both of TestTeam's original question IDs and clear both
    from gap detection -- proving one answer fully satisfies both required
    questions end to end, not just one of them.
    """
    questionnaires, dedup_mapping = _synthetic_config()

    pending = build_pending_questions(["TestTeam"], questionnaires, dedup_mapping)
    # The two same-team sources must collapse into exactly one pending
    # question, not two -- this is the crux of consolidation.
    assert len(pending) == 1
    canonical = pending[0]
    assert canonical["canonical_id"] == "DEDUP.TEST_SAME_TEAM"
    assert {src["question_id"] for src in canonical["sources"]} == {"TT.1", "TT.2"}

    canonical["answered"] = True
    canonical["answer"] = "Yes"

    team_forms = map_answers_to_team_forms(pending, ["TestTeam"])
    assert team_forms["TestTeam"]["TT.1"] == "Yes"
    assert team_forms["TestTeam"]["TT.2"] == "Yes"

    gaps = detect_gaps(["TestTeam"], questionnaires, team_forms)
    assert gaps == [], f"unexpected gaps after answering the shared canonical: {gaps}"


def test_unanswered_same_team_duplicate_leaves_both_source_questions_gapped() -> None:
    """
    Contrast case: if the consolidated canonical is never answered, gap
    detection must report *both* original question IDs as missing, not just
    one -- proving consolidation doesn't accidentally hide one of the two
    required questions when the canonical is left unanswered.
    """
    questionnaires, dedup_mapping = _synthetic_config()

    pending = build_pending_questions(["TestTeam"], questionnaires, dedup_mapping)
    assert len(pending) == 1
    # Leave it unanswered (default state from build_pending_questions).

    team_forms = map_answers_to_team_forms(pending, ["TestTeam"])
    assert team_forms["TestTeam"] == {}

    gaps = detect_gaps(["TestTeam"], questionnaires, team_forms)
    gapped_ids = {gap["question_id"] for gap in gaps}
    assert gapped_ids == {"TT.1", "TT.2"}
    assert all(gap["team"] == "TestTeam" and gap["required"] for gap in gaps)


def _two_team_synthetic_config() -> tuple[dict, dict]:
    """Minimal two-team fixture: TeamA has one canonical question (CANON.A),
    TeamB has a separate, unrelated canonical question (CANON.B). Used to
    exercise build_pending_questions' prior_answers parameter across a
    growing activated_teams set."""
    questionnaires = {
        "teams": {
            "TeamA": {"questions": [{"id": "A.1", "text": "Team A question?", "required": True}]},
            "TeamB": {"questions": [{"id": "B.1", "text": "Team B question?", "required": True}]},
        }
    }
    dedup_mapping = {
        "canonical_questions": [
            {
                "canonical_id": "CANON.A",
                "canonical_question": "Team A question?",
                "category": "general",
                "sources": [{"team": "TeamA", "question_id": "A.1", "match_type": "exact"}],
            },
            {
                "canonical_id": "CANON.B",
                "canonical_question": "Team B question?",
                "category": "general",
                "sources": [{"team": "TeamB", "question_id": "B.1", "match_type": "exact"}],
            },
        ]
    }
    return questionnaires, dedup_mapping


def test_prior_answers_omitted_is_byte_identical_to_pre_existing_default() -> None:
    """
    prior_answers is a purely additive parameter: omitting it (the default)
    or passing it explicitly as None must produce exactly the same output as
    before the parameter existed -- every canonical answered=False/answer=None.
    """
    questionnaires, dedup_mapping = _two_team_synthetic_config()
    expected = [
        {
            "canonical_id": "CANON.A",
            "canonical_question": "Team A question?",
            "category": "general",
            "sources": [{"team": "TeamA", "question_id": "A.1", "match_type": "exact"}],
            "source_teams": ["TeamA"],
            "answered": False,
            "answer": None,
        },
        {
            "canonical_id": "CANON.B",
            "canonical_question": "Team B question?",
            "category": "general",
            "sources": [{"team": "TeamB", "question_id": "B.1", "match_type": "exact"}],
            "source_teams": ["TeamB"],
            "answered": False,
            "answer": None,
        },
    ]

    omitted = build_pending_questions(["TeamA", "TeamB"], questionnaires, dedup_mapping)
    explicit_none = build_pending_questions(["TeamA", "TeamB"], questionnaires, dedup_mapping, None)

    assert omitted == expected
    assert explicit_none == expected


def test_prior_answers_preserves_answer_across_growing_activated_teams() -> None:
    """
    A canonical answered while only TeamA was activated must still show
    answered=True with its original answer once TeamB activates too, when
    that answer is passed back in via prior_answers -- and the newly-added
    team's own canonical must come back unanswered, not spuriously leaked
    from TeamA's prior_answers dict.
    """
    questionnaires, dedup_mapping = _two_team_synthetic_config()

    first = build_pending_questions(["TeamA"], questionnaires, dedup_mapping)
    assert len(first) == 1
    assert first[0]["canonical_id"] == "CANON.A"

    prior_answers = {"CANON.A": "Yes, TeamA answer"}
    second = build_pending_questions(
        ["TeamA", "TeamB"], questionnaires, dedup_mapping, prior_answers
    )
    by_id = {q["canonical_id"]: q for q in second}

    assert by_id["CANON.A"]["answered"] is True
    assert by_id["CANON.A"]["answer"] == "Yes, TeamA answer"

    assert by_id["CANON.B"]["answered"] is False
    assert by_id["CANON.B"]["answer"] is None
