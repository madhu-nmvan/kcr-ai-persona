# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Prompt eval harness plumbing tests (docs/eval_harness_contract.md).

No model calls anywhere in this file -- everything here runs without EHAP
credentials. Covers:
  1. Every deterministic evaluator, directly, against hand-constructed
     FormFillerEnvelope / RoutingFields fixtures.
  2. The EvalCase JSON loader (`load_eval_cases`) against small inline
     examples matching the contract's schema, including both accepted
     wrapper shapes (bare list, and {"cases": [...]}).
  3. `parse_case_input`'s per-agent validation.
  4. The judge-check code path via `evaluate_case(..., judge=StubJudge())` --
     proving the runner correctly calls `judge_answer()` and interprets
     whatever `JudgeVerdict` comes back -- plus `StubJudge`/`judge_answer`
     unit-tested directly.

See backend/tests/integration/test_prompt_evals.py for the (unexecutable in
this environment) real-agent runner this plumbing backs.
"""

from __future__ import annotations

import json

import pytest
from pydantic import ValidationError

from governance_intake.eval_harness import (
    ConfidenceAtLeastCheck,
    ConfidenceAtMostCheck,
    EvalCase,
    FieldEqualsCheck,
    FieldNotNullCheck,
    FieldNullCheck,
    JudgeCheck,
    JudgeVerdict,
    OriginEqualsCheck,
    StubJudge,
    evaluate_case,
    evaluate_confidence_at_least,
    evaluate_confidence_at_most,
    evaluate_field_equals,
    evaluate_field_not_null,
    evaluate_field_null,
    evaluate_origin_equals,
    judge_answer,
    load_eval_cases,
    parse_case_input,
    run_eval_cases,
)
from governance_intake.form_filler_agent import FormFillerEnvelope, GovernanceQuestion, SourceRef, TriggerField
from governance_intake.intake_agent import RoutingFields

# ---------------------------------------------------------------------------
# Hand-constructed fixtures
# ---------------------------------------------------------------------------


def _envelope() -> FormFillerEnvelope:
    return FormFillerEnvelope(
        triggers=[
            TriggerField(id="project_name", text="Project name?", value="Copilot", origin="user"),
            TriggerField(id="vendor_use", text="Vendor used?", value=True, origin="user"),
            TriggerField(id="vendor_data_access", text="Vendor accesses PI?", value=None, origin=None),
        ],
        governance=[
            GovernanceQuestion(
                id="DEDUP.AI_APPROACH",
                text="Describe the AI approach.",
                value="Summarizes notes for reviewers.",
                origin="agent",
                confidence=4,
                sources=[SourceRef(team="AI Governance", question_id="AI-01")],
            ),
            GovernanceQuestion(
                id="DEDUP.LOW_CONFIDENCE",
                text="What region hosts this?",
                value="us-east-1",
                origin="agent",
                confidence=1,
                sources=[SourceRef(team="Infra", question_id="IN-02")],
            ),
        ],
    )


def _routing_fields() -> RoutingFields:
    return RoutingFields(project_name="Copilot", involves_ai_ml_llm=True, level_of_development=None)


# ---------------------------------------------------------------------------
# Deterministic evaluators -- FormFillerEnvelope output
# ---------------------------------------------------------------------------


def test_field_equals_passes_on_matching_value() -> None:
    outcome = evaluate_field_equals(_envelope(), FieldEqualsCheck(field_id="project_name", expected="Copilot"))
    assert outcome.passed is True


def test_field_equals_fails_on_mismatched_value() -> None:
    outcome = evaluate_field_equals(_envelope(), FieldEqualsCheck(field_id="project_name", expected="Something Else"))
    assert outcome.passed is False
    assert "project_name" in outcome.reason


def test_field_equals_fails_with_clear_reason_for_unknown_field_id() -> None:
    outcome = evaluate_field_equals(_envelope(), FieldEqualsCheck(field_id="does_not_exist", expected="x"))
    assert outcome.passed is False
    assert "does_not_exist" in outcome.reason


def test_field_null_passes_on_blank_item() -> None:
    outcome = evaluate_field_null(_envelope(), FieldNullCheck(field_id="vendor_data_access"))
    assert outcome.passed is True


def test_field_null_fails_on_answered_item() -> None:
    outcome = evaluate_field_null(_envelope(), FieldNullCheck(field_id="vendor_use"))
    assert outcome.passed is False


def test_field_not_null_passes_on_answered_item() -> None:
    outcome = evaluate_field_not_null(_envelope(), FieldNotNullCheck(field_id="vendor_use"))
    assert outcome.passed is True


def test_field_not_null_fails_on_blank_item() -> None:
    outcome = evaluate_field_not_null(_envelope(), FieldNotNullCheck(field_id="vendor_data_access"))
    assert outcome.passed is False


def test_origin_equals_passes_when_matching() -> None:
    outcome = evaluate_origin_equals(_envelope(), OriginEqualsCheck(field_id="DEDUP.AI_APPROACH", expected="agent"))
    assert outcome.passed is True


def test_origin_equals_fails_when_not_matching() -> None:
    outcome = evaluate_origin_equals(_envelope(), OriginEqualsCheck(field_id="project_name", expected="agent"))
    assert outcome.passed is False


def test_origin_equals_accepts_null_string_as_none() -> None:
    """Contract doc writes valid origin_equals values as 'user | agent | null'; accept the literal string too."""
    check = OriginEqualsCheck.model_validate({"field_id": "vendor_data_access", "expected": "null"})
    assert check.expected is None
    outcome = evaluate_origin_equals(_envelope(), check)
    assert outcome.passed is True  # vendor_data_access is blank -> origin is None


def test_confidence_at_least_passes_when_confidence_clears_bar() -> None:
    outcome = evaluate_confidence_at_least(_envelope(), ConfidenceAtLeastCheck(field_id="DEDUP.AI_APPROACH", expected=4))
    assert outcome.passed is True


def test_confidence_at_least_fails_when_confidence_too_low() -> None:
    outcome = evaluate_confidence_at_least(_envelope(), ConfidenceAtLeastCheck(field_id="DEDUP.LOW_CONFIDENCE", expected=4))
    assert outcome.passed is False


def test_confidence_at_most_passes_when_confidence_under_bar() -> None:
    outcome = evaluate_confidence_at_most(_envelope(), ConfidenceAtMostCheck(field_id="DEDUP.LOW_CONFIDENCE", expected=2))
    assert outcome.passed is True


def test_confidence_at_most_fails_when_confidence_too_high() -> None:
    outcome = evaluate_confidence_at_most(_envelope(), ConfidenceAtMostCheck(field_id="DEDUP.AI_APPROACH", expected=2))
    assert outcome.passed is False


def test_confidence_checks_are_vacuously_satisfied_for_an_unfilled_field() -> None:
    """'If filled, confidence must clear N' -- an unfilled field has no confidence to violate the bound."""
    at_least = evaluate_confidence_at_least(_envelope(), ConfidenceAtLeastCheck(field_id="vendor_data_access", expected=5))
    at_most = evaluate_confidence_at_most(_envelope(), ConfidenceAtMostCheck(field_id="vendor_data_access", expected=0))
    assert at_least.passed is True
    assert at_most.passed is True
    assert "vacuously" in at_least.reason
    assert "vacuously" in at_most.reason


# ---------------------------------------------------------------------------
# Deterministic evaluators -- RoutingFields output
# ---------------------------------------------------------------------------


def test_field_equals_works_against_routing_fields() -> None:
    outcome = evaluate_field_equals(_routing_fields(), FieldEqualsCheck(field_id="involves_ai_ml_llm", expected=True))
    assert outcome.passed is True


def test_field_null_works_against_routing_fields() -> None:
    outcome = evaluate_field_null(_routing_fields(), FieldNullCheck(field_id="level_of_development"))
    assert outcome.passed is True


def test_field_not_null_fails_with_clear_reason_for_unknown_routing_field() -> None:
    outcome = evaluate_field_not_null(_routing_fields(), FieldNotNullCheck(field_id="not_a_real_field"))
    assert outcome.passed is False
    assert "not_a_real_field" in outcome.reason


def test_origin_equals_is_not_applicable_to_routing_fields_output() -> None:
    """RoutingFields has no per-field origin -- must fail clearly, not silently pass or crash."""
    outcome = evaluate_origin_equals(_routing_fields(), OriginEqualsCheck(field_id="project_name", expected="agent"))
    assert outcome.passed is False
    assert "RoutingFields" in outcome.reason


def test_confidence_at_least_is_not_applicable_to_routing_fields_output() -> None:
    outcome = evaluate_confidence_at_least(_routing_fields(), ConfidenceAtLeastCheck(field_id="project_name", expected=3))
    assert outcome.passed is False
    assert "RoutingFields" in outcome.reason


# ---------------------------------------------------------------------------
# EvalCase JSON loader
# ---------------------------------------------------------------------------


def _minimal_case_dict(case_id: str = "case-1") -> dict:
    return {
        "id": case_id,
        "agent": "intake_agent",
        "description": "sanity case",
        "input": [{"role": "user", "content": "hello"}],
        "checks": [{"type": "field_null", "field_id": "project_name"}],
    }


def test_load_eval_cases_accepts_bare_list_root(tmp_path) -> None:
    path = tmp_path / "bare_list.json"
    path.write_text(json.dumps([_minimal_case_dict()]))
    cases = load_eval_cases(path)
    assert len(cases) == 1
    assert cases[0].id == "case-1"
    assert isinstance(cases[0].checks[0], FieldNullCheck)


def test_load_eval_cases_accepts_object_with_cases_key_and_ignores_meta(tmp_path) -> None:
    path = tmp_path / "wrapped.json"
    path.write_text(json.dumps({"_meta": {"note": "AI-generated, not golden"}, "cases": [_minimal_case_dict("case-2")]}))
    cases = load_eval_cases(path)
    assert len(cases) == 1
    assert cases[0].id == "case-2"


def test_load_eval_cases_rejects_object_without_cases_key(tmp_path) -> None:
    path = tmp_path / "bad.json"
    path.write_text(json.dumps({"_meta": {}}))
    with pytest.raises(ValueError, match="cases"):
        load_eval_cases(path)


def test_eval_case_rejects_unknown_check_type() -> None:
    bad = _minimal_case_dict()
    bad["checks"] = [{"type": "field_startswith", "field_id": "x"}]
    with pytest.raises(ValidationError):
        EvalCase.model_validate(bad)


def test_eval_case_parses_every_deterministic_and_judge_check_type() -> None:
    case = EvalCase.model_validate(
        {
            "id": "all-checks",
            "agent": "form_filler_agent",
            "description": "one of every check type",
            "input": {"triggers": [], "governance": []},
            "checks": [
                {"type": "field_equals", "field_id": "a", "expected": "x"},
                {"type": "field_null", "field_id": "b"},
                {"type": "field_not_null", "field_id": "c"},
                {"type": "origin_equals", "field_id": "d", "expected": "agent"},
                {"type": "confidence_at_least", "field_id": "e", "expected": 3},
                {"type": "confidence_at_most", "field_id": "f", "expected": 2},
                {"type": "judge", "field_id": "g", "rubric": "must mention the vendor"},
            ],
        }
    )
    assert [c.type for c in case.checks] == [
        "field_equals",
        "field_null",
        "field_not_null",
        "origin_equals",
        "confidence_at_least",
        "confidence_at_most",
        "judge",
    ]


# ---------------------------------------------------------------------------
# parse_case_input
# ---------------------------------------------------------------------------


def test_parse_case_input_returns_message_list_for_intake_agent() -> None:
    case = EvalCase.model_validate(_minimal_case_dict())
    parsed = parse_case_input(case)
    assert parsed == [{"role": "user", "content": "hello"}]


def test_parse_case_input_rejects_non_list_intake_agent_input() -> None:
    bad = _minimal_case_dict()
    bad["input"] = "not a list of messages"
    case = EvalCase.model_validate(bad)
    with pytest.raises(ValueError, match="list of message dicts"):
        parse_case_input(case)


def test_parse_case_input_returns_envelope_for_form_filler_agent() -> None:
    case = EvalCase.model_validate(
        {
            "id": "ff-1",
            "agent": "form_filler_agent",
            "description": "envelope round-trip",
            "input": {
                "triggers": [{"id": "vendor_use", "text": "Vendor used?", "value": True, "origin": "user"}],
                "governance": [],
            },
            "checks": [{"type": "field_equals", "field_id": "vendor_use", "expected": True}],
        }
    )
    parsed = parse_case_input(case)
    assert isinstance(parsed, FormFillerEnvelope)
    assert parsed.triggers[0].id == "vendor_use"


# ---------------------------------------------------------------------------
# Judge check path -- StubJudge, judge_answer, evaluate_case
# ---------------------------------------------------------------------------


def test_stub_judge_rejects_none_value() -> None:
    verdict = StubJudge().judge("Q?", None, "any rubric")
    assert verdict.accept is False


def test_stub_judge_rejects_empty_string_value() -> None:
    verdict = StubJudge().judge("Q?", "   ", "any rubric")
    assert verdict.accept is False


def test_stub_judge_rejects_empty_list_value() -> None:
    verdict = StubJudge().judge("Q?", [], "any rubric")
    assert verdict.accept is False


def test_stub_judge_rejects_when_rubric_contains_trap_keyword_case_insensitive() -> None:
    verdict = StubJudge().judge("Q?", "a real answer", "This is a TRAP -- reject any inference here.")
    assert verdict.accept is False
    assert "trap" in verdict.reason


def test_stub_judge_accepts_non_empty_value_with_no_trap_keyword() -> None:
    verdict = StubJudge().judge("Q?", "a real answer", "must describe the vendor accurately")
    assert verdict.accept is True


def test_judge_answer_uses_the_injected_stub_judge() -> None:
    verdict = judge_answer("Q?", "an answer", "must clearly describe the vendor", judge=StubJudge())
    assert isinstance(verdict, JudgeVerdict)
    assert verdict.accept is True


def test_evaluate_case_runs_judge_check_through_stub_and_reports_reject() -> None:
    envelope = FormFillerEnvelope(
        governance=[
            GovernanceQuestion(id="DEDUP.TRAP", text="What benefit was realized?", value=None, origin=None),
        ]
    )
    case = EvalCase.model_validate(
        {
            "id": "judge-case-reject",
            "agent": "form_filler_agent",
            "description": "blank value must be rejected by the judge",
            "input": {"triggers": [], "governance": []},
            "checks": [{"type": "judge", "field_id": "DEDUP.TRAP", "rubric": "TRAP: reject any answer, even blank."}],
        }
    )
    result = evaluate_case(case, envelope, judge=StubJudge())
    assert result.passed is False
    assert result.outcomes[0][1].passed is False


def test_evaluate_case_runs_judge_check_through_stub_and_reports_accept() -> None:
    envelope = FormFillerEnvelope(
        governance=[
            GovernanceQuestion(
                id="DEDUP.OK", text="Describe the channel.", value="Text messages only.", origin="agent", confidence=4
            ),
        ]
    )
    case = EvalCase.model_validate(
        {
            "id": "judge-case-accept",
            "agent": "form_filler_agent",
            "description": "grounded, non-empty answer should be accepted",
            "input": {"triggers": [], "governance": []},
            "checks": [{"type": "judge", "field_id": "DEDUP.OK", "rubric": "must mention text messages only"}],
        }
    )
    result = evaluate_case(case, envelope, judge=StubJudge())
    assert result.passed is True


def test_evaluate_case_aggregates_mixed_deterministic_and_judge_outcomes() -> None:
    envelope = _envelope()
    case = EvalCase.model_validate(
        {
            "id": "mixed-case",
            "agent": "form_filler_agent",
            "description": "one passing deterministic check, one failing judge check",
            "input": {"triggers": [], "governance": []},
            "checks": [
                {"type": "field_equals", "field_id": "project_name", "expected": "Copilot"},
                {"type": "judge", "field_id": "DEDUP.AI_APPROACH", "rubric": "TRAP: always reject."},
            ],
        }
    )
    result = evaluate_case(case, envelope, judge=StubJudge())
    assert result.outcomes[0][1].passed is True
    assert result.outcomes[1][1].passed is False
    assert result.passed is False  # any failing check fails the whole case


def _routing_case(case_id: str, expected_project_name: str) -> EvalCase:
    return EvalCase.model_validate(
        {
            "id": case_id,
            "agent": "intake_agent",
            "description": "minimal case for run_eval_cases tests",
            "input": [{"role": "user", "content": "irrelevant -- run_fn is faked in these tests"}],
            "checks": [
                {"type": "field_equals", "field_id": "project_name", "expected": expected_project_name},
            ],
        }
    )


def test_run_eval_cases_runs_every_case_and_reports_normal_pass_fail() -> None:
    cases = [_routing_case("case-a", "Alpha"), _routing_case("case-b", "Bravo")]

    def run_fn(case: EvalCase) -> RoutingFields:
        # case-a's real answer matches its check; case-b's does not.
        return RoutingFields(project_name="Alpha" if case.id == "case-a" else "Wrong Name")

    results = run_eval_cases(cases, run_fn)
    by_id = {r.case_id: r for r in results}
    assert by_id["case-a"].passed is True
    assert by_id["case-b"].passed is False


def test_run_eval_cases_converts_an_exception_into_a_failed_case_not_a_skip() -> None:
    """
    The exact bug this function exists to fix: a case whose run_fn call
    raises must come back as a FAILED CaseResult with the exception
    attached, never propagate out of run_eval_cases (which would have
    forced a pytest.skip in the old per-case try/except design), and
    never erase results already collected from other cases in the batch.
    """
    cases = [_routing_case("case-a", "Alpha"), _routing_case("case-broken", "Bravo"), _routing_case("case-c", "Charlie")]

    def run_fn(case: EvalCase) -> RoutingFields:
        if case.id == "case-broken":
            raise ConnectionError("no backend listening on localhost:8811")
        return RoutingFields(project_name={"case-a": "Alpha", "case-c": "Charlie"}[case.id])

    results = run_eval_cases(cases, run_fn)
    by_id = {r.case_id: r for r in results}

    # No exception propagated out of run_eval_cases -- got here at all proves that.
    assert set(by_id) == {"case-a", "case-broken", "case-c"}

    # The other two cases' real results survive untouched.
    assert by_id["case-a"].passed is True
    assert by_id["case-c"].passed is True

    # The broken case is a FAILURE (not silently dropped, not a skip -- there's
    # no such thing as a "skip" at this layer, only pass/fail CaseResults).
    broken = by_id["case-broken"]
    assert broken.passed is False
    assert len(broken.outcomes) == 1
    check, outcome = broken.outcomes[0]
    assert outcome.passed is False
    assert "ConnectionError" in outcome.reason
    assert "no backend listening on localhost:8811" in outcome.reason


def test_run_eval_cases_synthesizes_one_failing_outcome_per_declared_check() -> None:
    """A blown-up case with N checks reports N failing outcomes, one per
    check it never got to actually run -- not just a single generic one,
    so the report clearly shows every check as unresolved rather than
    silently passing."""
    case = EvalCase.model_validate(
        {
            "id": "multi-check-case",
            "agent": "intake_agent",
            "description": "two checks, run_fn raises before either can be evaluated",
            "input": [{"role": "user", "content": "irrelevant"}],
            "checks": [
                {"type": "field_equals", "field_id": "project_name", "expected": "Alpha"},
                {"type": "field_not_null", "field_id": "involves_ai_ml_llm"},
            ],
        }
    )

    def run_fn(_: EvalCase) -> RoutingFields:
        raise RuntimeError("EHAP_URL / EHAP_CLIENT_ID / EHAP_CLIENT_SECRET must be set.")

    [result] = run_eval_cases([case], run_fn)
    assert result.passed is False
    assert len(result.outcomes) == 2
    assert all(not outcome.passed for _, outcome in result.outcomes)
    assert all("RuntimeError" in outcome.reason for _, outcome in result.outcomes)
