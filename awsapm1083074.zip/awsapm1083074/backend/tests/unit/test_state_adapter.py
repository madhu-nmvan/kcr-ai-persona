# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""state_adapter: STATE envelope <-> session, both directions, both ways."""

from __future__ import annotations

import pytest

from governance_intake.handler import IntakeData
from governance_intake.postdedup import begin_session
from governance_intake.state_adapter import (
    envelope_from_session,
    session_inputs_from_state,
    state_from_session,
)

# Trigger values (FormFillerEnvelope shape) that deterministically activate a
# production-AI team set via the rule engine — no team list needed on input.
ACTIVATING_TRIGGERS = [
    {"id": "involves_ai_ml_llm", "value": True, "origin": "user", "confidence": None},
    {"id": "ai_ml_llm_business_use_case_fit", "value": True, "origin": "user", "confidence": None},
    {"id": "new_use_of_ai", "value": True, "origin": "user", "confidence": None},
    {"id": "PHI_PI_PFI_use", "value": True, "origin": "user", "confidence": None},
    {"id": "vendor_use", "value": True, "origin": "user", "confidence": None},
    {"id": "vendor_data_access", "value": True, "origin": "user", "confidence": None},
    {
        "id": "target_deployment_hosting",
        "value": ["ElevanceHealth Cloud Instance"],
        "origin": "user",
        "confidence": None,
    },
]


@pytest.fixture(scope="module")
def data() -> IntakeData:
    return IntakeData()


# ---------------------------------------------------------------------------
# session_inputs_from_state
# ---------------------------------------------------------------------------


def test_parses_full_envelope():
    state = {
        "messages": [
            {"role": "user", "content": "We are building an AI claims tool."},
            {"role": "agent", "content": "Tell me more."},
        ],
        "trigger": {"fields": {"project_name": "Claims AI", "uses_ai": True}, "complete": False},
        "activated_teams": [{"team": "RAI", "review_phase": 1}],
        "governance": {"questions": [], "complete": False},
    }
    inputs = session_inputs_from_state(state)
    assert inputs.activated_teams == [{"team": "RAI", "review_phase": 1}]
    assert len(inputs.messages) == 2
    assert inputs.trigger_fields == {"project_name": "Claims AI", "uses_ai": True}


def test_team_names_as_bare_strings_are_normalized():
    inputs = session_inputs_from_state({"activated_teams": ["Privacy", "RAI"]})
    assert inputs.activated_teams == [
        {"team": "Privacy", "review_phase": 1},
        {"team": "RAI", "review_phase": 1},
    ]


def test_assistant_role_is_normalized_to_agent():
    inputs = session_inputs_from_state({"messages": [{"role": "assistant", "content": "hello"}]})
    assert inputs.messages == [{"role": "agent", "content": "hello"}]


def test_null_trigger_fields_are_dropped():
    inputs = session_inputs_from_state({"trigger": {"fields": {"a": None, "b": "x"}}})
    assert inputs.trigger_fields == {"b": "x"}


def test_flat_collected_fields_variant_accepted():
    inputs = session_inputs_from_state({"collected_fields": {"uses_ai": True}})
    assert inputs.trigger_fields == {"uses_ai": True}


def test_missing_sections_degrade_to_empty():
    inputs = session_inputs_from_state({})
    assert inputs.activated_teams == []
    assert inputs.messages == []
    assert inputs.trigger_fields == {}


def test_garbage_entries_are_skipped_not_fatal():
    inputs = session_inputs_from_state(
        {
            "activated_teams": [None, 42, {"no_team_key": 1}, {"team": "  "}, "Privacy"],
            "messages": ["not-a-dict", {"role": "user"}, {"role": "sys", "content": "x"}],
        }
    )
    assert inputs.activated_teams == [{"team": "Privacy", "review_phase": 1}]
    assert inputs.messages == []


def test_unknown_teams_are_surfaced_not_dropped():
    inputs = session_inputs_from_state(
        {"activated_teams": ["Privacy", "Totally Fake Team"]},
        known_teams={"Privacy"},
    )
    assert inputs.unknown_teams == ["Totally Fake Team"]
    # ...and the entry itself is still present for the caller to decide on.
    assert {"team": "Totally Fake Team", "review_phase": 1} in inputs.activated_teams


def test_non_dict_state_raises():
    with pytest.raises(ValueError):
        session_inputs_from_state([])  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# state_from_session
# ---------------------------------------------------------------------------


def test_round_trip_uses_spec_names(data):
    state = {
        "messages": [{"role": "user", "content": "AI project with PHI."}],
        "trigger": {"fields": {"uses_ai": True}},
        "activated_teams": ["AI Program Office"],
    }
    sess = begin_session("sess-t1", "u1", state, data)
    envelope = state_from_session(sess, data)

    qs = envelope["governance"]["questions"]
    assert qs, "AI Program Office has questions"
    q = qs[0]
    assert "text" in q and "canonical_question" not in q  # spec naming wins
    assert q["answered"] is False and q["answer"] is None
    assert envelope["governance"]["complete"] is False
    assert envelope["trigger"]["fields"] == {"uses_ai": True}
    assert envelope["trigger"]["complete"] is False  # 40 required fields absent
    assert envelope["messages"] == state["messages"]


def test_contentless_only_session_is_vacuously_complete(data):
    # Contentless (delegated) team: zero questions, zero gaps -> complete,
    # so a legitimate delegated-only session can never deadlock.
    sess = begin_session("sess-t2", "u1", {"activated_teams": ["Clinical Partnership Review"]}, data)
    envelope = state_from_session(sess, data)
    assert envelope["governance"]["questions"] == []
    assert envelope["governance"]["complete"] is True


# ---------------------------------------------------------------------------
# FormFillerEnvelope (the real #13 contract) — input parsing
# ---------------------------------------------------------------------------


def test_form_filler_envelope_is_detected_and_parsed():
    env = {
        "triggers": [
            {"id": "involves_ai_ml_llm", "value": True, "origin": "user", "confidence": None},
            {"id": "blank_field", "value": None, "origin": None, "confidence": None},
        ],
        "governance": [
            {"id": "DEDUP.X", "value": "an answer", "origin": "agent", "confidence": 4, "sources": []},
            {"id": "DEDUP.Y", "value": None, "origin": None, "confidence": None, "sources": []},
        ],
    }
    inputs = session_inputs_from_state(env)
    # Teams are NOT carried in the envelope — derived from triggers downstream.
    assert inputs.activated_teams == []
    # Blank trigger dropped; answered one kept.
    assert inputs.trigger_fields == {"involves_ai_ml_llm": True}
    # Blank governance dropped; answered one kept with origin mapped.
    assert inputs.governance_answers == {"DEDUP.X": {"value": "an answer", "origin": "agent"}}


def test_form_filler_envelope_top_level_messages_are_honored():
    # Not part of the envelope schema, but accepted so grounded prefill has
    # the transcript to quote. Roles normalize like the placeholder path.
    env = {"triggers": [], "messages": [{"role": "assistant", "content": "hi"}]}
    inputs = session_inputs_from_state(env)
    assert inputs.messages == [{"role": "agent", "content": "hi"}]


def test_begin_session_from_form_filler_envelope_activates_teams(data):
    sess = begin_session("ff-1", "u1", {"triggers": ACTIVATING_TRIGGERS, "governance": []}, data)
    assert sess["activated_teams"], "teams derived from trigger values via the rule engine"
    assert sess["pending_questions"], "deduped question set built for the activated teams"


def test_begin_session_seeds_prior_governance_answers(data):
    env = {"triggers": ACTIVATING_TRIGGERS, "governance": []}
    sess = begin_session("ff-2", "u1", env, data)
    canonical_id = sess["pending_questions"][0]["canonical_id"]

    env_with_answer = {
        "triggers": ACTIVATING_TRIGGERS,
        "governance": [
            {
                "id": canonical_id,
                "value": "advisory only",
                "origin": "agent",
                "confidence": 4,
                "sources": [],
            }
        ],
    }
    sess2 = begin_session("ff-3", "u1", env_with_answer, data)
    q = next(q for q in sess2["pending_questions"] if q["canonical_id"] == canonical_id)
    assert q["answered"] is True
    assert q["answer"] == "advisory only"
    assert q["answer_origin"] == "prefill"  # agent-origin -> prefill internally


# ---------------------------------------------------------------------------
# FormFillerEnvelope — outbound (envelope_from_session)
# ---------------------------------------------------------------------------


def test_envelope_from_session_emits_contract_shape(data):
    sess = begin_session("ev-1", "u1", {"activated_teams": ["AI Program Office"]}, data)
    env = envelope_from_session(sess, data)

    assert set(env) == {"triggers", "governance"}
    assert env["triggers"], "one FormItem per RoutingFields field"
    assert set(env["triggers"][0]) == {"id", "text", "value", "origin", "confidence"}
    # An unanswered trigger is a coherent blank (contract provenance rule).
    blank = next(t for t in env["triggers"] if t["value"] is None)
    assert blank["origin"] is None and blank["confidence"] is None

    g0 = env["governance"][0]
    assert set(g0) == {"id", "text", "value", "origin", "confidence", "sources"}
    assert g0["value"] is None and g0["origin"] is None  # unanswered
    assert "canonical_question" not in g0  # contract renames text/value


def test_envelope_from_session_maps_prefill_to_agent_origin(data):
    sess = begin_session("ev-2", "u1", {"activated_teams": ["AI Program Office"]}, data)
    q = sess["pending_questions"][0]
    q.update(answered=True, answer="grounded value", answer_origin="prefill")

    g = next(x for x in envelope_from_session(sess, data)["governance"] if x["id"] == q["canonical_id"])
    assert g["value"] == "grounded value"
    assert g["origin"] == "agent"
    assert g["confidence"] == 4  # accepted grounded prefill


def test_envelope_from_session_user_answer_carries_no_confidence(data):
    sess = begin_session("ev-3", "u1", {"activated_teams": ["AI Program Office"]}, data)
    q = sess["pending_questions"][0]
    q.update(answered=True, answer="user value", answer_origin="user")

    g = next(x for x in envelope_from_session(sess, data)["governance"] if x["id"] == q["canonical_id"])
    assert g["value"] == "user value"
    assert g["origin"] == "user"
    assert g["confidence"] is None  # user-provided must not carry confidence
