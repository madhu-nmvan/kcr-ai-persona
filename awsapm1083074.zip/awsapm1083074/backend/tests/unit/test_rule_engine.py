# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""Focused contract tests for the routing-rule DSL."""

from __future__ import annotations

import pytest

from governance_intake.handler import IntakeData
from governance_intake.rule_engine import evaluate_condition, evaluate_rules


def test_any_of_returns_false_for_scalar_field_value() -> None:
    """``any_of`` is only defined for list-valued routing fields."""
    condition = {"any_of": ["vendor_data_access", ["Protected Information (PI)"]]}
    assert evaluate_condition(condition, {"vendor_data_access": True}) is False


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("Production", True),
        ("POC", False),
    ],
)
def test_in_matches_scalar_values_against_its_allowed_list(value: str, expected: bool) -> None:
    condition = {
        "in": [
            "level_of_development",
            ["Pilot", "Production"],
        ]
    }
    assert evaluate_condition(condition, {"level_of_development": value}) is expected


@pytest.mark.parametrize(
    ("fields", "expected"),
    [
        ({"identify_vendors_to_PI": ["Acme Corp"]}, True),
        ({"identify_vendors_to_PI": []}, False),
        ({"identify_vendors_to_PI": None}, False),
        ({}, False),
    ],
)
def test_truthy_requires_a_present_non_empty_value(
    fields: dict[str, list[str] | None], expected: bool
) -> None:
    assert evaluate_condition({"truthy": "identify_vendors_to_PI"}, fields) is expected


def test_intake_data_loads_the_real_trigger_rules_document() -> None:
    """The production trigger document must remain valid JSON and contain routing rules."""
    data = IntakeData()
    assert data.trigger_rules["rules"]


def test_procurement_rule_uses_vendor_use_not_the_retired_uses_vendor_field() -> None:
    """Procurement routing follows the current schema key, preventing stale-field activation."""
    rules = IntakeData().trigger_rules

    current_field_teams = {team["team"] for team in evaluate_rules({"vendor_use": True}, rules)}
    stale_field_teams = {team["team"] for team in evaluate_rules({"uses_vendor": True}, rules)}

    assert "Procurement" in current_field_teams
    assert "Procurement" not in stale_field_teams


def test_due_rule_does_not_activate_when_project_is_within_data_use_policy() -> None:
    """Regression: DUE's policy-compliance branch must trigger on ``false``, not ``true``.

    Every other DUE OR-branch condition is False, and the two AND-gated
    prerequisites (data solution type, Production maturity) are satisfied, so
    the only variable left is ``within_data_use_release_policy``. With the
    project reported as within policy (``True``), DUE must not activate.
    """
    rules = IntakeData().trigger_rules
    fields = {
        "data_solution_types": ["Proxy ID"],
        "level_of_development": "Production",
        "new_or_different_deployment_type": False,
        "has_business_received_communication": False,
        "stakeholder_value": False,
        "abrasive_to_providers_customers_members": False,
        "vendor_data_access": False,
        "external_data_release": False,
        "within_data_use_release_policy": True,
    }

    team_names = {team["team"] for team in evaluate_rules(fields, rules)}

    assert "DUE" not in team_names


# ---------------------------------------------------------------------------
# EDOM (docx: PI.4 OR PI.11 OR PI.12 OR MPI.1 OR MPI.13 OR MPI.18 = YES)
# ---------------------------------------------------------------------------

EDOM_TRIGGER_FIELDS = [
    "vendor_data_access",  # PI.4
    "involves_contacting_delegates_vendors_behalf_EH",  # PI.11
    "risk_of_heath_care_fraud_waste_abuse",  # PI.12
    "impacts_members_providers",  # MPI.1
    "violates_CMS_state_program_requirements",  # MPI.13
    "involves_digital_health_member_outcomes",  # MPI.18
]


@pytest.mark.parametrize("field", EDOM_TRIGGER_FIELDS)
def test_edom_activates_on_any_single_trigger_field(field: str) -> None:
    """EDOM's condition is an OR: any one of its six fields being true fires it."""
    rules = IntakeData().trigger_rules
    team_names = {t["team"] for t in evaluate_rules({field: True}, rules)}
    assert "EDOM" in team_names


def test_edom_does_not_activate_when_all_trigger_fields_are_false() -> None:
    rules = IntakeData().trigger_rules
    fields = {f: False for f in EDOM_TRIGGER_FIELDS}
    team_names = {t["team"] for t in evaluate_rules(fields, rules)}
    assert "EDOM" not in team_names


# ---------------------------------------------------------------------------
# Wave-1 teams: one firing profile + one non-firing profile each, grounded in
# the team's extracted_questions/<slug>/questions.txt trigger block.
# ---------------------------------------------------------------------------


def _activated(fields: dict) -> set[str]:
    return {t["team"] for t in evaluate_rules(fields, IntakeData().trigger_rules)}


# Clinical Partnership Review -- PI.8 = YES (use_of_clinical_data is an enum
# with no "None" option, so any selected value means yes).
def test_clinical_partnership_review_fires_on_any_clinical_data_value() -> None:
    assert "Clinical Partnership Review" in _activated(
        {"use_of_clinical_data": "Care Management"}
    )


def test_clinical_partnership_review_does_not_fire_without_clinical_data() -> None:
    assert "Clinical Partnership Review" not in _activated({"use_of_clinical_data": None})


# Corporate Communications -- GI.1=Production AND (MPI.4 OR MPI.5).
@pytest.mark.parametrize(
    "extra",
    [{"stakeholder_value": True}, {"abrasive_to_providers_customers_members": True}],
)
def test_corporate_communications_fires_in_production_with_either_mpi(extra: dict) -> None:
    assert "Corporate Communications" in _activated(
        {"level_of_development": "Production", **extra}
    )


def test_corporate_communications_does_not_fire_outside_production() -> None:
    assert "Corporate Communications" not in _activated(
        {"level_of_development": "Pilot", "stakeholder_value": True}
    )


def test_corporate_communications_does_not_fire_without_either_mpi() -> None:
    assert "Corporate Communications" not in _activated(
        {
            "level_of_development": "Production",
            "stakeholder_value": False,
            "abrasive_to_providers_customers_members": False,
        }
    )


# Legal - Data Governance & Privacy -- D.6 OR D.9.
@pytest.mark.parametrize(
    "extra",
    [{"sending_receiving_protected_information": True}, {"PHI_PI_PFI_use": True}],
)
def test_legal_data_gov_privacy_fires_on_either_branch(extra: dict) -> None:
    assert "Legal - Data Governance & Privacy" in _activated(extra)


def test_legal_data_gov_privacy_does_not_fire_when_both_false() -> None:
    assert "Legal - Data Governance & Privacy" not in _activated(
        {"sending_receiving_protected_information": False, "PHI_PI_PFI_use": False}
    )


# Legal - Intellectual Property (IP) -- GI.9 (manners_of_use) OR GI.10.
def test_legal_ip_fires_on_a_manner_of_use() -> None:
    assert "Legal - Intellectual Property (IP)" in _activated(
        {"manners_of_use": ["Client data will flow through the solution"]}
    )


def test_legal_ip_fires_on_new_novel_pi_use() -> None:
    assert "Legal - Intellectual Property (IP)" in _activated({"new_novel_PI_use": True})


def test_legal_ip_does_not_fire_on_not_applicable_only() -> None:
    assert "Legal - Intellectual Property (IP)" not in _activated(
        {"manners_of_use": ["Not applicable"], "new_novel_PI_use": False}
    )


# Legal-Tech-Novel or High Risk Tech -- GI.11 OR GI.12 OR GI.16.
LEGAL_NOVEL_FIELDS = [
    "new_novel_technology",  # GI.11
    "high_risk_use_potential",  # GI.11
    "new_or_different_deployment_type",  # GI.12
    "new_altered_business_proccess",  # GI.16
]


@pytest.mark.parametrize("field", LEGAL_NOVEL_FIELDS)
def test_legal_tech_novel_fires_on_any_trigger_field(field: str) -> None:
    assert "Legal-Tech-Novel or High Risk Tech" in _activated({field: True})


def test_legal_tech_novel_does_not_fire_when_all_false() -> None:
    assert "Legal-Tech-Novel or High Risk Tech" not in _activated(
        {f: False for f in LEGAL_NOVEL_FIELDS}
    )


# Legal-Tech-Commercialization -- GI.9.
def test_legal_tech_commercialization_fires_on_a_manner_of_use() -> None:
    assert "Legal-Tech-Commercialization" in _activated(
        {"manners_of_use": ["External client(s) access the solution directly"]}
    )


def test_legal_tech_commercialization_does_not_fire_on_not_applicable_only() -> None:
    assert "Legal-Tech-Commercialization" not in _activated(
        {"manners_of_use": ["Not applicable"]}
    )


# OCCO -- GI.1=Production AND MPI.1 AND MPI.9.
def test_occo_fires_in_production_with_member_impact_and_consumer_impact() -> None:
    assert "OCCO" in _activated(
        {
            "level_of_development": "Production",
            "impacts_members_providers": True,
            "consumer_impacts": ["Telephone calls"],
        }
    )


def test_occo_does_not_fire_without_consumer_impact() -> None:
    assert "OCCO" not in _activated(
        {
            "level_of_development": "Production",
            "impacts_members_providers": True,
            "consumer_impacts": [],
        }
    )


# On-Prem/Private Hosting -- GI.1=Production AND D.3 in {Cloud Instance, Kyndryl}.
def test_on_prem_fires_in_production_with_cloud_instance_or_kyndryl() -> None:
    assert "On-Prem/Private Hosting" in _activated(
        {
            "level_of_development": "Production",
            "target_deployment_hosting": ["Kyndryl Managed"],
        }
    )


def test_on_prem_does_not_fire_for_elevance_hosted_only() -> None:
    assert "On-Prem/Private Hosting" not in _activated(
        {
            "level_of_development": "Production",
            "target_deployment_hosting": ["ElevanceHealth Hosted"],
        }
    )


# Payment Card Industry (PCI) -- D.5.
def test_pci_fires_on_payment_data() -> None:
    assert "Payment Card Industry (PCI)" in _activated(
        {"use_of_payment_information_data": True}
    )


def test_pci_does_not_fire_without_payment_data() -> None:
    assert "Payment Card Industry (PCI)" not in _activated(
        {"use_of_payment_information_data": False}
    )


# Anthem FEP / WellPoint Federal -- GI.1=Production AND LOB (deployment_line_of_business).
# The two share a single scalar enum field, so they are mutually exclusive.
def test_anthem_fep_fires_for_fep_line_of_business() -> None:
    teams = _activated(
        {"level_of_development": "Production", "deployment_line_of_business": "FEP"}
    )
    assert "Anthem Federal Employees Program (FEP)" in teams
    assert "WellPoint Federal" not in teams


def test_wellpoint_federal_fires_for_wellpoint_line_of_business() -> None:
    teams = _activated(
        {
            "level_of_development": "Production",
            "deployment_line_of_business": "WellPoint Federal",
        }
    )
    assert "WellPoint Federal" in teams
    assert "Anthem Federal Employees Program (FEP)" not in teams


def test_anthem_fep_does_not_fire_outside_production() -> None:
    assert "Anthem Federal Employees Program (FEP)" not in _activated(
        {"level_of_development": "Pilot", "deployment_line_of_business": "FEP"}
    )


# NGS / FGS -- GI.1=Production AND LOB (lines_of_business_for_deployment).
def test_ngs_fires_for_commercial_ngs_line_of_business() -> None:
    assert "National Government Solutions (NGS)" in _activated(
        {
            "level_of_development": "Production",
            "lines_of_business_for_deployment": ["Commercial NGS"],
        }
    )


def test_fgs_fires_for_commercial_fgs_line_of_business() -> None:
    assert "Federal Government Solutions (FGS) Home Office" in _activated(
        {
            "level_of_development": "Production",
            "lines_of_business_for_deployment": ["Commercial – FGS"],
        }
    )


def test_ngs_does_not_fire_for_unrelated_line_of_business() -> None:
    assert "National Government Solutions (NGS)" not in _activated(
        {
            "level_of_development": "Production",
            "lines_of_business_for_deployment": ["CarelonRx"],
        }
    )


# ---------------------------------------------------------------------------
# at_least operator (count/threshold) + Compliance-Technology
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("threshold", "expected"),
    [(0, True), (1, True), (2, True), (3, False), (4, False)],
)
def test_at_least_counts_matching_conditions(threshold: int, expected: bool) -> None:
    """Exactly two of the three inner conditions are true."""
    condition = {
        "at_least": [
            threshold,
            [
                {"equals": ["a", True]},
                {"equals": ["b", True]},
                {"equals": ["c", True]},
            ],
        ]
    }
    assert evaluate_condition(condition, {"a": True, "b": True, "c": False}) is expected


def test_at_least_treats_missing_fields_as_non_matches() -> None:
    condition = {"at_least": [1, [{"equals": ["a", True]}, {"equals": ["b", True]}]]}
    assert evaluate_condition(condition, {}) is False


def test_at_least_counts_nested_conditions_once_each() -> None:
    condition = {
        "at_least": [
            2,
            [
                {"all": [{"equals": ["a", True]}, {"equals": ["b", True]}]},
                {"any": [{"equals": ["c", True]}, {"equals": ["d", True]}]},
                {"equals": ["e", True]},
            ],
        ]
    }
    assert evaluate_condition(condition, {"a": True, "b": True, "c": False, "d": False, "e": True})


# Compliance-Technology -- "If any TWO of {GI.13, PI.1, D.3, D.9, AI.1, +2 NEW}
# = YES". D.3 ("any EXCEPT No Data Center Deployment Location") maps to a
# non-empty target_deployment_hosting list, i.e. {"truthy": ...}.
def test_compliance_technology_fires_on_exactly_two_yes() -> None:
    # Exactly two conditions true: GI.13 (reg/rep risk) + AI.1 (AI/ML/LLM).
    assert "Compliance-Technology" in _activated(
        {"regulatory_reputational_risks": True, "involves_ai_ml_llm": True}
    )


def test_compliance_technology_does_not_fire_on_a_single_yes() -> None:
    assert "Compliance-Technology" not in _activated(
        {"involves_ai_ml_llm": True}
    )


def test_compliance_technology_counts_a_non_empty_hosting_target_as_one_yes() -> None:
    # D.3 (non-empty hosting target) + PI.1 (vendor_use) = two YES.
    assert "Compliance-Technology" in _activated(
        {"target_deployment_hosting": ["ElevanceHealth Hosted"], "vendor_use": True}
    )


# ---------------------------------------------------------------------------
# Enterprise Standards Governance (ESG)
#
# NOTE: the docx trigger block is a flat OR/AND list whose grouping precedence
# is ambiguous. These tests pin the encoded reading:
#   (new_software OR newly_deployed_software)
#   AND (what_type_technology_gov_request in {Pilot, PROD})
#   AND (use_of_previously_unapproved_software OR vendor_provided_service in {Existing, New})
# The grouping itself is flagged [Elevance] in TRIGGER_RULES_INTEGRATION.md.
# ---------------------------------------------------------------------------

ESG_FIRING_FIELDS = {
    "new_software": True,
    "what_type_technology_gov_request": "PROD",
    "use_of_previously_unapproved_software": True,
}


def test_esg_fires_when_all_three_groups_satisfied() -> None:
    assert "Enterprise Standards Governance (ESG)" in _activated(dict(ESG_FIRING_FIELDS))


def test_esg_fires_via_vendor_provided_service_branch() -> None:
    fields = {
        "newly_deployed_software": True,
        "what_type_technology_gov_request": "Pilot",
        "vendor_provided_service": "New",
    }
    assert "Enterprise Standards Governance (ESG)" in _activated(fields)


def test_esg_does_not_fire_when_software_group_absent() -> None:
    fields = dict(ESG_FIRING_FIELDS, new_software=False)
    assert "Enterprise Standards Governance (ESG)" not in _activated(fields)


def test_esg_does_not_fire_when_request_type_group_absent() -> None:
    fields = dict(ESG_FIRING_FIELDS)
    del fields["what_type_technology_gov_request"]
    assert "Enterprise Standards Governance (ESG)" not in _activated(fields)


def test_esg_does_not_fire_when_third_group_absent() -> None:
    fields = dict(ESG_FIRING_FIELDS, use_of_previously_unapproved_software=False)
    fields["vendor_provided_service"] = "None"
    assert "Enterprise Standards Governance (ESG)" not in _activated(fields)
