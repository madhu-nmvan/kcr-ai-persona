# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""question_order: deterministic implication-first ordering."""

from __future__ import annotations

from governance_intake.handler import IntakeData
from governance_intake.question_dedup import build_pending_questions
from governance_intake.question_order import order_pending_questions


def _q(cid, category="general", n_sources=1):
    return {
        "canonical_id": cid,
        "canonical_question": f"Question {cid}?",
        "category": category,
        "sources": [{"team": f"T{i}", "question_id": f"{cid}.{i}"} for i in range(n_sources)],
        "answered": False,
        "answer": None,
    }


def test_widest_fanout_comes_first():
    pending = [_q("A", n_sources=1), _q("B", n_sources=4), _q("C", n_sources=2)]
    ordered = order_pending_questions(pending)
    assert [q["canonical_id"] for q in ordered] == ["B", "C", "A"]


def test_categories_stay_contiguous_within_same_fanout():
    pending = [
        _q("A", category="security"),
        _q("B", category="data"),
        _q("C", category="security"),
        _q("D", category="data"),
    ]
    ordered = order_pending_questions(pending)
    assert [q["canonical_id"] for q in ordered] == ["A", "C", "B", "D"]


def test_ordering_is_stable_and_pure():
    pending = [_q("A"), _q("B"), _q("C")]
    first = order_pending_questions(pending)
    second = order_pending_questions(pending)
    assert first == second
    assert [q["canonical_id"] for q in pending] == ["A", "B", "C"]  # not mutated
    assert [q["canonical_id"] for q in first] == ["A", "B", "C"]  # stable tiebreak


def test_real_corpus_orders_shared_questions_before_singletons():
    data = IntakeData()
    pending = build_pending_questions(
        ["AI Program Office", "RAI", "Privacy"],
        data.questionnaires,
        data.dedup_mapping,
    )
    ordered = order_pending_questions(pending)
    fanouts = [len(q["sources"]) for q in ordered]
    assert fanouts == sorted(fanouts, reverse=True)
    assert fanouts[0] >= 2  # the corpus has shared canonicals for these teams
