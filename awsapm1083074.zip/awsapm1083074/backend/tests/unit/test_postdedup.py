# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""postdedup service layer: answers, prefill decisions, completeness, submit."""

from __future__ import annotations

import pytest

from governance_intake.handler import IntakeData
from governance_intake.postdedup import (
    PostDedupError,
    apply_prefill_decisions,
    begin_session,
    completeness,
    record_answers,
    record_attachment,
    stats,
    submit,
)

PPTX = {"key": "k1", "filename": "diagram.pptx", "size": 10, "content_type": "x"}


@pytest.fixture(scope="module")
def data() -> IntakeData:
    return IntakeData()


def _small_session(data, teams=("AI Program Office",)):
    return begin_session("sess-x", "u1", {"activated_teams": list(teams)}, data)


def _propose(q, answer="proposed answer"):
    q["prefill"] = {
        "answer": answer,
        "provenance": {"kind": "transcript", "ref": "0", "quote": "..."},
        "status": "proposed",
    }


# ---------------------------------------------------------------------------
# begin_session
# ---------------------------------------------------------------------------


def test_begin_session_with_explicit_teams(data):
    sess = _small_session(data)
    assert sess["phase"] == "asking_questions"
    assert sess["pending_questions"]
    assert sess["dedup_stats"]["raw_question_count"] > 0
    assert sess["team_forms"] == {"AI Program Office": {}}


def test_begin_session_derives_teams_from_trigger_fields(data):
    sess = begin_session(
        "sess-d", "u1", {"trigger": {"fields": {"involves_ai_ml_llm": True}}}, data
    )
    teams = {t["team"] for t in sess["activated_teams"]}
    assert "RAI" in teams  # involves_ai_ml_llm=true fires the RAI rule


def test_begin_session_with_neither_teams_nor_fields_raises(data):
    with pytest.raises(PostDedupError):
        begin_session("sess-e", "u1", {}, data)


def test_begin_session_surfaces_unknown_teams(data):
    sess = begin_session(
        "sess-u", "u1", {"activated_teams": ["AI Program Office", "Nope Team"]}, data
    )
    assert sess["unknown_teams"] == ["Nope Team"]


# ---------------------------------------------------------------------------
# record_answers
# ---------------------------------------------------------------------------


def test_answer_and_clear_round_trip(data):
    sess = _small_session(data)
    q = sess["pending_questions"][0]
    cid = q["canonical_id"]

    record_answers(sess, data, [{"canonical_id": cid, "answer": "Yes."}])
    assert q["answered"] and q["answer"] == "Yes." and q["answer_origin"] == "user"
    for src in q["sources"]:
        assert sess["team_forms"][src["team"]][src["question_id"]] == "Yes."

    record_answers(sess, data, [{"canonical_id": cid, "answer": ""}])
    assert not q["answered"] and q["answer"] is None and "answer_origin" not in q
    for src in q["sources"]:
        assert src["question_id"] not in sess["team_forms"][src["team"]]


def test_unknown_canonical_id_is_an_error_not_ignored(data):
    sess = _small_session(data)
    with pytest.raises(PostDedupError, match="Unknown canonical ids"):
        record_answers(sess, data, [{"canonical_id": "NOPE.1", "answer": "x"}])


def test_record_answers_requires_asking_phase(data):
    sess = _small_session(data)
    sess["phase"] = "complete"
    with pytest.raises(PostDedupError, match="phase"):
        record_answers(sess, data, [])


# ---------------------------------------------------------------------------
# prefill decisions
# ---------------------------------------------------------------------------


def test_proposed_prefill_is_never_silently_committed(data):
    sess = _small_session(data)
    q = sess["pending_questions"][0]
    _propose(q)

    snap = completeness(sess, data)
    assert not q["answered"]
    assert q["canonical_id"] in snap["unanswered_ids"]
    # ...and it contributes nothing to the fan-out forms.
    assert all(not form for form in sess["team_forms"].values())


def test_accepting_prefill_commits_with_prefill_origin(data):
    sess = _small_session(data)
    q = sess["pending_questions"][0]
    _propose(q, answer="From your description.")

    apply_prefill_decisions(sess, data, accept=[q["canonical_id"]])
    assert q["answered"] and q["answer"] == "From your description."
    assert q["answer_origin"] == "prefill"
    assert q["prefill"]["status"] == "accepted"
    for src in q["sources"]:
        assert sess["team_forms"][src["team"]][src["question_id"]] == q["answer"]


def test_dismissing_prefill_leaves_question_open(data):
    sess = _small_session(data)
    q = sess["pending_questions"][0]
    _propose(q)
    apply_prefill_decisions(sess, data, dismiss=[q["canonical_id"]])
    assert q["prefill"]["status"] == "dismissed"
    assert not q["answered"]


def test_accept_all_only_touches_proposed(data):
    sess = _small_session(data)
    q0, q1, q2 = sess["pending_questions"][:3]
    _propose(q0)
    _propose(q1)
    q1["prefill"]["status"] = "dismissed"
    apply_prefill_decisions(sess, data, accept_all=True)
    assert q0["answered"] and q0["prefill"]["status"] == "accepted"
    assert not q1["answered"] and q1["prefill"]["status"] == "dismissed"
    assert not q2.get("answered")


def test_user_edit_over_accepted_prefill_flips_origin(data):
    sess = _small_session(data)
    q = sess["pending_questions"][0]
    _propose(q)
    apply_prefill_decisions(sess, data, accept=[q["canonical_id"]])
    record_answers(sess, data, [{"canonical_id": q["canonical_id"], "answer": "Corrected."}])
    assert q["answer"] == "Corrected." and q["answer_origin"] == "user"


def test_decision_without_proposal_is_an_error(data):
    sess = _small_session(data)
    cid = sess["pending_questions"][0]["canonical_id"]
    with pytest.raises(PostDedupError, match="No proposed prefill"):
        apply_prefill_decisions(sess, data, accept=[cid])


def test_accept_and_dismiss_overlap_is_an_error(data):
    sess = _small_session(data)
    q = sess["pending_questions"][0]
    _propose(q)
    cid = q["canonical_id"]
    with pytest.raises(PostDedupError, match="both"):
        apply_prefill_decisions(sess, data, accept=[cid], dismiss=[cid])


# ---------------------------------------------------------------------------
# completeness / submit
# ---------------------------------------------------------------------------


def test_submit_refuses_while_incomplete_and_creates_nothing(data):
    sess = _small_session(data)
    with pytest.raises(PostDedupError, match="Not complete"):
        submit(sess, data)
    assert sess.get("ticket") is None
    assert sess["phase"] == "asking_questions"


def test_submit_requires_pptx_attachment(data):
    sess = begin_session(
        "sess-c", "u1", {"activated_teams": ["Clinical Partnership Review"]}, data
    )
    with pytest.raises(PostDedupError, match="pptx"):
        submit(sess, data)


def test_full_answer_then_submit_fans_out(data):
    sess = _small_session(data)
    record_answers(
        sess,
        data,
        [
            {"canonical_id": q["canonical_id"], "answer": f"A{i}"}
            for i, q in enumerate(sess["pending_questions"])
        ],
    )
    snap = completeness(sess, data)
    assert snap["complete"], snap
    record_attachment(sess, PPTX)
    ticket = submit(sess, data)
    assert ticket["ticket_id"].startswith("GOV-")
    assert sess["phase"] == "complete"
    assert ticket["team_forms"]["AI Program Office"]
    # Every AI Program Office question got a value via fan-out.
    n_qs = len(data.questionnaires["teams"]["AI Program Office"]["questions"])
    assert len(ticket["team_forms"]["AI Program Office"]) == n_qs


def test_contentless_only_session_submits_vacuously(data):
    sess = begin_session(
        "sess-v", "u1", {"activated_teams": ["Clinical Partnership Review"]}, data
    )
    assert completeness(sess, data)["complete"]
    record_attachment(sess, PPTX)
    ticket = submit(sess, data)
    assert ticket["answered_questions"] == []
    assert [t["team"] for t in ticket["activated_teams"]] == [
        "Clinical Partnership Review"
    ]


# ---------------------------------------------------------------------------
# stats
# ---------------------------------------------------------------------------


def test_stats_counts_prefill_lifecycle(data):
    sess = _small_session(data)
    q0, q1 = sess["pending_questions"][:2]
    _propose(q0)
    _propose(q1)
    apply_prefill_decisions(sess, data, accept=[q0["canonical_id"]], dismiss=[q1["canonical_id"]])
    s = stats(sess)
    assert s["prefill"] == {
        "proposed": 0,
        "accepted": 1,
        "dismissed": 1,
        "rejected_ungrounded": 0,
    }
    assert s["answered_by_prefill_count"] == 1
    assert s["raw_question_count"] >= s["consolidated_question_count"]
