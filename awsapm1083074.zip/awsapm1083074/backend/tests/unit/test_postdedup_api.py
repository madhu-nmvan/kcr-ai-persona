# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""postdedup_api: HTTP surface over the service layer (TestClient, no LLM)."""

from __future__ import annotations

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from governance_intake.handler import IntakeData
from governance_intake.postdedup_api import build_router
from governance_intake.session import InMemorySessionStore


@pytest.fixture(scope="module")
def data() -> IntakeData:
    return IntakeData()


@pytest.fixture()
def client(data, monkeypatch, tmp_path) -> TestClient:
    monkeypatch.setenv("INTAKE_SKIP_LLM", "1")
    monkeypatch.setenv("INTAKE_ATTACHMENTS_BACKEND", "local")
    monkeypatch.setenv("INTAKE_ATTACHMENTS_DIR", str(tmp_path))
    app = FastAPI()
    app.include_router(build_router(InMemorySessionStore(), data))
    return TestClient(app)


STATE = {
    "messages": [{"role": "user", "content": "An AI claims tool on AWS."}],
    "trigger": {"fields": {"project_name": "Claims AI"}},
    "activated_teams": ["AI Program Office"],
}


def _create(client, state=None):
    resp = client.post("/api/post-dedup/sessions", json={"state": state or STATE})
    assert resp.status_code == 201, resp.text
    return resp.json()


def test_create_returns_envelope_completeness_and_stats(client):
    view = _create(client)
    assert view["phase"] == "asking_questions"
    qs = view["state"]["governance"]["questions"]
    assert qs and "text" in qs[0]
    assert view["completeness"]["complete"] is False
    assert view["stats"]["raw_question_count"] > 0
    assert view["state"]["governance"]["complete"] is False


def test_create_with_empty_state_is_400(client):
    resp = client.post("/api/post-dedup/sessions", json={"state": {}})
    assert resp.status_code == 400


def test_get_unknown_session_is_404(client):
    assert client.get("/api/post-dedup/sessions/sess-nope").status_code == 404


# FormFillerEnvelope (real #13 contract): trigger values activate teams via the
# rule engine — no activated_teams list on input.
FORM_FILLER_STATE = {
    "triggers": [
        {"id": "involves_ai_ml_llm", "value": True, "origin": "user", "confidence": None},
        {"id": "ai_ml_llm_business_use_case_fit", "value": True, "origin": "user", "confidence": None},
        {"id": "new_use_of_ai", "value": True, "origin": "user", "confidence": None},
    ],
    "governance": [],
}


def test_create_from_form_filler_envelope_activates_and_dedups(client):
    view = _create(client, FORM_FILLER_STATE)
    assert view["phase"] == "asking_questions"
    assert view["state"]["governance"]["questions"], "teams activated from triggers"
    assert view["stats"]["raw_question_count"] > 0


def test_envelope_endpoint_returns_contract_shape(client):
    view = _create(client, FORM_FILLER_STATE)
    session_id = view["session_id"]
    resp = client.get(f"/api/post-dedup/sessions/{session_id}/envelope")
    assert resp.status_code == 200, resp.text
    env = resp.json()
    assert set(env) == {"triggers", "governance"}
    assert env["triggers"] and set(env["triggers"][0]) == {
        "id",
        "text",
        "value",
        "origin",
        "confidence",
    }
    g0 = env["governance"][0]
    assert set(g0) == {"id", "text", "value", "origin", "confidence", "sources"}


def test_answers_round_trip_and_unknown_id_400(client):
    view = _create(client)
    sid = view["session_id"]
    cid = view["state"]["governance"]["questions"][0]["canonical_id"]

    resp = client.post(
        f"/api/post-dedup/sessions/{sid}/answers",
        json={"answers": [{"canonical_id": cid, "answer": "Yes."}]},
    )
    assert resp.status_code == 200
    q = next(q for q in resp.json()["state"]["governance"]["questions"] if q["canonical_id"] == cid)
    assert q["answered"] and q["answer"] == "Yes." and q["answer_origin"] == "user"

    resp = client.post(
        f"/api/post-dedup/sessions/{sid}/answers",
        json={"answers": [{"canonical_id": "GHOST.1", "answer": "x"}]},
    )
    assert resp.status_code == 400


def test_prefill_endpoint_noops_under_skip_llm(client):
    view = _create(client)
    resp = client.post(f"/api/post-dedup/sessions/{view['session_id']}/prefill")
    assert resp.status_code == 200
    assert resp.json()["prefill_summary"]["proposed"] == 0


def test_prefill_decisions_flow(client, data):
    view = _create(client)
    sid = view["session_id"]
    cid = view["state"]["governance"]["questions"][0]["canonical_id"]

    # Stage a proposal server-side (prefill itself is LLM-gated); decisions
    # are exercised through the API.
    resp = client.post(
        f"/api/post-dedup/sessions/{sid}/prefill/decisions",
        json={"accept": [cid]},
    )
    assert resp.status_code == 400  # no proposal staged -> client out of sync


def test_submit_refuses_incomplete_with_409(client):
    view = _create(client)
    resp = client.post(f"/api/post-dedup/sessions/{view['session_id']}/submit")
    assert resp.status_code == 409
    assert "unanswered" in resp.json()["detail"]


def test_full_flow_answers_upload_submit(client):
    view = _create(client)
    sid = view["session_id"]
    answers = [
        {"canonical_id": q["canonical_id"], "answer": f"A{i}"}
        for i, q in enumerate(view["state"]["governance"]["questions"])
    ]
    resp = client.post(f"/api/post-dedup/sessions/{sid}/answers", json={"answers": answers})
    assert resp.status_code == 200
    assert resp.json()["completeness"]["complete"] is True

    # Submit still blocked: the .pptx diagram is required.
    assert client.post(f"/api/post-dedup/sessions/{sid}/submit").status_code == 409

    resp = client.post(
        f"/api/post-dedup/sessions/{sid}/attachments/upload",
        files={"file": ("diagram.pptx", b"fake-pptx-bytes", "application/octet-stream")},
    )
    assert resp.status_code == 200, resp.text

    resp = client.post(f"/api/post-dedup/sessions/{sid}/submit")
    assert resp.status_code == 200
    ticket = resp.json()["ticket"]
    assert ticket["ticket_id"].startswith("GOV-")
    assert ticket["team_forms"]["AI Program Office"]

    # Post-submit, mutating endpoints refuse.
    resp = client.post(
        f"/api/post-dedup/sessions/{sid}/answers",
        json={"answers": []},
    )
    assert resp.status_code == 400


def test_qa_review_endpoint_advisory_empty_under_skip_llm(client):
    view = _create(client)
    resp = client.post(f"/api/post-dedup/sessions/{view['session_id']}/qa-review")
    assert resp.status_code == 200
    assert resp.json() == {"concerns": []}


def test_stats_endpoint(client):
    view = _create(client)
    resp = client.get(f"/api/post-dedup/sessions/{view['session_id']}/stats")
    assert resp.status_code == 200
    body = resp.json()
    assert body["raw_question_count"] >= body["consolidated_question_count"]


def test_contentless_team_flows_through_api(client):
    view = _create(client, state={"activated_teams": ["Clinical Partnership Review"]})
    assert view["state"]["governance"]["questions"] == []
    assert view["completeness"]["complete"] is True


def test_unknown_teams_surface_in_view(client):
    view = _create(
        client,
        state={"activated_teams": ["AI Program Office", "Imaginary Team"]},
    )
    assert view["unknown_teams"] == ["Imaginary Team"]
