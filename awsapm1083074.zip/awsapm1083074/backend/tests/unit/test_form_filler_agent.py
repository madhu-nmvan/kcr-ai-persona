# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
FormFillerAgent sanity integration (docs/form_filler_agent_contract.md).

Covers the one invariant that matters -- a non-None input value must come
back byte-identical -- at three layers:
  1. StubFormFillerModel itself (the deterministic "model").
  2. fill_form's own defense-in-depth re-assertion, which must catch a model
     that violates the invariant rather than trusting the model class.
  3. The actual POST /api/formfiller/fill route, end to end.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from governance_intake.form_filler_agent import (
    FormFillerEnvelope,
    FormFillerInvariantError,
    FormFillerModel,
    GovernanceQuestion,
    StubFormFillerModel,
    TriggerField,
    fill_form,
)
from governance_intake.server import app

# Real intake_schema.json field types (see intake_schema.json), used to pin
# expected placeholder types without hand-rolling a fake schema.
STRING_TRIGGER_ID = "project_name"
BOOL_TRIGGER_ID = "involves_ai_ml_llm"
ARRAY_TRIGGER_ID = "target_deployment_hosting"


def _model() -> StubFormFillerModel:
    return StubFormFillerModel()


# ---------------------------------------------------------------------------
# StubFormFillerModel
# ---------------------------------------------------------------------------


def test_stub_fills_first_blank_string_trigger_with_placeholder_text() -> None:
    envelope = FormFillerEnvelope(
        triggers=[TriggerField(id=STRING_TRIGGER_ID, text="Project name?")]
    )
    result = _model().fill(envelope)
    item = result.triggers[0]
    assert item.value == "stub-filled answer"
    assert item.origin == "agent"
    assert item.confidence == 4


def test_stub_fills_blank_bool_trigger_with_true() -> None:
    envelope = FormFillerEnvelope(
        triggers=[TriggerField(id=BOOL_TRIGGER_ID, text="Involves AI/ML/LLM?")]
    )
    result = _model().fill(envelope)
    item = result.triggers[0]
    assert item.value is True
    assert item.origin == "agent"
    assert item.confidence == 4


def test_stub_fills_blank_array_trigger_with_empty_list() -> None:
    envelope = FormFillerEnvelope(
        triggers=[TriggerField(id=ARRAY_TRIGGER_ID, text="Target hosting?")]
    )
    result = _model().fill(envelope)
    item = result.triggers[0]
    assert item.value == []
    assert item.origin == "agent"
    assert item.confidence == 4


def test_stub_fills_blank_governance_question_with_placeholder_text() -> None:
    """Governance canonical IDs never appear in intake_schema.json -> free text."""
    envelope = FormFillerEnvelope(
        governance=[
            GovernanceQuestion(
                id="DEDUP.AI_SOLUTION_BE",
                text="Describe the AI solution's back end.",
                sources=[{"team": "AI Program Office", "question_id": "AI.1"}],
            )
        ]
    )
    result = _model().fill(envelope)
    item = result.governance[0]
    assert item.value == "stub-filled answer"
    assert item.origin == "agent"
    assert item.confidence == 4
    # Passthrough field is untouched.
    assert item.sources[0].team == "AI Program Office"


def test_stub_fills_exactly_the_first_blank_across_triggers_then_governance() -> None:
    envelope = FormFillerEnvelope(
        triggers=[
            TriggerField(id="already_answered", text="Answered?", value=True, origin="user"),
            TriggerField(id=STRING_TRIGGER_ID, text="Project name?"),
            TriggerField(id=BOOL_TRIGGER_ID, text="Involves AI/ML/LLM?"),
        ],
        governance=[
            GovernanceQuestion(id="DEDUP.X", text="Some governance question?"),
        ],
    )
    result = _model().fill(envelope)

    # First trigger: untouched, still answered by the user.
    assert result.triggers[0].value is True
    assert result.triggers[0].origin == "user"

    # Second trigger: the first blank -- gets filled.
    assert result.triggers[1].value == "stub-filled answer"
    assert result.triggers[1].origin == "agent"
    assert result.triggers[1].confidence == 4

    # Third trigger: still blank, never reached.
    assert result.triggers[2].value is None
    assert result.triggers[2].origin is None
    assert result.triggers[2].confidence is None

    # Governance: still blank, never reached.
    assert result.governance[0].value is None
    assert result.governance[0].origin is None
    assert result.governance[0].confidence is None


def test_stub_returns_answered_items_byte_identical() -> None:
    envelope = FormFillerEnvelope(
        triggers=[
            TriggerField(
                id=BOOL_TRIGGER_ID, text="Involves AI/ML/LLM?", value=False, origin="user"
            ),
        ],
        governance=[
            GovernanceQuestion(
                id="DEDUP.ANSWERED",
                text="Already answered?",
                value="yes, by a human",
                origin="user",
                sources=[{"team": "DUE", "question_id": "D.1"}],
            ),
        ],
    )
    result = _model().fill(envelope)
    assert result.triggers[0].model_dump() == envelope.triggers[0].model_dump()
    assert result.governance[0].model_dump() == envelope.governance[0].model_dump()


def test_stub_leaves_a_fully_answered_envelope_untouched() -> None:
    """No blanks anywhere -> fill() is a no-op."""
    envelope = FormFillerEnvelope(
        triggers=[TriggerField(id=BOOL_TRIGGER_ID, text="?", value=True, origin="user")],
        governance=[],
    )
    result = _model().fill(envelope)
    assert result.model_dump() == envelope.model_dump()


# ---------------------------------------------------------------------------
# fill_form -- defense-in-depth invariant re-assertion
# ---------------------------------------------------------------------------


class _OverwritingModel(FormFillerModel):
    """A deliberately-broken model that overwrites an already-answered item."""

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        result = envelope.model_copy(deep=True)
        for item in result.triggers:
            item.value = "corrupted"
            item.origin = "agent"
            item.confidence = 5
        return result


def test_fill_form_raises_when_the_model_overwrites_an_answered_item() -> None:
    envelope = FormFillerEnvelope(
        triggers=[
            TriggerField(id=STRING_TRIGGER_ID, text="Project name?", value="Real Answer", origin="user")
        ]
    )
    with pytest.raises(FormFillerInvariantError):
        fill_form(envelope, _OverwritingModel())


def test_fill_form_passes_through_the_stub_happily() -> None:
    envelope = FormFillerEnvelope(
        triggers=[
            TriggerField(id="already_answered", text="Answered?", value=True, origin="user"),
            TriggerField(id=STRING_TRIGGER_ID, text="Project name?"),
        ]
    )
    result = fill_form(envelope, StubFormFillerModel())
    assert result.triggers[0].value is True
    assert result.triggers[1].value == "stub-filled answer"


# ---------------------------------------------------------------------------
# Full round-trip through the actual FastAPI route
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def client() -> TestClient:
    return TestClient(app)


def test_route_round_trip_returns_200_and_expected_shape(client: TestClient) -> None:
    payload = {
        "triggers": [
            {
                "id": "already_answered",
                "text": "Answered?",
                "value": True,
                "origin": "user",
                "confidence": None,
            },
            {
                "id": STRING_TRIGGER_ID,
                "text": "Project name?",
                "value": None,
                "origin": None,
                "confidence": None,
            },
        ],
        "governance": [
            {
                "id": "DEDUP.ROUTE_TEST",
                "text": "A governance question?",
                "value": None,
                "origin": None,
                "confidence": None,
                "sources": [{"team": "DUE", "question_id": "D.9"}],
            }
        ],
    }

    response = client.post("/api/formfiller/fill", json=payload)

    assert response.status_code == 200
    body = response.json()

    # Answered item: byte-identical.
    assert body["triggers"][0] == payload["triggers"][0]

    # First blank (project_name, a string field): filled by the stub.
    filled = body["triggers"][1]
    assert filled["id"] == STRING_TRIGGER_ID
    assert filled["value"] == "stub-filled answer"
    assert filled["origin"] == "agent"
    assert filled["confidence"] == 4

    # Governance question never reached (trigger blank came first): untouched.
    assert body["governance"][0]["value"] is None
    assert body["governance"][0]["origin"] is None
    assert body["governance"][0]["sources"] == payload["governance"][0]["sources"]


def test_route_returns_422_for_a_schema_invalid_envelope(client: TestClient) -> None:
    """FastAPI's default validation error -- no custom error handling needed."""
    response = client.post("/api/formfiller/fill", json={"triggers": [{"id": "x"}]})
    assert response.status_code == 422


# ---------------------------------------------------------------------------
# T1 -- provenance coherence validator, exercised through the route
# (docs/form_filler_agent_contract.md invariant I1: value/origin/confidence
# must be a coherent triple; FastAPI/pydantic turns the nested
# model_validator's ValueError into a 422 with no route code changes.)
# ---------------------------------------------------------------------------


def test_route_returns_422_for_blank_item_carrying_a_user_origin(client: TestClient) -> None:
    payload = {
        "triggers": [{"id": "x", "text": "t?", "value": None, "origin": "user", "confidence": None}]
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 422


def test_route_returns_422_for_blank_item_carrying_an_agent_origin(client: TestClient) -> None:
    payload = {
        "triggers": [{"id": "x", "text": "t?", "value": None, "origin": "agent", "confidence": None}]
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 422


def test_route_returns_422_for_blank_item_carrying_a_confidence_score(client: TestClient) -> None:
    payload = {
        "triggers": [{"id": "x", "text": "t?", "value": None, "origin": None, "confidence": 3}]
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 422


def test_route_returns_422_for_answered_item_with_no_origin(client: TestClient) -> None:
    payload = {
        "triggers": [{"id": "x", "text": "t?", "value": "answer", "origin": None, "confidence": None}]
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 422


def test_route_returns_422_for_user_answer_carrying_a_confidence_score(client: TestClient) -> None:
    payload = {
        "triggers": [{"id": "x", "text": "t?", "value": "answer", "origin": "user", "confidence": 3}]
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 422


def test_route_returns_422_for_agent_answer_missing_a_confidence_score(client: TestClient) -> None:
    payload = {
        "triggers": [{"id": "x", "text": "t?", "value": "answer", "origin": "agent", "confidence": None}]
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 422


def test_route_returns_200_for_a_coherent_envelope(client: TestClient) -> None:
    """Regression check: I1 must not be over-strict -- valid combos still pass."""
    payload = {
        "triggers": [
            {"id": "t1", "text": "Blank?", "value": None, "origin": None, "confidence": None},
            {
                "id": "t2",
                "text": "Answered by user?",
                "value": "user answer",
                "origin": "user",
                "confidence": None,
            },
            {
                "id": "t3",
                "text": "Answered by agent?",
                "value": "agent answer",
                "origin": "agent",
                "confidence": 4,
            },
        ],
        "governance": [],
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 200


# ---------------------------------------------------------------------------
# T2 -- envelope integrity check, exercised directly against fill_form with
# a corrupt FormFillerModel test double (docs/form_filler_agent_contract.md
# invariant I2: a model must never remove/mutate a blank item's immutable
# fields, nor fill a blank without a proper agent-origin+confidence stamp.)
# ---------------------------------------------------------------------------


class _RemovingModel(FormFillerModel):
    """Deliberately-broken model that drops a blank governance question entirely."""

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        result = envelope.model_copy(deep=True)
        result.governance = [item for item in result.governance if item.value is not None]
        return result


class _MutatingTextModel(FormFillerModel):
    """Deliberately-broken model that rewrites a blank item's text instead of filling it."""

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        result = envelope.model_copy(deep=True)
        for item in result.governance:
            if item.value is None:
                item.text = "mutated question text"
        return result


class _ImpersonatingModel(FormFillerModel):
    """Deliberately-broken model that fills a blank but stamps it as user-provided."""

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        result = envelope.model_copy(deep=True)
        for item in result.governance:
            if item.value is None:
                item.value = "filled by impersonator"
                item.origin = "user"
                item.confidence = None
        return result


class _CorrectlyFillingModel(FormFillerModel):
    """A well-behaved model that fills a blank the way the contract requires."""

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        result = envelope.model_copy(deep=True)
        for item in result.governance:
            if item.value is None:
                item.value = "correctly filled answer"
                item.origin = "agent"
                item.confidence = 4
        return result


def _envelope_with_one_blank_governance_question() -> FormFillerEnvelope:
    return FormFillerEnvelope(
        governance=[
            GovernanceQuestion(
                id="DEDUP.T2_BLANK",
                text="A blank governance question?",
                sources=[{"team": "AI Program Office", "question_id": "AI.1"}],
            )
        ]
    )


def test_fill_form_raises_when_the_model_removes_a_blank_item() -> None:
    envelope = _envelope_with_one_blank_governance_question()
    with pytest.raises(FormFillerInvariantError):
        fill_form(envelope, _RemovingModel())


def test_fill_form_raises_when_the_model_mutates_a_blank_items_text() -> None:
    envelope = _envelope_with_one_blank_governance_question()
    with pytest.raises(FormFillerInvariantError):
        fill_form(envelope, _MutatingTextModel())


def test_fill_form_raises_when_the_model_impersonates_the_user_to_fill_a_blank() -> None:
    envelope = _envelope_with_one_blank_governance_question()
    with pytest.raises(FormFillerInvariantError):
        fill_form(envelope, _ImpersonatingModel())


def test_fill_form_accepts_a_correctly_filled_blank() -> None:
    """Positive control: the check isn't just rejecting everything."""
    envelope = _envelope_with_one_blank_governance_question()
    result = fill_form(envelope, _CorrectlyFillingModel())
    item = result.governance[0]
    assert item.value == "correctly filled answer"
    assert item.origin == "agent"
    assert item.confidence == 4
    assert item.text == "A blank governance question?"
    assert item.sources[0].team == "AI Program Office"


# ---------------------------------------------------------------------------
# I2 residual -- duplicate item ids (Beta re-review, 2026-07-16). The old
# `_assert_collection_integrity` built `{item.id: item for item in items}`
# *before* comparing before/after, so two items sharing an id silently
# collapsed to one dict key on each side -- a dropped duplicate was
# invisible to the "keys match" check. Two defenses now exist:
#   Part A -- FormFillerEnvelope._validate_unique_ids rejects duplicate ids
#             at the schema boundary (422 at the route), same principle as I1.
#   Part B -- _assert_collection_integrity no longer trusts that the
#             boundary always ran: it checks count, then sorted-id identity
#             (which also catches multiset-shifted duplicates), then
#             explicitly refuses to proceed if either side still carries a
#             duplicate id despite Part A -- in case a model's fill()
#             constructs its return via model_construct(), skipping
#             FormFillerEnvelope's validators entirely.
# ---------------------------------------------------------------------------


def test_constructing_envelope_with_duplicate_governance_ids_raises_validation_error() -> None:
    with pytest.raises(ValidationError, match="duplicate item ids"):
        FormFillerEnvelope(
            governance=[
                GovernanceQuestion(id="DUP", text="First blank governance question?"),
                GovernanceQuestion(id="DUP", text="Second blank governance question?"),
            ]
        )


def test_route_returns_422_for_envelope_with_duplicate_governance_ids(client: TestClient) -> None:
    payload = {
        "governance": [
            {
                "id": "DUP",
                "text": "First blank governance question?",
                "value": None,
                "origin": None,
                "confidence": None,
                "sources": [],
            },
            {
                "id": "DUP",
                "text": "Second blank governance question?",
                "value": None,
                "origin": None,
                "confidence": None,
                "sources": [],
            },
        ]
    }
    response = client.post("/api/formfiller/fill", json=payload)
    assert response.status_code == 422


class _DroppingOneOfTwoModel(FormFillerModel):
    """Deliberately-broken model whose fill() silently drops one item, shrinking the collection."""

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        result = envelope.model_copy(deep=True)
        result.governance = result.governance[:1]
        return result


def test_fill_form_raises_when_the_model_drops_one_of_two_distinct_id_items() -> None:
    """
    Simplest direct reproduction of Beta's underlying finding, independent of
    duplicate ids entirely: two DISTINCT-id blank governance items go in, the
    model's fill() returns only one of them. The count check added in Part B
    (`len(before_items) != len(after_items)`) catches this on its own, before
    any id comparison runs at all.
    """
    envelope = FormFillerEnvelope(
        governance=[
            GovernanceQuestion(id="G1", text="A blank governance question?"),
            GovernanceQuestion(id="G2", text="Another blank governance question?"),
        ]
    )
    with pytest.raises(FormFillerInvariantError, match="item count changed"):
        fill_form(envelope, _DroppingOneOfTwoModel())


class _DuplicatingIdOutputModel(FormFillerModel):
    """
    Deliberately-broken model simulating an implementation that builds its
    return via FormFillerEnvelope.model_construct() -- bypassing
    _validate_unique_ids entirely -- and hands back a governance collection
    with a duplicated id.
    """

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        duplicated_item = envelope.governance[0].model_copy(deep=True)
        return FormFillerEnvelope.model_construct(
            triggers=envelope.triggers,
            governance=[duplicated_item, duplicated_item.model_copy(deep=True)],
        )


def test_fill_form_raises_when_the_models_output_contains_a_duplicate_id_via_model_construct() -> None:
    """
    Proves the defense-in-depth point specifically: Part B's duplicate-id
    refusal, not just the sorted-id check, is what closes the gap when a
    model bypasses validated construction.

    Note on construction: the sorted-id check added in Part B also catches
    any "multiset-shifted" duplicate -- if `before` has N distinct ids and
    `after` (same length) contains a repeat, `sorted(before) != sorted(after)`
    by definition (a repeat means <=N-1 distinct values on one side). Part A
    guarantees a normally-constructed `before` is always duplicate-free, so
    that branch would already catch any duplicate introduced *only* on the
    `after` side. To reach the duplicate-id-refusal branch itself -- the
    genuinely last line of defense, for when neither side went through
    validated construction -- `before` here is also built via
    model_construct() with the same duplicated id the corrupt model echoes
    back, simulating a caller that bypassed the schema boundary entirely
    (e.g. stale data predating Part A). Even in that already-degraded
    scenario, Part B refuses to guess at per-item identity rather than
    silently accepting it.
    """
    blank = GovernanceQuestion.model_construct(
        id="DUP", text="A blank governance question?", value=None, origin=None,
        confidence=None, sources=[],
    )
    envelope = FormFillerEnvelope.model_construct(
        triggers=[], governance=[blank, blank.model_copy(deep=True)]
    )
    with pytest.raises(FormFillerInvariantError, match="duplicate item ids"):
        fill_form(envelope, _DuplicatingIdOutputModel())


def test_fill_form_raises_on_betas_reported_duplicate_id_drop_scenario() -> None:
    """
    Regression test for Beta's residual I2 finding (feature-form-filler-agent
    review, acknowledged_by_author I2, 2026-07-16): two blank governance
    items shared `id="DUP"`; the model dropped one; the old
    `_assert_collection_integrity` built `{item.id: item for item in items}`
    on each side *before* comparing, so both `before` and `after` collapsed
    to the single key `{"DUP": ...}` and the corruption was accepted.

    Part A now rejects a duplicate-id `before` at normal construction, so
    reproducing the exact input shape requires model_construct() to bypass
    it -- itself evidence that Part A closes this hole for every real
    caller. Even in that bypassed case, Part B's count check catches the
    drop immediately (2 items in, 1 item out) rather than trusting a
    dict-collapsed id-set comparison.
    """
    dup_a = GovernanceQuestion.model_construct(
        id="DUP", text="First blank governance question?", value=None,
        origin=None, confidence=None, sources=[],
    )
    dup_b = GovernanceQuestion.model_construct(
        id="DUP", text="Second blank governance question?", value=None,
        origin=None, confidence=None, sources=[],
    )
    envelope = FormFillerEnvelope.model_construct(triggers=[], governance=[dup_a, dup_b])
    with pytest.raises(FormFillerInvariantError, match="item count changed"):
        fill_form(envelope, _DroppingOneOfTwoModel())
