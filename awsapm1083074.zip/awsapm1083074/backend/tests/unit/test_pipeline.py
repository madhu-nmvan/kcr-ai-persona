# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Pure-function pipeline tests (no LLM, no AWS).

Exercises the deterministic pieces end to end against the bundled config:
rule_engine -> question_dedup -> form_mapper -> gap_detector -> ticket_creator,
plus schema_check. This is the fast feedback loop and the proof that the
routing + deduplication config is internally consistent.
"""

from __future__ import annotations

import pytest

from governance_intake.intake_agent import RoutingFields
from governance_intake.form_mapper import map_answers_to_team_forms
from governance_intake.gap_detector import detect_gaps
from governance_intake.handler import IntakeData
from governance_intake.question_dedup import build_pending_questions, dedup_stats
from governance_intake.rule_engine import evaluate_rules
from governance_intake.schema_check import (
    all_routing_fields_present,
    missing_required_fields,
)
from governance_intake.session import InMemorySessionStore, new_session
from governance_intake.ticket_creator import create_ticket


# A production AI project whose routing answers activate every current team;
# shared project-description questions should still collapse through deduplication.
COLLECTED = {
    "project_name": "Claims Summarizer",
    "project_description": "AI summarization of Medicare claims for case managers.",
    "involves_ai_ml_llm": True,
    "new_use_of_ai": True,
    "ai_ml_llm_business_use_case_fit": True,
    "level_of_development": "Production",
    "target_deployment_hosting": ["ElevanceHealth Cloud Instance"],
    "vendor_use": True,
    "PHI_PI_PFI_use": True,
    "stakeholder_value": True,
    "abrasive_to_providers_customers_members": True,
    "data_solution_types": ["Proxy ID"],
    "new_or_different_deployment_type": True,
    "has_business_received_communication": True,
    "vendor_data_access": True,
    "external_data_release": True,
    "within_data_use_release_policy": False,
    "accesses_enterprise_data_platforms": True,
    "architectural_material_change": True,
    "new_altered_business_proccess": True,
    "sending_receiving_protected_information": True,
    "lines_of_business_for_deployment": ["CarelonRx", "Commercial NGS", "Commercial – FGS"],
    "identify_vendors_to_PI": ["Acme Corp"],
    # Wave-1 routing inputs (teams added on feature/trigger-rules-guardrails).
    "use_of_clinical_data": "Care Management",
    "manners_of_use": ["Client data will flow through the solution"],
    "new_novel_PI_use": True,
    "new_novel_technology": True,
    "high_risk_use_potential": True,
    "impacts_members_providers": True,
    "consumer_impacts": ["Telephone calls"],
    "use_of_payment_information_data": True,
    # deployment_line_of_business is a single-select enum, so FEP and WellPoint
    # Federal are mutually exclusive; this profile selects FEP, so only Anthem
    # FEP activates (WellPoint's own activation is covered in test_rule_engine).
    "deployment_line_of_business": "FEP",
    "involves_contacting_delegates_vendors_behalf_EH": True,
    "risk_of_heath_care_fraud_waste_abuse": True,
    "violates_CMS_state_program_requirements": True,
    "involves_digital_health_member_outcomes": True,
    "regulatory_reputational_risks": True,
    "changes_regulated_functions": True,
    "potential_for_compliance_issue": True,
    "new_software": True,
    "newly_deployed_software": True,
    "what_type_technology_gov_request": "PROD",
    "use_of_previously_unapproved_software": True,
    "vendor_provided_service": "New",
}


@pytest.fixture(scope="module")
def data() -> IntakeData:
    return IntakeData()


def test_routing_fields_complete(data: IntakeData) -> None:
    """A fully-answered realistic intake satisfies every current required field."""
    assert missing_required_fields(data.intake_schema, COLLECTED) == []
    assert all_routing_fields_present(data.intake_schema, COLLECTED) is True


def test_routing_fields_report_an_empty_required_multi_select(data: IntakeData) -> None:
    # An empty selection is not a complete answer for the required
    # data-solution-types field, even though it does not prevent rule evaluation.
    incomplete = dict(COLLECTED, data_solution_types=[])
    missing = missing_required_fields(data.intake_schema, incomplete)
    assert [field["name"] for field in missing] == ["data_solution_types"]
    assert all_routing_fields_present(data.intake_schema, incomplete) is False


def test_no_vendor_intake_does_not_require_vendor_names(data: IntakeData) -> None:
    """Regression for issue #3: identify_vendors_to_PI must not gate Phase 1
    when the project never grants a vendor access to Protected Information.
    """
    no_vendor = dict(
        COLLECTED,
        vendor_use=False,
        vendor_data_access=False,
        identify_vendors_to_PI=None,
    )
    missing = missing_required_fields(data.intake_schema, no_vendor)
    assert "identify_vendors_to_PI" not in [field["name"] for field in missing]
    assert all_routing_fields_present(data.intake_schema, no_vendor) is True


def test_every_required_schema_field_is_extractable(data: IntakeData) -> None:
    """Phase 1 cannot require a value that structured extraction cannot return."""
    required_fields = {
        field["name"] for field in data.intake_schema["fields"] if field.get("required")
    }
    assert required_fields <= RoutingFields.model_fields.keys()


def test_rules_activate_expected_teams(data: IntakeData) -> None:
    activated = evaluate_rules(COLLECTED, data.trigger_rules)
    team_names = {t["team"] for t in activated}
    # The profile intentionally satisfies each team's configured trigger.
    # WellPoint Federal is absent by design: it shares the single-select
    # deployment_line_of_business enum with Anthem FEP, and the profile
    # selects FEP (see COLLECTED). Its activation is covered in
    # test_rule_engine.py::test_wellpoint_federal_fires_for_wellpoint_line_of_business.
    assert team_names == {
        "AI Program Office",
        "RAI",
        "Legal Tech-AI",
        "Privacy",
        "DUE",
        "Security-InfoSec",
        "Security-ESA",
        "Security-VSRM",
        "Cloud Adoption",
        "Procurement",
        "Enterprise Architecture",
        "BU/Regulatory",
        "EDA ARB",
        "EDOM",
        "Clinical Partnership Review",
        "Corporate Communications",
        "Legal - Data Governance & Privacy",
        "Legal - Intellectual Property (IP)",
        "Legal-Tech-Novel or High Risk Tech",
        "Legal-Tech-Commercialization",
        "OCCO",
        "On-Prem/Private Hosting",
        "Payment Card Industry (PCI)",
        "Anthem Federal Employees Program (FEP)",
        "National Government Solutions (NGS)",
        "Federal Government Solutions (FGS) Home Office",
        "Compliance-Technology",
        "Enterprise Standards Governance (ESG)",
    }


def test_dedup_reduces_question_count(data: IntakeData) -> None:
    team_names = [t["team"] for t in evaluate_rules(COLLECTED, data.trigger_rules)]
    pending = build_pending_questions(team_names, data.questionnaires, data.dedup_mapping)
    stats = dedup_stats(team_names, data.questionnaires, pending)
    # Consolidation must never invent questions and must remove at least some.
    assert stats["consolidated_question_count"] <= stats["raw_question_count"]
    assert stats["reduction_ratio"] > 0.0


def test_fan_out_fills_every_configured_team_form(data: IntakeData) -> None:
    team_names = [t["team"] for t in evaluate_rules(COLLECTED, data.trigger_rules)]
    pending = build_pending_questions(team_names, data.questionnaires, data.dedup_mapping)
    for q in pending:
        q["answered"] = True
        q["answer"] = f"<answer for {q['canonical_id']}>"

    team_forms = map_answers_to_team_forms(pending, team_names)
    # After the xlsx-primary merge, the fan-out fills a form for every activated
    # team that has questionnaire content. The one exception is a team with no
    # questionnaire content at all: Clinical Partnership Review is a delegated
    # team whose only real question is its PI.8 trigger itself -- it has an
    # entry with zero questions (DATA_GAPS.md sec 3), so it activates for
    # routing but legitimately has no form to fill.
    teams_with_content = {
        team
        for team in team_names
        if data.questionnaires["teams"].get(team, {}).get("questions")
    }
    assert {team for team, form in team_forms.items() if form} == teams_with_content

    gaps = detect_gaps(team_names, data.questionnaires, team_forms)
    assert gaps == [], f"unexpected gaps after answering all canonicals: {gaps}"


def test_equivalent_ai_program_office_questions_are_deduplicated(data: IntakeData) -> None:
    """One canonical must fan out to both equivalent active AIPO question IDs."""
    team_names = [t["team"] for t in evaluate_rules(COLLECTED, data.trigger_rules)]
    pending = build_pending_questions(team_names, data.questionnaires, data.dedup_mapping)
    ai_solution_canonical = next(
        (q for q in pending if q["canonical_id"] == "DEDUP.AI_SOLUTION_BE"), None
    )
    assert ai_solution_canonical is not None
    assert {source["question_id"] for source in ai_solution_canonical["sources"]} == {
        "AIPO.2",
        "AIPO.3",
    }


def test_ticket_creation(data: IntakeData) -> None:
    activated = evaluate_rules(COLLECTED, data.trigger_rules)
    team_names = [t["team"] for t in activated]
    pending = build_pending_questions(team_names, data.questionnaires, data.dedup_mapping)
    for q in pending:
        q["answered"] = True
        q["answer"] = f"<answer for {q['canonical_id']}>"
    team_forms = map_answers_to_team_forms(pending, team_names)

    store = InMemorySessionStore()
    sess = new_session("test", "test@elevancehealth.com")
    sess.update(
        {
            "phase": "complete",
            "collected_fields": COLLECTED,
            "activated_teams": activated,
            "pending_questions": pending,
            "team_forms": team_forms,
        }
    )
    ticket = create_ticket(sess)
    sess["ticket"] = ticket
    store.put(sess)

    assert ticket["ticket_id"]
    assert len(ticket["answered_questions"]) == len(pending)
    assert {t["team"] for t in ticket["activated_teams"]} == set(team_names)
