# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""qa_review: advisory-only final pass."""

from __future__ import annotations

from governance_intake.qa_review import QAConcern, QAReview, review_answers


def _sess(answered=2, unanswered=1):
    qs = []
    for i in range(answered):
        qs.append(
            {"canonical_id": f"A{i}", "canonical_question": f"Q{i}?",
             "answered": True, "answer": f"answer {i}"}
        )
    for i in range(unanswered):
        qs.append(
            {"canonical_id": f"U{i}", "canonical_question": f"Open{i}?",
             "answered": False, "answer": None}
        )
    return {"pending_questions": qs}


class FakeAgent:
    def __init__(self, review):
        self.review = review
        self.prompts = []

    def structured_output(self, model_cls, prompt):
        assert model_cls is QAReview
        self.prompts.append(prompt)
        return self.review


def test_concerns_flow_through_and_persist_on_session():
    sess = _sess()
    fake = FakeAgent(
        QAReview(concerns=[QAConcern(canonical_id="A0", concern="vague", clarifying_question="Which system?")])
    )
    concerns = review_answers(sess, agent_factory=lambda: fake)
    assert concerns == sess["qa_review"]
    assert concerns[0]["canonical_id"] == "A0"
    # Only answered questions are shown to the reviewer agent.
    assert "U0" not in fake.prompts[0]


def test_concerns_for_unknown_or_unanswered_ids_are_dropped():
    sess = _sess()
    fake = FakeAgent(
        QAReview(
            concerns=[
                QAConcern(canonical_id="U0", concern="x", clarifying_question="y"),
                QAConcern(canonical_id="GHOST", concern="x", clarifying_question="y"),
            ]
        )
    )
    assert review_answers(sess, agent_factory=lambda: fake) == []


def test_concern_count_is_capped():
    sess = _sess(answered=10)
    fake = FakeAgent(
        QAReview(
            concerns=[
                QAConcern(canonical_id=f"A{i}", concern="c", clarifying_question="q")
                for i in range(10)
            ]
        )
    )
    assert len(review_answers(sess, agent_factory=lambda: fake, max_concerns=3)) == 3


def test_skip_llm_and_nothing_answered_return_empty(monkeypatch):
    boom = lambda: (_ for _ in ()).throw(AssertionError("must not be called"))  # noqa: E731

    empty = _sess(answered=0, unanswered=3)
    assert review_answers(empty, agent_factory=boom) == []
    assert empty["qa_review"] == []

    monkeypatch.setenv("INTAKE_SKIP_LLM", "1")
    sess = _sess()
    assert review_answers(sess, agent_factory=boom) == []
