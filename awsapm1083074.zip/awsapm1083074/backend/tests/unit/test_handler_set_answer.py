# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
IntakeHandler.set_answer -- direct (non-chat) Phase-2 answer write.

Regression coverage for a Beta finding (backend-three-diff-reconciliation
review, I1): the presence/clear semantics must match
postdedup.record_answers exactly -- only None or a blank string clears a
question. False and 0 are valid answers and must mark the question
answered, not clear it.
"""

from __future__ import annotations

from governance_intake.handler import IntakeData, IntakeHandler
from governance_intake.session import PHASE_ASKING, InMemorySessionStore, new_session


def _asking_session_with_one_pending() -> dict:
    sess = new_session("sess-set-answer-test", "demo@elevancehealth.com")
    sess["phase"] = PHASE_ASKING
    sess["activated_teams"] = []
    sess["pending_questions"] = [
        {
            "canonical_id": "TEST.Q1",
            "canonical_question": "Does this involve X?",
            "sources": [],
            "answered": False,
            "answer": None,
        }
    ]
    return sess


def _handler() -> IntakeHandler:
    return IntakeHandler(store=InMemorySessionStore(), demo_mode=False)


def test_set_answer_false_is_answered_not_cleared() -> None:
    handler = _handler()
    sess = _asking_session_with_one_pending()
    handler.store.put(sess)

    handler.set_answer(sess["session_id"], "TEST.Q1", False)

    stored = handler.store.get(sess["session_id"])
    q = next(q for q in stored["pending_questions"] if q["canonical_id"] == "TEST.Q1")
    assert q["answer"] is False
    assert q["answered"] is True


def test_set_answer_zero_is_answered_not_cleared() -> None:
    handler = _handler()
    sess = _asking_session_with_one_pending()
    handler.store.put(sess)

    handler.set_answer(sess["session_id"], "TEST.Q1", 0)

    stored = handler.store.get(sess["session_id"])
    q = next(q for q in stored["pending_questions"] if q["canonical_id"] == "TEST.Q1")
    assert q["answer"] == 0
    assert q["answered"] is True


def test_set_answer_none_clears() -> None:
    handler = _handler()
    sess = _asking_session_with_one_pending()
    sess["pending_questions"][0]["answer"] = "something"
    sess["pending_questions"][0]["answered"] = True
    sess["pending_questions"][0]["answer_origin"] = "user"
    handler.store.put(sess)

    handler.set_answer(sess["session_id"], "TEST.Q1", None)

    stored = handler.store.get(sess["session_id"])
    q = next(q for q in stored["pending_questions"] if q["canonical_id"] == "TEST.Q1")
    assert q["answer"] is None
    assert q["answered"] is False
    assert "answer_origin" not in q


def test_set_answer_blank_string_clears() -> None:
    handler = _handler()
    sess = _asking_session_with_one_pending()
    handler.store.put(sess)

    handler.set_answer(sess["session_id"], "TEST.Q1", "   ")

    stored = handler.store.get(sess["session_id"])
    q = next(q for q in stored["pending_questions"] if q["canonical_id"] == "TEST.Q1")
    assert q["answered"] is False


def test_set_answer_normal_string_is_answered() -> None:
    handler = _handler()
    sess = _asking_session_with_one_pending()
    handler.store.put(sess)

    handler.set_answer(sess["session_id"], "TEST.Q1", "Yes, on AWS")

    stored = handler.store.get(sess["session_id"])
    q = next(q for q in stored["pending_questions"] if q["canonical_id"] == "TEST.Q1")
    assert q["answer"] == "Yes, on AWS"
    assert q["answered"] is True
    assert q["answer_origin"] == "user"
