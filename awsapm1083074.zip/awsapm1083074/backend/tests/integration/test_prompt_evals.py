# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Prompt eval harness runner (docs/eval_harness_contract.md).

Loads the generated EvalCase fixtures (backend/tests/integration/fixtures/
generated/{intake_agent,form_filler_agent}_cases.json -- produced by a
separate case-generation pass; each file carries a "_meta" header noting it's
regenerable, AI-authored, and NOT a hand-vetted golden set) and, for every
case, runs the case's input through the REAL agent entry point
(`extract_routing_fields` for intake_agent cases, `fill_form` for
form_filler_agent cases), then applies every check in the case via
`governance_intake.eval_harness` -- deterministic checks through the pure
evaluators, `judge` checks through `judge_answer()` using the real,
EHAP-backed `EHAPJudge` (the default `judge_answer()` uses when no `judge=`
override is passed, i.e. exactly what runs here).

Two things stop this file from being smoke-tested end to end in this dev
environment, both stated plainly rather than glossed over:

1. No `.env` / EHAP credentials exist here. `extract_routing_fields` calls
   `get_ehap_model()`, which raises `RuntimeError` immediately if
   `EHAP_URL`/`EHAP_CLIENT_ID`/`EHAP_CLIENT_SECRET` aren't set. Any judge
   check would hit the same wall through `EHAPJudge`.
2. Independent of credentials: no EHAP-backed `FormFillerModel` exists yet
   anywhere in this codebase (`form_filler_agent.py`'s only implementation is
   `StubFormFillerModel`; live EHAP wiring is explicitly out of scope for the
   FormFillerAgent contract pass -- see docs/form_filler_agent_contract.md,
   "Explicitly out of scope"). So even with credentials, form_filler_agent
   eval cases can't run against a real model until that lands -- running them
   against the stub instead would silently evaluate the wrong thing (the
   stub fills exactly one placeholder field per call; it would fail nearly
   every check written for real LLM behavior, in a way that looks like a
   regression but isn't).

Both surface as a clear `pytest.skip` (not a hard failure) the first time
`_run_case` raises `RuntimeError`, since every case in a run hits the same
missing-credentials-or-model wall.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, List

import pytest

from governance_intake.eval_harness import CaseResult, EvalCase, load_eval_cases, parse_case_input, run_eval_cases
from governance_intake.form_filler_agent import FormFillerEnvelope, FormFillerModel, fill_form
from governance_intake.intake_agent import extract_routing_fields
from governance_intake.ehap_model import get_ehap_model

pytestmark = pytest.mark.integration

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures" / "generated"
INTAKE_FIXTURE = FIXTURES_DIR / "intake_agent_cases.json"
FORM_FILLER_FIXTURE = FIXTURES_DIR / "form_filler_agent_cases.json"


def _load_or_skip(path: Path) -> List[EvalCase]:
    if not path.exists():
        pytest.skip(
            f"generated eval fixture not found yet: {path} "
            "(the case-generation pass may not have finished/run in this environment)"
        )
    return load_eval_cases(path)


def _real_form_filler_model() -> FormFillerModel:
    """
    No EHAP-backed FormFillerModel exists in this codebase yet -- see this
    file's module docstring, point 2. Raise a specific, catchable error so
    the test can skip with an accurate reason instead of quietly falling
    back to StubFormFillerModel (which would produce meaningless results).
    """
    raise RuntimeError(
        "no EHAP-backed FormFillerModel exists yet in governance_intake.form_filler_agent "
        "(only StubFormFillerModel is implemented -- live EHAP wiring is explicitly out of "
        "scope for the FormFillerAgent contract pass, see docs/form_filler_agent_contract.md); "
        "form_filler_agent eval cases cannot run against a real model until that lands"
    )


def _skip_if_ehap_not_configured() -> None:
    """
    Preflight check, run ONCE before any case executes -- not caught
    per-case. get_ehap_model() does zero network I/O; it only raises if
    EHAP_URL/EHAP_CLIENT_ID/EHAP_CLIENT_SECRET are unset, which is the one
    legitimate "not set up for live testing" precondition. Anything that
    goes wrong AFTER this point (unreachable host, bad response, etc.) is
    a real failure, not a reason to skip -- see _run_and_assert.
    """
    try:
        get_ehap_model()
    except RuntimeError as exc:
        pytest.skip(f"EHAP not configured in this environment: {exc}")


def _skip_if_no_real_form_filler_model() -> None:
    """Same preflight principle as above, for the form_filler_agent path."""
    try:
        _real_form_filler_model()
    except RuntimeError as exc:
        pytest.skip(f"no real FormFillerModel implementation exists yet: {exc}")


def _run_case(case: EvalCase) -> Any:
    parsed_input = parse_case_input(case)
    if case.agent == "intake_agent":
        return extract_routing_fields(parsed_input)
    assert isinstance(parsed_input, FormFillerEnvelope)  # narrows for mypy; parse_case_input guarantees this
    model = _real_form_filler_model()
    return fill_form(parsed_input, model)


def _format_report(results: List[CaseResult]) -> str:
    lines = []
    for result in results:
        lines.append(f"[{'PASS' if result.passed else 'FAIL'}] {result.case_id}")
        for check, outcome in result.outcomes:
            lines.append(f"    - {check.type} field_id={check.field_id}: {'ok' if outcome.passed else 'FAIL'} -- {outcome.reason}")
    return "\n".join(lines)


def _run_and_assert(cases: List[EvalCase]) -> None:
    results = run_eval_cases(cases, _run_case)
    report = _format_report(results)
    failed = [r.case_id for r in results if not r.passed]
    assert not failed, f"{len(failed)}/{len(results)} eval case(s) failed:\n{report}"


def test_intake_agent_eval_cases() -> None:
    _skip_if_ehap_not_configured()
    cases = [c for c in _load_or_skip(INTAKE_FIXTURE) if c.agent == "intake_agent"]
    if not cases:
        pytest.skip(f"{INTAKE_FIXTURE} has no intake_agent cases")
    _run_and_assert(cases)


def test_form_filler_agent_eval_cases() -> None:
    _skip_if_no_real_form_filler_model()
    cases = [c for c in _load_or_skip(FORM_FILLER_FIXTURE) if c.agent == "form_filler_agent"]
    if not cases:
        pytest.skip(f"{FORM_FILLER_FIXTURE} has no form_filler_agent cases")
    _run_and_assert(cases)
