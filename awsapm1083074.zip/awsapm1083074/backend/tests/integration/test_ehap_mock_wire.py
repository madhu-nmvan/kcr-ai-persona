# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
EHAP wire-shape integration test against the local ehap-mock server.

Boots ehap-mock (stdlib-only, see ehap-mock/README.md) on an ephemeral port
and drives the real EHAPClient through it: OAuth token issuance, an
authenticated chat call, and the 401 paths (bad sentinel credentials,
revoked token). This proves the client speaks the gateway's shapes without
needing real EHAP credentials.

Skipped automatically when the ehap-mock checkout isn't present.
Run: uv run --extra dev pytest backend/tests/integration -m integration
"""

from __future__ import annotations

import contextlib
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import pytest
import requests

from governance_intake.ehap_model import EHAPClient

pytestmark = pytest.mark.integration

MOCK_DIR = Path(__file__).resolve().parents[3] / "ehap-mock"
FAIL_CLIENT_ID = "mock-invalid-client"


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def mock_server():
    script = MOCK_DIR / "ehap_mock.py"
    if not script.exists():
        pytest.skip("ehap-mock checkout not present")
    port = _free_port()
    proc = subprocess.Popen(
        [sys.executable, str(script)],
        cwd=MOCK_DIR,
        env={
            "PATH": "/usr/bin:/bin",
            "EHAP_MOCK_PORT": str(port),
            "EHAP_MOCK_FAIL_CLIENT_ID": FAIL_CLIENT_ID,
        },
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(50):
            with contextlib.suppress(OSError):
                with urllib.request.urlopen(f"{base}/healthz", timeout=1):
                    break
            time.sleep(0.1)
        else:
            pytest.fail("ehap-mock did not come up")
        yield base
    finally:
        proc.terminate()
        proc.wait(timeout=5)


def _client(base: str, client_id: str = "dev-client") -> EHAPClient:
    # Dummy credential for the local ehap-mock only - not a real secret.
    # nosec B106: hardcoded value is intentional test scaffolding.
    return EHAPClient(
        endpoint=base,
        client_id=client_id,
        client_secret="dev-secret", # nosec B106
        model_id="anthropic:claude-sonnet-4-6",
    )


def test_token_then_authenticated_chat_wire(mock_server):
    client = _client(mock_server)
    token = client.get_token()
    assert token
    # Wire-level only: the mock's /v2/text/chats catalog entry carries no
    # response_example (spec had none), so it returns an empty JSON object
    # and EHAPClient.chat()'s text extraction rightly refuses it — tracked
    # as a mock-fidelity issue. The auth + request shape is still proven.
    resp = requests.post(
        f"{mock_server}/v2/text/chats",
        headers={"Authorization": f"Bearer {token}"},
        params={"qos": "accurate", "preview": "true"},
        json=client._build_body(
            [{"role": "user", "content": "hello"}], system="You are a test.", stream=False
        ),
        timeout=10,
    )
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/json")


def test_bad_credentials_401(mock_server):
    client = _client(mock_server, client_id=FAIL_CLIENT_ID)
    with pytest.raises(requests.HTTPError) as exc:
        client.get_token()
    assert exc.value.response.status_code == 401


def test_revoked_token_401(mock_server):
    client = _client(mock_server)
    token = client.get_token()
    requests.post(f"{mock_server}/_mock/tokens/{token}/revoke", timeout=5)
    with pytest.raises(requests.HTTPError) as exc:
        client.chat([{"role": "user", "content": "hello"}])
    assert exc.value.response.status_code == 401
