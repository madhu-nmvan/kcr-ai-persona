# Eval fixtures

Checked-in input data for the prompt eval suite
(`backend/tests/integration/test_prompt_evals.py`). For the eval *contract* —
the check-type schema, what "pass" means, when the suite skips vs. fails —
see [`docs/eval_harness_contract.md`](../../../../docs/eval_harness_contract.md).
This file covers only what's on disk here.

---

## `generated/`

`intake_agent_cases.json` and `form_filler_agent_cases.json` — one JSON file
per agent under test. Each has:

```json
{
  "_meta": { "note": "...", "generated_by": "Beta", "date": "..." },
  "cases": [
    {
      "id": "intake-clear-ai-pilot-with-sensitive-data",
      "agent": "intake_agent",
      "description": "...",
      "input": [ /* chat turns, or trigger-field state for form_filler */ ],
      "checks": [ /* field_equals / field_null / origin_equals / ... */ ]
    }
  ]
}
```

`_meta.note` is load-bearing: these are **AI-generated dev-confidence
scenarios**, not a hand-vetted golden set or a compliance corpus. Treat a
failing case as "investigate," not "the spec was violated" — the check
schema and generation process are the contract; these files are just one
instantiation of it.

**Regenerating**: there's no regeneration script checked in. Per the eval
harness contract, case generation is a one-time-ish step (Beta authoring
realistic + adversarial scenarios against the schema) that produces these
committed fixtures directly — not a pipeline you re-run automatically.
