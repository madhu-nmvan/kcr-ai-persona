# Backend — governance-intake

Python 3.12 + [uv]. Runs the FastAPI app on port 8000 and hosts the
deterministic routing/dedup pipeline plus the EHAP gateway client.

This doc covers the backend dev workflow: setup, running the server, testing
(including the prompt eval suite), linting/type-checking, and backend-specific
troubleshooting. For the app overview and the end-to-end local/SageMaker
walkthroughs, see the [root README](../README.md).

[uv]: https://docs.astral.sh/uv/

---

## Setup

From the repo root, in PowerShell:

```powershell
uv sync --all-extras
```

If you don't have `uv`: `pip install uv` (or `python -m pip install uv`) first.
If Python itself is missing, install Python 3.12+ (or `uv python install 3.12`).

### Configure your `.env`

```powershell
Copy-Item .env.example .env
notepad .env
```

For real chat, fill in the EHAP credentials:

```
EHAP_URL=https://api.horizon.elevancehealth.com
EHAP_CLIENT_ID=<your id>
EHAP_CLIENT_SECRET=<your secret>
EHAP_MODEL_ID=anthropic:claude-sonnet-4-6
```

Defaults use no AWS (in-memory sessions, local-disk uploads), so nothing else
is needed to run.

### Running without real EHAP (`DEV=true`)

Local development and this backend's integration/eval test suite can run
without real EHAP access. Set `DEV=true` in `.env`; `EHAP_URL`,
`EHAP_CLIENT_ID`, and `EHAP_CLIENT_SECRET` then default to a local placeholder
(`http://localhost:8811`, dummy credentials) unless already set explicitly in
`.env` — an explicit value always wins. This repo does not ship a substitute
EHAP service. Point `DEV` mode at real EHAP credentials, or at any
locally-running service that implements EHAP's exact wire contract:
`POST /v2/oauth2/token` (client-credentials grant, returns
`{"access_token": ..., "expires_in": ...}`) and
`POST /v2/text/chats?qos=...&preview=...` (streaming and non-streaming chat
completions).

---

## Run the server

```powershell
uv run uvicorn governance_intake.server:app --host 0.0.0.0 --port 8000
```

Leave this terminal running — you should see `Application startup complete`.
Verify at http://localhost:8000/api/health (a small JSON payload means the API
is up). On a machine with `make`, `make run` does the same (honoring
`INTAKE_SERVER_PORT`, default 8000).

---

## Testing

Offline unit tests (no LLM, no AWS, no EHAP):

```powershell
uv run pytest -m "not integration"    # or: make test
```

Integration tests (anything that needs EHAP — real creds or a `DEV=true`
substitute per the setup section above):

```powershell
uv run pytest -m integration          # or: make test-integration
```

`make test-unit` (`uv run pytest backend/tests/unit`) runs the unit tree
directly.

### The prompt eval suite

`backend/tests/integration/test_prompt_evals.py` runs the intake-routing and
form-filler prompts against real model behavior (via EHAP or a DEV-mode
substitute) and checks the output against a generated case set
(`backend/tests/integration/fixtures/generated/*.json` — AI-generated
development-confidence scenarios, not a hand-vetted golden corpus). Skip vs.
fail is meaningful here: if EHAP isn't configured at all, the suite skips
cleanly (nothing to test). If EHAP IS configured but a case actually fails to
execute (network error, malformed response, anything), that's reported as a
genuine test FAILURE with the case ID and the original exception — never
silently swallowed into a skip. A skip means "not set up for this," never
"something's wrong but we're hiding it."

Run it standalone:

```powershell
uv run pytest backend/tests/integration/test_prompt_evals.py
```

It carries the `integration` marker, so it also runs under
`uv run pytest -m integration` / `make test-integration`.

---

## Lint & type-check

```powershell
uv run ruff check backend/src backend/tests   # lint      (make lint)
uv run mypy backend/src/governance_intake      # type-check (make type-check)
```

The scripted end-to-end check (pure pipeline + EHAP) is
`uv run python -m governance_intake.verify` (`make verify`).

---

## Troubleshooting

| Symptom | Cause / Fix |
|---------|-------------|
| `uv sync` → `invalid peer certificate` / `UnknownIssuer` | Corporate TLS proxy. `setx UV_SYSTEM_CERTS true` (new terminal) or `$env:UV_SYSTEM_CERTS="true"` (current), then retry. |
| `uv` / `python` not recognized | Install Python 3.12+, then `pip install uv`. `uv` can also install Python: `uv python install 3.12`. |
| PyPI blocked entirely | `$env:UV_INDEX_URL = "https://<internal-artifactory>/api/pypi/pypi/simple"`, then `uv sync --all-extras`. |
| `pytest` seems to hang; traceback ends in `KeyboardInterrupt` | First run compiles on import — wait ~10-20s. The `KeyboardInterrupt` just means it was cut off, not a real failure. |
| First chat message errors, or integration tests all skip | Missing/invalid EHAP creds in `.env`, or the host can't reach `EHAP_URL`. Set real creds, or `DEV=true` (see [Running without real EHAP](#running-without-real-ehap-devtrue)). |
| Port 8000 already in use | Run on another port: add `--port 8010` and use that in the URL. |
