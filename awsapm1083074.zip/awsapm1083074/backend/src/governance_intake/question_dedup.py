# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Question consolidation / online dedup.

Pure functions:
  - build_pending_questions(activated_teams, questionnaires, dedup_mapping)
      Returns the deduplicated list of canonical questions to ask the user.
      Each canonical entry tracks which (team, question_id) sources it covers.

The strategy:
  1. Walk dedup_mapping. For each canonical entry, keep only the sources whose
     team is activated. If at least one source remains, include the canonical.
  2. For every (team, question_id) in activated team questionnaires that is not
     covered by any canonical entry, emit a singleton canonical so no question
     is dropped.
  3. Result preserves dedup_mapping order, then singletons grouped by team in
     questionnaire order.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set, Tuple


CanonicalKey = Tuple[str, str]  # (team, question_id)


def _covered_sources(dedup_mapping: Dict[str, Any]) -> Set[CanonicalKey]:
    covered: Set[CanonicalKey] = set()
    for entry in dedup_mapping.get("canonical_questions", []):
        for src in entry.get("sources", []):
            covered.add((src["team"], src["question_id"]))
    return covered


def build_pending_questions(
    activated_teams: List[str],
    questionnaires: Dict[str, Any],
    dedup_mapping: Dict[str, Any],
    prior_answers: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    Build the consolidated pending_questions list for the activated teams.

    Returns a list of dicts with shape:
        {
          "canonical_id": str,
          "canonical_question": str,
          "category": str,
          "sources": [{"team": str, "question_id": str}, ...],
          "source_teams": [str, ...],
          "answered": False,
          "answer": None
        }

    prior_answers, when given, maps canonical_id -> answer for canonicals that
    were already answered in a previous call (e.g. before a newly-activated
    team enlarged the activated_teams set). Any canonical whose id is a key
    in prior_answers is emitted pre-answered instead of the default
    answered=False/answer=None. Omitting prior_answers (the default) leaves
    every canonical unanswered, exactly as before this parameter existed.
    """
    prior = prior_answers or {}
    activated_set = set(activated_teams)
    pending: List[Dict[str, Any]] = []

    # Pass 1: dedup canonicals filtered to activated team sources.
    for entry in dedup_mapping.get("canonical_questions", []):
        filtered_sources = [s for s in entry.get("sources", []) if s["team"] in activated_set]
        if not filtered_sources:
            continue
        canonical_id = entry["canonical_id"]
        answered = canonical_id in prior
        pending.append(
            {
                "canonical_id": canonical_id,
                "canonical_question": entry["canonical_question"],
                "category": entry.get("category", "general"),
                "sources": filtered_sources,
                "source_teams": sorted({s["team"] for s in filtered_sources}),
                "answered": answered,
                "answer": prior.get(canonical_id) if answered else None,
            }
        )

    # Pass 2: singletons for team questions not covered by any canonical.
    covered = _covered_sources(dedup_mapping)
    teams = questionnaires.get("teams", {})
    for team in activated_teams:
        team_data = teams.get(team)
        if not team_data:
            continue
        for q in team_data.get("questions", []):
            key = (team, q["id"])
            if key in covered:
                continue
            canonical_id = f"SINGLE.{team}.{q['id']}"
            answered = canonical_id in prior
            pending.append(
                {
                    "canonical_id": canonical_id,
                    "canonical_question": q["text"],
                    "category": _infer_singleton_category(team),
                    "sources": [{"team": team, "question_id": q["id"]}],
                    "source_teams": [team],
                    "answered": answered,
                    "answer": prior.get(canonical_id) if answered else None,
                }
            )

    return pending


def _infer_singleton_category(team: str) -> str:
    """Best-effort grouping for singleton questions so batched presentation stays coherent."""
    t = team.lower()
    if "security" in t:
        return "security"
    if "privacy" in t or "due" in t:
        return "data"
    if "vendor" in t or "procurement" in t or "legal" in t:
        return "vendor"
    if "ai" in t or "rai" in t:
        return "ai_usecase"
    if "cloud" in t or "architecture" in t or "arb" in t:
        return "infrastructure"
    if "offshore" in t or "medicaid" in t:
        return "offshore"
    if "regulatory" in t or "bu" in t:
        return "regulatory"
    return "general"


def dedup_stats(
    activated_teams: List[str],
    questionnaires: Dict[str, Any],
    pending_questions: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Compute reduction metrics: raw question count vs. consolidated count."""
    teams = questionnaires.get("teams", {})
    raw = sum(len(teams.get(t, {}).get("questions", [])) for t in activated_teams)
    consolidated = len(pending_questions)
    reduction = 0.0 if raw == 0 else 1.0 - (consolidated / raw)
    return {
        "raw_question_count": raw,
        "consolidated_question_count": consolidated,
        "reduction_ratio": round(reduction, 3),
    }


def next_question_batch(
    pending_questions: List[Dict[str, Any]], batch_size: int = 2
) -> List[Dict[str, Any]]:
    """
    Pick the next batch of unanswered questions, preferring questions from the
    same category for coherent presentation.
    """
    unanswered = [q for q in pending_questions if not q.get("answered")]
    if not unanswered:
        return []

    head_category = unanswered[0].get("category", "general")
    same = [q for q in unanswered if q.get("category", "general") == head_category]
    return same[:batch_size]
