# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Prompt eval harness (docs/eval_harness_contract.md).

Hand-rolled, not a general eval framework: our surface is two structured
extraction/fill-in prompts (`intake_agent.py`'s `extract_routing_fields`,
`form_filler_agent.py`'s `fill_form`) with an already-deterministic
acceptance boundary. Most checks are a plain assertion; the few genuinely
open-ended ones get a narrow judge call through `ehap_model.py`.

What lives here (real code, testable without any live model -- see
`backend/tests/unit/test_eval_harness.py`):
  EvalCase, Check (+ its 7 variants)  -> Pydantic schema for the generated
                                          fixture files (contract doc,
                                          "EvalCase schema").
  load_eval_cases(path)               -> reads one generated fixture file.
  parse_case_input(case)              -> agent-specific input, validated.
  evaluate_field_equals / _null / _not_null / origin_equals /
    confidence_at_least / confidence_at_most
                                       -> pure functions, one per
                                          deterministic Check type. No model
                                          calls; unit-testable in isolation.
  JudgeVerdict, JudgeModel, StubJudge, EHAPJudge, judge_answer()
                                       -> the "judge" Check type. JudgeModel
                                          mirrors form_filler_agent.py's
                                          FormFillerModel swap-point pattern:
                                          EHAPJudge is the real, EHAP-backed
                                          implementation; StubJudge is a
                                          deterministic, network-free stand-in
                                          for tests.
  evaluate_case(case, output, judge)  -> applies every check in a case,
                                          dispatching deterministic checks to
                                          the pure evaluators above and
                                          "judge" checks to judge_answer().

What does NOT live here: actually calling `extract_routing_fields` / `fill_form`
against a real agent, or loading the generated fixture files under
`backend/tests/integration/fixtures/generated/`. That orchestration is the
pytest runner's job (`backend/tests/integration/test_prompt_evals.py`) --
this module is the reusable plumbing it's built on.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from itertools import chain
from pathlib import Path
from typing import Annotated, Any, Callable, Dict, List, Literal, Optional, Tuple, Union

from pydantic import BaseModel, Field, TypeAdapter, field_validator
from strands import Agent

from .ehap_model import EHAPModel, get_ehap_model
from .form_filler_agent import FormFillerEnvelope
from .intake_agent import RoutingFields

# ---------------------------------------------------------------------------
# Check schema (contract doc: "EvalCase schema" -> "Check")
# ---------------------------------------------------------------------------


class FieldEqualsCheck(BaseModel):
    type: Literal["field_equals"] = "field_equals"
    field_id: str
    expected: Any = None


class FieldNullCheck(BaseModel):
    type: Literal["field_null"] = "field_null"
    field_id: str


class FieldNotNullCheck(BaseModel):
    type: Literal["field_not_null"] = "field_not_null"
    field_id: str


class OriginEqualsCheck(BaseModel):
    type: Literal["origin_equals"] = "origin_equals"
    field_id: str
    expected: Optional[Literal["user", "agent"]] = None

    @field_validator("expected", mode="before")
    @classmethod
    def _normalize_null_string(cls, value: Any) -> Any:
        # The contract doc writes the valid values as "user | agent | null".
        # A generated case might emit JSON null (-> None already) or the
        # literal string "null" -- accept both rather than silently treating
        # a typo'd "null" string as a (never-matching) origin value.
        if isinstance(value, str) and value.lower() == "null":
            return None
        return value


class ConfidenceAtLeastCheck(BaseModel):
    type: Literal["confidence_at_least"] = "confidence_at_least"
    field_id: str
    expected: int = Field(ge=0, le=5)


class ConfidenceAtMostCheck(BaseModel):
    type: Literal["confidence_at_most"] = "confidence_at_most"
    field_id: str
    expected: int = Field(ge=0, le=5)


class JudgeCheck(BaseModel):
    type: Literal["judge"] = "judge"
    field_id: str
    rubric: str


Check = Annotated[
    Union[
        FieldEqualsCheck,
        FieldNullCheck,
        FieldNotNullCheck,
        OriginEqualsCheck,
        ConfidenceAtLeastCheck,
        ConfidenceAtMostCheck,
        JudgeCheck,
    ],
    Field(discriminator="type"),
]
_CheckAdapter: TypeAdapter[Check] = TypeAdapter(Check)


# ---------------------------------------------------------------------------
# EvalCase schema + loader
# ---------------------------------------------------------------------------

AgentName = Literal["intake_agent", "form_filler_agent"]


class EvalCase(BaseModel):
    id: str
    agent: AgentName
    description: str
    input: Any
    checks: List[Check]


def load_eval_cases(path: Path) -> List[EvalCase]:
    """
    Load one generated fixture file (contract doc: division of labor #1).

    Accepts either shape at the JSON root, since JSON has no comment syntax
    for the "regenerable, AI-authored, not hand-vetted" header the contract
    asks generated files to carry:
      - a bare list of EvalCase objects, or
      - an object with a "cases" key holding that list (any other keys, e.g.
        "_comment"/"_meta", are ignored).
    """
    import json

    with path.open(encoding="utf-8") as f:
        raw = json.load(f)
    if isinstance(raw, dict):
        if "cases" not in raw:
            raise ValueError(f"{path}: JSON object root must have a 'cases' key")
        raw_cases = raw["cases"]
    elif isinstance(raw, list):
        raw_cases = raw
    else:
        raise ValueError(f"{path}: expected a JSON list or object at the root, got {type(raw).__name__}")
    return [EvalCase.model_validate(c) for c in raw_cases]


def parse_case_input(case: EvalCase) -> Union[List[Dict[str, Any]], FormFillerEnvelope]:
    """
    Validate `case.input` into the shape the real agent function expects.

    - intake_agent: `extract_routing_fields(messages: List[Dict[str, Any]])`
      (confirmed against intake_agent.py -- multi-turn message list, not a
      bare string) -> `case.input` must be a list of message dicts.
    - form_filler_agent: `fill_form(envelope, model)` -> `case.input` must be
      a `FormFillerEnvelope` per docs/form_filler_agent_contract.md.
    """
    if case.agent == "intake_agent":
        if not isinstance(case.input, list):
            raise ValueError(
                f"case {case.id!r}: intake_agent input must be a list of message dicts, "
                f"got {type(case.input).__name__}"
            )
        return case.input
    if case.agent == "form_filler_agent":
        return FormFillerEnvelope.model_validate(case.input)
    raise ValueError(f"case {case.id!r}: unknown agent {case.agent!r}")  # unreachable, AgentName is a Literal


# ---------------------------------------------------------------------------
# Field lookup -- bridges the two possible agent output shapes.
# ---------------------------------------------------------------------------


def _lookup_field(output: Any, field_id: str) -> Tuple[Any, Optional[str], Optional[int]]:
    """
    Returns (value, origin, confidence) for `field_id` in an agent output.

    - FormFillerEnvelope: `field_id` is a TriggerField/GovernanceQuestion
      `.id`; searched across triggers then governance. origin/confidence
      come from the matched item.
    - RoutingFields: `field_id` is the attribute name; value = getattr(...).
      RoutingFields carries no per-field origin/confidence (see
      intake_agent.py -- it's a flat extraction result, not an envelope), so
      origin and confidence are always (None, None) for this shape.

    Raises KeyError/AttributeError/TypeError on a bad field_id or output type
    -- a case-authoring bug, not a normal check failure. Callers turn these
    into a failed CheckOutcome with a clear reason rather than crashing the
    whole run.
    """
    if isinstance(output, FormFillerEnvelope):
        for item in chain(output.triggers, output.governance):
            if item.id == field_id:
                return item.value, item.origin, item.confidence
        raise KeyError(f"no trigger/governance item with id={field_id!r} in the FormFillerEnvelope output")
    if isinstance(output, RoutingFields):
        if field_id not in RoutingFields.model_fields:
            raise AttributeError(f"RoutingFields has no field {field_id!r}")
        return getattr(output, field_id), None, None
    raise TypeError(f"unsupported eval output type: {type(output).__name__}")


def _question_text_for(output: Any, field_id: str) -> str:
    """Best-effort question text for a judge-check prompt (see judge_answer())."""
    if isinstance(output, FormFillerEnvelope):
        for item in chain(output.triggers, output.governance):
            if item.id == field_id:
                return item.text
        raise KeyError(f"no trigger/governance item with id={field_id!r} in the FormFillerEnvelope output")
    if isinstance(output, RoutingFields):
        if field_id not in RoutingFields.model_fields:
            raise AttributeError(f"RoutingFields has no field {field_id!r}")
        description = RoutingFields.model_fields[field_id].description
        return description or field_id
    raise TypeError(f"unsupported eval output type: {type(output).__name__}")


# ---------------------------------------------------------------------------
# Deterministic evaluators -- pure functions, one per Check type.
# ---------------------------------------------------------------------------


class CheckOutcome(BaseModel):
    passed: bool
    reason: str


def evaluate_field_equals(output: Any, check: FieldEqualsCheck) -> CheckOutcome:
    try:
        value, _, _ = _lookup_field(output, check.field_id)
    except (KeyError, AttributeError, TypeError) as exc:
        return CheckOutcome(passed=False, reason=str(exc))
    if value == check.expected:
        return CheckOutcome(passed=True, reason=f"field {check.field_id!r} == {check.expected!r}")
    return CheckOutcome(
        passed=False,
        reason=f"field {check.field_id!r} == {value!r}, expected {check.expected!r}",
    )


def evaluate_field_null(output: Any, check: FieldNullCheck) -> CheckOutcome:
    try:
        value, _, _ = _lookup_field(output, check.field_id)
    except (KeyError, AttributeError, TypeError) as exc:
        return CheckOutcome(passed=False, reason=str(exc))
    if value is None:
        return CheckOutcome(passed=True, reason=f"field {check.field_id!r} is null")
    return CheckOutcome(passed=False, reason=f"field {check.field_id!r} == {value!r}, expected null")


def evaluate_field_not_null(output: Any, check: FieldNotNullCheck) -> CheckOutcome:
    try:
        value, _, _ = _lookup_field(output, check.field_id)
    except (KeyError, AttributeError, TypeError) as exc:
        return CheckOutcome(passed=False, reason=str(exc))
    if value is not None:
        return CheckOutcome(passed=True, reason=f"field {check.field_id!r} == {value!r} (not null)")
    return CheckOutcome(passed=False, reason=f"field {check.field_id!r} is null, expected a value")


def evaluate_origin_equals(output: Any, check: OriginEqualsCheck) -> CheckOutcome:
    if not isinstance(output, FormFillerEnvelope):
        return CheckOutcome(
            passed=False,
            reason=(
                "origin_equals only applies to form_filler_agent output (FormFillerEnvelope); "
                f"RoutingFields has no per-field origin (got {type(output).__name__})"
            ),
        )
    try:
        _, origin, _ = _lookup_field(output, check.field_id)
    except (KeyError, AttributeError, TypeError) as exc:
        return CheckOutcome(passed=False, reason=str(exc))
    if origin == check.expected:
        return CheckOutcome(passed=True, reason=f"origin of {check.field_id!r} == {check.expected!r}")
    return CheckOutcome(
        passed=False,
        reason=f"origin of {check.field_id!r} == {origin!r}, expected {check.expected!r}",
    )


def _evaluate_confidence_bound(
    output: Any,
    check: Union[ConfidenceAtLeastCheck, ConfidenceAtMostCheck],
    *,
    at_least: bool,
) -> CheckOutcome:
    """
    Shared logic for confidence_at_least / confidence_at_most.

    Design decision (contract doc only says "if filled, confidence must
    clear N" -- read literally, "if filled" makes the check CONDITIONAL on
    the field having been filled by the agent): if the field is unfilled
    (confidence is None -- per form_filler_agent_contract.md, confidence is
    only ever set when origin == "agent"), both checks are VACUOUSLY
    satisfied. A confidence bound is a claim about how confident the agent
    was WHEN it filled something in, not a disguised field_not_null check --
    pair this with an explicit field_not_null/field_null check in the same
    case if "must be filled at all" also needs asserting.
    """
    if not isinstance(output, FormFillerEnvelope):
        return CheckOutcome(
            passed=False,
            reason=(
                f"{check.type} only applies to form_filler_agent output (FormFillerEnvelope); "
                f"RoutingFields has no per-field confidence (got {type(output).__name__})"
            ),
        )
    try:
        _, _, confidence = _lookup_field(output, check.field_id)
    except (KeyError, AttributeError, TypeError) as exc:
        return CheckOutcome(passed=False, reason=str(exc))
    if confidence is None:
        return CheckOutcome(
            passed=True,
            reason=f"field {check.field_id!r} is unfilled (confidence is None) -- '{check.type}' vacuously satisfied",
        )
    ok = confidence >= check.expected if at_least else confidence <= check.expected
    comparator = ">=" if at_least else "<="
    if ok:
        return CheckOutcome(
            passed=True,
            reason=f"confidence of {check.field_id!r} == {confidence} {comparator} {check.expected}",
        )
    return CheckOutcome(
        passed=False,
        reason=f"confidence of {check.field_id!r} == {confidence}, expected {comparator} {check.expected}",
    )


def evaluate_confidence_at_least(output: Any, check: ConfidenceAtLeastCheck) -> CheckOutcome:
    return _evaluate_confidence_bound(output, check, at_least=True)


def evaluate_confidence_at_most(output: Any, check: ConfidenceAtMostCheck) -> CheckOutcome:
    return _evaluate_confidence_bound(output, check, at_least=False)


_DETERMINISTIC_EVALUATORS = {
    "field_equals": evaluate_field_equals,
    "field_null": evaluate_field_null,
    "field_not_null": evaluate_field_not_null,
    "origin_equals": evaluate_origin_equals,
    "confidence_at_least": evaluate_confidence_at_least,
    "confidence_at_most": evaluate_confidence_at_most,
}


def evaluate_deterministic_check(output: Any, check: Check) -> CheckOutcome:
    """Dispatch to the pure evaluator for `check`'s type. Not for `judge` checks."""
    evaluator = _DETERMINISTIC_EVALUATORS.get(check.type)
    if evaluator is None:
        raise ValueError(f"{check.type!r} is not a deterministic check type (did you mean run_judge_check?)")
    return evaluator(output, check)


# ---------------------------------------------------------------------------
# Judge check -- the one Check type that makes a model call.
# ---------------------------------------------------------------------------


class JudgeVerdict(BaseModel):
    accept: bool
    reason: str


class JudgeModel(ABC):
    """Swap point for a real EHAP-backed judge. Mirrors form_filler_agent.py's FormFillerModel."""

    @abstractmethod
    def judge(self, question_text: str, submitted_value: Any, rubric: str) -> JudgeVerdict:
        raise NotImplementedError


class StubJudge(JudgeModel):
    """
    Deterministic stand-in for EHAPJudge -- network-free, for tests. Mirrors
    StubFormFillerModel's "obviously simple but exercises the real code path"
    role; it is NOT smart and does not weigh whether the value actually
    answers the question.

    Exact behavior:
      1. REJECT if `submitted_value` is None, an empty/whitespace-only
         string, or an empty list.
      2. REJECT if `rubric` contains the case-insensitive substring "trap"
         (a case author's signal that this rubric is a deliberate
         hallucination/red-flag trap the stub should catch).
      3. Otherwise ACCEPT.
    """

    TRAP_KEYWORD = "trap"

    def judge(self, question_text: str, submitted_value: Any, rubric: str) -> JudgeVerdict:
        if submitted_value is None:
            return JudgeVerdict(accept=False, reason="stub: submitted_value is None")
        if isinstance(submitted_value, str) and not submitted_value.strip():
            return JudgeVerdict(accept=False, reason="stub: submitted_value is an empty string")
        if isinstance(submitted_value, list) and not submitted_value:
            return JudgeVerdict(accept=False, reason="stub: submitted_value is an empty list")
        if self.TRAP_KEYWORD in rubric.lower():
            return JudgeVerdict(accept=False, reason=f"stub: rubric contains trap keyword {self.TRAP_KEYWORD!r}")
        return JudgeVerdict(accept=True, reason="stub: non-empty value and no trap keyword in rubric")


JUDGE_SYSTEM_PROMPT = """\
You are a careful, skeptical-but-fair QA reviewer for an automated \
governance-intake form. You are shown one question, one submitted answer, \
and a rubric describing what an acceptable answer looks like AND what would \
count as a hallucination or red flag for this specific case.

Accept the answer only if it genuinely and specifically addresses the \
question in a way consistent with the rubric. Reject it if it contradicts \
the rubric, looks fabricated or unsupported by the rubric's stated grounding, \
is empty/non-responsive, or dodges the question. Do not be needlessly \
pedantic -- a reasonable paraphrase or a differently-worded but substantively \
correct answer should be accepted.

Respond with ONLY the requested JSON object: {"accept": true|false, "reason": \
"one or two sentences explaining your verdict"}.
"""


class EHAPJudge(JudgeModel):
    """
    Real judge, wired through ehap_model.py.

    Model-override finding: EHAPModel supports a per-instance `model_id`
    (constructor arg) and Strands' `update_config(model_id=...)` config API,
    so overriding which model backs a *specific* EHAPModel instance is
    technically possible. But `get_ehap_model()` -- the factory every other
    caller in this codebase uses (intake_agent.py's routing/QA/extraction
    agents) -- builds ONE process-wide singleton with no override argument,
    permanently pinned to `DEFAULT_EHAP_MODEL_ID` (env `EHAP_MODEL_ID`, else
    "anthropic:claude-sonnet-4-6"). There is no *per-call* override path
    exposed anywhere callers actually use. Per the contract ("if EHAP only
    exposes one configured model, the judge just uses that one; no
    fabricated 'slow tier'"), EHAPJudge reuses that same singleton rather
    than constructing a second EHAPModel instance with a different model_id.
    """

    def __init__(self, model: Optional[EHAPModel] = None) -> None:
        self._model = model or get_ehap_model()

    def judge(self, question_text: str, submitted_value: Any, rubric: str) -> JudgeVerdict:
        agent = Agent(model=self._model, system_prompt=JUDGE_SYSTEM_PROMPT, callback_handler=None)
        prompt = (
            f"Question asked: {question_text}\n\n"
            f"Submitted answer: {submitted_value!r}\n\n"
            f"Rubric (acceptable answers, and red flags for this case): {rubric}"
        )
        return agent.structured_output(JudgeVerdict, prompt=prompt)


_default_judge: Optional[JudgeModel] = None


def judge_answer(
    question_text: str,
    submitted_value: Any,
    rubric: str,
    *,
    judge: Optional[JudgeModel] = None,
) -> JudgeVerdict:
    """
    Contract doc signature: `judge_answer(question_text, submitted_value,
    rubric) -> JudgeVerdict`. The optional `judge` keyword is the
    FormFillerModel-style swap point -- real call sites omit it and get the
    lazily-constructed EHAPJudge singleton; tests pass `judge=StubJudge()`.
    """
    active_judge = judge if judge is not None else _get_default_judge()
    return active_judge.judge(question_text, submitted_value, rubric)


def _get_default_judge() -> JudgeModel:
    global _default_judge
    if _default_judge is None:
        _default_judge = EHAPJudge()
    return _default_judge


def run_judge_check(output: Any, check: JudgeCheck, judge: Optional[JudgeModel] = None) -> CheckOutcome:
    try:
        value, _, _ = _lookup_field(output, check.field_id)
        question_text = _question_text_for(output, check.field_id)
    except (KeyError, AttributeError, TypeError) as exc:
        return CheckOutcome(passed=False, reason=str(exc))
    verdict = judge_answer(question_text, value, check.rubric, judge=judge)
    return CheckOutcome(passed=verdict.accept, reason=verdict.reason)


# ---------------------------------------------------------------------------
# Case-level orchestration
# ---------------------------------------------------------------------------


class CaseResult(BaseModel):
    case_id: str
    outcomes: List[Tuple[Check, CheckOutcome]]

    @property
    def passed(self) -> bool:
        return all(outcome.passed for _, outcome in self.outcomes)


def evaluate_case(case: EvalCase, output: Any, judge: Optional[JudgeModel] = None) -> CaseResult:
    """Apply every check in `case` against `output` (an already-produced agent result)."""
    outcomes: List[Tuple[Check, CheckOutcome]] = []
    for check in case.checks:
        if isinstance(check, JudgeCheck):
            outcome = run_judge_check(output, check, judge=judge)
        else:
            outcome = evaluate_deterministic_check(output, check)
        outcomes.append((check, outcome))
    return CaseResult(case_id=case.id, outcomes=outcomes)


def run_eval_cases(cases: List[EvalCase], run_fn: Callable[[EvalCase], Any]) -> List[CaseResult]:
    """
    Run every case through `run_fn`, sparing none of them from a bad
    neighbor. A case whose `run_fn` call raises (network failure,
    malformed structured output, anything) is recorded as a FAILED
    CaseResult carrying the exception's type and message against every
    check that case declared -- never silently dropped, and never
    allowed to abort the loop and erase results already collected from
    earlier cases.

    Deliberately has no pytest dependency and no opinion about
    preconditions (missing EHAP config, no real model implementation,
    etc.) -- callers check those ONCE, up front, before ever calling this
    function, and skip there instead. This function's only job is: once
    we've committed to actually attempting cases, every one of them ends
    up as a real pass or a real fail, never a skip.
    """
    results: List[CaseResult] = []
    for case in cases:
        try:
            output = run_fn(case)
        except Exception as exc:  # noqa: BLE001 -- deliberately broad, see docstring
            error_reason = f"case execution raised {type(exc).__name__}: {exc}"
            outcomes = [(check, CheckOutcome(passed=False, reason=error_reason)) for check in case.checks]
            results.append(CaseResult(case_id=case.id, outcomes=outcomes))
            continue
        results.append(evaluate_case(case, output))
    return results
