# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
One-shot demo verification script.

Run: uv run python -m governance_intake.verify   (or: make verify)

Flow (default):
  1. Sanity-check the deterministic routing pipeline (no LLM).
  2. Run a scripted conversation via EHAP:
       Phase 1 -> routing_agent gathers routing fields.
       Phase 2 -> qa_agent walks the user through a single "focus" team's
                  hard-coded questions (no dedup, no cross-team fan-out).
  3. Print a demo ticket for that focus team with all Q&A captured.

Required env (see .env.example):
  EHAP_URL, EHAP_CLIENT_ID, EHAP_CLIENT_SECRET

Optional env:
  INTAKE_SKIP_LLM=1     run only the pure-function part
  INTAKE_FULL_FLOW=1    switch to the full deduplicated flow instead of demo
  INTAKE_FOCUS_TEAM=... force a specific focus team
"""

from __future__ import annotations

import json
import os
import sys
import textwrap
import traceback

# Keep the scripted smoke test cheap: only walk one team's Q&A by default.
# To test the full multi-team walk: unset INTAKE_DEMO_TEAM_LIMIT before running.
os.environ.setdefault("INTAKE_DEMO_TEAM_LIMIT", "1")


# ---------------------------------------------------------------------------
# Cosmetics
# ---------------------------------------------------------------------------

def section(title: str) -> None:
    bar = "=" * 78
    print(f"\n{bar}\n {title}\n{bar}")


def kv(label: str, value) -> None:
    print(f"  {label}: {value}")


def wrap(text: str, prefix: str = "  ") -> str:
    return textwrap.indent(textwrap.fill(text, width=100), prefix)


# ---------------------------------------------------------------------------
# Step 1: pure-function pipeline
# ---------------------------------------------------------------------------

def run_pure_pipeline() -> None:
    from .handler import IntakeData
    from .rule_engine import evaluate_rules
    from .schema_check import all_routing_fields_present, missing_required_fields

    data = IntakeData()

    fields = {
        "project_name": "Claims Summarizer",
        "project_description": (
            "AI summarization of Medicare claims for case managers, built with "
            "a third-party LLM vendor that will have access to PHI."
        ),
        "involves_ai_ml_llm": True,
        "new_use_of_ai": True,
        "ai_ml_llm_business_use_case_fit": True,
        "level_of_development": "Production",
        "target_deployment_hosting": ["ElevanceHealth Cloud Instance"],
        "vendor_use": True,
        "PHI_PI_PFI_use": True,
        "stakeholder_value": True,
        "abrasive_to_providers_customers_members": False,
        "data_solution_types": ["MCID (Master Consumer Identifier", "Proxy ID"],
        "new_or_different_deployment_type": False,
        "has_business_received_communication": True,
        "vendor_data_access": True,
        "external_data_release": True,
        "within_data_use_release_policy": True,
        "accesses_enterprise_data_platforms": True,
        "architectural_material_change": False,
        "new_altered_business_proccess": True,
        "sending_receiving_protected_information": True,
        "lines_of_business_for_deployment": ["Government – Medicare"],
        "identify_vendors_to_PI": ["Acme AI"],
        # Routing inputs for the teams added on feature/trigger-rules-guardrails.
        "regulatory_reputational_risks": True,
        "changes_regulated_functions": False,
        "potential_for_compliance_issue": True,
        "impacts_members_providers": True,
        "involves_contacting_delegates_vendors_behalf_EH": False,
        "risk_of_heath_care_fraud_waste_abuse": False,
        "violates_CMS_state_program_requirements": False,
        "involves_digital_health_member_outcomes": False,
        "use_of_payment_information_data": False,
        "new_novel_PI_use": False,
        "new_novel_technology": False,
        "high_risk_use_potential": False,
        "new_software": False,
        "newly_deployed_software": False,
        "use_of_previously_unapproved_software": False,
        "manners_of_use": ["Not applicable"],
        "vendor_provided_service": "New",
    }

    section("Step 1: pure-function pipeline (no LLM)")
    missing = missing_required_fields(data.intake_schema, fields)
    kv("routing fields complete", all_routing_fields_present(data.intake_schema, fields))
    kv("missing required", [m["name"] for m in missing])

    activated = evaluate_rules(fields, data.trigger_rules)
    kv("activated teams", [t["team"] for t in activated])
    demo_qs = data.demo_team_questions.get("teams", {})
    with_demo = [t["team"] for t in activated if demo_qs.get(t["team"])]
    kv("teams with demo questions", with_demo)
    print("\n  pure-function pipeline: PASS")


# ---------------------------------------------------------------------------
# Step 1b: post-dedup pure pipeline (STATE -> session -> answers -> ticket)
# ---------------------------------------------------------------------------

def run_postdedup_pipeline() -> None:
    from .handler import IntakeData
    from .postdedup import (
        apply_prefill_decisions,
        begin_session,
        completeness,
        record_answers,
        record_attachment,
        stats,
        submit,
    )
    from .prefill import PrefillProposal, PrefillProvenance, ground

    data = IntakeData()
    section("Step 1b: post-dedup pure pipeline (no LLM)")

    state = {
        "messages": [
            {"role": "user", "content": "We summarize Medicare claims with an LLM."}
        ],
        "trigger": {"fields": {"involves_ai_ml_llm": True, "PHI_PI_PFI_use": True}},
        "activated_teams": ["AI Program Office", "RAI", "Clinical Partnership Review"],
    }
    sess = begin_session("verify-postdedup", "verify@local", state, data)
    kv("pending questions", len(sess["pending_questions"]))
    kv("dedup stats", sess["dedup_stats"])
    assert sess["pending_questions"], "expected questions for AIPO+RAI"
    fanouts = [len(q["sources"]) for q in sess["pending_questions"]]
    assert fanouts == sorted(fanouts, reverse=True), "ordering: fan-out first"

    # Grounding gate: a verbatim quote passes, a fabricated one is rejected.
    user_msgs = [m["content"] for m in sess["ui_messages"] if m["role"] == "user"]
    grounded = PrefillProposal(
        canonical_id="X", answer="Medicare claims",
        provenance=PrefillProvenance(
            kind="transcript", ref="0", quote="summarize Medicare claims"
        ),
    )
    fabricated = PrefillProposal(
        canonical_id="X", answer="Azure",
        provenance=PrefillProvenance(kind="transcript", ref="0", quote="hosted on Azure"),
    )
    assert ground(grounded, user_msgs, sess["collected_fields"], {})
    assert not ground(fabricated, user_msgs, sess["collected_fields"], {})
    kv("grounding gate", "verbatim accepted / fabricated rejected")

    # Staged prefill is not an answer until accepted.
    target = sess["pending_questions"][0]
    target["prefill"] = {
        "answer": "From your description.",
        "provenance": grounded.provenance.model_dump(),
        "status": "proposed",
    }
    assert not completeness(sess, data)["complete"]
    assert target["canonical_id"] in completeness(sess, data)["unanswered_ids"]
    apply_prefill_decisions(sess, data, accept=[target["canonical_id"]])
    assert target["answered"] and target["answer_origin"] == "prefill"

    # Answer the rest, attach the diagram, submit, fan out.
    record_answers(
        sess, data,
        [
            {"canonical_id": q["canonical_id"], "answer": "Verified answer."}
            for q in sess["pending_questions"] if not q.get("answered")
        ],
    )
    snap = completeness(sess, data)
    assert snap["complete"], snap
    record_attachment(
        sess, {"key": "k", "filename": "diagram.pptx", "size": 1, "content_type": "x"}
    )
    ticket = submit(sess, data)
    n_aipo = len(data.questionnaires["teams"]["AI Program Office"]["questions"])
    assert len(ticket["team_forms"]["AI Program Office"]) == n_aipo
    kv("ticket", ticket["ticket_id"])
    kv("stats", stats(sess))
    print("\n  post-dedup pipeline: PASS")


# ---------------------------------------------------------------------------
# Step 2: LLM-backed conversation
# ---------------------------------------------------------------------------

# Phase 1 turns (routing).
SCRIPT_ROUTING = [
    "Hi, I'm building an AI claims-summarization assistant for our Medicare "
    "line of business. We're moving from pilot to production next quarter, "
    "and it's a genuinely new use of AI for us - it summarizes raw claim "
    "records into plain-language notes, which is new functionality we don't "
    "have today.",

    "It uses Anthropic Claude through a vendor called Acme AI, so yes, we "
    "use a vendor. Acme AI will have access to PHI - the member claims data "
    "we send them. We're deploying to our ElevanceHealth Cloud Instance, and "
    "the solution leverages MCID for member matching. We do send and "
    "receive protected information with Acme AI as part of that pipeline.",

    "No material change to our existing architecture, but it does access "
    "our enterprise data platforms for the claims feed. There's an external "
    "data release to Acme AI, and legal already confirmed it's within our "
    "Data Use and Release policy. We did get a routine inquiry from a "
    "regulator about our AI use last quarter, nothing adversarial. It's not "
    "a new or different deployment type, and we don't expect this to be "
    "abrasive to providers or members - it should genuinely help them. "
    "Lines of business are Government – Medicare, and yes, this has real "
    "stakeholder value for our case managers.",
]

# Phase 2 turns (Q&A) - the 3 hard-coded AI Program Office questions.
SCRIPT_QA_DEMO = [
    "The model is a Claude-Sonnet-based summarizer fine-tuned on redacted "
    "historical claim narratives. Its job is to turn raw claim records into "
    "plain-language summaries that case managers use as a starting point for "
    "member outreach and appeals prep.",

    "The AI output is advisory only - case managers make every final "
    "coverage, payment, and clinical judgement themselves. The tool never "
    "auto-approves or auto-denies anything; it just accelerates the human "
    "review.",

    "Model performance is monitored weekly by our MLOps team: rouge/BLEU "
    "against gold-labeled summaries, an output-drift detector on token "
    "distribution, and p95 latency SLA. Full drift and fairness review "
    "runs quarterly, with results shared to the AI Program Office.",
]

# Phase 3 turn (attachments). The script fakes an attachment record via
# handler.record_attachment(...) right before this turn (a real upload needs
# a browser PUT). This turn just tells the agent "done".
SCRIPT_ATTACHMENT = ["Done, I've attached the solution diagram."]

SCRIPT = SCRIPT_ROUTING + SCRIPT_QA_DEMO + SCRIPT_ATTACHMENT


def print_demo_ticket(ticket: dict) -> None:
    section("Demo Ticket")
    kv("ticket_id", ticket["ticket_id"])
    kv("submitter", ticket.get("submitter"))
    kv("created_at", ticket.get("created_at"))
    team_order = ticket.get("team_order", [])
    kv("teams walked for Q&A", team_order)
    print("\n  All activated teams (only team_order teams are Q&A'd in demo mode):")
    for t in ticket.get("activated_teams_summary", []):
        marker = "*" if t["in_scope_for_demo"] else " "
        print(f"    [{marker}] {t['team']}  (phase {t['review_phase']})")

    print("\n  Routing fields captured:")
    for k, v in ticket.get("routing_fields", {}).items():
        if isinstance(v, list):
            v = ", ".join(str(x) for x in v)
        print(f"    - {k}: {v}")

    print(f"\n  Q&A across {len(team_order)} team(s):")
    for q in ticket.get("answered_questions", []):
        teams = ", ".join(q.get("source_teams", []))
        print(f"    [{teams}] Q: {q['canonical_question']}")
        print(wrap(f"A: {q['answer']}", "       "))

    for team in team_order:
        form = ticket.get("team_forms", {}).get(team, {})
        if form:
            print(f"\n  Filled form for {team} (question_id -> answer):")
            for qid, ans in form.items():
                print(f"    - {qid}: {ans[:120]}{'...' if len(ans) > 120 else ''}")

    attachments = ticket.get("attachments", [])
    print(f"\n  Attachments ({len(attachments)}):")
    for a in attachments:
        print(f"    - {a.get('filename')} ({a.get('size')} bytes) -> {a.get('key')}")


def run_conversation() -> None:
    from .handler import IntakeHandler
    from .session import PHASE_ATTACHMENTS, InMemorySessionStore

    full_flow = os.environ.get("INTAKE_FULL_FLOW") == "1"
    forced_focus = os.environ.get("INTAKE_FOCUS_TEAM") or None

    section("Step 2: LLM-backed conversation ({} mode)".format(
        "full flow" if full_flow else "demo (single-team Q&A)"
    ))
    kv("EHAP endpoint", os.environ.get("EHAP_URL", "(unset)"))
    kv("model", os.environ.get("EHAP_MODEL_ID", "anthropic:claude-sonnet-4-6"))
    kv("demo_mode", not full_flow)
    if forced_focus:
        kv("forced focus_team", forced_focus)

    store = InMemorySessionStore()
    handler = IntakeHandler(
        store=store,
        demo_mode=not full_flow,
        demo_focus_team=forced_focus,
    )
    sess = handler.start_session("verify-1", "verify@elevancehealth.com")
    kv("session", f"{sess['session_id']} started in phase {sess['phase']}")

    prev_phase = sess["phase"]
    out = {"phase": prev_phase, "reply": "", "collected_fields": {}, "activated_teams": [], "pending_questions": []}
    for i, msg in enumerate(SCRIPT, start=1):
        print(f"\n--- Turn {i} of up to {len(SCRIPT)} ---")

        # If we've just entered the attachments phase, fake an upload before
        # sending the "done" message (a real upload needs a browser POST).
        if prev_phase == PHASE_ATTACHMENTS:
            fake_attachment = {
                "key": "verify-1/fake-uuid__solution-diagram.pptx",
                "filename": "solution-diagram.pptx",
                "size": 123456,
                "content_type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                "backend": "local",
            }
            handler.record_attachment("verify-1", fake_attachment)
            print(f"  ** (simulated) attached {fake_attachment['filename']}")

        print(f"USER: {msg}")
        try:
            out = handler.handle_message("verify-1", msg)
        except Exception:
            print("\n  handler raised:")
            traceback.print_exc()
            sys.exit(1)

        print(f"\nAGENT [{out['phase']}]:")
        print(wrap(out["reply"]))

        if out["phase"] != prev_phase:
            print(f"  ** phase transition: {prev_phase} -> {out['phase']}")
            if out.get("focus_team"):
                print(f"  ** focus team for Q&A: {out['focus_team']}")
                open_qs = [q for q in out["pending_questions"] if not q.get("answered")]
                print(f"  ** {len(open_qs)} hard-coded questions to ask:")
                for q in open_qs:
                    print(f"       - {q['canonical_question']}")
            prev_phase = out["phase"]

        print(f"  collected fields ({len(out['collected_fields'])}): "
              f"{sorted(out['collected_fields'].keys())}")
        if out["activated_teams"]:
            print(f"  activated teams ({len(out['activated_teams'])}): "
                  f"{[t['team'] for t in out['activated_teams']]}")
        pending = out["pending_questions"]
        if pending:
            unanswered = [q for q in pending if not q.get("answered")]
            print(f"  pending questions: {len(pending)} total, "
                  f"{len(unanswered)} unanswered")

        if out.get("ticket"):
            print_demo_ticket(out["ticket"]) if not full_flow else print(
                json.dumps(out["ticket"], indent=2)
            )
            print("\n  LLM workflow: PASS")
            return

    section("End of scripted turns")
    print("  Flow did not complete within the scripted turns.")
    print(f"  Final phase: {out['phase']}")


# ---------------------------------------------------------------------------

def main() -> None:
    run_pure_pipeline()
    run_postdedup_pipeline()
    if os.environ.get("INTAKE_SKIP_LLM") == "1":
        print("\nINTAKE_SKIP_LLM=1 set. Skipping LLM step.")
        return
    run_conversation()


if __name__ == "__main__":
    main()
