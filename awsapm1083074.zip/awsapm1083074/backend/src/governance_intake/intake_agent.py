# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Intake agent definitions.

Design:
  - Uses strands.Agent for the conversation loop.
  - The LLM behind Strands is our custom EHAPModel (see ehap_model.py), which
    talks to the Elevance Horizon gateway.
  - Structured extraction is a SEPARATE Strands Agent per turn seeded with
    an extractor system prompt; the transcript is passed as an explicit user
    prompt so extraction never pollutes the main chat history.

Public API used by handler.py:
  build_routing_agent(messages)           -> strands.Agent for Phase 1
  build_qa_agent(pending, messages, ctx)  -> strands.Agent for Phase 2
  extract_routing_fields(messages)        -> RoutingFields
  extract_answer_batch(pending, messages) -> AnswerBatch
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field
from strands import Agent

# Model selection goes through the provider seam so local development can
# run on ehap-mock or the Anthropic API without EHAP credentials.
from .llm_provider import get_model


# ---------------------------------------------------------------------------
# Pydantic schemas for structured extraction.
# ---------------------------------------------------------------------------


class RoutingFields(BaseModel):
    """
    Routing fields extracted from the conversation so far.

    All fields are Optional. Only set a field if the user's messages clearly
    confirm the value. Never guess.
    """

    project_name: Optional[str] = None
    project_description: Optional[str] = Field(
        default=None, description="1-2 sentence description of what the project does."
    )
    involves_ai_ml_llm: Optional[bool] = Field(
        default=None, description="Does the project use AI, ML, or LLM technology?"
    )
    new_use_of_ai: Optional[bool] = Field(
        default=None,
        description=(
            "Is this project identified as a project with new use of "
            "artificial intelligence? Distinct from involves_ai_ml_llm: this "
            "asks whether the AI use is NEW/novel to the business, not "
            "merely whether AI is used at all -- if the project uses no AI "
            "whatsoever, this is confidently False, not unset."
        ),
    )
    ai_ml_llm_business_use_case_fit: Optional[bool] = Field(
        default=None,
        description="Is the use of AI, ML, or LLM technology the right use for the business use case?",
    )
    level_of_development: Optional[str] = Field(
        default=None, description="One of: POC, Pilot, Production"
    )
    target_deployment_hosting: Optional[List[str]] = Field(
        default=None,
        description=(
            "Subset of: ElevanceHealth Hosted, ElevanceHealth Cloud Instance, "
            "Kyndryl Managed"
        ),
    )
    vendor_use: Optional[bool] = Field(
        default=None,
        description=(
            "Does the project use a vendor to either support development or "
            "to deliver the solution (e.g. contractors, consultants, SaaS "
            "provider, cloud service provider, AI service (LLMs))?"
        ),
    )
    PHI_PI_PFI_use: Optional[bool] = Field(
        default=None, description="Does the project collect or use PHI, PI or PFI data?"
    )
    stakeholder_value: Optional[bool] = Field(
        default=None,
        description="Does this project request have a significant benefit to any stakeholders?",
    )
    abrasive_to_providers_customers_members: Optional[bool] = Field(
        default=None,
        description="Will this request be abrasive to providers, customers, or members?",
    )
    data_solution_types: Optional[List[str]] = Field(
        default=None,
        description="Subset of: MCID (Master Consumer Identifier, Proxy ID",
    )
    new_or_different_deployment_type: Optional[bool] = Field(
        default=None,
        description=(
            "Will this project deploy something in a new or unique way that "
            "differs from its original or traditional intent or purpose?"
        ),
    )
    has_business_received_communication: Optional[bool] = Field(
        default=None,
        description=(
            "Is it identified that business received a communication in any "
            "manner from a regulator or lawyer?"
        ),
    )
    vendor_data_access: Optional[bool] = Field(
        default=None,
        description=(
            "Does the project identify that vendors/delegates will have "
            "access to Private Health Information (PHI), Protected "
            "Information (PI), Private Financial Information (PFI), or any "
            "other sensitive information?"
        ),
    )
    external_data_release: Optional[bool] = Field(
        default=None, description="Does the project include an external data release?"
    )
    within_data_use_release_policy: Optional[bool] = Field(
        default=None,
        description=(
            "Is the project within the compliance of the Data Use and "
            "Release policy (DU & RP)?"
        ),
    )
    accesses_enterprise_data_platforms: Optional[bool] = Field(
        default=None, description="Does this request entail access to enterprise data platforms?"
    )
    architectural_material_change: Optional[bool] = Field(
        default=None,
        description=(
            "Will the project request require creation or migration of "
            "databases or material change to existing architecture?"
        ),
    )
    new_altered_business_proccess: Optional[bool] = Field(
        default=None,
        description=(
            "Will this project request enable new/altered business process "
            "and/or capabilities?"
        ),
    )
    sending_receiving_protected_information: Optional[bool] = Field(
        default=None,
        description=(
            "Does this project send or receive Protected Information "
            "from external entities? Distinct from PHI_PI_PFI_use: this is "
            "specifically about exchange with external entities, not "
            "internal collection/use -- if only internal use is described, "
            "leave this unset rather than assuming external exchange."
        ),
    )
    lines_of_business_for_deployment: Optional[List[str]] = Field(
        default=None,
        description=(
            "Subset of: Carelon, Carelon Global, Carelon Health, Carelon "
            "Insights, CarelonRx, Commercial NGS, Government – DSNP, "
            "Government – GRS, Government – Medicare, Government – Medicaid, "
            "Government – MMP, Commercial – ANA, Commercial – FGS, "
            "Commercial – NGS, Commercial – Individual, Commercial – Large "
            "Group ASO, Commercial – Large Group Fully Insured, Commercial – "
            "Small Group, Commercial – Specialty Dental, Commercial – "
            "Specialty Life, Risk Adjustment"
        ),
    )
    identify_vendors_to_PI: Optional[List[str]] = Field(
        default=None,
        description="Vendor name(s) with access to Protected Information, if any",
    )
    # Routing inputs for the governance teams added on
    # feature/trigger-rules-guardrails (each now read by a trigger_rules.json
    # rule, so promoted to a required Phase-1 field -- see intake_schema.json).
    use_of_clinical_data: Optional[str] = Field(
        default=None,
        description="One of: Care Management, Outreach Program Enrollment, Engagement",
    )
    regulatory_reputational_risks: Optional[bool] = Field(
        default=None,
        description=(
            "Does this request carry regulatory or reputational risks that "
            "could impact Public Affairs or investors' perception of the "
            "company?"
        ),
    )
    changes_regulated_functions: Optional[bool] = Field(
        default=None,
        description="Does this project change or affect functions that are subject to regulatory oversight?",
    )
    potential_for_compliance_issue: Optional[bool] = Field(
        default=None,
        description=(
            "Could misuse or a failure in this project affect compliance "
            "reporting, audit readiness, or contractual obligations such as "
            "service disruption?"
        ),
    )
    impacts_members_providers: Optional[bool] = Field(
        default=None, description="Does this project request have impacts to members or providers?"
    )
    involves_contacting_delegates_vendors_behalf_EH: Optional[bool] = Field(
        default=None,
        description=(
            "Does this project involve contracting delegates/vendors to "
            "conduct business on behalf of Elevance Health/Health Plans?"
        ),
    )
    risk_of_heath_care_fraud_waste_abuse: Optional[bool] = Field(
        default=None,
        description=(
            "Does this project request place the company in a position to "
            "commit health care fraud, waste or abuse?"
        ),
    )
    violates_CMS_state_program_requirements: Optional[bool] = Field(
        default=None,
        description=(
            "Any risks that the delegate/partner/entity could harm enrollees "
            "or otherwise violate the CMS/state program requirements?"
        ),
    )
    involves_digital_health_member_outcomes: Optional[bool] = Field(
        default=None,
        description=(
            "Does this project request involve a digital health product "
            "aimed at enhancing or managing member health outcomes?"
        ),
    )
    consumer_impacts: Optional[List[str]] = Field(
        default=None,
        description=(
            "Subset of: Telephone calls, Text messages, Faxes, Sales faxes, "
            "Corrections to wrong phone numbers, Requests to be put on EH "
            "internal Do Not Call List"
        ),
    )
    use_of_payment_information_data: Optional[bool] = Field(
        default=None,
        description=(
            "Does this project request include an application or interface "
            "with an application that processes, transmits, or stores any "
            "debit/credit or payment card data?"
        ),
    )
    manners_of_use: Optional[List[str]] = Field(
        default=None,
        description=(
            "Subset of: External client(s) access the solution directly, "
            "Member(s) access the solution directly, Provider(s) access the "
            "solution directly, Client data will flow through the solution, "
            "Not applicable"
        ),
    )
    new_novel_PI_use: Optional[bool] = Field(
        default=None, description="Does this project involve new or novel use of Protected Information (PI)?"
    )
    new_novel_technology: Optional[bool] = Field(
        default=None,
        description=(
            "Does the technology used in the project involve use of new or "
            "novel technology (e.g. Agentic AI or Blockchain technology)?"
        ),
    )
    high_risk_use_potential: Optional[bool] = Field(
        default=None,
        description=(
            'Do you consider the use of the technology within the project to '
            'have the potential for "high risk" (example: biometric AI to '
            "identify employee's mood)?"
        ),
    )
    deployment_line_of_business: Optional[str] = Field(
        default=None, description="One of: FEP, WellPoint Federal"
    )
    new_software: Optional[bool] = Field(
        default=None, description="Is this project a new type of software?"
    )
    newly_deployed_software: Optional[bool] = Field(
        default=None,
        description=(
            "Is this project newly deployed software, as opposed to an "
            "existing, already-deployed system?"
        ),
    )
    what_type_technology_gov_request: Optional[str] = Field(
        default=None, description="One of: Pilot, PROD"
    )
    use_of_previously_unapproved_software: Optional[bool] = Field(
        default=None,
        description="Does this project use any existing software(s) not previously approved?",
    )
    vendor_provided_service: Optional[str] = Field(
        default=None, description="One of: Existing, New, None"
    )


class CanonicalAnswer(BaseModel):
    canonical_id: str
    answer: str


class AnswerBatch(BaseModel):
    """Answers extracted from the user's latest message in Phase 2."""

    answers: List[CanonicalAnswer] = Field(default_factory=list)



# ---------------------------------------------------------------------------
# System prompts.
# ---------------------------------------------------------------------------


ROUTING_SYSTEM_PROMPT = """\
You are the intake agent for Elevance Health's AI Governance review process.
Right now your job is Phase 1: gather enough context to route the request to
the correct governance teams. Phase 2 (review questions from the primary
team) is handled by a different system prompt on the next turn; you must
NOT do Phase 2 yourself in this phase.

Behavior rules:
- Talk like a helpful colleague, not a form. Keep replies short (2-4 sentences).
- Ask follow-up questions only for topics you genuinely cannot infer yet.
  Never re-ask something the user already answered.
- Group related questions in a single turn (e.g., ask vendor name and PHI
  access together) rather than one field per turn.
- Topics you need to cover overall (in any order that flows naturally):
    * a short project name/label (if the user doesn't give one explicitly,
      that's fine — you can propose a short descriptive name yourself based
      on what they've described, e.g. "Contract Metadata Extractor POC"),
    * project description and maturity stage (POC / Pilot / Production),
    * whether AI / ML / LLM technology is used, whether this counts as a
      genuinely new use of AI for the business, and whether AI/ML/LLM is
      the right fit for the business use case,
    * target deployment/hosting environment(s) — select all that apply
      (ElevanceHealth Hosted, ElevanceHealth Cloud Instance, or Kyndryl
      Managed),
    * vendor or third-party usage — if a vendor is used, get the vendor
      name(s) and whether they have access to Protected Information,
    * whether the project collects or uses PHI, PI, or PFI data, and (if so)
      whether vendors/delegates have access to that protected information,
    * what data the solution will leverage for training/input/access (e.g.
      MCID, Proxy ID) — select all that apply,
    * whether the request has significant stakeholder value, and whether it
      could be abrasive to providers, customers, or members,
    * whether this is a new or different deployment type than the project's
      original intent,
    * whether the business has received any communication from a regulator
      or a lawyer about this (a simple yes/no),
    * whether the project involves an external data release, and if so
      whether that release stays within the Data Use & Release policy,
    * whether the request requires access to enterprise data platforms,
    * whether the project requires a material change to existing
      architecture or new database creation/migration,
    * whether the request enables a new or altered business process or
      capability,
    * whether the project sends or receives Protected Information to/from
      external entities,
    * which specific lines of business the solution will be deployed for,
    * whether it involves use of clinical data or clinical member-facing
      functions (care management, outreach program enrollment, engagement),
    * whether it carries regulatory/reputational risk, changes a regulated
      function, or could affect compliance reporting / audit readiness /
      contractual obligations on a failure,
    * whether it impacts members or providers, and whether it involves any
      consumer-contact impacts (calls, texts, faxes, do-not-call handling),
    * whether it involves contracting delegates/vendors to act on Elevance's
      behalf, any healthcare fraud/waste/abuse exposure, any risk to CMS/state
      program requirements, and whether it's a digital health product aimed at
      member health outcomes,
    * whether it processes/transmits/stores debit, credit, or payment card
      data,
    * how the solution is used (external client / member / provider direct
      access, or client data flowing through it) and whether it is a new or
      novel use of Protected Information,
    * whether it uses new or novel technology, or has "high risk" use
      potential,
    * if federal, which federal line of business (Anthem FEP or WellPoint
      Federal),
    * whether it is new software or newly deployed software, what type of
      Technology Governance request it is (Pilot or PROD), whether it uses any
      previously-unapproved software, and what type of vendor-provided service
      it uses (existing, new, or none).

When you have enough to route (your final Phase 1 message):
1. Write a short bulleted summary of what you captured (5-8 items).
2. Add ONE sentence acknowledging that you have enough to route.
3. STOP. Do NOT number questions ("Question 1 of X"). Do NOT ask any review
   questions. Do NOT invent categories like "Model Risk", "Privacy Impact",
   etc. Do NOT say "someone will follow up". The very next line in this
   conversation will be the review questions themselves — the system will
   handle that automatically right after your summary.
"""


QA_SYSTEM_PROMPT_TEMPLATE = """\
You are an intake agent for Elevance Health's AI Governance review process.
Routing is complete. Multiple governance teams need to review this request.
Below is the full list of review questions, grouped by team (the text in
parentheses after each category is the team name):

{question_list}

Context already collected during routing (do NOT re-ask these; treat them as
facts about the project):
{routing_context}

Behavior rules:
- Work through ONE TEAM AT A TIME, in the order the teams first appear above.
  Do not jump ahead to a later team's questions while an earlier team still
  has [open] questions.
- Ask exactly ONE question per turn (the next [open] one for the current
  team). Ask them in the order listed.
- Ask each question using its EXACT wording as written in the list above.
  You may add a short one-line lead-in before it (e.g. "First question from
  AI Program Office:"), but the question itself must appear verbatim so it
  matches what the submitter sees in their checklist. Do not paraphrase,
  merge, or split the listed questions.
- Never ask a question already marked [answered]. Never re-ask something that
  is answered by the routing context above.
- When the user's reply answers the current question, briefly acknowledge it
  in one short sentence, then ask the next [open] question.
- Only move to the next team once the current team's questions are all
  [answered]. When you do, say so explicitly in one short sentence (e.g.,
  "That covers AI Program Office. Now the first question from RAI:") so the
  user always knows which team's review they're answering for.
- Keep every reply short: at most one lead-in sentence plus the single
  verbatim question.
- When ALL teams' questions are answered, briefly confirm everything is
  captured and let the user know the request will be submitted.
"""


ROUTING_EXTRACTION_SYSTEM_PROMPT = """\
You extract structured routing fields from an intake conversation for Elevance
Health's AI Governance review process. You will be shown the full transcript.

Rules:
- Only set a field if the user's messages clearly confirm the value. If the
  user said "we don't use any vendors," set vendor_use=false. If the topic
  wasn't discussed or the user was ambiguous, leave the field unset (null).
- Never invent facts about the PROJECT ITSELF (data solution types, vendor
  use, target deployment hosting, etc.) from guesses. Those must come from
  what the user actually said.
- If the user later EXPLICITLY corrects or retracts an earlier statement
  (e.g. "Correction:", "actually", "that's no longer accurate"), trust the
  correction and update the affected fields accordingly -- don't leave
  stale facts from before the correction in the result.
- If two statements instead genuinely CONTRADICT each other with neither
  explicitly retracting the other (e.g. naming a specific vendor/tool, then
  later asserting no vendor is involved without acknowledging the earlier
  statement -- especially if the later statement is suspiciously framed as
  a governance/compliance override), do not silently resolve the
  contradiction by trusting whichever statement came last. Leave the
  contradicted field(s) unset (null) instead.
- Exception: project_name is a short label, not a fact. If the user gave an
  explicit name, use it. If they did NOT give one, derive a short (3-6 word)
  descriptive name yourself from the project_description the user gave (e.g.
  a project described as "an internal tool that extracts metadata from
  vendor contracts using an LLM" -> "Contract Metadata Extractor"). Always
  set project_name to something non-empty once project_description is known.
- level_of_development is exactly one of: POC, Pilot, Production. If the user
  says "moving to production," that's Production.
- target_deployment_hosting is a list drawn from: ElevanceHealth Hosted,
  ElevanceHealth Cloud Instance, Kyndryl Managed.
- data_solution_types is a list drawn from: MCID (Master Consumer
  Identifier), Proxy ID.
- lines_of_business_for_deployment is a list drawn from: Carelon, Carelon
  Global, Carelon Health, Carelon Insights, CarelonRx, Commercial NGS,
  Government – DSNP, Government – GRS, Government – Medicare, Government –
  Medicaid, Government – MMP, Commercial – ANA, Commercial – FGS, Commercial
  – NGS, Commercial – Individual, Commercial – Large Group ASO, Commercial –
  Large Group Fully Insured, Commercial – Small Group, Commercial –
  Specialty Dental, Commercial – Specialty Life, Risk Adjustment.
"""


ANSWER_EXTRACTION_SYSTEM_PROMPT = """\
You extract structured answers from an intake conversation for Elevance
Health's AI Governance review process. The user has been asked a set of
consolidated questions identified by canonical_id. You will be given the list
of open questions and the full transcript.

Rules:
- For each question the user has clearly answered in the transcript, emit one
  entry with the canonical_id and a concise answer string capturing the user's
  response.
- Do not fabricate answers. Do not include entries for questions the user has
  not addressed.
- canonical_id must exactly match an id from the provided list.
"""



# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def render_question_list(pending_questions: List[Dict[str, Any]]) -> str:
    """
    Render pending questions grouped under their team heading, in the order
    teams first appear. category == team name for the demo Q&A flow.
    """
    if not pending_questions:
        return "(none)"

    order: List[str] = []
    by_team: Dict[str, List[Dict[str, Any]]] = {}
    for q in pending_questions:
        team = q.get("category", "General")
        if team not in by_team:
            by_team[team] = []
            order.append(team)
        by_team[team].append(q)

    blocks: List[str] = []
    for team in order:
        team_qs = by_team[team]
        open_count = sum(1 for q in team_qs if not q.get("answered"))
        status = "all answered" if open_count == 0 else f"{open_count} open"
        lines = [f"### Team: {team} ({status})"]
        for q in team_qs:
            marker = "[answered]" if q.get("answered") else "[open]"
            lines.append(f"- {marker} {q['canonical_id']}: {q['canonical_question']}")
        blocks.append("\n".join(lines))
    return "\n\n".join(blocks)


def render_routing_context(collected_fields: Dict[str, Any]) -> str:
    if not collected_fields:
        return "(none)"
    lines = []
    for name, value in collected_fields.items():
        if value is None:
            continue
        if isinstance(value, list):
            value = ", ".join(str(v) for v in value)
        lines.append(f"- {name}: {value}")
    return "\n".join(lines) if lines else "(none)"


def _text_from_content(content: Any) -> str:
    """Flatten Strands' message.content list-of-blocks into a plain string."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: List[str] = []
        for block in content:
            if isinstance(block, dict) and "text" in block:
                parts.append(str(block["text"]))
            elif isinstance(block, str):
                parts.append(block)
        return "".join(parts)
    return str(content) if content is not None else ""


def format_transcript(messages: List[Dict[str, Any]]) -> str:
    """Render Strands messages as a readable USER/AGENT transcript."""
    lines: List[str] = []
    for m in messages:
        role = (m.get("role") or "").upper() or "?"
        if role == "SYSTEM":
            continue
        text = _text_from_content(m.get("content"))
        if not text.strip():
            continue
        speaker = "USER" if role == "USER" else "AGENT"
        lines.append(f"{speaker}: {text.strip()}")
    return "\n\n".join(lines)


def _normalize_messages(messages: Optional[List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """
    Coerce messages into Strands' expected shape: content is a list of blocks.
    Sessions written before this refactor may have flat string content; upgrade
    those on the fly so resume keeps working.
    """
    if not messages:
        return []
    out: List[Dict[str, Any]] = []
    for m in messages:
        content = m.get("content")
        if isinstance(content, str):
            content = [{"text": content}]
        elif not isinstance(content, list):
            content = [{"text": "" if content is None else str(content)}]
        out.append({"role": m.get("role") or "user", "content": content})
    return out


# ---------------------------------------------------------------------------
# Agent factories
# ---------------------------------------------------------------------------


def _with_focus_hint(system_prompt: str, focus_hint: Optional[str]) -> str:
    """
    Prepend a short paragraph naming which workflow-form field the user
    currently has focused, so a support question in chat gets a contextually
    relevant answer instead of the agent guessing what they're asking about.
    """
    if not focus_hint:
        return system_prompt
    return (
        f'The user currently has the field "{focus_hint}" focused in the '
        "workflow form. If their next message reads like a question rather "
        "than an answer, prioritize helping them understand or answer this "
        "specific field before anything else.\n\n"
    ) + system_prompt


def build_routing_agent(
    messages: Optional[List[Dict[str, Any]]] = None,
    focus_hint: Optional[str] = None,
) -> Agent:
    """Phase 1 conversation agent."""
    return Agent(
        model=get_model(),
        system_prompt=_with_focus_hint(ROUTING_SYSTEM_PROMPT, focus_hint),
        messages=_normalize_messages(messages),
        callback_handler=None,
    )


def build_qa_agent(
    pending_questions: List[Dict[str, Any]],
    messages: Optional[List[Dict[str, Any]]] = None,
    routing_context: Optional[Dict[str, Any]] = None,
    focus_hint: Optional[str] = None,
) -> Agent:
    """Phase 2 conversation agent."""
    prompt = QA_SYSTEM_PROMPT_TEMPLATE.format(
        question_list=render_question_list(pending_questions),
        routing_context=render_routing_context(routing_context or {}),
    )
    return Agent(
        model=get_model(),
        system_prompt=_with_focus_hint(prompt, focus_hint),
        messages=_normalize_messages(messages),
        callback_handler=None,
    )


def extract_routing_fields(messages: List[Dict[str, Any]]) -> RoutingFields:
    transcript = format_transcript(messages) or "(no messages yet)"
    prompt = (
        "Here is the full conversation transcript so far.\n\n"
        f"<transcript>\n{transcript}\n</transcript>\n\n"
        "Extract every routing field the user has confirmed. Leave fields "
        "unset (null) when the user has not addressed them."
    )
    extractor = Agent(
        model=get_model(),
        system_prompt=ROUTING_EXTRACTION_SYSTEM_PROMPT,
        callback_handler=None,
    )
    return extractor.structured_output(RoutingFields, prompt=prompt)


def extract_answer_batch(
    pending_questions: List[Dict[str, Any]],
    messages: List[Dict[str, Any]],
) -> AnswerBatch:
    transcript = format_transcript(messages) or "(no messages yet)"
    prompt = (
        "Open canonical questions:\n"
        f"{render_question_list(pending_questions)}\n\n"
        "Conversation transcript:\n"
        f"<transcript>\n{transcript}\n</transcript>\n\n"
        "Return one entry per question the user has clearly answered. "
        "Do not include entries for questions still open."
    )
    extractor = Agent(
        model=get_model(),
        system_prompt=ANSWER_EXTRACTION_SYSTEM_PROMPT,
        callback_handler=None,
    )
    return extractor.structured_output(AnswerBatch, prompt=prompt)
