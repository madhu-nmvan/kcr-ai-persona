# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""Governance Intake Agent for Elevance Health.

Conversational intake + routing + consolidated Q&A over the governance
review teams, backed by the EHAP LLM gateway. Deterministic routing and
question deduplication are driven by the config JSON under ``data/``.
"""

__version__ = "0.1.0"
