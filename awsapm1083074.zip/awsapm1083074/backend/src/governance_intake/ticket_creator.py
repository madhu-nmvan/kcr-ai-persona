# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Ticket creator.

Pure function: given a completed session, assemble the governance ticket
payload. Caller (handler) decides where to persist it.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Dict


def create_ticket(session: Dict[str, Any]) -> Dict[str, Any]:
    """Assemble the full ticket payload from session state."""
    now = datetime.now(timezone.utc).isoformat()
    ticket_id = f"GOV-{uuid.uuid4().hex[:8].upper()}"

    return {
        "ticket_id": ticket_id,
        "session_id": session.get("session_id"),
        "submitter": session.get("user_id"),
        "created_at": now,
        "request_metadata": {
            "project_name": session.get("collected_fields", {}).get("project_name"),
            "project_description": session.get("collected_fields", {}).get(
                "project_description"
            ),
            "level_of_development": session.get("collected_fields", {}).get(
                "level_of_development"
            ),
        },
        "routing_fields": session.get("collected_fields", {}),
        "activated_teams": session.get("activated_teams", []),
        "team_forms": session.get("team_forms", {}),
        "answered_questions": [
            {
                "canonical_id": q["canonical_id"],
                "canonical_question": q["canonical_question"],
                "answer": q["answer"],
                "source_teams": q.get("source_teams", []),
            }
            for q in session.get("pending_questions", [])
            if q.get("answered")
        ],
        "status": "Submitted",
    }
