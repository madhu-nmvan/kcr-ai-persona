# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Form mapper.

Pure function: given the answered canonical questions, fan out each answer to
every team-specific form field it covers.

Output shape:
    {
      "Privacy": {"PRIVACY.1": "...", "PRIVACY.3": "..."},
      "Security-InfoSec": {"SEC.1": "...", "SEC.5": "..."},
      ...
    }
"""

from __future__ import annotations

from typing import Any, Dict, List


def map_answers_to_team_forms(
    pending_questions: List[Dict[str, Any]],
    activated_teams: List[str],
) -> Dict[str, Dict[str, Any]]:
    """
    Build per-team form dicts from answered canonical questions.

    Unanswered canonicals do not contribute keys; gap_detector handles those.
    """
    team_forms: Dict[str, Dict[str, Any]] = {team: {} for team in activated_teams}

    for q in pending_questions:
        if not q.get("answered"):
            continue
        answer = q.get("answer")
        for src in q.get("sources", []):
            team = src["team"]
            if team not in team_forms:
                # Not activated; ignore
                continue
            team_forms[team][src["question_id"]] = answer

    return team_forms
