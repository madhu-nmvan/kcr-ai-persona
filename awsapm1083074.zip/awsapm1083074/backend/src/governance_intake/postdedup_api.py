# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Post-dedup HTTP API.

A FastAPI router for the form-first post-activation experience. Constructed
via build_router(store, data) so tests can wire an in-memory store; server.py
mounts it with the process singletons.

Routes (all under /api/post-dedup):
    POST /sessions                        create from a STATE envelope
    GET  /sessions/{id}                   STATE envelope + stats + completeness
    POST /sessions/{id}/answers           batch answer edits (fill-in pass opt-in)
    POST /sessions/{id}/prefill           run the grounded prefill pass
    POST /sessions/{id}/prefill/decisions accept / dismiss proposals
    POST /sessions/{id}/qa-review         advisory counselor pass
    POST /sessions/{id}/attachments/upload  multipart diagram upload
    POST /sessions/{id}/submit            deterministic gate -> ticket
    GET  /sessions/{id}/stats             before/after strip

Works on any session in the asking phase — whether created here from STATE
or arrived at through the existing chat flow.
"""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel, Field

from . import postdedup
from .attachments import AttachmentError, read_upload_bounded, save_attachment
from .postdedup import PostDedupError
from .prefill import run_prefill
from .qa_review import review_answers
from .session import SessionStore
from .state_adapter import envelope_from_session, state_from_session


class CreateSessionRequest(BaseModel):
    state: dict[str, Any]
    user_id: str | None = "demo@elevancehealth.com"


class AnswerEdit(BaseModel):
    canonical_id: str
    answer: Any = None


class AnswersRequest(BaseModel):
    answers: list[AnswerEdit]
    # Opt-in fill-in loop: after recording, re-run prefill so the new
    # answers can imply (propose) later ones.
    run_prefill: bool = False


class PrefillDecisionsRequest(BaseModel):
    accept: list[str] = Field(default_factory=list)
    dismiss: list[str] = Field(default_factory=list)
    accept_all: bool = False


def build_router(store: SessionStore, data: Any, demo_mode: bool = False) -> APIRouter:
    router = APIRouter(prefix="/api/post-dedup")

    def _get(session_id: str) -> dict[str, Any]:
        sess = store.get(session_id)
        if sess is None:
            raise HTTPException(status_code=404, detail="Unknown session")
        return sess

    def _view(sess: dict[str, Any]) -> dict[str, Any]:
        return {
            "session_id": sess["session_id"],
            "phase": sess["phase"],
            "state": state_from_session(sess, data),
            "completeness": (postdedup.completeness(sess, data, demo_mode) if sess["phase"] == "asking_questions" else None),
            "stats": postdedup.stats(sess),
            "unknown_teams": sess.get("unknown_teams", []),
            "attachments": sess.get("attachments", []),
            "qa_review": sess.get("qa_review", []),
            "ticket": sess.get("ticket"),
        }

    @router.post("/sessions", status_code=201)
    def create_session(body: CreateSessionRequest) -> dict[str, Any]:
        session_id = f"sess-{uuid.uuid4().hex[:8]}"
        try:
            sess = postdedup.begin_session(session_id, body.user_id or "demo@elevancehealth.com", body.state, data)
        except PostDedupError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        store.put(sess)
        return _view(sess)

    @router.get("/sessions/{session_id}")
    def get_session(session_id: str) -> dict[str, Any]:
        return _view(_get(session_id))

    @router.post("/sessions/{session_id}/answers")
    def record_answers(session_id: str, body: AnswersRequest) -> dict[str, Any]:
        sess = _get(session_id)
        try:
            postdedup.record_answers(sess, data, [a.model_dump() for a in body.answers], demo_mode=demo_mode)
            prefill_summary = None
            if body.run_prefill:
                prefill_summary = run_prefill(sess)
        except PostDedupError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        except RuntimeError as e:  # no LLM provider configured
            raise HTTPException(status_code=503, detail=str(e)) from e
        store.put(sess)
        view = _view(sess)
        view["prefill_summary"] = prefill_summary
        return view

    @router.post("/sessions/{session_id}/prefill")
    def prefill(session_id: str) -> dict[str, Any]:
        sess = _get(session_id)
        try:
            summary = run_prefill(sess)
        except PostDedupError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e)) from e
        store.put(sess)
        view = _view(sess)
        view["prefill_summary"] = summary
        return view

    @router.post("/sessions/{session_id}/prefill/decisions")
    def prefill_decisions(session_id: str, body: PrefillDecisionsRequest) -> dict[str, Any]:
        sess = _get(session_id)
        try:
            postdedup.apply_prefill_decisions(
                sess,
                data,
                accept=body.accept,
                dismiss=body.dismiss,
                accept_all=body.accept_all,
                demo_mode=demo_mode,
            )
        except PostDedupError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        store.put(sess)
        return _view(sess)

    @router.post("/sessions/{session_id}/qa-review")
    def qa_review(session_id: str) -> dict[str, Any]:
        sess = _get(session_id)
        try:
            concerns = review_answers(sess)
        except RuntimeError as e:
            raise HTTPException(status_code=503, detail=str(e)) from e
        store.put(sess)
        return {"concerns": concerns}

    @router.post("/sessions/{session_id}/attachments/upload")
    async def upload(session_id: str, file: UploadFile = File(...)) -> dict[str, Any]:  # noqa: B008 (FastAPI idiom, matches server.py)
        sess = _get(session_id)
        try:
            # Bounded read: reject oversized uploads before fully buffering.
            raw = await read_upload_bounded(file)
            attachment = save_attachment(
                session_id=session_id,
                filename=file.filename or "attachment",
                data=raw,
                content_type=file.content_type,
            )
            postdedup.record_attachment(sess, attachment)
        except (AttachmentError, PostDedupError) as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        store.put(sess)
        return {"attachment": attachment, "attachments": sess["attachments"]}

    @router.post("/sessions/{session_id}/submit")
    def submit(session_id: str) -> dict[str, Any]:
        sess = _get(session_id)
        try:
            ticket = postdedup.submit(sess, data, demo_mode=demo_mode)
        except PostDedupError as e:
            # Conflict: the deterministic gate refused; body carries the facts.
            raise HTTPException(status_code=409, detail=str(e)) from e
        store.put(sess)
        return {"ticket": ticket, "phase": sess["phase"]}

    @router.get("/sessions/{session_id}/stats")
    def get_stats(session_id: str) -> dict[str, Any]:
        return postdedup.stats(_get(session_id))

    @router.get("/sessions/{session_id}/envelope")
    def get_envelope(session_id: str) -> dict[str, Any]:
        # The FormFillerEnvelope (real #13 contract): POST this to
        # /api/formfiller/fill and merge the returned agent-filled values
        # back via the answers endpoint. Shape-conformant with
        # form_filler_agent.FormFillerEnvelope.
        return envelope_from_session(_get(session_id), data)

    return router
