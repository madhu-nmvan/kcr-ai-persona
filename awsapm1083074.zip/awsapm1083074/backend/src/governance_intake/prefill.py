# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Grounded LLM pre-fill.

Proposes answers to open canonical questions from material the submitter
actually provided: the chat transcript (user turns only), the trigger-field
answers, and previously answered governance questions (the Phase-B fill-in
loop). Every proposal must cite its source with a verbatim quote, and a
deterministic grounding gate re-verifies that quote against the claimed
source before the proposal is allowed anywhere near the session — a
confidently wrong pre-filled compliance answer is worse than a blank.

Proposals land as q["prefill"] with status "proposed". Committing them is a
separate, explicit user decision (postdedup.apply_prefill_decisions).

INTAKE_SKIP_LLM=1 makes propose/run a no-op so the pure pipeline and tests
never call out.
"""

from __future__ import annotations

import os
import re
import unicodedata
from collections.abc import Callable
from typing import Any, Literal

from pydantic import BaseModel, Field

PROVENANCE_TRANSCRIPT = "transcript"
PROVENANCE_TRIGGER_FIELD = "trigger_field"
PROVENANCE_PRIOR_ANSWER = "prior_answer"

_MIN_QUOTE_CHARS = 3
_DEFAULT_BATCH_SIZE = 40


class PrefillProvenance(BaseModel):
    kind: Literal["transcript", "trigger_field", "prior_answer"]
    ref: str = Field(
        description=(
            "Where the quote came from: the trigger field name, the "
            "0-based index of the user message, or the canonical_id of a "
            "previously answered question."
        )
    )
    quote: str = Field(
        description="Verbatim excerpt from that source supporting the answer."
    )


class PrefillProposal(BaseModel):
    canonical_id: str
    answer: str
    provenance: PrefillProvenance


class PrefillBatch(BaseModel):
    proposals: list[PrefillProposal] = Field(default_factory=list)


PREFILL_SYSTEM_PROMPT = """\
You pre-fill governance questionnaire answers from what a project submitter
has already said. You are given open questions, the submitter's own messages,
their intake (trigger) field answers, and answers they already gave to other
governance questions.

Rules — follow them exactly:
- Propose an answer ONLY when the provided material clearly supports it.
  When in doubt, do not propose. A blank is better than a guess.
- Never invent, infer beyond, or embellish what the submitter said.
- Every proposal must carry provenance: kind is "transcript" (ref = the
  user message index shown), "trigger_field" (ref = the field name), or
  "prior_answer" (ref = the canonical id of an already-answered question).
- The quote must be copied VERBATIM from that source. Proposals whose quote
  does not appear in the source are discarded automatically.
- Answer in the submitter's terms, concisely.
"""


AgentFactory = Callable[[], Any]


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFKC", str(s)).casefold()
    return re.sub(r"\s+", " ", s).strip()


def _stringify(value: Any) -> str:
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, list):
        return ", ".join(str(v) for v in value)
    return str(value)


def ground(
    proposal: PrefillProposal,
    user_messages: list[str],
    trigger_fields: dict[str, Any],
    prior_answers: dict[str, str],
) -> bool:
    """
    Deterministic check that the proposal's quote really appears in the
    source it claims. Pure; no LLM.
    """
    quote = _norm(proposal.provenance.quote)
    if len(quote) < _MIN_QUOTE_CHARS:
        return False

    kind = proposal.provenance.kind
    ref = proposal.provenance.ref

    if kind == PROVENANCE_TRANSCRIPT:
        return any(quote in _norm(m) for m in user_messages)

    if kind == PROVENANCE_TRIGGER_FIELD:
        if ref not in trigger_fields:
            return False
        value = _norm(_stringify(trigger_fields[ref]))
        return bool(value) and (quote in value or value in quote)

    if kind == PROVENANCE_PRIOR_ANSWER:
        answer = prior_answers.get(ref)
        return answer is not None and quote in _norm(answer)

    return False


def _render_questions(questions: list[dict[str, Any]]) -> str:
    lines = []
    for q in questions:
        lines.append(f"- [{q['canonical_id']}] {q.get('canonical_question', '')}")
    return "\n".join(lines)


def _render_user_messages(user_messages: list[str]) -> str:
    if not user_messages:
        return "(none)"
    return "\n".join(f"[{i}] {m}" for i, m in enumerate(user_messages))


def _render_fields(fields: dict[str, Any]) -> str:
    if not fields:
        return "(none)"
    return "\n".join(f"- {k}: {_stringify(v)}" for k, v in sorted(fields.items()))


def _render_prior_answers(prior: dict[str, str]) -> str:
    if not prior:
        return "(none)"
    return "\n".join(f"- [{cid}] {ans}" for cid, ans in prior.items())


def _default_agent_factory() -> Any:
    from strands import Agent

    from .llm_provider import get_model

    return Agent(
        model=get_model(),
        system_prompt=PREFILL_SYSTEM_PROMPT,
        callback_handler=None,
    )


def propose_prefills(
    open_questions: list[dict[str, Any]],
    user_messages: list[str],
    trigger_fields: dict[str, Any],
    prior_answers: dict[str, str],
    batch_size: int = _DEFAULT_BATCH_SIZE,
    agent_factory: AgentFactory | None = None,
) -> tuple[list[PrefillProposal], int]:
    """
    Ask the model for proposals over the open questions, in batches sized
    for the full-mode corpus (hundreds to ~1,600 questions).

    Returns (grounded_proposals, rejected_count). rejected_count is how many
    model proposals failed the deterministic grounding gate (or referenced
    unknown/answered questions) and were dropped.
    """
    if os.environ.get("INTAKE_SKIP_LLM") == "1" or not open_questions:
        return [], 0
    if not user_messages and not trigger_fields and not prior_answers:
        return [], 0  # nothing to ground against; every proposal would fail

    factory = agent_factory or _default_agent_factory
    open_ids = {q["canonical_id"] for q in open_questions}

    grounded: list[PrefillProposal] = []
    rejected = 0
    for start in range(0, len(open_questions), batch_size):
        batch = open_questions[start : start + batch_size]
        prompt = (
            "Open questions:\n"
            f"{_render_questions(batch)}\n\n"
            "Submitter's messages (user turns only, indexed):\n"
            f"{_render_user_messages(user_messages)}\n\n"
            "Trigger-field answers:\n"
            f"{_render_fields(trigger_fields)}\n\n"
            "Previously answered governance questions:\n"
            f"{_render_prior_answers(prior_answers)}\n\n"
            "Propose grounded pre-fill answers for any of the open questions "
            "the material clearly answers. Skip everything else."
        )
        result: PrefillBatch = factory().structured_output(PrefillBatch, prompt=prompt)
        for proposal in result.proposals:
            if proposal.canonical_id not in open_ids:
                rejected += 1
                continue
            if not proposal.answer.strip():
                rejected += 1
                continue
            if ground(proposal, user_messages, trigger_fields, prior_answers):
                grounded.append(proposal)
            else:
                rejected += 1
    return grounded, rejected


def run_prefill(
    sess: dict[str, Any],
    agent_factory: AgentFactory | None = None,
    batch_size: int = _DEFAULT_BATCH_SIZE,
) -> dict[str, int]:
    """
    Full pass over a session: propose prefills for open questions that don't
    already carry a proposal (dismissed ones are not re-proposed), verify
    grounding, and stage the survivors as status="proposed".

    Returns {"proposed": n, "rejected": n, "eligible": n}.
    """
    pending = sess.get("pending_questions", [])
    eligible = [
        q for q in pending if not q.get("answered") and not q.get("prefill")
    ]
    user_messages = [
        m["content"]
        for m in sess.get("ui_messages", [])
        if m.get("role") == "user" and m.get("content")
    ]
    trigger_fields = sess.get("collected_fields", {})
    prior_answers = {
        q["canonical_id"]: str(q["answer"])
        for q in pending
        if q.get("answered") and q.get("answer") is not None
    }

    proposals, rejected = propose_prefills(
        eligible,
        user_messages,
        trigger_fields,
        prior_answers,
        batch_size=batch_size,
        agent_factory=agent_factory,
    )

    by_id = {q["canonical_id"]: q for q in eligible}
    staged = 0
    for proposal in proposals:
        q = by_id.get(proposal.canonical_id)
        if q is None or q.get("prefill"):
            # Duplicate proposal for the same question in one pass: keep first.
            rejected += 1
            continue
        q["prefill"] = {
            "answer": proposal.answer,
            "provenance": proposal.provenance.model_dump(),
            "status": "proposed",
        }
        staged += 1

    sess["prefill_rejected_count"] = sess.get("prefill_rejected_count", 0) + rejected
    return {"proposed": staged, "rejected": rejected, "eligible": len(eligible)}
