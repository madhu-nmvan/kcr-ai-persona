# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Session state management.

Provides a small abstraction so we can swap an in-memory dict store for a real
DynamoDB store later without touching handler logic.

Session shape:
    {
      "session_id": str,
      "user_id": str,
      "phase": "collecting_routing_info" | "asking_questions"
             | "collecting_attachments" | "complete",
      "chat_history": list,           # Strands-internal agent messages
      "ui_messages": list[dict],      # UI-visible turns: {"role": "user"|"agent", "content": str}
      "collected_fields": dict,
      "activated_teams": list[dict],
      "focus_team": str | None,
      "team_order": list[str],
      "pending_questions": list[dict],
      "team_forms": dict[str, dict],
      "attachments": list[dict],      # [{"s3_key","filename","size","content_type","uploaded_at"}]
      "ticket": dict | None,
      "created_at": iso8601 str,
      "updated_at": iso8601 str
    }

Two backends today:
  InMemorySessionStore    - process-local dict. Great for tests / dev.
  DynamoDBSessionStore    - persistent, survives restarts, supports history.
"""

from __future__ import annotations

import copy
import hashlib
import json
import logging
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


log = logging.getLogger("intake.session")

PHASE_ROUTING = "collecting_routing_info"
PHASE_ASKING = "asking_questions"
PHASE_ATTACHMENTS = "collecting_attachments"
PHASE_COMPLETE = "complete"


def _display_id(session_id: str, now: datetime) -> str:
    """
    Cosmetic, deterministic "ticket-looking" id (e.g. INT-2026-A3F9C1) for the
    UI's Submission Overview card. Derived from session_id, not a real
    sequential counter — placeholder for real ticket numbering later.
    """
    # Not a security control — just a short, stable, human-readable label.
    # SHA-256 (not SHA-1) so no deprecated hash appears anywhere in the code,
    # even for cosmetic use; usedforsecurity=False documents the intent.
    digest = hashlib.sha256(session_id.encode(), usedforsecurity=False).hexdigest()[:6].upper()
    return f"INT-{now.year}-{digest}"


def new_session(session_id: str, user_id: str) -> Dict[str, Any]:
    now = datetime.now(timezone.utc)
    now_iso = now.isoformat()
    return {
        "session_id": session_id,
        "display_id": _display_id(session_id, now),
        "user_id": user_id,
        "phase": PHASE_ROUTING,
        "chat_history": [],
        "ui_messages": [],
        "collected_fields": {},
        "activated_teams": [],
        "focus_team": None,
        "team_order": [],
        "pending_questions": [],
        "team_forms": {},
        "attachments": [],
        "ticket": None,
        "created_at": now_iso,
        "updated_at": now_iso,
    }


def touch(session: Dict[str, Any]) -> None:
    session["updated_at"] = datetime.now(timezone.utc).isoformat()


def add_ui_message(session: Dict[str, Any], role: str, content: str) -> None:
    """Append a UI-visible message. role must be 'user' or 'agent'."""
    session.setdefault("ui_messages", []).append({"role": role, "content": content})


def summarize(session: Dict[str, Any]) -> str:
    """Short label for a session — for the history sidebar. Best-effort."""
    project = (session.get("collected_fields") or {}).get("project_name")
    if project:
        return project[:80]
    for m in session.get("ui_messages", []):
        if m.get("role") == "user" and m.get("content"):
            return m["content"][:80]
    return "(new session)"


# ---------------------------------------------------------------------------
# Abstract store
# ---------------------------------------------------------------------------


class SessionStore(ABC):
    @abstractmethod
    def get(self, session_id: str) -> Optional[Dict[str, Any]]:
        ...

    @abstractmethod
    def put(self, session: Dict[str, Any]) -> None:
        ...

    def list_sessions(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Return short summaries of recent sessions, newest first.

        Each entry looks like:
            {"session_id": str, "user_id": str, "phase": str,
             "updated_at": str, "summary": str}
        """
        raise NotImplementedError


# ---------------------------------------------------------------------------
# In-memory backend
# ---------------------------------------------------------------------------


class InMemorySessionStore(SessionStore):
    """Process-local store. Not persistent. Good for local_test / unit tests."""

    def __init__(self) -> None:
        self._data: Dict[str, Dict[str, Any]] = {}

    def get(self, session_id: str) -> Optional[Dict[str, Any]]:
        record = self._data.get(session_id)
        return copy.deepcopy(record) if record else None

    def put(self, session: Dict[str, Any]) -> None:
        touch(session)
        self._data[session["session_id"]] = copy.deepcopy(session)

    def list_sessions(self, limit: int = 50) -> List[Dict[str, Any]]:
        items = list(self._data.values())
        items.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
        return [
            {
                "session_id": s["session_id"],
                "user_id": s.get("user_id", ""),
                "phase": s.get("phase", ""),
                "updated_at": s.get("updated_at", ""),
                "summary": summarize(s),
            }
            for s in items[:limit]
        ]


# ---------------------------------------------------------------------------
# DynamoDB backend
# ---------------------------------------------------------------------------


class DynamoDBSessionStore(SessionStore):
    """
    DynamoDB-backed session store.

    Table schema:
        partition key: session_id (string)
    Item attributes:
        session_id  (S) - primary key
        user_id     (S)
        phase       (S)
        updated_at  (S) - ISO 8601 for sorting
        summary     (S) - short label for the history sidebar
        data        (S) - JSON blob of the full session dict

    We keep the whole session as one JSON string ("data") to sidestep DynamoDB
    type-coercion issues with nested lists / dicts / None values. Top-level
    indexed attributes exist so scans for the history dropdown stay cheap.
    """

    def __init__(
        self,
        table_name: str,
        region_name: Optional[str] = None,
        auto_create: bool = True,
    ) -> None:
        import boto3

        self.table_name = table_name
        self.region_name = region_name
        self._dynamodb = boto3.resource("dynamodb", region_name=region_name)
        self._client = self._dynamodb.meta.client
        self._table = self._dynamodb.Table(table_name)
        if auto_create:
            self._ensure_table_exists()

    def _ensure_table_exists(self) -> None:
        from botocore.exceptions import ClientError

        try:
            self._client.describe_table(TableName=self.table_name)
            return
        except ClientError as e:
            if e.response["Error"]["Code"] != "ResourceNotFoundException":
                raise

        log.info("Creating DynamoDB table %s (on-demand billing)...", self.table_name)
        self._client.create_table(
            TableName=self.table_name,
            KeySchema=[{"AttributeName": "session_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "session_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST",
        )
        self._client.get_waiter("table_exists").wait(TableName=self.table_name)
        log.info("Table %s ready.", self.table_name)

    def get(self, session_id: str) -> Optional[Dict[str, Any]]:
        resp = self._table.get_item(Key={"session_id": session_id})
        item = resp.get("Item")
        if not item:
            return None
        raw = item.get("data")
        if not raw:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            log.exception("Corrupt session %s in DynamoDB", session_id)
            return None

    def put(self, session: Dict[str, Any]) -> None:
        touch(session)
        item = {
            "session_id": session["session_id"],
            "user_id": session.get("user_id") or "",
            "phase": session.get("phase") or "",
            "updated_at": session.get("updated_at") or "",
            "summary": summarize(session),
            "data": json.dumps(session, default=str),
        }
        self._table.put_item(Item=item)

    def list_sessions(self, limit: int = 50) -> List[Dict[str, Any]]:
        # Scan is fine for the demo. For a real app add a GSI on user_id.
        resp = self._table.scan(
            ProjectionExpression="session_id, user_id, phase, updated_at, summary",
            Limit=max(limit * 4, 100),  # over-fetch, then sort
        )
        items = resp.get("Items", [])
        items.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
        return items[:limit]
