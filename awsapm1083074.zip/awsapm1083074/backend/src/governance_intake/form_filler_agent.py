# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
FormFillerAgent — data models, model interface, and orchestration.

Sanity-integration pass validating the contract in
docs/form_filler_agent_contract.md. The agent is a pure function
`(FormFillerEnvelope) -> FormFillerEnvelope`: it receives whatever's been
filled in so far (by a human or a prior agent call) and returns the same
envelope with any newly-fillable blanks completed.

The one invariant that matters (contract doc, same heading): the agent may
only set `value` on items where `value` is currently `None`. Any item with a
non-`None` value in the input MUST come back byte-identical in the output.
`fill_form()` re-asserts this itself rather than trusting the model
implementation, so a buggy/future EHAP-backed model can never silently
corrupt an already-answered item.

No live EHAP wiring in this pass (contract doc, "Explicitly out of scope") —
`StubFormFillerModel` is the entire "model" for now, deterministic and
network-free. `FormFillerModel` is the swap point: a real EHAP-backed
implementation drops in later without callers (the route in server.py)
changing at all. Mirrors the `SessionStore(ABC)` swap pattern already used
in session.py.

Public API used by server.py:
    FormFillerEnvelope, TriggerField, GovernanceQuestion   -> request/response schema
    StubFormFillerModel                                    -> the current model
    fill_form(envelope, model)                              -> orchestration entry point
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from itertools import chain
from pathlib import Path
from typing import Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, model_validator

DATA_DIR = Path(__file__).resolve().parent / "data"


# ---------------------------------------------------------------------------
# Envelope schema (contract doc: "Envelope" + "Base fields" + "GovernanceQuestion adds")
# ---------------------------------------------------------------------------


class SourceRef(BaseModel):
    team: str
    question_id: str


class FormItem(BaseModel):
    """Base fields shared by TriggerField and GovernanceQuestion."""

    id: str
    text: str
    value: Optional[Union[bool, str, List[str]]] = None
    origin: Optional[Literal["user", "agent"]] = None
    confidence: Optional[int] = Field(default=None, ge=0, le=5)

    @model_validator(mode="after")
    def _validate_provenance_coherence(self) -> "FormItem":
        if self.value is None:
            if self.origin is not None:
                raise ValueError(
                    "a blank item (value=None) must not carry an origin "
                    f"(got origin={self.origin!r})"
                )
            if self.confidence is not None:
                raise ValueError(
                    "a blank item (value=None) must not carry a confidence score "
                    f"(got confidence={self.confidence!r})"
                )
        else:
            if self.origin is None:
                raise ValueError(
                    "an answered item (value is not None) must carry an origin "
                    "('user' or 'agent')"
                )
            if self.origin == "user" and self.confidence is not None:
                raise ValueError(
                    "a user-provided answer must not carry a confidence score "
                    f"(got confidence={self.confidence!r})"
                )
            if self.origin == "agent" and self.confidence is None:
                raise ValueError(
                    "an agent-provided answer must carry a confidence score (0-5)"
                )
        return self


class TriggerField(FormItem):
    """One per RoutingFields field (see intake_agent.py); fixed ~40 items, present from turn 1."""


class GovernanceQuestion(FormItem):
    """
    Grows as teams activate; [] until the first team activates.

    `sources` is a passthrough from `question_dedup.build_pending_questions` —
    which (team, question_id) pairs this canonical answers. Not related to
    `origin`: `sources` says who asked, `origin` says who answered.
    """

    sources: List[SourceRef] = Field(default_factory=list)


class FormFillerEnvelope(BaseModel):
    triggers: List[TriggerField] = Field(default_factory=list)
    governance: List[GovernanceQuestion] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_unique_ids(self) -> "FormFillerEnvelope":
        for name, items in (("triggers", self.triggers), ("governance", self.governance)):
            ids = [item.id for item in items]
            if len(ids) != len(set(ids)):
                duplicates = sorted({i for i in ids if ids.count(i) > 1})
                raise ValueError(
                    f"{name!r} contains duplicate item ids: {duplicates!r} "
                    "(every item id must be unique within its collection)"
                )
        return self


# ---------------------------------------------------------------------------
# Model interface + stub implementation
# ---------------------------------------------------------------------------


class FormFillerModel(ABC):
    """Swap point for a real EHAP-backed implementation. See module docstring."""

    @abstractmethod
    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        """Return a new envelope with newly-fillable blanks completed."""
        raise NotImplementedError


def _load_trigger_field_types(schema_path: Optional[Path] = None) -> Dict[str, str]:
    """
    id (RoutingFields attribute name) -> intake_schema.json "type" ("bool" |
    "string" | "enum" | "array").

    Governance canonical IDs (e.g. "DEDUP.AI_SOLUTION_BE") never appear here —
    they're free text per the contract doc, so callers should default missing
    lookups to "string".
    """
    path = schema_path or (DATA_DIR / "intake_schema.json")
    with path.open(encoding="utf-8") as f:
        schema = json.load(f)
    return {field["name"]: field.get("type", "string") for field in schema.get("fields", [])}


class StubFormFillerModel(FormFillerModel):
    """
    Deterministic stand-in for a real EHAP-backed FormFillerAgent.

    Finds the first blank item (`value is None`) across triggers then
    governance, in order, and fills exactly that one with a placeholder
    appropriate to its apparent type: bool field -> True, list field -> [],
    everything else (string/enum triggers, all governance questions, which
    are free text) -> "stub-filled answer". Sets origin="agent",
    confidence=4. Every other item, blank or already answered, is untouched.
    """

    def __init__(self, trigger_field_types: Optional[Dict[str, str]] = None) -> None:
        self._trigger_field_types = (
            trigger_field_types if trigger_field_types is not None else _load_trigger_field_types()
        )

    def fill(self, envelope: FormFillerEnvelope) -> FormFillerEnvelope:
        result = envelope.model_copy(deep=True)
        for item in chain(result.triggers, result.governance):
            if item.value is not None:
                continue
            item.value = self._placeholder_for(item.id)
            item.origin = "agent"
            item.confidence = 4
            break
        return result

    def _placeholder_for(self, item_id: str) -> Union[bool, str, List[str]]:
        field_type = self._trigger_field_types.get(item_id, "string")
        if field_type == "bool":
            return True
        if field_type == "array":
            return []
        return "stub-filled answer"


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------


class FormFillerInvariantError(RuntimeError):
    """Raised when a model implementation overwrites or drops an already-answered item."""


def fill_form(envelope: FormFillerEnvelope, model: FormFillerModel) -> FormFillerEnvelope:
    """
    Run `model.fill`, then defend the one invariant that matters ourselves —
    defense-in-depth, not trust in the model class. Raises
    FormFillerInvariantError instead of returning a corrupted envelope if the
    model ever touches an item that came in with a non-None value.
    """
    result = model.fill(envelope)
    _assert_envelope_integrity(envelope, result)
    return result


def _assert_envelope_integrity(before: FormFillerEnvelope, after: FormFillerEnvelope) -> None:
    _assert_collection_integrity(before.triggers, after.triggers, "triggers")
    _assert_collection_integrity(before.governance, after.governance, "governance")


def _assert_collection_integrity(before_items, after_items, collection_name: str) -> None:
    if len(before_items) != len(after_items):
        raise FormFillerInvariantError(
            f"invariant violated in {collection_name!r}: item count changed "
            f"(before={len(before_items)}, after={len(after_items)})"
        )

    before_ids = [item.id for item in before_items]
    after_ids = [item.id for item in after_items]
    if sorted(before_ids) != sorted(after_ids):
        raise FormFillerInvariantError(
            f"invariant violated in {collection_name!r}: item ids changed "
            f"(before={sorted(before_ids)!r}, after={sorted(after_ids)!r})"
        )

    if len(set(before_ids)) != len(before_ids) or len(set(after_ids)) != len(after_ids):
        raise FormFillerInvariantError(
            f"invariant violated in {collection_name!r}: duplicate item ids present, "
            "cannot verify per-item identity "
            f"(before={before_ids!r}, after={after_ids!r})"
        )

    before_by_id = {item.id: item for item in before_items}
    after_by_id = {item.id: item for item in after_items}

    for item_id, before_item in before_by_id.items():
        after_item = after_by_id[item_id]

        if before_item.value is not None:
            if after_item.model_dump() != before_item.model_dump():
                raise FormFillerInvariantError(
                    f"invariant violated for id={item_id!r}: a non-None input value was "
                    f"not returned byte-identical (before={before_item.model_dump()!r}, "
                    f"after={after_item.model_dump()!r})"
                )
            continue

        before_immutable = before_item.model_dump(exclude={"value", "origin", "confidence"})
        after_immutable = after_item.model_dump(exclude={"value", "origin", "confidence"})
        if before_immutable != after_immutable:
            raise FormFillerInvariantError(
                f"invariant violated for id={item_id!r}: a blank item's immutable fields "
                f"(text/sources) changed (before={before_immutable!r}, "
                f"after={after_immutable!r})"
            )

        if after_item.value is None:
            continue

        if after_item.origin != "agent" or after_item.confidence is None:
            raise FormFillerInvariantError(
                f"invariant violated for id={item_id!r}: a newly-filled blank must carry "
                f"origin='agent' and a non-None confidence "
                f"(got origin={after_item.origin!r}, confidence={after_item.confidence!r})"
            )
