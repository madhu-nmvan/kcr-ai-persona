# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Attachment storage for the intake agent.

Two backends, selected via INTAKE_ATTACHMENTS_BACKEND:
  local (default) - saves files to a local directory on the server host.
                     No AWS resources required. Good for the initial demo
                     and for environments (like a fresh SageMaker notebook)
                     where S3/IAM haven't been provisioned yet.
  s3               - uploads go straight to an S3 bucket via put_object
                     (server-mediated, not presigned — simpler to reason
                     about, fine for demo-scale files). Requires
                     INTAKE_ATTACHMENTS_BUCKET and IAM permissions.

Either way, the browser POSTs the file to OUR server as multipart/form-data
(see server.py's /api/intake-agent/attachments/upload), and this module
decides where the bytes actually land.

Validation rules (checked before any bytes are written):
  - size must be <= MAX_ATTACHMENT_SIZE_BYTES (200 MB)
  - extension must be in ALLOWED_EXTENSIONS
At least one PPTX/PPT attachment is required before a ticket can be
created; has_required_attachment() checks that against the full set of
attachments for a session (called from handler.py).
"""

from __future__ import annotations

import os
import re
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Protocol


MAX_ATTACHMENT_SIZE_BYTES = 200 * 1024 * 1024  # 200 MB

# Chunk size for the bounded streaming read of an upload. Reading in chunks
# lets us abort as soon as a file exceeds MAX_ATTACHMENT_SIZE_BYTES instead of
# buffering an unbounded body fully into memory first.
_UPLOAD_CHUNK_BYTES = 1024 * 1024  # 1 MB


class _ChunkReader(Protocol):
    async def read(self, size: int = ...) -> bytes: ...


async def read_upload_bounded(
    file: "_ChunkReader",
    max_bytes: int = MAX_ATTACHMENT_SIZE_BYTES,
) -> bytes:
    """
    Read an uploaded file in bounded chunks, raising AttachmentError as soon
    as the accumulated size exceeds `max_bytes`.

    This is the memory guardrail for the upload endpoints: a hostile or
    accidental oversized upload is rejected after at most `max_bytes` (+ one
    chunk) have been read, instead of the whole body being buffered first.
    It does NOT replace an ingress/WAF body-size limit (see the security
    handover) — it is the in-process backstop for that control.
    """
    mb = max_bytes / (1024 * 1024)
    buf = bytearray()
    while True:
        chunk = await file.read(_UPLOAD_CHUNK_BYTES)
        if not chunk:
            break
        buf.extend(chunk)
        if len(buf) > max_bytes:
            raise AttachmentError(f"File is too large. Maximum size is {mb:.0f} MB.")
    return bytes(buf)

# Extension -> content-type allowlist. Kept intentionally narrow to what the
# governance intake process actually asks for (solution/data-flow diagrams as
# PPTX, plus common supporting-doc formats).
ALLOWED_EXTENSIONS = {
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".ppt": "application/vnd.ms-powerpoint",
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
}

# At least one attachment with one of these extensions is required to submit.
REQUIRED_EXTENSIONS = {".pptx", ".ppt"}

_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")


class AttachmentError(ValueError):
    """Raised for validation failures (bad extension, too large, etc.)."""


def _backend() -> str:
    return os.environ.get("INTAKE_ATTACHMENTS_BACKEND", "local").lower()


def validate_filename_and_size(filename: str, size: Optional[int]) -> str:
    """
    Validate extension + size. Returns the lowercased extension (with dot)
    on success. Raises AttachmentError on failure.
    """
    _, ext = os.path.splitext(filename or "")
    ext = ext.lower()
    if ext not in ALLOWED_EXTENSIONS:
        allowed = ", ".join(sorted(ALLOWED_EXTENSIONS))
        raise AttachmentError(
            f"File type {ext or '(none)'!r} is not allowed. Allowed types: {allowed}"
        )
    if size is not None and size > MAX_ATTACHMENT_SIZE_BYTES:
        mb = MAX_ATTACHMENT_SIZE_BYTES / (1024 * 1024)
        raise AttachmentError(f"File is too large. Maximum size is {mb:.0f} MB.")
    return ext


def _safe_filename(filename: str) -> str:
    base = os.path.basename(filename or "attachment")
    return _SAFE_NAME_RE.sub("_", base) or "attachment"


def build_key(session_id: str, filename: str) -> str:
    """Storage key, shared shape for both backends: session_id/uuid__filename."""
    return f"{session_id}/{uuid.uuid4().hex}__{_safe_filename(filename)}"


def has_required_attachment(attachments: List[Dict[str, Any]]) -> bool:
    """True if at least one attachment matches REQUIRED_EXTENSIONS (PPTX/PPT)."""
    for a in attachments:
        _, ext = os.path.splitext(a.get("filename", ""))
        if ext.lower() in REQUIRED_EXTENSIONS:
            return True
    return False


# ---------------------------------------------------------------------------
# Local disk backend (default — no AWS resources required)
# ---------------------------------------------------------------------------


def _local_dir() -> Path:
    base = os.environ.get("INTAKE_ATTACHMENTS_DIR")
    # Default to an "uploads/" dir relative to the current working directory
    # (repo root when run via `make run`). Never write inside the installed
    # package. Override with INTAKE_ATTACHMENTS_DIR.
    path = Path(base) if base else Path.cwd() / "uploads"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _save_local(key: str, data: bytes) -> Dict[str, Any]:
    dest = _local_dir() / key
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return {"size": len(data), "storage_path": str(dest)}


def _read_local(key: str) -> bytes:
    dest = _local_dir() / key
    if not dest.exists():
        raise AttachmentError(f"Attachment not found: {key}")
    return dest.read_bytes()


# ---------------------------------------------------------------------------
# S3 backend (opt-in via INTAKE_ATTACHMENTS_BACKEND=s3)
# ---------------------------------------------------------------------------


def _s3_client(region_name: Optional[str] = None):
    import boto3

    return boto3.client("s3", region_name=region_name)


def _s3_bucket_name() -> str:
    bucket = os.environ.get("INTAKE_ATTACHMENTS_BUCKET")
    if not bucket:
        raise RuntimeError(
            "INTAKE_ATTACHMENTS_BACKEND=s3 requires INTAKE_ATTACHMENTS_BUCKET to be set."
        )
    return bucket


def _s3_region() -> Optional[str]:
    return os.environ.get("INTAKE_ATTACHMENTS_REGION")


def _save_s3(key: str, data: bytes, content_type: str) -> Dict[str, Any]:
    client = _s3_client(_s3_region())
    client.put_object(
        Bucket=_s3_bucket_name(),
        Key=key,
        Body=data,
        ContentType=content_type,
    )
    return {"size": len(data)}


def presign_download(key: str, expires_in: int = 300) -> str:
    """
    Presigned GET URL for a stored S3 object — used if a reviewer needs to
    view an attachment later. Only meaningful when the s3 backend is active.
    """
    client = _s3_client(_s3_region())
    return client.generate_presigned_url(
        "get_object",
        Params={"Bucket": _s3_bucket_name(), "Key": key},
        ExpiresIn=expires_in,
    )


# ---------------------------------------------------------------------------
# Public API — backend-agnostic
# ---------------------------------------------------------------------------


def save_attachment(
    session_id: str,
    filename: str,
    data: bytes,
    content_type: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Validate and store an uploaded file's raw bytes.

    This is the ONE entry point server.py calls (via a single multipart
    upload endpoint) — no presigned URLs, no two-step confirm. Simpler flow
    for the initial demo; swap for presigned S3 URLs later if large files or
    server-bypass becomes a real requirement.

    Returns the attachment record to store on the session:
        {"key", "filename", "size", "content_type", "backend"}
    Raises AttachmentError on validation failure.
    """
    ext = validate_filename_and_size(filename, len(data))
    key = build_key(session_id, filename)
    put_content_type = content_type or ALLOWED_EXTENSIONS[ext]

    backend = _backend()
    if backend == "local":
        meta = _save_local(key, data)
    elif backend == "s3":
        meta = _save_s3(key, data, put_content_type)
    else:
        raise RuntimeError(
            f"Unknown INTAKE_ATTACHMENTS_BACKEND={backend!r}. Use 'local' or 's3'."
        )

    return {
        "key": key,
        "filename": _safe_filename(filename),
        "size": meta.get("size", len(data)),
        "content_type": put_content_type,
        "backend": backend,
    }


def read_attachment(key: str) -> bytes:
    """Read back a stored attachment's bytes (local backend only, for now)."""
    backend = _backend()
    if backend == "local":
        return _read_local(key)
    raise NotImplementedError(f"read_attachment not implemented for backend={backend!r}")
