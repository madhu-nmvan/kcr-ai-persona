# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
STATE adapter — the single boundary between an external question/answer
envelope and this codebase's session dict.

Two envelope shapes are accepted on input, detected structurally:

1. **FormFillerEnvelope** (the real contract — Jeremy's PR #13,
   docs/form_filler_agent_contract.md): ``{"triggers": [...], "governance":
   [...]}`` where each item is ``{id, text, value, origin, confidence}`` and
   governance items add ``sources: [{team, question_id}]``. `value is None`
   means unanswered (the contract drops the redundant `answered` flag); teams
   are NOT carried — they derive from the trigger values via the rule engine
   (Jeremy's progressive activation). This is the shape we integrate against;
   `envelope_from_session` emits it for round-tripping through his `fill_form`.
2. **Placeholder envelope** (the earlier spec-§5 shape, retained so nothing
   that already speaks it breaks): ``{messages, trigger:{fields}, activated_teams,
   governance:{questions}}``.

We match the FormFillerEnvelope *shape by contract* (plain dicts), NOT by
importing `form_filler_agent`'s Pydantic models — that module lives on #13 and
is not yet merged to np01_rnp, so a build-time import would couple this branch
to an unmerged one. When #13 lands, `envelope_from_session`'s output can be
validated straight through `FormFillerEnvelope(**...)`.

Known translations owned here:
  - envelope question objects use `text`/`value`; session canonicals use
    `canonical_question`/`answer` + a redundant `answered` flag.
  - answer provenance: session `answer_origin` "user"/"prefill" maps to
    envelope `origin` "user"/"agent" (an accepted grounded prefill is an
    agent-supplied value; per the contract it must carry a 0-5 confidence).
  - placeholder `activated_teams` may arrive as [{"team", "review_phase"}] or
    bare strings; message roles may be "agent" or "assistant".

Pure module: no LLM, no I/O.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .gap_detector import detect_gaps
from .schema_check import all_routing_fields_present

# Confidence assigned to an accepted grounded prefill when emitted as an
# agent-origin value in the FormFillerEnvelope. The prefill's grounding gate
# already verified the answer's quote appears verbatim in a source, so an
# accepted prefill is high-confidence; the contract requires a 0-5 integer.
_ACCEPTED_PREFILL_CONFIDENCE = 4


@dataclass
class SessionInputs:
    """The inputs this lane's contract assumes exist."""

    activated_teams: list[dict[str, Any]]  # [{"team": str, "review_phase": int}]
    messages: list[dict[str, str]]  # [{"role": "user"|"agent", "content": str}]
    trigger_fields: dict[str, Any]
    unknown_teams: list[str] = field(default_factory=list)  # surfaced, not dropped
    # canonical_id -> {"value": Any, "origin": "user"|"agent"}. Governance
    # answers already present in a FormFillerEnvelope (e.g. filled by a prior
    # fill_form pass or a previous turn). Empty for the placeholder envelope.
    governance_answers: dict[str, dict[str, Any]] = field(default_factory=dict)


def _normalize_team_entry(entry: Any) -> dict[str, Any] | None:
    if isinstance(entry, str):
        name = entry.strip()
        return {"team": name, "review_phase": 1} if name else None
    if isinstance(entry, dict):
        name = str(entry.get("team") or entry.get("name") or "").strip()
        if not name:
            return None
        phase = entry.get("review_phase", 1)
        return {"team": name, "review_phase": phase if isinstance(phase, int) else 1}
    return None


def _normalize_message(entry: Any) -> dict[str, str] | None:
    if not isinstance(entry, dict):
        return None
    content = entry.get("content")
    if not isinstance(content, str) or not content.strip():
        return None
    role = str(entry.get("role") or "").strip().lower()
    if role == "user":
        return {"role": "user", "content": content}
    if role in ("agent", "assistant"):
        return {"role": "agent", "content": content}
    return None


def session_inputs_from_state(
    state: dict[str, Any],
    known_teams: set[str] | None = None,
) -> SessionInputs:
    """
    Parse a STATE envelope (or a best-effort variant of one) into the three
    inputs. Tolerant of missing sections: each degrades to empty rather than
    raising, because upstream ownership of the envelope is still in flux.

    When `known_teams` is given (the questionnaire/rule roster), team names
    not in it are collected into `unknown_teams` — surfaced to the caller
    instead of silently dropped, per the exact-string-join hazard.
    """
    if not isinstance(state, dict):
        raise ValueError("STATE must be a JSON object")

    # FormFillerEnvelope (the real contract) is detected structurally: it
    # carries `triggers`/`governance` as *lists*, where the placeholder uses a
    # singular `trigger` dict and a `governance` dict. Route it to the
    # dedicated parser; teams derive from trigger values downstream.
    if isinstance(state.get("triggers"), list) or isinstance(state.get("governance"), list):
        return _inputs_from_form_filler_envelope(state)

    raw_teams = state.get("activated_teams") or []
    teams: list[dict[str, Any]] = []
    for entry in raw_teams if isinstance(raw_teams, list) else []:
        norm = _normalize_team_entry(entry)
        if norm is not None:
            teams.append(norm)

    unknown: list[str] = []
    if known_teams is not None:
        unknown = sorted({t["team"] for t in teams} - known_teams)

    raw_messages = state.get("messages") or []
    messages: list[dict[str, str]] = []
    for entry in raw_messages if isinstance(raw_messages, list) else []:
        norm_msg = _normalize_message(entry)
        if norm_msg is not None:
            messages.append(norm_msg)

    trigger = state.get("trigger")
    fields: dict[str, Any] = {}
    if isinstance(trigger, dict) and isinstance(trigger.get("fields"), dict):
        fields = dict(trigger["fields"])
    elif isinstance(state.get("collected_fields"), dict):
        # Variant: flat session-style naming.
        fields = dict(state["collected_fields"])
    # Envelope convention: null means "not answered yet" — drop nulls so
    # downstream presence checks (schema_check) behave.
    fields = {k: v for k, v in fields.items() if v is not None}

    return SessionInputs(
        activated_teams=teams,
        messages=messages,
        trigger_fields=fields,
        unknown_teams=unknown,
    )


def _inputs_from_form_filler_envelope(state: dict[str, Any]) -> SessionInputs:
    """
    Parse a FormFillerEnvelope (the real #13 contract) into SessionInputs.

    Triggers become the trigger_fields the rule engine routes on; answered
    governance items become `governance_answers` (applied to the rebuilt
    pending set in `postdedup.begin_session`). Activated teams are NOT read
    from the envelope — the contract doesn't carry them; they derive
    deterministically from the trigger values downstream (matching Jeremy's
    progressive activation). An optional top-level `messages` list is still
    honored so the grounded prefill has the transcript to quote from.
    """
    trigger_fields: dict[str, Any] = {}
    for item in state.get("triggers") or []:
        if not isinstance(item, dict):
            continue
        item_id = str(item.get("id") or "").strip()
        value = item.get("value")
        if item_id and value is not None:
            trigger_fields[item_id] = value

    governance_answers: dict[str, dict[str, Any]] = {}
    for item in state.get("governance") or []:
        if not isinstance(item, dict):
            continue
        item_id = str(item.get("id") or "").strip()
        value = item.get("value")
        if not item_id or value is None:
            continue
        origin = "agent" if item.get("origin") == "agent" else "user"
        governance_answers[item_id] = {"value": value, "origin": origin}

    messages: list[dict[str, str]] = []
    for entry in state.get("messages") or []:
        norm_msg = _normalize_message(entry)
        if norm_msg is not None:
            messages.append(norm_msg)

    return SessionInputs(
        activated_teams=[],
        messages=messages,
        trigger_fields=trigger_fields,
        unknown_teams=[],
        governance_answers=governance_answers,
    )


def _question_to_envelope(q: dict[str, Any]) -> dict[str, Any]:
    """Session canonical -> spec-§5 question object (spec names win)."""
    out: dict[str, Any] = {
        "canonical_id": q["canonical_id"],
        "text": q.get("canonical_question", ""),
        "category": q.get("category", "general"),
        "sources": [{"team": s["team"], "question_id": s["question_id"]} for s in q.get("sources", [])],
        "source_teams": q.get("source_teams", []),
        "answered": bool(q.get("answered")),
        "answer": q.get("answer"),
    }
    if q.get("answer_origin"):
        out["answer_origin"] = q["answer_origin"]
    if q.get("prefill"):
        out["prefill"] = q["prefill"]
    return out


def state_from_session(sess: dict[str, Any], data: Any) -> dict[str, Any]:
    """
    Build the spec-§5 STATE envelope from a session dict.

    `data` is an IntakeData-shaped object (needs .intake_schema and
    .questionnaires). Both `complete` flags are computed here,
    deterministically — never taken from stored state.
    """
    pending = sess.get("pending_questions", [])
    team_names = [t["team"] for t in sess.get("activated_teams", [])]

    trigger_complete = all_routing_fields_present(data.intake_schema, sess.get("collected_fields", {}))
    # Vacuously true when pending is empty: a session activating only
    # contentless (delegated) teams has nothing to answer and must not
    # deadlock. Required-question gaps still block via detect_gaps.
    all_answered = all(q.get("answered") for q in pending)
    gaps = detect_gaps(team_names, data.questionnaires, sess.get("team_forms", {}))
    governance_complete = all_answered and not gaps

    return {
        "messages": list(sess.get("ui_messages", [])),
        "trigger": {
            "fields": dict(sess.get("collected_fields", {})),
            "complete": trigger_complete,
        },
        "activated_teams": list(sess.get("activated_teams", [])),
        "governance": {
            "questions": [_question_to_envelope(q) for q in pending],
            "complete": governance_complete,
        },
    }


# ---------------------------------------------------------------------------
# FormFillerEnvelope (the real #13 contract) — outbound
# ---------------------------------------------------------------------------


def _trigger_items_from_session(sess: dict[str, Any], data: Any) -> list[dict[str, Any]]:
    """
    One FormItem per RoutingFields field, in intake_schema order. A collected
    value is emitted as a user-origin answer; an absent one stays blank
    (value/origin/confidence all None), matching the contract's provenance
    coherence rule.
    """
    fields = sess.get("collected_fields", {})
    items: list[dict[str, Any]] = []
    for field_def in data.intake_schema.get("fields", []):
        name = field_def.get("name")
        if not name:
            continue
        present = name in fields and fields[name] is not None
        items.append(
            {
                "id": name,
                "text": field_def.get("description", name),
                "value": fields[name] if present else None,
                "origin": "user" if present else None,
                "confidence": None,
            }
        )
    return items


def _governance_item_from_question(q: dict[str, Any]) -> dict[str, Any]:
    """Session canonical -> FormFillerEnvelope GovernanceQuestion."""
    answered = bool(q.get("answered"))
    value = q.get("answer") if answered else None

    origin: str | None = None
    confidence: int | None = None
    if value is not None:
        if q.get("answer_origin") == "prefill":
            origin, confidence = "agent", _ACCEPTED_PREFILL_CONFIDENCE
        else:
            origin = "user"

    return {
        "id": q["canonical_id"],
        "text": q.get("canonical_question", ""),
        "value": value,
        "origin": origin,
        "confidence": confidence,
        "sources": [{"team": s["team"], "question_id": s["question_id"]} for s in q.get("sources", [])],
    }


def envelope_from_session(sess: dict[str, Any], data: Any) -> dict[str, Any]:
    """
    Build a FormFillerEnvelope (docs/form_filler_agent_contract.md) from a
    session — the outbound integration contract, e.g. to POST to Jeremy's
    `/api/formfiller/fill` and merge the returned agent-filled values back.

    Plain dict by design (see module docstring): shape-conformant with
    `form_filler_agent.FormFillerEnvelope` without importing an unmerged
    module. When #13 lands, `FormFillerEnvelope(**envelope_from_session(...))`
    validates it directly.
    """
    return {
        "triggers": _trigger_items_from_session(sess, data),
        "governance": [_governance_item_from_question(q) for q in sess.get("pending_questions", [])],
    }
