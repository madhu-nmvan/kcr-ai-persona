# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Question ordering intelligence (Phase B).

Deterministic ordering of the consolidated question list so that earlier
answers can imply later ones:

  1. Cross-team canonicals first, widest fan-out first — one answer fills
     the most team-form fields and gives the fill-in prefill pass (which
     grounds on prior answers) the most material to work with.
  2. Within the same fan-out, keep category groups together so the
     presentation stays coherent.
  3. Stable on the original corpus order as the final tiebreak, so two runs
     over the same session always agree.

Pure function; no LLM. The "auto-fill implied answers" half of the loop is
prefill.run_prefill with prior_answer provenance, re-run after answer
batches — see postdedup_api.
"""

from __future__ import annotations

from typing import Any


def order_pending_questions(
    pending: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Return a new, deterministically ordered list (input not mutated)."""
    indexed = list(enumerate(pending))

    def fanout(q: dict[str, Any]) -> int:
        return len(q.get("sources", []))

    # First-appearance rank per category keeps groups contiguous without
    # imposing an arbitrary alphabetical order on the corpus.
    category_rank: dict[str, int] = {}
    for _, q in indexed:
        category_rank.setdefault(q.get("category", "general"), len(category_rank))

    def key(item: tuple[int, dict[str, Any]]) -> tuple[int, int, int]:
        idx, q = item
        return (
            -fanout(q),
            category_rank[q.get("category", "general")],
            idx,
        )

    return [q for _, q in sorted(indexed, key=key)]
