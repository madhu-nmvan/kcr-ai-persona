# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
FastAPI server exposing the intake agent.

By default this runs with ZERO AWS dependencies:
  - Sessions are held in memory (INTAKE_SESSION_BACKEND=memory)
  - Attachments are saved to local disk (INTAKE_ATTACHMENTS_BACKEND=local)
Both can be switched to DynamoDB / S3 once those resources and their IAM
grants are provisioned (see infra/terraform/ and .env.example).

Endpoints:
    GET  /api/health                          -> service metadata
    POST /api/intake-agent/start               -> create a new session, get greeting
    POST /api/intake-agent/message             -> {session_id, message} -> next turn
    POST /api/intake-agent/message/stream      -> same, as SSE
    POST /api/intake-agent/attachments/upload  -> multipart file upload
    GET  /api/intake-agent/sessions            -> recent sessions (history)
    GET  /api/intake-agent/sessions/{id}       -> resume a session
    POST /api/formfiller/fill                  -> FormFillerAgent sanity endpoint
                                                   (stub model, see form_filler_agent.py)
    GET  /api/intake-agent/session/{id}        -> full internal dump (debug)
    GET  /api/intake-agent/schema              -> intake_schema.json (for the JSON-driven form)
    GET  /api/intake-agent/teams               -> team_roster.json (labels for steps/overview)
    PATCH /api/intake-agent/sessions/{id}/fields/{field_name}    -> direct Phase-1 field write
    PATCH /api/intake-agent/sessions/{id}/answers/{canonical_id} -> direct Phase-2 answer write
    /api/post-dedup/*                          -> form-first post-dedup
                                                  experience (postdedup_api.py)

Run (from the repo root, after `make install`):
    uv run uvicorn governance_intake.server:app --port 8000
"""

from __future__ import annotations

import logging
import os
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

log = logging.getLogger("intake.server")


def _env_enabled(name: str) -> bool:
    """True when an env flag is set to a truthy value (1/true/yes/on)."""
    return os.environ.get(name, "").strip().lower() in {"1", "true", "yes", "on"}


def _load_dotenv(path: Path) -> None:
    """
    Load KEY=VALUE lines from a .env file into os.environ WITHOUT relying on
    the shell to source it. Shell sourcing (`. .env`) breaks when a secret
    contains characters the shell interprets, and silently leaves the vars
    unset. Reading the file here sidesteps all of that.

    Rules:
      - blank lines and lines starting with '#' are ignored
      - an optional leading 'export ' is stripped
      - surrounding single or double quotes around the value are stripped
      - values are taken literally (no shell interpolation)
      - existing os.environ values win (so real exported env can override)
    """
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if key and key not in os.environ:
            os.environ[key] = value


# Load .env BEFORE reading any INTAKE_*/EHAP_* config below. Location is the
# current working directory (the repo root when run via `make run`), or an
# explicit path via INTAKE_DOTENV.
_load_dotenv(Path(os.environ.get("INTAKE_DOTENV", ".env")))

os.environ.setdefault("INTAKE_SESSION_BACKEND", "memory")
os.environ.setdefault("INTAKE_ATTACHMENTS_BACKEND", "local")

import json

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .attachments import AttachmentError, read_upload_bounded, save_attachment
from .form_filler_agent import FormFillerEnvelope, StubFormFillerModel, fill_form
from .handler import IntakeHandler
from .postdedup_api import build_router
from .session import (
    DynamoDBSessionStore,
    InMemorySessionStore,
    SessionStore,
    add_ui_message,
)


app = FastAPI(title="Elevance Health - Governance Intake Agent API", version="0.1.0")


def _cors_origins() -> list[str]:
    """
    Explicit CORS allowlist, driven by INTAKE_CORS_ORIGINS (comma-separated).

    Secure by default: with the variable unset we fall back to local dev
    origins only (the Vite dev server and a same-host backend), NOT a
    wildcard. A wildcard origin combined with credentials is rejected by
    browsers anyway and — more importantly — trusts every site on the
    internet, so we never emit one. In a deployed environment set
    INTAKE_CORS_ORIGINS to the exact UI origin(s), e.g.:

        INTAKE_CORS_ORIGINS=https://govhub.example.com

    The frontend calls the API with relative paths and does NOT send cookies
    or Authorization via the browser's credential mechanism, so credentialed
    CORS is not required; leaving it off keeps the allowlist strict.
    """
    raw = os.environ.get("INTAKE_CORS_ORIGINS", "").strip()
    if raw:
        return [o.strip() for o in raw.split(",") if o.strip()]
    # Local-dev fallback only. Override in every deployed environment.
    return [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
    ]


app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins(),
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["Content-Type"],
)


def _build_store() -> SessionStore:
    """
    Session backend selection.
      INTAKE_SESSION_BACKEND=memory   (default) - process-local, cleared on restart.
      INTAKE_SESSION_BACKEND=dynamodb           - persists sessions to DynamoDB.
    """
    backend = os.environ.get("INTAKE_SESSION_BACKEND", "memory").lower()
    if backend == "memory":
        return InMemorySessionStore()
    if backend == "dynamodb":
        table = os.environ.get("INTAKE_DDB_TABLE", "govhub-intake-sessions")
        region = os.environ.get("INTAKE_DDB_REGION") or os.environ.get("AWS_REGION")
        # In customer environments the table is provisioned by Terraform (TFE);
        # do NOT create it from code. Set INTAKE_DDB_AUTO_CREATE=1 for local dev.
        auto_create = os.environ.get("INTAKE_DDB_AUTO_CREATE", "0").lower() in {
            "1", "true", "yes",
        }
        return DynamoDBSessionStore(
            table_name=table,
            region_name=region,
            auto_create=auto_create,
        )
    raise ValueError(
        f"Unknown INTAKE_SESSION_BACKEND={backend!r}. Use 'dynamodb' or 'memory'."
    )


_store = _build_store()
_handler = IntakeHandler(
    store=_store,
    demo_mode=True,
    demo_focus_team=os.environ.get("INTAKE_FOCUS_TEAM") or None,
)
_form_filler_model = StubFormFillerModel()

# Form-first post-dedup experience (see postdedup_api.py). Shares the
# session store, so sessions reaching asking_questions via chat are also
# addressable here.
app.include_router(build_router(_store, _handler.data, demo_mode=_handler.demo_mode))


GREETING = (
    "Hi - I'm the Governance Intake Agent for Elevance Health. "
    "Tell me about the project you'd like to submit for governance review: "
    "what you're building, who it's for, and any AI, vendor, data, or cloud "
    "specifics you already know. I'll ask follow-up questions as we go."
)


# --- Schemas ---------------------------------------------------------------


class StartRequest(BaseModel):
    user_id: Optional[str] = "demo@elevancehealth.com"


class MessageRequest(BaseModel):
    session_id: str
    message: str
    # {"name"/"canonical_id", "label", "description"} of whatever workflow-
    # form field the user currently has focused, so chat can give a
    # contextually relevant reply. Optional — omit for general conversation.
    focused_field: Optional[Dict[str, Any]] = None


class FieldValueRequest(BaseModel):
    value: Any = None


class AnswerValueRequest(BaseModel):
    answer: Any = None


# --- Routes ----------------------------------------------------------------


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "ehap_model": os.environ.get("EHAP_MODEL_ID", "anthropic:claude-sonnet-4-6"),
        "session_backend": os.environ.get("INTAKE_SESSION_BACKEND", "memory"),
        "attachments_backend": os.environ.get("INTAKE_ATTACHMENTS_BACKEND", "local"),
        "demo_mode": _handler.demo_mode,
        "demo_focus_team": _handler.demo_focus_team,
    }


@app.post("/api/intake-agent/start")
def start(body: StartRequest):
    session_id = f"sess-{uuid.uuid4().hex[:8]}"
    sess = _handler.start_session(session_id, body.user_id or "demo@elevancehealth.com")
    # Seed the greeting into the persisted transcript so the resume flow
    # renders the same first message as a fresh start.
    add_ui_message(sess, "agent", GREETING)
    _store.put(sess)
    return {
        "session_id": session_id,
        "ui_messages": sess["ui_messages"],
        **_handler.get_public_state(session_id),
    }


@app.get("/api/intake-agent/sessions")
def list_sessions(limit: int = 50):
    """Recent sessions (newest first). Lightweight, for the history dropdown."""
    try:
        items = _store.list_sessions(limit=limit)
    except NotImplementedError:
        items = []
    return {"sessions": items}


@app.get("/api/intake-agent/sessions/{session_id}")
def get_session_public(session_id: str):
    """
    Load a full session for resume. Returns the same shape the UI needs to
    render existing messages + sidebar state.
    """
    sess = _store.get(session_id)
    if not sess:
        raise HTTPException(status_code=404, detail="Unknown session")
    return {
        "session_id": sess["session_id"],
        "ui_messages": sess.get("ui_messages", []),
        **_handler.get_public_state(session_id),
    }


@app.post("/api/intake-agent/message")
def message(body: MessageRequest):
    try:
        out = _handler.handle_message(
            body.session_id, body.message, focused_field=body.focused_field
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception:
        # Log the full traceback server-side; return a generic message so
        # exception internals (types, stack details) never reach the client.
        log.exception("Unhandled error handling message for session %s", body.session_id)
        raise HTTPException(status_code=500, detail="Internal server error")
    return out


@app.post("/api/intake-agent/message/stream")
async def message_stream(body: MessageRequest):
    """
    Server-Sent Events stream of the next turn.

    Each event is a single SSE `data:` line carrying JSON:
      {"type": "delta", "text": "..."}
      {"type": "state", "phase": ..., "collected_fields": {...}, ...}
      {"type": "error", "message": "..."}
    The stream terminates after the state event (or on error).
    """

    async def event_gen():
        async for event in _handler.handle_message_stream(
            body.session_id, body.message, focused_field=body.focused_field
        ):
            yield f"data: {json.dumps(event, default=str)}\n\n"

    return StreamingResponse(
        event_gen(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # disable nginx buffering if fronted by one
            "Connection": "keep-alive",
        },
    )


@app.post("/api/intake-agent/attachments/upload")
async def attachments_upload(session_id: str, file: UploadFile = File(...)):
    """
    Single-step upload: the browser POSTs the file directly to our server as
    multipart/form-data. We validate it, save the bytes (local disk by
    default, or S3 if INTAKE_ATTACHMENTS_BACKEND=s3), and record it on the
    session.
    """
    try:
        # Bounded read: reject oversized uploads before the whole body is
        # buffered into memory (see attachments.read_upload_bounded).
        data = await read_upload_bounded(file)
        attachment = save_attachment(
            session_id=session_id,
            filename=file.filename or "attachment",
            data=data,
            content_type=file.content_type,
        )
    except AttachmentError as e:
        raise HTTPException(status_code=400, detail=str(e))

    try:
        sess = _handler.record_attachment(session_id, attachment)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return {"attachment": attachment, "attachments": sess.get("attachments", [])}


@app.get("/api/intake-agent/session/{session_id}")
def get_session_debug(session_id: str):
    """
    Full internal session dump - for local debugging only.

    Disabled unless INTAKE_ENABLE_DEBUG_DUMP is explicitly truthy, so the raw
    session (including intake content) is never exposed by default in any
    deployed environment. The public resume endpoint
    (/api/intake-agent/sessions/{id}) returns the sanitized shape the UI needs.
    """
    if not _env_enabled("INTAKE_ENABLE_DEBUG_DUMP"):
        raise HTTPException(status_code=404, detail="Not found")
    sess = _store.get(session_id)
    if not sess:
        raise HTTPException(status_code=404, detail="Unknown session")
    return sess


@app.post("/api/formfiller/fill")
def formfiller_fill(body: FormFillerEnvelope):
    """
    FormFillerAgent sanity endpoint (docs/form_filler_agent_contract.md).

    Stub model only -- no live EHAP call. Fills the first blank item found
    (triggers, then governance) and returns the same envelope shape. Any
    item that came in with a non-None value is guaranteed byte-identical in
    the response; see form_filler_agent.fill_form.
    """
    return fill_form(body, _form_filler_model)


@app.get("/api/intake-agent/schema")
def get_schema():
    """intake_schema.json as-is (fields carry a "group" for UI sectioning) -
    lets the frontend render Phase 1 as a JSON-driven form instead of
    hardcoding field lists."""
    return _handler.data.intake_schema


@app.get("/api/intake-agent/teams")
def get_teams():
    """team_roster.json - display names/labels for the step list and
    Submission Overview panel."""
    return _handler.data.team_roster


def _raise_for_value_error(e: ValueError) -> None:
    status = 404 if str(e).startswith("Unknown session") else 400
    raise HTTPException(status_code=status, detail=str(e))


@app.patch("/api/intake-agent/sessions/{session_id}/fields/{field_name}")
def set_routing_field(session_id: str, field_name: str, body: FieldValueRequest):
    """
    Direct (non-chat) write to a Phase-1 routing field - the manual-fill
    counterpart to what chat-driven extraction already does automatically.
    Triggers the same phase transition chat completion does if this was the
    last required field.
    """
    try:
        return _handler.set_routing_field(session_id, field_name, body.value)
    except ValueError as e:
        _raise_for_value_error(e)


@app.patch("/api/intake-agent/sessions/{session_id}/answers/{canonical_id}")
def set_answer(session_id: str, canonical_id: str, body: AnswerValueRequest):
    """
    Direct (non-chat) write to a Phase-2 question's answer - the manual-fill
    counterpart to what chat-driven extraction already does automatically.
    """
    try:
        return _handler.set_answer(session_id, canonical_id, body.answer)
    except ValueError as e:
        _raise_for_value_error(e)

# ---------------------------------------------------------------------------
# Static UI (optional).
#
# The frontend lives in a separate tree for now. If you build it and point
# INTAKE_UI_DIST at the build output (e.g. ../frontend/dist), the server will
# serve it at / so one process serves both API and UI. If unset, only /api/*
# is exposed and the UI is run/served separately.
# ---------------------------------------------------------------------------


_ui_dist_env = os.environ.get("INTAKE_UI_DIST")
if _ui_dist_env:
    _ui_dist = Path(_ui_dist_env)
    if _ui_dist.exists():
        app.mount("/", StaticFiles(directory=str(_ui_dist), html=True), name="ui")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "governance_intake.server:app",
        host="0.0.0.0",
        port=int(os.environ.get("INTAKE_SERVER_PORT", "8000")),
        reload=False,
        log_level="info",
    )
