# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
EHAP model provider for Strands.

Implements strands.models.Model against the Elevance Horizon LLM gateway
(OAuth2 REST). Plug into strands.Agent like any other provider:

    from strands import Agent
    from governance_intake.ehap_model import get_ehap_model

    agent = Agent(model=get_ehap_model(), system_prompt="...")
    result = agent("hello")
    fields = agent.structured_output(RoutingFields, prompt="...")

Two classes live here:
  EHAPClient - low-level HTTP client (token + /v2/text/chats).
  EHAPModel  - strands.models.Model subclass wrapping EHAPClient, so Strands
               can drive it with its usual stream / structured_output APIs.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from typing import Any, AsyncGenerator, Dict, List, Optional, Type, TypeVar

import httpx
import requests
import urllib3
from pydantic import BaseModel
from strands.models import Model


log = logging.getLogger("intake.ehap")


def _resolve_tls_verify() -> Any:
    """
    Resolve the TLS-verification setting used for every gateway request.

    Secure by default. EHAP uses corporate-signed certs on an internal
    hostname, so verification against the system trust store may fail until the
    corporate CA is available. Resolution order:

      1. EHAP_CA_BUNDLE set  -> verify against that CA bundle (a path,
         passed straight to requests/httpx `verify=`). This is the correct
         production fix for the internal cert.
      2. EHAP_TLS_VERIFY in {0,false,no,off} -> disable verification.
         Explicit escape hatch only; logs a warning. Do NOT use in production
         (leaks the OAuth2 client_secret and all traffic to MITM).
      3. otherwise -> True (verify against the system trust store).
    """
    ca_bundle = os.environ.get("EHAP_CA_BUNDLE")
    if ca_bundle:
        return ca_bundle
    flag = os.environ.get("EHAP_TLS_VERIFY", "true").strip().lower()
    if flag in {"0", "false", "no", "off"}:
        return False
    return True


# Environments in which disabling TLS verification is forbidden. The active
# environment is read from APP_ENV / DEPLOY_ENV / INTAKE_ENV (first one set).
_PROTECTED_ENVS = {"prod", "production", "staging", "stage", "preprod", "pre-prod"}


def _active_env() -> str:
    for var in ("APP_ENV", "DEPLOY_ENV", "INTAKE_ENV", "ENVIRONMENT"):
        val = os.environ.get(var)
        if val:
            return val.strip().lower()
    return ""


def _assert_tls_allowed(verify: Any) -> None:
    """
    Anti-downgrade guardrail: fail fast at startup if TLS verification is
    disabled in a protected environment (prod/staging/preprod).

    The escape hatch (EHAP_TLS_VERIFY=false) is fine for local/demo
    work, but silently shipping it to a real environment would expose the
    OAuth2 client_secret and all gateway traffic to MITM. Raising here turns
    that misconfiguration into a loud startup failure rather than a silent
    security regression. Runtime governance (which env values map to which
    workspace) remains a customer responsibility — see the security handover.
    """
    if verify is False and _active_env() in _PROTECTED_ENVS:
        raise RuntimeError(
            "TLS certificate verification is disabled (EHAP_TLS_VERIFY) "
            f"but the environment is {_active_env()!r}, where insecure TLS is "
            "forbidden. Set EHAP_CA_BUNDLE to the corporate CA bundle "
            "to verify securely, or unset EHAP_TLS_VERIFY."
        )


# Computed once at import; every request below passes verify=_TLS_VERIFY.
_TLS_VERIFY = _resolve_tls_verify()
_assert_tls_allowed(_TLS_VERIFY)

if _TLS_VERIFY is False:
    # Only when verification was explicitly disabled via EHAP_TLS_VERIFY.
    # Silence the noisy per-request InsecureRequestWarning; this one-time log
    # line is the durable signal that TLS verification is off.
    log.warning(
        "TLS certificate verification is DISABLED for EHAP requests "
        "(EHAP_TLS_VERIFY). Set EHAP_CA_BUNDLE to a CA bundle "
        "path to verify securely."
    )
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


DEFAULT_EHAP_MODEL_ID = os.environ.get(
    "EHAP_MODEL_ID", "anthropic:claude-sonnet-4-6"
)

T = TypeVar("T", bound=BaseModel)



# ---------------------------------------------------------------------------
# EHAPClient - low-level HTTP client
# ---------------------------------------------------------------------------


class EHAPClient:
    """
    Low-level HTTP client for the Elevance Horizon LLM gateway.

    Endpoints used:
      POST /v2/oauth2/token             (client_credentials -> bearer)
      POST /v2/text/chats?qos=accurate&preview=true
    """

    def __init__(
        self,
        endpoint: str,
        client_id: str,
        client_secret: str,
        model_id: Optional[str] = None,
        qos: str = "accurate",
        preview: bool = True,
        request_timeout: int = 120,
    ) -> None:
        self.endpoint = endpoint.rstrip("/")
        self.client_id = client_id
        self.client_secret = client_secret
        self.model_id = model_id or DEFAULT_EHAP_MODEL_ID
        self.qos = qos
        self.preview = preview
        self.request_timeout = request_timeout
        self._token: Optional[str] = None
        self._token_expires_at: float = 0.0

    def get_token(self) -> str:
        if self._token and time.time() < self._token_expires_at:
            return self._token
        resp = requests.post(
            f"{self.endpoint}/v2/oauth2/token",
            json={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "grant_type": "client_credentials",
            },
            verify=_TLS_VERIFY,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
        self._token = data["access_token"]
        # Assume ~1h if the server didn't tell us; refresh 60s early.
        self._token_expires_at = time.time() + int(data.get("expires_in", 3600)) - 60
        return self._token

    def _build_body(
        self,
        messages: List[Dict[str, Any]],
        system: Optional[str],
        stream: bool,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"messages": messages, "stream": stream}
        if self.model_id:
            body["model"] = self.model_id
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if system:
            # EHAP-shape system prompt: prepend as a system-role message.
            body["messages"] = [{"role": "system", "content": system}, *messages]
        return body

    def _build_params(self) -> Dict[str, str]:
        params = {"qos": self.qos}
        if self.preview:
            params["preview"] = "true"
        return params

    def chat(
        self,
        messages: List[Dict[str, Any]],
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Non-streaming chat. Returns the assistant's text response."""
        token = self.get_token()
        body = self._build_body(messages, system, stream=False,
                                temperature=temperature, max_tokens=max_tokens)
        resp = requests.post(
            f"{self.endpoint}/v2/text/chats",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            params=self._build_params(),
            json=body,
            verify=_TLS_VERIFY,
            timeout=self.request_timeout,
        )
        resp.raise_for_status()
        return _extract_text(resp.json())

    async def chat_stream_async(
        self,
        messages: List[Dict[str, Any]],
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ):
        """
        Streaming chat via Server-Sent Events. Yields text deltas as they
        arrive from EHAP. Uses httpx for native async streaming.

        The exact SSE event shape isn't documented in the sample the customer
        shared, so _extract_stream_delta handles the common ones:
          Anthropic-style:  {"type": "content_block_delta", "delta": {"text": ...}}
          OpenAI-style:     {"choices": [{"delta": {"content": ...}}]}
          Plain:            {"delta": {"text": ...}} / {"text": ...}
        """
        token = self.get_token()
        body = self._build_body(messages, system, stream=True,
                                temperature=temperature, max_tokens=max_tokens)

        debug = os.environ.get("EHAP_DEBUG_STREAM", "").lower() in {"1", "true", "yes"}
        t0 = time.time()
        chunk_count = 0

        # Proper SSE event framing per spec: a single event can be split
        # across MULTIPLE CONSECUTIVE "data:" lines, which must be joined
        # with "\n" before parsing. A blank line marks the end of the event.
        # Parsing each "data:" line independently (the previous approach)
        # broke on any event EHAP split across multiple lines — a partial
        # JSON fragment would fail to parse, fall into the "raw text"
        # fallback, and get injected into the visible reply as garbage
        # (symptom: chunks of words/JSON missing or mangled mid-sentence).
        data_lines: List[str] = []

        def _flush_event() -> Optional[str]:
            """Join buffered data lines into one payload; clears the buffer."""
            nonlocal data_lines
            if not data_lines:
                return None
            payload = "\n".join(data_lines)
            data_lines = []
            return payload

        timeout = httpx.Timeout(connect=15.0, read=None, write=15.0, pool=15.0)
        async with httpx.AsyncClient(verify=_TLS_VERIFY, timeout=timeout) as client:
            async with client.stream(
                "POST",
                f"{self.endpoint}/v2/text/chats",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                    "Accept": "text/event-stream",
                },
                params=self._build_params(),
                json=body,
            ) as resp:
                resp.raise_for_status()
                if debug:
                    print(f"[EHAP SSE] connected, headers={dict(resp.headers)}")
                async for line in resp.aiter_lines():
                    if debug:
                        chunk_count += 1
                        print(f"[EHAP SSE +{time.time()-t0:.3f}s #{chunk_count}] {line!r}")

                    if line.startswith(":"):
                        continue  # comment/keepalive, never part of an event

                    if not line:
                        # Blank line = end of event. Process whatever we've
                        # buffered, then move on.
                        payload = _flush_event()
                        if payload is None:
                            continue
                    elif line.startswith("data:"):
                        # SSE spec: strip AT MOST one leading space after the
                        # colon. Do NOT use .lstrip() — for raw-text streams a
                        # token's leading space can be a real word boundary.
                        chunk = line[5:]
                        if chunk.startswith(" "):
                            chunk = chunk[1:]
                        data_lines.append(chunk)
                        continue
                    else:
                        continue  # event:/id:/retry: lines — ignored

                    if payload == "[DONE]":
                        if debug:
                            print(f"[EHAP SSE] done after {time.time()-t0:.3f}s, {chunk_count} lines")
                        return
                    try:
                        event = json.loads(payload)
                    except json.JSONDecodeError:
                        # Genuinely non-JSON payload (some gateways stream
                        # raw text). Yield as-is, no stripping.
                        if payload:
                            yield payload
                        continue
                    text = _extract_stream_delta(event)
                    if text:
                        yield text

                # Stream ended without a trailing blank line — flush anything
                # still buffered so we don't silently drop the last event.
                final_payload = _flush_event()
                if final_payload and final_payload != "[DONE]":
                    try:
                        event = json.loads(final_payload)
                        text = _extract_stream_delta(event)
                        if text:
                            yield text
                    except json.JSONDecodeError:
                        yield final_payload

                if debug:
                    print(f"[EHAP SSE] stream ended after {time.time()-t0:.3f}s, {chunk_count} lines")



# ---------------------------------------------------------------------------
# EHAPModel - strands.models.Model subclass
# ---------------------------------------------------------------------------


class EHAPModel(Model):
    """
    Strands Model implementation talking to EHAP.

    stream() forwards every chunk from EHAP's SSE stream to Strands as it
    arrives (true streaming, no buffering). structured_output() prompt-
    engineers JSON extraction against a Pydantic schema and uses the
    non-streaming chat endpoint since the whole payload has to be parsed
    at once anyway.
    """

    def __init__(
        self,
        endpoint: str,
        client_id: str,
        client_secret: str,
        model_id: Optional[str] = None,
        qos: str = "accurate",
        preview: bool = True,
    ) -> None:
        self._client = EHAPClient(
            endpoint=endpoint,
            client_id=client_id,
            client_secret=client_secret,
            model_id=model_id,
            qos=qos,
            preview=preview,
        )
        self._config: Dict[str, Any] = {"model_id": self._client.model_id}

    # -- Strands Model config API --------------------------------------------

    def update_config(self, **model_config: Any) -> None:
        self._config.update(model_config)
        if "model_id" in model_config:
            self._client.model_id = model_config["model_id"]

    def get_config(self) -> Dict[str, Any]:
        return dict(self._config)

    # -- Streaming chat ------------------------------------------------------

    async def stream(
        self,
        messages: List[Dict[str, Any]],
        tool_specs: Optional[List[Any]] = None,
        system_prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        # tool_specs are ignored — EHAP tool_use not wired in this build.
        ehap_messages = _flatten_messages(messages)

        # --- Reliability over token-latency -------------------------------
        # EHAP's SSE stream proved unreliable in practice: chunks were dropped
        # or reassembled wrong, so the UI showed truncated/garbled questions
        # (e.g. only the tail of a question would appear). For an intake
        # workflow, delivering the COMPLETE, correct question matters far more
        # than shaving a second off time-to-first-token.
        #
        # So: fetch the full reply via the reliable non-streaming endpoint,
        # then re-emit it in small word-sized chunks so the UI still "types"
        # it out. Because we start from the complete string, truncation is
        # impossible — whatever the LLM produced is exactly what the user sees.
        text = await asyncio.to_thread(
            self._client.chat, ehap_messages, system_prompt
        )

        yield {"messageStart": {"role": "assistant"}}
        yield {"contentBlockStart": {"start": {}}}
        for chunk in _chunk_for_typing(text):
            yield {"contentBlockDelta": {"delta": {"text": chunk}}}
            await asyncio.sleep(0.01)
        yield {"contentBlockStop": {}}
        yield {"messageStop": {"stopReason": "end_turn"}}
        yield {
            "metadata": {
                "usage": {
                    "inputTokens": 0,
                    "outputTokens": 0,
                    "totalTokens": 0,
                },
                "metrics": {"latencyMs": 0},
            }
        }

    # -- Structured output (prompt-engineered JSON) --------------------------

    async def structured_output(
        self,
        output_model: Type[T],
        prompt: List[Dict[str, Any]],
        system_prompt: Optional[str] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        EHAP doesn't expose tool-use in the sample shared, so we
        prompt-engineer JSON output against the Pydantic schema.
        """
        schema = output_model.model_json_schema()
        user_text = _flatten_prompt(prompt)
        instruction = (
            f"{user_text}\n\n"
            "Respond with ONLY a valid JSON object matching the schema below. "
            "Do not wrap in markdown fences. Do not add commentary. Do not "
            "include fields not in the schema. Use null for fields you cannot "
            "confidently fill.\n\n"
            f"JSON schema:\n{json.dumps(schema, indent=2)}"
        )
        ehap_messages = [{"role": "user", "content": instruction}]
        text = await asyncio.to_thread(
            self._client.chat, ehap_messages, system_prompt
        )
        data = _extract_json(text)
        yield {"output": output_model(**data)}



# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


_ehap_model_singleton: Optional[EHAPModel] = None


def _apply_dev_defaults() -> None:
    if os.environ.get("DEV", "").lower() not in {"1", "true", "yes"}:
        return
    os.environ.setdefault("EHAP_URL", "http://localhost:8811")
    os.environ.setdefault("EHAP_CLIENT_ID", "dev-simulator")
    os.environ.setdefault("EHAP_CLIENT_SECRET", "dev-simulator")


def get_ehap_model() -> EHAPModel:
    """Module-level singleton so the OAuth token cache is shared."""
    global _ehap_model_singleton
    if _ehap_model_singleton is not None:
        return _ehap_model_singleton

    _apply_dev_defaults()
    endpoint = os.environ.get("EHAP_URL")
    client_id = os.environ.get("EHAP_CLIENT_ID")
    client_secret = os.environ.get("EHAP_CLIENT_SECRET")
    if not (endpoint and client_id and client_secret):
        raise RuntimeError(
            "EHAP_URL / EHAP_CLIENT_ID / EHAP_CLIENT_SECRET must be set."
        )
    _ehap_model_singleton = EHAPModel(
        endpoint=endpoint,
        client_id=client_id,
        client_secret=client_secret,
    )
    return _ehap_model_singleton


# ---------------------------------------------------------------------------
# Message-format helpers
# ---------------------------------------------------------------------------


def _flatten_messages(messages: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """
    Strands' Messages shape -> EHAP's flat message list.

    Strands passes each message as {"role": ..., "content": [{"text": "..."}]}
    (list of ContentBlocks). EHAP wants {"role": ..., "content": "string"}.
    We flatten the block list to a plain string. Any non-text block (toolUse,
    toolResult, image, etc.) is dropped — this build doesn't use them.
    """
    out: List[Dict[str, str]] = []
    for m in messages:
        role = m.get("role") or "user"
        content = m.get("content")
        if isinstance(content, list):
            parts: List[str] = []
            for block in content:
                if isinstance(block, dict) and isinstance(block.get("text"), str):
                    parts.append(block["text"])
            text = "".join(parts)
        elif isinstance(content, str):
            text = content
        else:
            text = "" if content is None else str(content)
        out.append({"role": role, "content": text})
    return out


def _chunk_for_typing(text: str) -> List[str]:
    """
    Split a complete reply into small chunks for a UI typing effect.

    Splits on whitespace but KEEPS the trailing whitespace attached to each
    token, so re-joining the chunks reproduces the original text exactly
    (spaces and newlines preserved). Operating on the already-complete string
    means no content can be lost.
    """
    if not text:
        return []
    chunks = re.findall(r"\S+\s*|\s+", text)
    return chunks or [text]


def _flatten_prompt(prompt: Any) -> str:
    """Turn Strands' Messages (or a single message / string) into one prompt string."""
    if isinstance(prompt, list):
        messages = _flatten_messages(prompt)
        return "\n\n".join(m["content"] for m in messages if m.get("content"))
    if isinstance(prompt, dict):
        return _flatten_messages([prompt])[0].get("content", "")
    return str(prompt or "")


# ---------------------------------------------------------------------------
# Response parsing helpers
# ---------------------------------------------------------------------------


def _extract_text(data: Any) -> str:
    """
    Pull the assistant reply text out of an EHAP JSON response.

    The sample the customer shared doesn't fully document the shape, so we
    try the common LLM gateway shapes in order:
      Anthropic-style:  {"content": [{"type":"text","text":"..."}]}
      OpenAI-style:     {"choices":[{"message":{"content":"..."}}]}
      Flat:             {"content":"..."} or {"text":"..."}
    """
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        content = data.get("content")
        if isinstance(content, list):
            parts = [
                c.get("text", "")
                for c in content
                if isinstance(c, dict) and c.get("type") == "text"
            ]
            if parts:
                return "".join(parts)
        choices = data.get("choices")
        if isinstance(choices, list) and choices:
            msg = choices[0].get("message") if isinstance(choices[0], dict) else None
            if isinstance(msg, dict) and isinstance(msg.get("content"), str):
                return msg["content"]
        if isinstance(content, str):
            return content
        if isinstance(data.get("text"), str):
            return data["text"]
        msg = data.get("message")
        if isinstance(msg, dict) and isinstance(msg.get("content"), str):
            return msg["content"]
        if isinstance(msg, str):
            return msg
    raise ValueError(
        f"Could not find assistant text in EHAP response: {json.dumps(data)[:400]}"
    )


def _extract_stream_delta(event: Any) -> str:
    """
    Pull a text delta out of one streamed SSE event.

    Handles the common shapes:
      Anthropic: {"type": "content_block_delta", "delta": {"type": "text_delta", "text": "..."}}
      OpenAI:    {"choices": [{"delta": {"content": "..."}}]}
      Plain:     {"delta": {"text": "..."}}, {"text": "..."}, {"content": "..."}
    """
    if not isinstance(event, dict):
        return ""

    # Anthropic-style content_block_delta
    if event.get("type") == "content_block_delta":
        delta = event.get("delta") or {}
        if isinstance(delta, dict) and isinstance(delta.get("text"), str):
            return delta["text"]

    # OpenAI-style choices[0].delta.content
    choices = event.get("choices")
    if isinstance(choices, list) and choices and isinstance(choices[0], dict):
        delta = choices[0].get("delta") or {}
        if isinstance(delta, dict) and isinstance(delta.get("content"), str):
            return delta["content"]

    # Generic delta.text / delta.content
    delta = event.get("delta")
    if isinstance(delta, dict):
        if isinstance(delta.get("text"), str):
            return delta["text"]
        if isinstance(delta.get("content"), str):
            return delta["content"]

    # Flat text/content
    if isinstance(event.get("text"), str):
        return event["text"]
    if isinstance(event.get("content"), str):
        return event["content"]

    return ""


_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*([\s\S]*?)```", re.IGNORECASE)
_JSON_OBJECT_RE = re.compile(r"\{[\s\S]*\}")


def _extract_json(text: str) -> Dict[str, Any]:
    """Best-effort JSON parse from possibly-fenced LLM output."""
    text = (text or "").strip()

    fenced = _JSON_FENCE_RE.search(text)
    if fenced:
        candidate = fenced.group(1).strip()
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            pass

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    obj = _JSON_OBJECT_RE.search(text)
    if obj:
        return json.loads(obj.group(0))

    raise ValueError(f"No JSON object found in response: {text[:300]}")
