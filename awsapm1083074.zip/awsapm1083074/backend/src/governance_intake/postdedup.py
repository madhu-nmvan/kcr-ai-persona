# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Post-dedup experience: service layer.

Form-first operations over a session in the asking_questions phase:
create-from-STATE, record/edit/clear answers, prefill acceptance,
deterministic completeness, submit (existing ticket fan-out), and the
before/after stats strip.

Pure orchestration — no LLM calls here (prefill proposals come from
prefill.py; this module only applies decisions about them).
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from .attachments import has_required_attachment
from .form_mapper import map_answers_to_team_forms
from .gap_detector import detect_gaps
from .question_dedup import build_pending_questions, dedup_stats
from .question_order import order_pending_questions
from .rule_engine import evaluate_rules
from .session import PHASE_ASKING, PHASE_ATTACHMENTS, PHASE_COMPLETE, new_session
from .state_adapter import SessionInputs, session_inputs_from_state
from .ticket_creator import create_ticket

ANSWER_ORIGIN_USER = "user"
ANSWER_ORIGIN_PREFILL = "prefill"

PREFILL_PROPOSED = "proposed"
PREFILL_ACCEPTED = "accepted"
PREFILL_DISMISSED = "dismissed"


class PostDedupError(ValueError):
    """Client-input error from a post-dedup operation."""


def begin_session(
    session_id: str,
    user_id: str,
    state: dict[str, Any],
    data: Any,
) -> dict[str, Any]:
    """
    Create a session directly in the asking phase from a STATE envelope.

    Activated teams come from the envelope when present; otherwise they are
    derived deterministically from the trigger fields via the rule engine.
    Unknown team names (exact-string join hazard) are kept on the session as
    `unknown_teams` so the caller can surface them.
    """
    inputs: SessionInputs = session_inputs_from_state(state, known_teams=set(data.questionnaires.get("teams", {})))

    activated = inputs.activated_teams
    if not activated:
        if not inputs.trigger_fields:
            raise PostDedupError(
                "STATE carries neither activated_teams nor trigger fields; nothing to build a question set from."
            )
        activated = evaluate_rules(inputs.trigger_fields, data.trigger_rules)

    team_names = [t["team"] for t in activated]
    pending = order_pending_questions(build_pending_questions(team_names, data.questionnaires, data.dedup_mapping))
    _apply_prior_governance_answers(pending, inputs.governance_answers)

    sess = new_session(session_id, user_id)
    sess["phase"] = PHASE_ASKING
    sess["collected_fields"] = inputs.trigger_fields
    sess["activated_teams"] = activated
    sess["unknown_teams"] = inputs.unknown_teams
    sess["ui_messages"] = inputs.messages
    sess["pending_questions"] = pending
    sess["team_forms"] = map_answers_to_team_forms(pending, team_names)
    sess["dedup_stats"] = dedup_stats(team_names, data.questionnaires, pending)
    sess["open_gaps"] = detect_gaps(team_names, data.questionnaires, sess["team_forms"])
    return sess


# ---------------------------------------------------------------------------
# Answers
# ---------------------------------------------------------------------------


def record_answers(
    sess: dict[str, Any],
    data: Any,
    answers: list[dict[str, Any]],
    demo_mode: bool = False,
) -> dict[str, Any]:
    """
    Apply a batch of answer edits: [{"canonical_id": str, "answer": Any}].

    An empty/None answer clears the question (reopens it and removes its
    team-form fields). User edits always win: an edit over an accepted
    prefill flips the origin to "user". Unknown canonical ids are an error —
    the client is out of sync and should refetch, not be silently ignored.
    """
    _require_phase(sess)
    by_id = {q["canonical_id"]: q for q in sess["pending_questions"]}
    unknown = [a.get("canonical_id") for a in answers if a.get("canonical_id") not in by_id]
    if unknown:
        raise PostDedupError(f"Unknown canonical ids: {unknown}")

    for entry in answers:
        q = by_id[entry["canonical_id"]]
        answer = entry.get("answer")
        if answer is None or (isinstance(answer, str) and not answer.strip()):
            q["answer"] = None
            q["answered"] = False
            q.pop("answer_origin", None)
        else:
            q["answer"] = answer
            q["answered"] = True
            q["answer_origin"] = ANSWER_ORIGIN_USER

    _refresh_derived(sess, data)
    return completeness(sess, data, demo_mode)


def apply_prefill_decisions(
    sess: dict[str, Any],
    data: Any,
    accept: Iterable[str] | None = None,
    dismiss: Iterable[str] | None = None,
    accept_all: bool = False,
    demo_mode: bool = False,
) -> dict[str, Any]:
    """
    Accept or dismiss proposed prefills by canonical id.

    Accepting commits the proposal's answer with origin "prefill"; the
    provenance stays on the question. Only questions with a proposal in
    status "proposed" are eligible — ids without one are an error (client
    out of sync). Never touches user-entered answers.
    """
    _require_phase(sess)
    by_id = {q["canonical_id"]: q for q in sess["pending_questions"]}

    accept_ids = set(accept or [])
    if accept_all:
        accept_ids |= {cid for cid, q in by_id.items() if (q.get("prefill") or {}).get("status") == PREFILL_PROPOSED}
    dismiss_ids = set(dismiss or [])

    overlap = accept_ids & dismiss_ids
    if overlap:
        raise PostDedupError(f"Ids both accepted and dismissed: {sorted(overlap)}")

    for cid in sorted(accept_ids | dismiss_ids):
        q = by_id.get(cid)
        proposal = (q or {}).get("prefill")
        if not q or not proposal or proposal.get("status") != PREFILL_PROPOSED:
            raise PostDedupError(f"No proposed prefill for canonical id: {cid}")
        if cid in accept_ids:
            proposal["status"] = PREFILL_ACCEPTED
            q["answer"] = proposal["answer"]
            q["answered"] = True
            q["answer_origin"] = ANSWER_ORIGIN_PREFILL
        else:
            proposal["status"] = PREFILL_DISMISSED

    _refresh_derived(sess, data)
    return completeness(sess, data, demo_mode)


# ---------------------------------------------------------------------------
# Completeness / submit / stats
# ---------------------------------------------------------------------------


def completeness(sess: dict[str, Any], data: Any, demo_mode: bool = False) -> dict[str, Any]:
    """
    Deterministic completeness snapshot. Proposed (unaccepted) prefills do
    NOT count as answered -- nothing is silently committed.

    demo_mode mirrors handler.py's IntakeHandler.demo_mode: demo sessions
    only walk a curated subset of each team's real questionnaire
    (demo_team_questions.json), so open_gaps against the FULL questionnaire
    catalog are expected and must not block completion -- see handler.py's
    `qa_done = all_answered and (self.demo_mode or not gaps)`. Outside demo
    mode, gaps are real coverage holes and do block completion.
    """
    pending = sess["pending_questions"]
    team_names = [t["team"] for t in sess["activated_teams"]]
    unanswered = [q["canonical_id"] for q in pending if not q.get("answered")]
    gaps = sess.get("open_gaps", [])
    return {
        "complete": not unanswered and (demo_mode or not gaps),
        "unanswered_count": len(unanswered),
        "unanswered_ids": unanswered[:50],
        "open_gaps": gaps,
        "activated_team_count": len(team_names),
    }


def record_attachment(sess: dict[str, Any], attachment: dict[str, Any]) -> None:
    """
    Attach a saved upload to a form-first session. Unlike the chat flow
    (which has a dedicated attachments phase), the form collects the
    solution/data-flow diagram alongside the answers.
    """
    _require_phase(sess)
    sess.setdefault("attachments", []).append(attachment)


def submit(sess: dict[str, Any], data: Any, demo_mode: bool = False) -> dict[str, Any]:
    """
    Deterministic gate -> existing ticket fan-out. Refusal raises with the
    blocking facts; nothing is created on refusal. The production rule that
    a solution/data-flow diagram (.pptx) must accompany every ticket holds
    here exactly as in the chat flow.
    """
    _require_phase(sess)
    snapshot = completeness(sess, data, demo_mode)
    if not snapshot["complete"]:
        raise PostDedupError(
            f"Not complete: {snapshot['unanswered_count']} unanswered canonical "
            f"question(s), {len(snapshot['open_gaps'])} required team-form gap(s)."
        )
    if not has_required_attachment(sess.get("attachments", [])):
        raise PostDedupError("A solution/data-flow diagram (.pptx) attachment is required before submission.")
    ticket = create_ticket(sess)
    ticket["attachments"] = sess.get("attachments", [])
    ticket["prefill_stats"] = stats(sess).get("prefill", {})
    sess["ticket"] = ticket
    sess["phase"] = PHASE_COMPLETE
    return ticket


def stats(sess: dict[str, Any]) -> dict[str, Any]:
    """Before/after strip: raw vs consolidated vs pre-filled vs answered."""
    pending = sess.get("pending_questions", [])
    dstats = sess.get("dedup_stats", {})
    prefills = [q.get("prefill") for q in pending if q.get("prefill")]
    answered = [q for q in pending if q.get("answered")]
    return {
        "raw_question_count": dstats.get("raw_question_count", 0),
        "consolidated_question_count": dstats.get("consolidated_question_count", len(pending)),
        "reduction_ratio": dstats.get("reduction_ratio", 0.0),
        "answered_count": len(answered),
        "answered_by_prefill_count": sum(1 for q in answered if q.get("answer_origin") == ANSWER_ORIGIN_PREFILL),
        "prefill": {
            "proposed": sum(1 for p in prefills if p.get("status") == PREFILL_PROPOSED),
            "accepted": sum(1 for p in prefills if p.get("status") == PREFILL_ACCEPTED),
            "dismissed": sum(1 for p in prefills if p.get("status") == PREFILL_DISMISSED),
            "rejected_ungrounded": sess.get("prefill_rejected_count", 0),
        },
    }


# ---------------------------------------------------------------------------


def _apply_prior_governance_answers(
    pending: list[dict[str, Any]],
    governance_answers: dict[str, dict[str, Any]],
) -> None:
    """
    Seed already-answered governance values from a FormFillerEnvelope onto the
    freshly-built pending set (in place). Mirrors Jeremy's `build_pending_questions`
    `prior_answers` behavior, but applied here so this lane stays decoupled from
    that function's signature. Canonical ids absent from the current set (a
    team deactivated, or unknown id) are skipped, not errored — this is a
    tolerant load of prior state, not a user edit.
    """
    if not governance_answers:
        return
    by_id = {q["canonical_id"]: q for q in pending}
    for canonical_id, entry in governance_answers.items():
        q = by_id.get(canonical_id)
        if q is None:
            continue
        value = entry.get("value")
        if value is None:
            continue
        q["answer"] = value
        q["answered"] = True
        q["answer_origin"] = ANSWER_ORIGIN_PREFILL if entry.get("origin") == "agent" else ANSWER_ORIGIN_USER


def _refresh_derived(sess: dict[str, Any], data: Any) -> None:
    team_names = [t["team"] for t in sess["activated_teams"]]
    sess["team_forms"] = map_answers_to_team_forms(sess["pending_questions"], team_names)
    sess["open_gaps"] = detect_gaps(team_names, data.questionnaires, sess["team_forms"])


# handler.py's own chat flow can independently flip an in-progress session
# from asking_questions to collecting_attachments (its qa_done gate, on the
# SAME shared session -- see the single-session collapse). Post-dedup's
# routes must tolerate that: a user editing an answer or attaching the
# diagram through the dashboard after chat decided the Q&A was done is a
# real cross-surface race, not a client bug -- see review finding I2/GAP2.
_ASKING_OR_ATTACHMENTS = {PHASE_ASKING, PHASE_ATTACHMENTS}


def _require_phase(sess: dict[str, Any]) -> None:
    if sess.get("phase") not in _ASKING_OR_ATTACHMENTS:
        raise PostDedupError(
            f"Session is in phase {sess.get('phase')!r}; this operation requires "
            f"one of {sorted(_ASKING_OR_ATTACHMENTS)!r}."
        )
