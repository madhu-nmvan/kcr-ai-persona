# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Gap detector.

Pure function: for each activated team, compare the team's required questions
against the filled team_forms and return gaps that still need to be answered.
"""

from __future__ import annotations

from typing import Any, Dict, List


def detect_gaps(
    activated_teams: List[str],
    questionnaires: Dict[str, Any],
    team_forms: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Return a list of gaps. Each gap is:
        {"team": str, "question_id": str, "text": str, "required": bool}

    A gap is any required question for an activated team that has no value in
    team_forms (or has an empty/None value).
    """
    gaps: List[Dict[str, Any]] = []
    teams = questionnaires.get("teams", {})

    for team in activated_teams:
        filled = team_forms.get(team, {})
        for q in teams.get(team, {}).get("questions", []):
            if not q.get("required", False):
                continue
            value = filled.get(q["id"])
            if _is_empty(value):
                gaps.append(
                    {
                        "team": team,
                        "question_id": q["id"],
                        "text": q["text"],
                        "required": True,
                    }
                )
    return gaps


def _is_empty(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str) and not value.strip():
        return True
    if isinstance(value, (list, dict)) and len(value) == 0:
        return True
    return False


def all_required_filled(
    activated_teams: List[str],
    questionnaires: Dict[str, Any],
    team_forms: Dict[str, Dict[str, Any]],
) -> bool:
    """True when no required question remains unanswered across activated teams."""
    return len(detect_gaps(activated_teams, questionnaires, team_forms)) == 0
