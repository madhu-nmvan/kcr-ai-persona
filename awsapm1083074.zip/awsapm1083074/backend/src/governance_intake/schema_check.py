# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Schema completeness checker for routing fields.

Pure function: given the intake_schema.json doc and the collected_fields dict,
return the list of missing required fields. Honors `required_when` conditions
using the same rule_engine DSL.
"""

from __future__ import annotations

from typing import Any, Dict, List

from .rule_engine import evaluate_condition


def missing_required_fields(
    intake_schema: Dict[str, Any], collected: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """Return descriptors of fields that are required-and-absent."""
    missing: List[Dict[str, Any]] = []
    for field in intake_schema.get("fields", []):
        name = field["name"]
        is_required = field.get("required", False)
        required_when = field.get("required_when")
        conditional = required_when is not None and evaluate_condition(required_when, collected)

        if not (is_required or conditional):
            continue
        if _present(collected.get(name)):
            continue
        missing.append(
            {
                "name": name,
                "type": field.get("type"),
                "description": field.get("description", ""),
            }
        )
    return missing


def all_routing_fields_present(
    intake_schema: Dict[str, Any], collected: Dict[str, Any]
) -> bool:
    return len(missing_required_fields(intake_schema, collected)) == 0


def _present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str) and not value.strip():
        return False
    if isinstance(value, list) and len(value) == 0:
        return False
    return True
