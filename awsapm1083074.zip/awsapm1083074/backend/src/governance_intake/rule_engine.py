# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Rule engine.

Pure function: given collected routing fields and a trigger_rules.json structure,
return the list of activated governance teams (with review_phase metadata).

The DSL supported in `when` clauses:
    {"equals":   [field, value]}      field == value
    {"in":       [field, [values]]}   field is in values
    {"contains": [field, value]}      list field contains value
    {"any_of":   [field, [values]]}   list field intersects values
    {"truthy":   field}               bool(field) is True
    {"all":      [cond, ...]}         all conditions true
    {"any":      [cond, ...]}         any condition true
    {"at_least": [n, [cond, ...]]}    at least n of the conditions are true
    {"not":      cond}                negation
"""

from __future__ import annotations

from typing import Any, Dict, List


class RuleEvalError(ValueError):
    """Raised when a rule cannot be evaluated."""


def _get(fields: Dict[str, Any], name: str) -> Any:
    return fields.get(name)


def evaluate_condition(cond: Any, fields: Dict[str, Any]) -> bool:
    """Evaluate a single DSL condition against fields. Missing field => False."""
    if not isinstance(cond, dict) or len(cond) != 1:
        raise RuleEvalError(f"Condition must be a single-key dict, got: {cond!r}")

    op, args = next(iter(cond.items()))

    if op == "equals":
        field, value = args
        return _get(fields, field) == value

    if op == "in":
        field, values = args
        return _get(fields, field) in values

    if op == "contains":
        field, value = args
        v = _get(fields, field)
        return isinstance(v, list) and value in v

    if op == "any_of":
        field, values = args
        v = _get(fields, field)
        if not isinstance(v, list):
            return False
        return any(item in v for item in values)

    if op == "truthy":
        return bool(_get(fields, args))

    if op == "all":
        return all(evaluate_condition(c, fields) for c in args)

    if op == "any":
        return any(evaluate_condition(c, fields) for c in args)

    if op == "at_least":
        threshold, conditions = args
        matched = sum(1 for c in conditions if evaluate_condition(c, fields))
        return matched >= threshold

    if op == "not":
        return not evaluate_condition(args, fields)

    raise RuleEvalError(f"Unknown operator: {op}")


def evaluate_rules(fields: Dict[str, Any], rules_doc: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Evaluate trigger rules and return list of activated teams.

    Each entry is {"team": str, "review_phase": int}. Order follows rule order;
    duplicates are removed (first occurrence wins).
    """
    activated: List[Dict[str, Any]] = []
    seen = set()
    for rule in rules_doc.get("rules", []):
        team = rule["team"]
        if team in seen:
            continue
        try:
            if evaluate_condition(rule["when"], fields):
                activated.append({"team": team, "review_phase": rule.get("review_phase", 1)})
                seen.add(team)
        except RuleEvalError as e:
            raise RuleEvalError(f"Rule for team {team!r} failed: {e}") from e
    return activated


def activated_team_names(fields: Dict[str, Any], rules_doc: Dict[str, Any]) -> List[str]:
    """Convenience: list of team names only."""
    return [t["team"] for t in evaluate_rules(fields, rules_doc)]
