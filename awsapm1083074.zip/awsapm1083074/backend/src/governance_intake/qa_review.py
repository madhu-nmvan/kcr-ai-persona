# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
QA / counselor final-pass agent (Phase B).

Optional, strictly advisory review of the answered questions before
submission: flags answers that look insufficient for a governance reviewer
and suggests one clarifying question each. It never blocks submit and never
changes an answer — output is a list the UI can render as suggestions.

INTAKE_SKIP_LLM=1 (and any provider failure surfaced by the caller) means
no review; submission proceeds on the deterministic gate alone.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from typing import Any

from pydantic import BaseModel, Field

_MAX_CONCERNS = 5


class QAConcern(BaseModel):
    canonical_id: str
    concern: str = Field(description="Why the answer may not satisfy a reviewer.")
    clarifying_question: str = Field(
        description="One concrete question that would strengthen the answer."
    )


class QAReview(BaseModel):
    concerns: list[QAConcern] = Field(default_factory=list)


QA_REVIEW_SYSTEM_PROMPT = """\
You are a governance counselor reviewing a submitter's completed intake
answers before they go to review teams. Identify at most {max_concerns}
answers that a reviewer would likely bounce back — vague, self-contradictory,
or clearly incomplete relative to the question asked. For each, state the
concern and ONE clarifying question that would strengthen the application.

Only flag genuine weaknesses. If the answers are adequate, return no
concerns. Never rewrite answers; never invent facts.
"""


def _default_agent_factory() -> Any:
    from strands import Agent

    from .llm_provider import get_model

    return Agent(
        model=get_model(),
        system_prompt=QA_REVIEW_SYSTEM_PROMPT.format(max_concerns=_MAX_CONCERNS),
        callback_handler=None,
    )


def review_answers(
    sess: dict[str, Any],
    agent_factory: Callable[[], Any] | None = None,
    max_concerns: int = _MAX_CONCERNS,
) -> list[dict[str, Any]]:
    """
    Run the advisory pass over answered questions. Returns concern dicts
    (possibly empty) and stores them on sess["qa_review"]. Concerns citing
    unknown canonical ids are dropped — advisory output must still point at
    real questions.
    """
    answered = [
        q for q in sess.get("pending_questions", []) if q.get("answered")
    ]
    if os.environ.get("INTAKE_SKIP_LLM") == "1" or not answered:
        sess["qa_review"] = []
        return []

    lines = [
        f"- [{q['canonical_id']}] Q: {q.get('canonical_question', '')}\n"
        f"  A: {q.get('answer')}"
        for q in answered
    ]
    prompt = (
        "Answered governance questions:\n"
        + "\n".join(lines)
        + "\n\nFlag at most "
        f"{max_concerns} weak answers, or none if all are adequate."
    )

    factory = agent_factory or _default_agent_factory
    review: QAReview = factory().structured_output(QAReview, prompt=prompt)

    known = {q["canonical_id"] for q in answered}
    concerns = [
        c.model_dump()
        for c in review.concerns[:max_concerns]
        if c.canonical_id in known
    ]
    sess["qa_review"] = concerns
    return concerns
