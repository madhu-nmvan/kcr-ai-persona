# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Handler: orchestrates the intake flow.

Two modes controlled by the demo_mode flag on IntakeHandler:

  demo_mode=True (default for the initial demo)
    Phase 1 (collecting_routing_info) -> Phase 2 (asking_questions) -> complete
    - Phase 1: routing_agent + extract_routing_fields collect routing info.
    - When routing is complete, pick a single "focus team" from the activated
      teams and use its hard-coded questions (data/demo_team_questions.json)
      directly as pending_questions. No dedup, no fan-out.
    - Phase 2: qa_agent + extract_answer_batch drive the Q&A over that team's
      questions. Ticket is issued for the focus team only.

  demo_mode=False (full flow, retained for later)
    Phase 1 -> deduplicated Phase 2 across all activated teams -> complete
    - Same shape but pending_questions is produced by question_dedup and
      team_forms fan out to every activated team.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .attachments import has_required_attachment
from .form_mapper import map_answers_to_team_forms
from .gap_detector import detect_gaps
from .intake_agent import (
    AnswerBatch,
    RoutingFields,
    build_qa_agent,
    build_routing_agent,
    extract_answer_batch,
    extract_routing_fields,
)
from .question_dedup import build_pending_questions, dedup_stats
from .question_order import order_pending_questions
from .rule_engine import evaluate_rules
from .schema_check import all_routing_fields_present
from .session import (
    PHASE_ASKING,
    PHASE_ATTACHMENTS,
    PHASE_COMPLETE,
    PHASE_ROUTING,
    SessionStore,
    new_session,
)
from .ticket_creator import create_ticket


DATA_DIR = Path(__file__).resolve().parent / "data"


ATTACHMENT_PROMPT = (
    "One last thing before I submit this — governance review requires a "
    "**solution / data-flow diagram** (PowerPoint format) attached to the "
    "request. Please use the upload button below to attach your PPTX (you "
    "can add other supporting documents too, like PDFs or Word docs). "
    "Let me know once you've uploaded it and I'll submit the request."
)

# Phrases that signal "I've uploaded, go ahead and submit" in the attachments
# phase. Kept as a simple keyword check (not an LLM call) since this phase's
# only decision is binary: are we done, or still waiting on an upload.
_DONE_PHRASES = (
    "done", "submit", "that's all", "thats all", "finished", "go ahead",
    "attached", "uploaded", "ready", "complete", "all set",
)


# ---------------------------------------------------------------------------
# Data loading.
# ---------------------------------------------------------------------------


class IntakeData:
    """Bundles the config JSON files. Loaded once per handler instance."""

    def __init__(self, data_dir: Optional[Path] = None) -> None:
        d = data_dir or DATA_DIR
        with (d / "intake_schema.json").open(encoding="utf-8") as f:
            self.intake_schema = json.load(f)
        with (d / "trigger_rules.json").open(encoding="utf-8") as f:
            self.trigger_rules = json.load(f)
        with (d / "questionnaires.json").open(encoding="utf-8") as f:
            self.questionnaires = json.load(f)
        with (d / "dedup_mapping.json").open(encoding="utf-8") as f:
            self.dedup_mapping = json.load(f)
        with (d / "team_roster.json").open(encoding="utf-8") as f:
            self.team_roster = json.load(f)

        preseed_path = d / "preseed_map.json"
        self.preseed_map = (
            json.loads(preseed_path.read_text(encoding="utf-8")) if preseed_path.exists() else {"mappings": []}
        )
        demo_qs_path = d / "demo_team_questions.json"
        self.demo_team_questions = (
            json.loads(demo_qs_path.read_text(encoding="utf-8")) if demo_qs_path.exists() else {"teams": {}}
        )


# ---------------------------------------------------------------------------
# Handler.
# ---------------------------------------------------------------------------


class IntakeHandler:
    """Stateless handler. Holds config + session store; one instance is fine."""

    def __init__(
        self,
        store: SessionStore,
        data: Optional[IntakeData] = None,
        demo_mode: bool = True,
        demo_focus_team: Optional[str] = None,
    ) -> None:
        """
        Args:
          store: SessionStore backing session state.
          data: IntakeData; auto-loaded from the workspace `data/` dir if omitted.
          demo_mode: When True, Phase 2 runs Q&A on a single focus team's hard-
            coded questions (no dedup). When False, runs the full dedup flow.
          demo_focus_team: Force a specific focus team for demo mode. When None,
            the handler picks the first activated team that has hard-coded demo
            questions defined.
        """
        self.store = store
        self.data = data or IntakeData()
        self.demo_mode = demo_mode
        self.demo_focus_team = demo_focus_team
        # Optional cap on how many teams are walked in demo mode. Useful for
        # cheap smoke tests (verify.py) where walking all activated teams'
        # Q&A would mean dozens of LLM calls. None = no cap (real behavior).
        self.demo_team_limit = (
            int(os.environ["INTAKE_DEMO_TEAM_LIMIT"])
            if os.environ.get("INTAKE_DEMO_TEAM_LIMIT")
            else None
        )

    # -- Public API -----------------------------------------------------------

    def start_session(self, session_id: str, user_id: str) -> Dict[str, Any]:
        sess = new_session(session_id, user_id)
        self.store.put(sess)
        return sess

    def get_public_state(self, session_id: str) -> Dict[str, Any]:
        """Public wrapper around _public_state, for endpoints (GET /start,
        GET /sessions/{id}) that need the same shape outside a chat turn."""
        sess = self.store.get(session_id)
        if sess is None:
            raise ValueError(f"Unknown session: {session_id}")
        return _public_state(sess)

    def handle_message(
        self,
        session_id: str,
        user_message: str,
        focused_field: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run one conversational turn. Returns a dict with reply + state."""
        sess = self.store.get(session_id)
        if sess is None:
            raise ValueError(f"Unknown session: {session_id}")
        focus_hint = _focus_hint_from_field(focused_field)

        if sess["phase"] == PHASE_ROUTING:
            reply, sess = self._step_routing(sess, user_message, focus_hint)
        elif sess["phase"] == PHASE_ASKING:
            reply, sess = self._step_asking(sess, user_message, focus_hint)
        elif sess["phase"] == PHASE_ATTACHMENTS:
            reply, sess = self._step_attachments(sess, user_message)
        elif sess["phase"] == PHASE_COMPLETE:
            reply = (
                "This request has already been submitted. "
                f"Ticket: {sess.get('ticket', {}).get('ticket_id')}."
            )
        else:
            raise ValueError(f"Unknown phase: {sess['phase']}")

        self.store.put(sess)
        return {"reply": reply, **_public_state(sess)}

    # -- Phase 1: routing -----------------------------------------------------

    def _step_routing(
        self,
        sess: Dict[str, Any],
        user_message: str,
        focus_hint: Optional[str] = None,
    ) -> Tuple[str, Dict[str, Any]]:
        agent = build_routing_agent(messages=sess["chat_history"], focus_hint=focus_hint)
        agent_result = agent(user_message)
        reply = _result_text(agent_result)

        # Persist history BEFORE extraction so a failure doesn't lose the turn.
        sess["chat_history"] = list(agent.messages)

        try:
            extracted: RoutingFields = extract_routing_fields(sess["chat_history"])
            new_fields = {k: v for k, v in extracted.model_dump().items() if v is not None}
        except Exception as e:  # pragma: no cover
            new_fields = {}
            reply += f"\n\n[debug: routing extraction failed: {e}]"

        sess["collected_fields"].update(new_fields)
        _fill_project_name_fallback(sess["collected_fields"])

        if self._maybe_advance_from_routing(sess):
            focus_team = sess.get("focus_team")
            if self.demo_mode and focus_team:
                reply += (
                    f"\n\nGreat — I have what I need. Let me ask a few review "
                    f"questions on behalf of the **{focus_team}** team so we "
                    "can wrap this up in one sitting.\n\n"
                )
            else:
                reply += "\n\nGreat — I have what I need. A few review questions:\n\n"
            reply += self._kickoff_qa_sync(sess)
        return reply, sess

    def _kickoff_qa_sync(self, sess: Dict[str, Any]) -> str:
        """Sync twin of _kickoff_qa_stream."""
        qa_agent = build_qa_agent(
            pending_questions=sess["pending_questions"],
            messages=[],
            routing_context=sess["collected_fields"],
        )
        seed_prompt = (
            "Please begin the review-question phase now. Ask me the first one "
            "or two open questions from your list."
        )
        result = qa_agent(seed_prompt)
        text = _result_text(result)
        sess["chat_history"] = list(qa_agent.messages)
        return text

    # -- Phase 2 entry --------------------------------------------------------

    def _maybe_advance_from_routing(self, sess: Dict[str, Any]) -> bool:
        """
        If all required routing fields are now present, transition to the
        asking phase. Shared by the chat path (_step_routing/_stream) and the
        direct-write path (set_routing_field) so manually completing the form
        advances the session exactly like finishing it via chat does.
        """
        if all_routing_fields_present(self.data.intake_schema, sess["collected_fields"]):
            self._enter_asking_phase(sess)
            return True
        return False

    def _enter_asking_phase(self, sess: Dict[str, Any]) -> None:
        activated = evaluate_rules(sess["collected_fields"], self.data.trigger_rules)
        sess["activated_teams"] = activated

        if self.demo_mode:
            team_order = self._order_teams_for_demo(activated)
            pending = self._build_demo_pending(team_order)
            sess["team_order"] = team_order
            sess["pending_questions"] = pending
            # focus_team tracks whichever team's questions are CURRENTLY being
            # asked; it advances team-by-team as pending gets answered.
            sess["focus_team"] = self._current_team(pending)
            team_names = team_order
        else:
            pending = order_pending_questions(
                build_pending_questions(
                    [t["team"] for t in activated],
                    self.data.questionnaires,
                    self.data.dedup_mapping,
                )
            )
            preseeded = self._preseed_from_routing(pending, sess["collected_fields"])
            sess["pending_questions"] = pending
            sess["preseeded_canonical_ids"] = preseeded
            sess["dedup_stats"] = dedup_stats(
                [t["team"] for t in activated], self.data.questionnaires, pending
            )
            team_names = [t["team"] for t in activated]

        sess["team_forms"] = map_answers_to_team_forms(pending, team_names)
        # Eager, so a session opened straight into the post-dedup view (same
        # session id, shared SessionStore -- see server.py) has a correct
        # completeness snapshot before any answer turn recomputes this.
        sess["open_gaps"] = detect_gaps(team_names, self.data.questionnaires, sess["team_forms"])
        sess["phase"] = PHASE_ASKING
        sess["chat_history"] = []

    def _order_teams_for_demo(self, activated: List[Dict[str, Any]]) -> List[str]:
        """
        Order in which teams are walked during Phase 2.

        If demo_focus_team was set at construction, that team goes first
        (useful for focused testing of one team's questions). Otherwise
        teams are walked in activation order. Only teams that have
        hard-coded demo questions defined are included — teams without demo
        questions are still listed on the ticket as activated, but are not
        part of the interactive Q&A.
        """
        activated_names = [t["team"] for t in activated]
        demo_qs = self.data.demo_team_questions.get("teams", {})
        with_questions = [name for name in activated_names if demo_qs.get(name)]

        if self.demo_focus_team and self.demo_focus_team in with_questions:
            rest = [n for n in with_questions if n != self.demo_focus_team]
            ordered = [self.demo_focus_team, *rest]
        else:
            ordered = with_questions

        if self.demo_team_limit is not None:
            ordered = ordered[: self.demo_team_limit]
        return ordered

    def _build_demo_pending(self, team_order: List[str]) -> List[Dict[str, Any]]:
        """
        Build pending_questions across ALL teams in team_order, in sequence.
        Each canonical is tagged with category=<team name> so the qa_agent
        can present questions grouped by team and move on to the next team
        once the current one is fully answered.
        """
        demo_qs = self.data.demo_team_questions.get("teams", {})
        questionnaires_teams = self.data.questionnaires.get("teams", {})

        pending: List[Dict[str, Any]] = []
        for team in team_order:
            demo_texts = demo_qs.get(team, [])
            real_qs = questionnaires_teams.get(team, {}).get("questions", [])
            text_to_id = {q["text"]: q["id"] for q in real_qs}

            for i, text in enumerate(demo_texts, start=1):
                qid = text_to_id.get(text, f"{_slug(team)}.DEMO{i}")
                pending.append(
                    {
                        "canonical_id": f"DEMO.{_slug(team)}.{i}",
                        "canonical_question": text,
                        "category": team,
                        "sources": [{"team": team, "question_id": qid}],
                        "source_teams": [team],
                        "answered": False,
                        "answer": None,
                    }
                )
        return pending

    @staticmethod
    def _current_team(pending_questions: List[Dict[str, Any]]) -> Optional[str]:
        """The team whose questions are still being asked (first unanswered)."""
        for q in pending_questions:
            if not q.get("answered"):
                return q.get("category")
        return None

    # -- Preseed (only used in full mode) ------------------------------------

    def _preseed_from_routing(
        self,
        pending: List[Dict[str, Any]],
        collected_fields: Dict[str, Any],
    ) -> List[str]:
        preseeded: List[str] = []
        by_id = {q["canonical_id"]: q for q in pending}
        for mapping in self.data.preseed_map.get("mappings", []):
            field = mapping.get("routing_field")
            if field not in collected_fields or collected_fields[field] in (None, "", []):
                continue
            value = collected_fields[field]
            answer_text = (
                ", ".join(str(v) for v in value) if isinstance(value, list) else str(value)
            )
            cid = mapping.get("canonical_id")
            if cid and cid in by_id:
                q = by_id[cid]
                if not q.get("answered"):
                    q["answer"] = answer_text
                    q["answered"] = True
                    preseeded.append(cid)
                continue
            source_qid = mapping.get("source_question_id")
            if source_qid:
                for q in pending:
                    if q.get("answered"):
                        continue
                    if any(s.get("question_id") == source_qid for s in q.get("sources", [])):
                        q["answer"] = answer_text
                        q["answered"] = True
                        preseeded.append(q["canonical_id"])
        return preseeded

    # -- Phase 2: asking questions -------------------------------------------

    def _refresh_asking_state(self, sess: Dict[str, Any]) -> bool:
        """
        Recompute team_forms/gaps after pending_questions changes (an answer
        was recorded, whether via chat extraction or a direct form write),
        and transition to the attachments phase if every question is now
        answered. Shared by the chat path (_step_asking/_stream) and the
        direct-write path (set_answer). Returns True if it transitioned.
        """
        if self.demo_mode:
            team_names = sess.get("team_order") or (
                [sess["focus_team"]] if sess.get("focus_team") else []
            )
            # Advance focus_team to whichever team's questions are still open.
            sess["focus_team"] = self._current_team(sess["pending_questions"])
        else:
            team_names = [t["team"] for t in sess["activated_teams"]]

        sess["team_forms"] = map_answers_to_team_forms(sess["pending_questions"], team_names)
        gaps = detect_gaps(team_names, self.data.questionnaires, sess["team_forms"])
        sess["open_gaps"] = gaps

        all_answered = all(q.get("answered") for q in sess["pending_questions"])
        # In demo mode we only ask each team's hard-coded subset (not their
        # full real questionnaire), so we don't gate completion on gaps
        # against the full questionnaire — those are out of scope for the demo.
        qa_done = all_answered and (self.demo_mode or not gaps)

        if qa_done:
            sess["phase"] = PHASE_ATTACHMENTS
            sess["chat_history"] = []
            return True
        return False

    def _step_asking(
        self,
        sess: Dict[str, Any],
        user_message: str,
        focus_hint: Optional[str] = None,
    ) -> Tuple[str, Dict[str, Any]]:
        agent = build_qa_agent(
            pending_questions=sess["pending_questions"],
            messages=sess["chat_history"],
            routing_context=sess["collected_fields"],
            focus_hint=focus_hint,
        )
        agent_result = agent(user_message)
        reply = _result_text(agent_result)
        sess["chat_history"] = list(agent.messages)

        try:
            extracted: AnswerBatch = extract_answer_batch(
                sess["pending_questions"], sess["chat_history"]
            )
            self._record_answers(sess, extracted)
        except Exception as e:  # pragma: no cover
            reply += f"\n\n[debug: answer extraction failed: {e}]"

        if self._refresh_asking_state(sess):
            reply += "\n\n" + ATTACHMENT_PROMPT
        # Team-to-team transitions are handled by the qa_agent itself.
        return reply, sess

    def _create_ticket(self, sess: Dict[str, Any]) -> Dict[str, Any]:
        ticket = create_ticket(sess)
        ticket["attachments"] = sess.get("attachments", [])
        if self.demo_mode:
            team_order = sess.get("team_order") or []
            # Demo ticket represents every team walked during Q&A, not just one.
            ticket["demo_mode"] = True
            ticket["team_order"] = team_order
            ticket["team_forms"] = {
                team: sess["team_forms"].get(team, {}) for team in team_order
            }
            ticket["activated_teams_summary"] = [
                {
                    "team": t["team"],
                    "review_phase": t.get("review_phase", 1),
                    "in_scope_for_demo": t["team"] in team_order,
                }
                for t in sess["activated_teams"]
            ]
        return ticket

    @staticmethod
    def _record_answers(sess: Dict[str, Any], batch: AnswerBatch) -> None:
        if not batch.answers:
            return
        by_id = {q["canonical_id"]: q for q in sess["pending_questions"]}
        for ans in batch.answers:
            q = by_id.get(ans.canonical_id)
            if not q:
                continue
            q["answer"] = ans.answer
            q["answered"] = True

    # -- Direct field/answer writes (bypass chat) ------------------------
    #
    # The manual-fill counterpart to what chat-driven extraction already does
    # automatically (extract_routing_fields / extract_answer_batch). Both
    # paths mutate the exact same collected_fields / pending_questions state,
    # so a field filled in directly and a field filled in via chat stay in
    # sync with no separate reconciliation needed. These reuse the same
    # completion checks/phase transitions the chat path uses.

    def set_routing_field(
        self, session_id: str, field_name: str, value: Any
    ) -> Dict[str, Any]:
        sess = self.store.get(session_id)
        if sess is None:
            raise ValueError(f"Unknown session: {session_id}")
        if sess["phase"] != PHASE_ROUTING:
            raise ValueError(
                f"Session is in phase {sess['phase']!r}; routing fields can "
                f"only be set during {PHASE_ROUTING!r}."
            )
        valid_names = {f["name"] for f in self.data.intake_schema.get("fields", [])}
        if field_name not in valid_names:
            raise ValueError(f"Unknown routing field: {field_name!r}")

        sess["collected_fields"][field_name] = value
        _fill_project_name_fallback(sess["collected_fields"])
        self._maybe_advance_from_routing(sess)

        self.store.put(sess)
        return _public_state(sess)

    def set_answer(
        self, session_id: str, canonical_id: str, answer: Any
    ) -> Dict[str, Any]:
        sess = self.store.get(session_id)
        if sess is None:
            raise ValueError(f"Unknown session: {session_id}")
        if sess["phase"] != PHASE_ASKING:
            raise ValueError(
                f"Session is in phase {sess['phase']!r}; answers can only be "
                f"set during {PHASE_ASKING!r}."
            )
        by_id = {q["canonical_id"]: q for q in sess["pending_questions"]}
        q = by_id.get(canonical_id)
        if q is None:
            raise ValueError(f"Unknown canonical_id: {canonical_id!r}")

        if answer is None or (isinstance(answer, str) and not answer.strip()):
            q["answer"] = None
            q["answered"] = False
            q.pop("answer_origin", None)
        else:
            q["answer"] = answer
            q["answered"] = True
            q["answer_origin"] = "user"

        self._refresh_asking_state(sess)

        self.store.put(sess)
        return _public_state(sess)

    # -- Attachments API --------------------------------------------------
    #
    # Called by server.py right after the file bytes are saved (local disk or
    # S3, via attachments.save_attachment). Not part of the chat turn itself —
    # the UI calls this via a dedicated upload endpoint, then the NEXT chat
    # turn (user saying "done") is what actually finalizes the ticket.

    def record_attachment(self, session_id: str, attachment: Dict[str, Any]) -> Dict[str, Any]:
        sess = self.store.get(session_id)
        if sess is None:
            raise ValueError(f"Unknown session: {session_id}")
        if sess["phase"] != PHASE_ATTACHMENTS:
            raise ValueError(
                f"Session is in phase {sess['phase']!r}; attachments are only "
                f"accepted during {PHASE_ATTACHMENTS!r}."
            )
        sess.setdefault("attachments", []).append(attachment)
        self.store.put(sess)
        return sess

    # -- Phase 3: collecting attachments -------------------------------------

    def _is_done_signal(self, user_message: str) -> bool:
        text = (user_message or "").lower()
        return any(phrase in text for phrase in _DONE_PHRASES)

    def _finalize_ticket_if_ready(self, sess: Dict[str, Any]) -> Optional[str]:
        """
        If the user has signaled they're done AND at least one required
        (PPTX) attachment is present, create the ticket and move to complete.
        Returns a reply suffix to append, or None if not finalized.
        """
        attachments = sess.get("attachments", [])
        if not has_required_attachment(attachments):
            names = ", ".join(a.get("filename", "?") for a in attachments) or "(none)"
            return (
                "\n\nI still need at least one **PowerPoint (.pptx)** "
                "solution/data-flow diagram attached before I can submit — "
                f"currently attached: {names}. Please upload the PPTX and let "
                "me know when it's ready."
            )
        ticket = self._create_ticket(sess)
        sess["ticket"] = ticket
        sess["phase"] = PHASE_COMPLETE
        return f"\n\nAll set. Submitted as ticket **{ticket['ticket_id']}**."

    def _step_attachments(
        self, sess: Dict[str, Any], user_message: str
    ) -> Tuple[str, Dict[str, Any]]:
        if self._is_done_signal(user_message):
            suffix = self._finalize_ticket_if_ready(sess)
            if suffix:
                return suffix.lstrip("\n"), sess
        attachments = sess.get("attachments", [])
        if attachments:
            names = ", ".join(a.get("filename", "?") for a in attachments)
            return (
                f"Got it — I see {names} attached so far. Let me know when "
                "you're done uploading (or upload another file) and I'll "
                "submit the request."
            ), sess
        return ATTACHMENT_PROMPT, sess

    async def _step_attachments_stream(self, sess: Dict[str, Any], user_message: str):
        if self._is_done_signal(user_message):
            suffix = self._finalize_ticket_if_ready(sess)
            if suffix:
                yield {"type": "delta", "text": suffix.lstrip("\n")}
                return
        attachments = sess.get("attachments", [])
        if attachments:
            names = ", ".join(a.get("filename", "?") for a in attachments)
            yield {
                "type": "delta",
                "text": (
                    f"Got it — I see {names} attached so far. Let me know when "
                    "you're done uploading (or upload another file) and I'll "
                    "submit the request."
                ),
            }
        else:
            yield {"type": "delta", "text": ATTACHMENT_PROMPT}

    # -- Streaming API --------------------------------------------------------
    #
    # handle_message_stream yields dict events:
    #   {"type": "delta", "text": "<chunk>"}          -> append to current reply
    #   {"type": "state", <full state snapshot>}      -> final state after turn
    #   {"type": "error", "message": "..."}           -> error condition
    # Consumers should treat the "state" event as authoritative for phase,
    # collected_fields, activated_teams, focus_team, pending_questions, ticket.

    async def handle_message_stream(
        self,
        session_id: str,
        user_message: str,
        focused_field: Optional[Dict[str, Any]] = None,
    ):
        sess = self.store.get(session_id)
        if sess is None:
            yield {"type": "error", "message": f"Unknown session: {session_id}"}
            return
        focus_hint = _focus_hint_from_field(focused_field)

        # Record the user turn in the UI-visible transcript before we run the
        # LLM, so a mid-turn crash still keeps the user's message on record.
        sess.setdefault("ui_messages", []).append(
            {"role": "user", "content": user_message}
        )

        reply_buffer: List[str] = []

        try:
            if sess["phase"] == PHASE_ROUTING:
                async for evt in self._step_routing_stream(sess, user_message, focus_hint):
                    if evt.get("type") == "delta":
                        reply_buffer.append(evt.get("text") or "")
                    yield evt
            elif sess["phase"] == PHASE_ASKING:
                async for evt in self._step_asking_stream(sess, user_message, focus_hint):
                    if evt.get("type") == "delta":
                        reply_buffer.append(evt.get("text") or "")
                    yield evt
            elif sess["phase"] == PHASE_ATTACHMENTS:
                async for evt in self._step_attachments_stream(sess, user_message):
                    if evt.get("type") == "delta":
                        reply_buffer.append(evt.get("text") or "")
                    yield evt
            elif sess["phase"] == PHASE_COMPLETE:
                completion_msg = (
                    "This request has already been submitted. "
                    f"Ticket: {sess.get('ticket', {}).get('ticket_id')}."
                )
                reply_buffer.append(completion_msg)
                yield {"type": "delta", "text": completion_msg}
            else:
                yield {"type": "error", "message": f"Unknown phase: {sess['phase']}"}
                return
        except Exception as e:
            yield {"type": "error", "message": f"{type(e).__name__}: {e}"}
            # Persist even on error so the user turn isn't lost.
            self.store.put(sess)
            return

        # Persist the agent's full reply as one UI message + snapshot state.
        sess["ui_messages"].append({"role": "agent", "content": "".join(reply_buffer)})
        self.store.put(sess)

        yield {"type": "state", **_public_state(sess)}

    async def _step_routing_stream(
        self,
        sess: Dict[str, Any],
        user_message: str,
        focus_hint: Optional[str] = None,
    ):
        agent = build_routing_agent(messages=sess["chat_history"], focus_hint=focus_hint)
        async for text in _stream_agent_text(agent, user_message):
            yield {"type": "delta", "text": text}

        sess["chat_history"] = list(agent.messages)

        try:
            extracted: RoutingFields = extract_routing_fields(sess["chat_history"])
            new_fields = {k: v for k, v in extracted.model_dump().items() if v is not None}
        except Exception as e:  # pragma: no cover
            new_fields = {}
            yield {"type": "delta", "text": f"\n\n[debug: routing extraction failed: {e}]"}

        sess["collected_fields"].update(new_fields)
        _fill_project_name_fallback(sess["collected_fields"])

        if self._maybe_advance_from_routing(sess):
            team_order = sess.get("team_order") or []
            if self.demo_mode and team_order:
                team_list = ", ".join(team_order)
                yield {
                    "type": "delta",
                    "text": (
                        f"\n\nGreat — I have what I need. This request needs review "
                        f"from {len(team_order)} team(s): {team_list}. I'll ask a "
                        "few questions on behalf of each, one team at a time, so "
                        "we can wrap this up in one sitting.\n\n"
                    ),
                }
            else:
                yield {
                    "type": "delta",
                    "text": "\n\nGreat — I have what I need. A few review questions:\n\n",
                }
            # Auto-kickoff Q&A in the same turn so the user sees the first
            # question streamed in right after the routing summary.
            async for evt in self._kickoff_qa_stream(sess):
                yield evt

    async def _kickoff_qa_stream(self, sess: Dict[str, Any]):
        """
        Streaming Q&A kickoff.

        Builds the qa_agent with fresh (empty) history and streams its first
        question or two. Saves qa_agent.messages back into sess["chat_history"]
        so the next real user turn continues that same qa_agent thread.

        The internal user seed message ("Please begin by asking the first
        review question.") is only visible to the LLM — the UI's message log
        never sees it because the UI only appends what the human typed.
        """
        qa_agent = build_qa_agent(
            pending_questions=sess["pending_questions"],
            messages=[],
            routing_context=sess["collected_fields"],
        )
        seed_prompt = (
            "Please begin the review-question phase now. Ask me the first one "
            "or two open questions from your list."
        )
        async for text in _stream_agent_text(qa_agent, seed_prompt):
            yield {"type": "delta", "text": text}
        sess["chat_history"] = list(qa_agent.messages)

    async def _step_asking_stream(
        self,
        sess: Dict[str, Any],
        user_message: str,
        focus_hint: Optional[str] = None,
    ):
        agent = build_qa_agent(
            pending_questions=sess["pending_questions"],
            messages=sess["chat_history"],
            routing_context=sess["collected_fields"],
            focus_hint=focus_hint,
        )
        async for text in _stream_agent_text(agent, user_message):
            yield {"type": "delta", "text": text}

        sess["chat_history"] = list(agent.messages)

        try:
            extracted: AnswerBatch = extract_answer_batch(
                sess["pending_questions"], sess["chat_history"]
            )
            self._record_answers(sess, extracted)
        except Exception as e:  # pragma: no cover
            yield {"type": "delta", "text": f"\n\n[debug: answer extraction failed: {e}]"}

        if self._refresh_asking_state(sess):
            yield {"type": "delta", "text": "\n\n" + ATTACHMENT_PROMPT}
        # Team-to-team transitions are handled by the qa_agent itself (see
        # QA_SYSTEM_PROMPT_TEMPLATE) since it already knows the full pending
        # list grouped by team category — no code-injected transition text
        # needed here, which would risk duplicating what the agent just said.


# ---------------------------------------------------------------------------

def _result_text(agent_result: Any) -> str:
    """Pull the reply text out of Strands' AgentResult."""
    if agent_result is None:
        return ""
    msg = getattr(agent_result, "message", None)
    if isinstance(msg, dict):
        content = msg.get("content")
        if isinstance(content, list) and content and isinstance(content[0], dict):
            return content[0].get("text", "")
    return str(agent_result)


def _slug(name: str) -> str:
    """Cheap slug for building stable canonical ids from team names."""
    return "_".join(name.replace("/", " ").replace("-", " ").split())


def _public_state(sess: Dict[str, Any]) -> Dict[str, Any]:
    """
    The state shape a client needs to render, without internal-only keys
    like chat_history. Shared by handle_message, handle_message_stream's
    "state" event, and the direct-write endpoints (set_routing_field /
    set_answer) so all four return the exact same shape.
    """
    return {
        "phase": sess["phase"],
        "display_id": sess.get("display_id"),
        "user_id": sess.get("user_id"),
        "created_at": sess.get("created_at"),
        "updated_at": sess.get("updated_at"),
        "collected_fields": sess["collected_fields"],
        "activated_teams": sess["activated_teams"],
        "focus_team": sess.get("focus_team"),
        "team_order": sess.get("team_order", []),
        "pending_questions": sess["pending_questions"],
        "team_forms": sess["team_forms"],
        "attachments": sess.get("attachments", []),
        "ticket": sess.get("ticket"),
    }


def _focus_hint_from_field(focused_field: Optional[Dict[str, Any]]) -> Optional[str]:
    """
    Build the short focus_hint string intake_agent's system prompts use, from
    the {"name"/"canonical_id", "label", "description"} the client sends
    alongside a chat turn to say which workflow-form field is focused.
    """
    if not focused_field:
        return None
    label = (
        focused_field.get("label")
        or focused_field.get("name")
        or focused_field.get("canonical_id")
    )
    if not label:
        return None
    description = focused_field.get("description")
    return f"{label} — {description}" if description else str(label)


def _fill_project_name_fallback(collected_fields: Dict[str, Any]) -> None:
    """
    Safety net: project_name is a required routing field, but the LLM may
    not always propose one on its own even when instructed to (prompt
    compliance isn't guaranteed). If we already have a project_description
    but no project_name, derive a short placeholder name deterministically
    so Phase 1 can never get stuck waiting on this one cosmetic field.
    """
    if collected_fields.get("project_name"):
        return
    description = collected_fields.get("project_description")
    if not description:
        return
    words = description.strip().split()
    short = " ".join(words[:6])
    if len(words) > 6:
        short += "…"
    collected_fields["project_name"] = short or "Untitled Project"


async def _stream_agent_text(agent: Any, user_message: str):
    """
    Iterate a Strands Agent's streaming events and yield text deltas.

    strands.Agent surfaces streaming as {"data": "<chunk>", ...} events for
    text deltas. We also tolerate contentBlockDelta shapes so this helper
    stays reusable if the underlying model provider changes.
    """
    async for event in agent.stream_async(user_message):
        if isinstance(event, dict) and isinstance(event.get("data"), str):
            yield event["data"]
