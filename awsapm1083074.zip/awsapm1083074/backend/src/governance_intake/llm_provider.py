# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
LLM provider seam for the post-dedup features.

The production target is the EHAP gateway (ehap_model.py). For local
development the same code can run against:
  - the ehap-mock server (set EHAP_URL=http://127.0.0.1:4100 with any
    client id/secret — exercises the real EHAP wire shape), or
  - the Anthropic API directly (EHAP_PROVIDER=anthropic + ANTHROPIC_API_KEY),
    for development before EHAP credentials exist.

Selection:
  EHAP_PROVIDER=ehap       -> EHAP gateway (default when EHAP creds are set)
  EHAP_PROVIDER=anthropic  -> Anthropic API (requires ANTHROPIC_API_KEY and
                              the `anthropic` optional dependency group)
  unset                    -> EHAP if its creds are present, else Anthropic
                              if ANTHROPIC_API_KEY is present, else error.

All LLM call sites route through this seam -- intake_agent.py's routing/QA
agents and both structured extractors, plus prefill/qa_review -- so local
development works without real EHAP credentials.
"""

from __future__ import annotations

import os
from typing import Any

DEFAULT_ANTHROPIC_MODEL_ID = "claude-sonnet-4-5"


def _anthropic_model() -> Any:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("EHAP_PROVIDER=anthropic requires ANTHROPIC_API_KEY.")
    try:
        from strands.models.anthropic import AnthropicModel
    except ImportError as e:  # pragma: no cover - env-dependent
        raise RuntimeError(
            "The anthropic provider needs the optional dependency group: "
            "uv sync --extra anthropic"
        ) from e
    return AnthropicModel(
        client_args={"api_key": api_key},
        model_id=os.environ.get("ANTHROPIC_MODEL_ID", DEFAULT_ANTHROPIC_MODEL_ID),
        max_tokens=4096,
    )


# The literal placeholders shipped in .env.example. A .env copied verbatim
# from the example "has" EHAP credentials that can never work — treat them
# as absent so the Anthropic fallback can kick in instead of a guaranteed
# auth failure against the real gateway.
_PLACEHOLDER_EHAP_VALUES = {"your-client-id", "your-client-secret"}


def get_model() -> Any:
    """Resolve the model for LLM calls (see module docstring)."""
    provider = (os.environ.get("EHAP_PROVIDER") or "").strip().lower()
    have_ehap = all(
        os.environ.get(k) not in (None, "", *_PLACEHOLDER_EHAP_VALUES)
        for k in ("EHAP_URL", "EHAP_CLIENT_ID", "EHAP_CLIENT_SECRET")
    )

    if provider == "anthropic":
        return _anthropic_model()
    if provider == "ehap" or have_ehap:
        from .ehap_model import get_ehap_model

        return get_ehap_model()
    if os.environ.get("ANTHROPIC_API_KEY"):
        return _anthropic_model()
    raise RuntimeError(
        "No LLM provider configured: set EHAP_URL/EHAP_CLIENT_ID/"
        "EHAP_CLIENT_SECRET (EHAP or ehap-mock), or ANTHROPIC_API_KEY."
    )
