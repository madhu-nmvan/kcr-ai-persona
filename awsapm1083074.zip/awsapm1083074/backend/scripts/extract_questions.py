#!/usr/bin/env python3
# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Deterministic, zero-LLM extractor for the governance requirements source
document ("Enhanced ELV Gov_Requirements_AI PRODUCTION.docx" or successor).

Walks word/document.xml directly (no python-docx dependency), splits into the
doc's three Heading1 sections, and for each canonical team in
data/team_roster.json pulls:
  - every paragraph of text under that team's heading in "Governance Teams
    Trigger Logic" (trigger conditions + any embedded full-text questions)
  - every paragraph of text under that team's heading in "Questionnaires by
    Governance Team" (the team's own question list, where one exists)
  - every image filename under that team's heading in "Other Gov Team Intake
    Form Screen Shots" (reference-only screenshots needing OCR)

Output per team, under data/extracted_questions/<slug>/:
  - questions.txt   human-readable, section-labeled, verbatim text
  - images/*.png    copied screenshots (only for teams that have any)
  - record.json     structured version of the same, with paragraph-index
                     provenance for traceability

Also writes data/extracted_questions/coverage_report.json summarizing what
each team got, so gaps are a diff against team_roster.json, not a manual
re-read of the doc.

Usage: place the source .docx at backend/scripts/source/<filename>.docx and
run `python backend/scripts/extract_questions.py`. This script does not call
any LLM and produces identical output on repeat runs against the same input
file.

Re-run procedure (see docs/EXTRACTION_MANIFEST.md): if Elevance supplies the
missing source docs (current-state GovHub intake form, RAI vendor
questionnaire, OAGC/IAM/Privacy-Law reference files), drop them in
backend/scripts/source/ and extend SECTION_NAMES / team_roster.json
accordingly, then re-run.
"""
import html
import json
import re
import zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SOURCE_DIR = SCRIPT_DIR / "source"
DATA_DIR = SCRIPT_DIR.parent / "src" / "governance_intake" / "data"
ROSTER = DATA_DIR / "team_roster.json"
OUT_DIR = DATA_DIR / "extracted_questions"

SECTION_NAMES = {
    "trigger": "Governance Teams Trigger Logic",
    "questionnaire": "Questionnaires by Governance Team",
    "screenshots": "Other Gov Team Intake Form Screen Shots – Reference Only, Not Comprehensive",
}

ID_PATTERN = re.compile(r"\b([A-Z]{1,4}\.\d+[a-z]?)\b")


def _find_docx() -> Path:
    candidates = sorted(SOURCE_DIR.glob("*.docx"))
    if not candidates:
        raise FileNotFoundError(
            f"No .docx found in {SOURCE_DIR}. Place the governance requirements "
            "source document there before running this script."
        )
    return candidates[0]


def slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    return re.sub(r"_+", "_", s)


def load_docx_paragraphs(docx_path: Path):
    with zipfile.ZipFile(docx_path) as z:
        xml = z.read("word/document.xml").decode("utf-8")
        rels = z.read("word/_rels/document.xml.rels").decode("utf-8")
    rid_map = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="media/([^"]+)"', rels))
    paras = re.findall(r"<w:p\b.*?</w:p>", xml, re.S)

    records = []
    for p in paras:
        text = html.unescape("".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", p, re.S)))
        style_m = re.search(r'<w:pStyle w:val="([^"]+)"', p)
        style = style_m.group(1) if style_m else None
        img_ids = re.findall(r'r:embed="(rId\d+)"', p)
        images = [rid_map[i] for i in img_ids if i in rid_map]
        records.append({"text": text, "style": style, "images": images})
    return records


def segment_by_heading1(paragraphs):
    """Return {heading1_text: [(idx, style, text, images), ...]}"""
    sections = {}
    current = None
    for idx, rec in enumerate(paragraphs):
        if rec["style"] == "Heading1":
            current = rec["text"].strip()
            sections[current] = []
        elif current is not None:
            sections[current].append((idx, rec["style"], rec["text"], rec["images"]))
    return sections


def split_by_heading2(entries):
    """Given a Heading1 section's entries, split into {heading2_text: [(idx, text, images), ...]}"""
    out = {}
    current = None
    for idx, style, text, images in entries:
        if style == "Heading2":
            current = text.strip()
            out[current] = []
        elif current is not None:
            out[current].append((idx, text, images))
    return out


def main():
    docx_path = _find_docx()
    roster = json.loads(ROSTER.read_text(encoding="utf-8"))
    paragraphs = load_docx_paragraphs(docx_path)
    sections = segment_by_heading1(paragraphs)

    trigger_by_heading = split_by_heading2(sections[SECTION_NAMES["trigger"]])
    quest_by_heading = split_by_heading2(sections[SECTION_NAMES["questionnaire"]])
    shots_by_heading = split_by_heading2(sections[SECTION_NAMES["screenshots"]])

    coverage = []

    for team in roster["teams"]:
        canonical = team["canonical_name"]
        slug = slugify(canonical)
        team_dir = OUT_DIR / slug
        team_dir.mkdir(parents=True, exist_ok=True)

        trigger_entries = trigger_by_heading.get(team.get("docx_trigger_heading") or "", [])
        quest_entries = quest_by_heading.get(team.get("docx_questionnaire_heading") or "", [])
        shot_entries = shots_by_heading.get(team.get("docx_screenshot_heading") or "", [])

        # collect coded question IDs embedded in trigger text (full-text questions, not just conditions)
        embedded_ids = []
        for idx, text, _imgs in trigger_entries:
            for m in ID_PATTERN.finditer(text):
                embedded_ids.append({"id": m.group(1), "para_index": idx, "text": text.strip()})

        image_files = []
        for idx, text, imgs in shot_entries:
            image_files.extend(imgs)

        record = {
            "canonical_name": canonical,
            "slug": slug,
            "status": team.get("status"),
            "trigger_logic": [
                {"para_index": idx, "text": text.strip()}
                for idx, text, _ in trigger_entries
                if text.strip()
            ],
            "embedded_trigger_questions": embedded_ids,
            "questionnaire_text": [
                {"para_index": idx, "text": text.strip()}
                for idx, text, _ in quest_entries
                if text.strip()
            ],
            "screenshot_images": image_files,
        }

        (team_dir / "record.json").write_text(json.dumps(record, indent=2))

        # human-readable questions.txt
        lines = [f"# {canonical}", ""]
        if record["trigger_logic"]:
            lines.append("## Trigger Logic (conditions + embedded full-text questions)")
            for e in record["trigger_logic"]:
                lines.append(f"- {e['text']}")
            lines.append("")
        if record["questionnaire_text"]:
            lines.append("## Questionnaire (team's own question list, as written)")
            for e in record["questionnaire_text"]:
                lines.append(f"- {e['text']}")
            lines.append("")
        if image_files:
            lines.append(f"## Screenshots requiring OCR ({len(image_files)} images, see images/)")
            lines.append("")
        (team_dir / "questions.txt").write_text("\n".join(lines))

        # copy images
        if image_files:
            img_dir = team_dir / "images"
            img_dir.mkdir(exist_ok=True)
            with zipfile.ZipFile(docx_path) as z:
                for fname in image_files:
                    data = z.read(f"word/media/{fname}")
                    (img_dir / fname).write_bytes(data)

        has_trigger_text = len(record["trigger_logic"]) > 0
        has_quest_text = len(record["questionnaire_text"]) > 0
        has_images = len(image_files) > 0
        coverage.append({
            "canonical_name": canonical,
            "slug": slug,
            "roster_status": team.get("status"),
            "trigger_logic_paragraphs": len(record["trigger_logic"]),
            "questionnaire_paragraphs": len(record["questionnaire_text"]),
            "embedded_question_ids": sorted({e["id"] for e in embedded_ids}),
            "screenshot_images": len(image_files),
            "has_any_content": has_trigger_text or has_quest_text or has_images,
            "needs_ocr": has_images,
        })

    (OUT_DIR / "coverage_report.json").write_text(json.dumps(coverage, indent=2))

    empty = [c["canonical_name"] for c in coverage if not c["has_any_content"]]
    needs_ocr = [c["canonical_name"] for c in coverage if c["needs_ocr"]]
    print(f"Extracted {len(coverage)} teams.")
    print(f"Teams with ZERO content (flag for [AWS]/[Elevance] follow-up): {empty}")
    print(f"Teams needing OCR ({len(needs_ocr)}): {needs_ocr}")


if __name__ == "__main__":
    main()
