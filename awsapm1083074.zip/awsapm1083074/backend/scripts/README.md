# Offline extraction / dedup scripts

Standalone, zero-app-runtime tools that regenerate the config data in
[`backend/src/governance_intake/data/`](../src/governance_intake/data/)
(`questionnaires.json`, `dedup_mapping.json`, `trigger_rules.json`, and the
per-team `extracted_questions*/` trees) from the original governance source
documents. Not imported by the running app — run by hand, output committed.

None of these take real source documents from anywhere checked in: drop
input files in `backend/scripts/source/` (gitignored) before running.

## Pipeline order

```
extract_questions.py ──┐
                        ├──> dedup_questions.py ──> audit_dedup.py
extract_xlsx_questions.py ─┘

extract_govhub_form.py   (standalone — separate source, see below)
```

| Script | Source doc | Output | Notes |
|---|---|---|---|
| `extract_questions.py` | Governance requirements `.docx` (walks `word/document.xml` directly, no `python-docx`) | `data/extracted_questions/<team>/{questions.txt,record.json}` | Zero-LLM, deterministic (byte-identical output on re-run). Source of trigger logic; questions are superseded per-team by the xlsx below. |
| `extract_xlsx_questions.py` | `Gov Team Reqs by Service Catalog Types.xlsx` | `data/extracted_questions_xlsx/<team>/record.json` | Zero-LLM. Source of truth for each team's actual review *questions* (docx stays authoritative for trigger logic only) — see `dedup_questions.py`'s docstring for the exact merge rule. |
| `dedup_questions.py` | Both `extracted_questions*/` trees above | `data/questionnaires.json`, `data/dedup_mapping.json` | First-draft Tier-2 canonicalization: xlsx-primary merge per team, then clusters the merged question set by local-embedding cosine similarity (`all-MiniLM-L6-v2` via `fastembed`). `question_dedup.py` (the app's runtime consumer) only reads the two output files — it doesn't care how they were produced. |
| `audit_dedup.py` | `dedup_mapping.json` + `questionnaires.json` + `trigger_rules.json` | report (stdout, optional `--json`) | Read-only. Cross-checks referential integrity and double-coverage (hard failures, non-zero exit) plus heuristic corpus-quality findings (headings, near-duplicates — reported but never fail the run). |
| `extract_govhub_form.py` | Live GovHub ServiceNow catalog item, saved as a browser HTML snapshot | (reference-only extraction, not part of the questionnaire pipeline above) | Different source shape entirely — Angular-rendered HTML, walked structurally via BeautifulSoup/lxml rather than regex, because label text repeats unpredictably across a field's markup. |

See each script's module docstring for the full extraction/merge algorithm —
this table is the map, not the manual. `docs/EXTRACTION_MANIFEST.md` and
`docs/DEDUP_AUDIT.md` cover the specific runs that produced the data
currently checked in.
