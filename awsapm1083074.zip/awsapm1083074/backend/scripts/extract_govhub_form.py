#!/usr/bin/env python3
# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Deterministic, zero-LLM extractor for the live GovHub ServiceNow Service
Portal catalog item ("TGOV Catalog Item - Governance Hub"), saved locally as
a browser "Save As... Complete Webpage" HTML snapshot.

Unlike extract_questions.py's source (a clean OOXML .docx, parsed by walking
word/document.xml directly), this source is real-world Angular-rendered
HTML: BeautifulSoup (+lxml) is used to walk the DOM structurally instead of
regex-scanning raw text, because the same label text repeats unpredictably
throughout each field's markup (aria-label attributes, tooltip spans,
select2's cloned accessibility markup) and only structural DOM traversal can
reliably tell "the same field, mentioned five times" from "five different
fields."

Structure this relies on:
  - each form field lives in exactly one `<div class="form-group">` wrapper
  - the field's ONE canonical label lives in
    `<label class="field-label ...">` -> the child
    `<span class="sp-field-label-padding ng-binding">` (other spans in the
    same label carry the "required" decoration or a help-tooltip icon, not
    the question text)
  - the field's type is read off the `type-<x>` class on the
    `<span class="type-<x> field-actual ...">` wrapper. This is a more
    reliable type signal than the `ng-switch-when="..."` HTML comments
    littered throughout every field-actual span: those comments enumerate
    EVERY branch Angular's ngSwitch template supports, not just the one
    that actually rendered.
  - the field's stable identity -- used for dedup, since the DOM repeats
    label text far more often than it repeats real fields -- is the
    `name=` attribute on the actual rendered `<input>`/`<select>`/
    `<textarea>` (id="sp_formfield_<name>"), falling back to the label's
    `for=` attribute, falling back to the field's `..._fieldmsgs_container`
    id, for the handful of fields (Save/Load Draft buttons, static
    instructional text blocks) rendered via a custom Angular widget instead
    of a standard form control.

Coded question IDs (GI.1, D.3, PI.4a, ...) are parsed off the front of the
label text with a regex; fields whose label has no such prefix are still
included (coded_id: null) -- completeness matters more than a tidy subset.

Some fields (ServiceNow field type `glide_list`, e.g. RBI.7 "what data will
the solution leverage", PI.4a "which vendors have access to Protected
Information") are multi-select pickers whose choices are populated live from
a ServiceNow reference table via AJAX and never appear as static <option>
markup in this snapshot -- for those, options is emitted as null rather than
a misleading empty list, so "genuinely no options" and "options exist but
aren't visible in this snapshot" stay distinguishable.

Usage: place the saved HTML at backend/scripts/source/govhub_form/*.html and
run `python backend/scripts/extract_govhub_form.py`. No LLM calls; produces
byte-identical output on repeat runs against the same input file.
"""

import json
import re
from pathlib import Path

from bs4 import BeautifulSoup
from bs4.element import Comment, Tag

SCRIPT_DIR = Path(__file__).resolve().parent
SOURCE_DIR = SCRIPT_DIR / "source" / "govhub_form"
DATA_DIR = SCRIPT_DIR.parent / "src" / "governance_intake" / "data"
OUT_PATH = DATA_DIR / "govhub_catalog_fields.json"

FORMFIELD_PREFIX = "sp_formfield_"
FIELDMSGS_SUFFIX = "_fieldmsgs_container"

CODED_ID_RE = re.compile(r"^([A-Z]{1,4}\.\d+[a-z]?)\s+(.*)$", re.S)

# ServiceNow field types that render as reference-table pickers (single or
# multi) whose choice list is populated live via AJAX -- never present as
# static <option> markup in a saved snapshot.
DYNAMIC_REFERENCE_TYPES = {"reference", "glide_list"}


def _find_html() -> Path:
    candidates = sorted(SOURCE_DIR.glob("*.html"))
    if not candidates:
        raise FileNotFoundError(
            f"No .html found in {SOURCE_DIR}. Place the saved GovHub catalog "
            "item page there before running this script."
        )
    return candidates[0]


def _visible_text(el: Tag) -> str:
    """Text of el's descendants, excluding Angular's ngIf/ngSwitch/ngRepeat
    HTML comments (which BeautifulSoup's get_text() would otherwise include,
    since Comment is itself a NavigableString subclass)."""
    parts = [s.strip() for s in el.find_all(string=True) if not isinstance(s, Comment)]
    return " ".join(p for p in parts if p)


def _label_text(form_group: Tag) -> str | None:
    label = form_group.find("label", class_="field-label")
    if label is None:
        return None
    for span in label.find_all("span"):
        classes = span.get("class") or []
        if "ng-binding" in classes and "sp-field-label-padding" in classes:
            text = span.get_text(strip=True)
            if text:
                return text
    return None


def _widget_type(field_actual: Tag) -> str:
    for cls in field_actual.get("class") or []:
        if cls.startswith("type-"):
            return cls[len("type-"):]
    return "unknown"


def _identity(form_group: Tag, field_actual: Tag) -> str | None:
    """Stable field identity: the name= on the real rendered input/select/
    textarea, falling back to the label's for= attribute, falling back to
    the field's message-container id -- for the few fields rendered via a
    custom widget instead of a standard form control."""
    widget = field_actual.find(
        ["select", "input", "textarea"],
        id=lambda i: i and i.startswith(FORMFIELD_PREFIX),
    )
    if widget is not None:
        name = widget.get("name")
        if name:
            return name
        return widget["id"][len(FORMFIELD_PREFIX):]

    label = form_group.find("label", class_="field-label")
    for_id = label.get("for") if label is not None else None
    if for_id and for_id.startswith(FORMFIELD_PREFIX):
        return for_id[len(FORMFIELD_PREFIX):]

    container = form_group.find(
        id=lambda i: i and i.startswith(FORMFIELD_PREFIX) and i.endswith(FIELDMSGS_SUFFIX)
    )
    if container is not None:
        raw = container["id"][len(FORMFIELD_PREFIX):-len(FIELDMSGS_SUFFIX)]
        return raw or None

    return None


def _options(field_actual: Tag, widget_type: str) -> list[str] | None:
    if widget_type in DYNAMIC_REFERENCE_TYPES:
        return None
    opts = [
        opt.get_text(strip=True)
        for opt in field_actual.find_all("option")
        if (opt.get("value") or "") != ""
    ]
    return opts or None


def _is_multi_select(field_actual: Tag, widget_type: str) -> bool:
    if widget_type == "glide_list":
        return True
    select = field_actual.find("select", id=lambda i: i and i.startswith(FORMFIELD_PREFIX))
    return bool(select is not None and select.has_attr("multiple"))


def extract_fields(soup: BeautifulSoup) -> list[dict]:
    records = []
    seen_identities: set[str] = set()

    for form_group in soup.find_all("div", class_="form-group"):
        field_actual = form_group.find("span", class_="field-actual")
        if field_actual is None:
            continue  # page chrome (cart/price widget, draft-button host div, submit button) -- not a form field

        identity = _identity(form_group, field_actual)
        if identity is None or identity in seen_identities:
            continue
        seen_identities.add(identity)

        label = _label_text(form_group)
        coded_id = None
        question_text = label
        if label:
            m = CODED_ID_RE.match(label)
            if m:
                coded_id, question_text = m.group(1), m.group(2).strip()

        if not question_text:
            # No structured field-label at all (Save/Load Draft buttons,
            # static instructional text blocks): fall back to the widget's
            # own visible text, then to a humanized form of its identity --
            # never fabricated content, only what the DOM itself provides.
            question_text = _visible_text(field_actual) or identity.replace("_", " ").strip()

        widget_type = _widget_type(field_actual)
        records.append(
            {
                "coded_id": coded_id,
                "label": question_text,
                "internal_name": identity,
                "widget_type": widget_type,
                "options": _options(field_actual, widget_type),
                "multi_select": _is_multi_select(field_actual, widget_type),
            }
        )

    records.sort(key=lambda r: (r["coded_id"] is None, r["coded_id"] or "", r["internal_name"]))
    return records


def main() -> None:
    html_path = _find_html()
    soup = BeautifulSoup(html_path.read_text(encoding="utf-8", errors="replace"), "lxml")
    fields = extract_fields(soup)
    coded = [f for f in fields if f["coded_id"]]

    source_rel = html_path.relative_to(SCRIPT_DIR.parent.parent)
    output = {
        "description": (
            "Form fields extracted from the live GovHub ServiceNow Service Portal catalog "
            "item ('TGOV Catalog Item - Governance Hub'), captured via browser "
            "'Save As... Complete Webpage' on 2026-07-15 and extracted deterministically "
            f"(no LLM calls) by backend/scripts/extract_govhub_form.py from {source_rel}."
        ),
        "fields": fields,
    }

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(json.dumps(output, indent=2) + "\n")

    print(f"Extracted {len(fields)} total fields ({len(coded)} with coded IDs).")
    print(f"Coded IDs found ({len(coded)}): {sorted({f['coded_id'] for f in coded})}")


if __name__ == "__main__":
    main()
