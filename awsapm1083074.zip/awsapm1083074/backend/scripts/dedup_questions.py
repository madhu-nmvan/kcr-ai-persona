#!/usr/bin/env python3
# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
First-draft Tier-2 canonicalization: cluster Tier-1 team questions into
unified/canonical questions via local embedding similarity.

Reads every team's extracted questions from TWO Tier-1 sources --
backend/src/governance_intake/data/extracted_questions/<slug>/record.json
(docx, via extract_questions.py) and .../extracted_questions_xlsx/<slug>/
record.json (xlsx, via extract_xlsx_questions.py) -- merges them per team
(xlsx primary, novel docx questions folded in; see "xlsx-primary merge"
design decision below), embeds each surviving question's text with a local
model (all-MiniLM-L6-v2, via fastembed -- same model Ei's dedup pipeline uses
in production), clusters the merged set by cosine similarity, and writes:

  - questionnaires.json  -- Tier-1 shape: {"teams": {team_key: {"questions": [...]}}}
  - dedup_mapping.json   -- Tier-2 shape: {"canonical_questions": [...]}

Consumer (question_dedup.py) is unchanged -- it only reads these two files at
runtime and doesn't care how they were produced.

Design decisions (first draft, tune before treating as final):

  - Input scope: only `questionnaire_text` paragraphs (docx side) and the
    question-matrix rows (xlsx side). Screenshot-derived content (7 teams,
    see team_roster.json notes) is deliberately excluded -- per Gan
    (2026-07-14), some of those fields are closed dropdowns with no visible
    option list, so feeding them into dedup would embed a question with an
    unknown answer domain. `trigger_logic`/`embedded_trigger_questions` are
    also excluded -- those are Tier-0 routing fields, already covered by
    intake_schema.json, not part of the Tier-1/Tier-2 questionnaire.

  - xlsx-primary merge (added 2026-07-15, per [AWS]/Gan's review -- see
    XLSX_RECONCILIATION.md from the investigation that preceded this): the
    xlsx workbook ("Gov Team Reqs by Service Catalog Types.xlsx") is the
    source of truth for each team's actual review questions; the docx stays
    authoritative for trigger logic only (unchanged). For each team with
    both an xlsx- and docx-extracted question set: ALL of that team's xlsx
    questions are kept unconditionally, and a docx question is kept only if
    it is "new" -- its embedding's max cosine similarity against every xlsx
    question for that SAME team is below --docx-novelty-threshold (default
    0.85, deliberately reusing --low-threshold's default rather than
    inventing a second "same question" cutoff in this embedding space).
    Calibrated against real pairs from the reconciliation investigation:
    a genuine near-duplicate paraphrase ("AI Program Office uses the gov and
    RAI intake forms as well." vs. "AI Program Office leverages the GovHub
    intake form and the RAI assessments." -- difflib ratio 0.66, clearly the
    same underlying question) scores 0.890 cosine; the closest same-topic but
    genuinely DIFFERENT question pair found ("What is the vendor name?" vs.
    "Are you using a vendor to support development or deliver the
    solution?") scores 0.684. 0.85 sits cleanly between those two real
    examples, so it drops the former as already-covered and keeps the
    latter as novel. Teams with no xlsx match (e.g. Clinical Partnership
    Review, which has no xlsx tab at all) keep 100% of their docx questions,
    unchanged from before this stage existed. This merge runs BEFORE the
    clustering stage below, on a per-team basis; clustering is otherwise
    untouched and now also does the bulk of the real same-team dedup work
    (see "Same-team clusters" in the run report) since xlsx and docx
    routinely both carry near-identical questions for a shared team.

  - Question detection (docx side): a paragraph is treated as a real
    question if it ends in "?" or opens with a common interrogative/
    imperative word (what, how, describe, please, ...). Everything else
    (section headers, "Notes from X:", descriptive asides) is dropped and
    counted in the run report, not silently discarded -- rerun with
    --dump-skipped to see exactly what was excluded and sanity-check the
    heuristic. The xlsx side has no equivalent heuristic: every non-blank
    question-matrix row is already a real question by construction (see
    extract_xlsx_questions.py), so nothing is filtered there.

  - Known upstream data-quality bug (found while building this): 2 of 32
    teams' questionnaire_text (ai_program_office, security_infosec_office)
    have raw docx run-XML leaked into the extracted text (extract_questions.py
    paragraph-join bug, not something added here). clean_question_text()
    strips it defensively so embeddings aren't computed against XML noise.
    The extractor itself is unfixed -- flagging, not fixing, since that's a
    separate change touching a delivered artifact.

  - Team identifier: team_roster.json's `trigger_rules_key` when present,
    else `canonical_name`. This must match whatever `activated_teams` the
    rule engine produces -- verified against trigger_rules.json's own
    "team" values (e.g. "AI Program Office", "Legal Tech-AI"), which are
    trigger_rules_key, not canonical_name, for teams that have one. The
    xlsx side has no team identifier of its own -- it's joined onto docx
    slugs (extracted_questions_xlsx/*/record.json's `docx_slugs` list) and
    inherits this same team_key through the docx side.

  - Clustering: connected components over a cosine-similarity graph
    (edge if similarity >= --low-threshold, default 0.85 -- same default
    Ei uses for dedup_threshold). This is single-linkage clustering, which
    can transitively over-merge (A~B~C but A!~C) -- the run report flags
    any cluster containing a pair below the threshold so you can see exactly
    where that happened instead of it hiding silently. Clustering itself is
    unchanged by the xlsx-primary merge above; it now simply runs against a
    much richer per-team question set, so same-team clusters (an xlsx
    question and a surviving docx question for the same team turning out to
    be near-duplicates despite passing the novelty check, or two xlsx rows
    that duplicate each other) are far more common than they were with the
    2-team demo stub -- see the run report's same-team-cluster count, which
    exists specifically because those are riskier to eyeball-verify than the
    cross-team clusters this script originally targeted.

  - match_type per source: "exact" if cosine(source, canonical) >= 0.97,
    else "paraphrase". "distinct" (per the Tier-2 shape's own doc comment)
    is a human/LLM judgment call for borderline clusters -- not automated
    here. Singletons are never written to dedup_mapping.json; the existing
    consumer (question_dedup.py) already synthesizes them at runtime.

  - Deterministic & idempotent: local model, fixed thresholds, stable sort
    order for extraction, merge, and canonical-text/ID assignment. Re-running
    against unchanged input (docx + xlsx record.json trees) reproduces
    byte-identical output.

Usage:
    uv run backend/scripts/dedup_questions.py
    uv run backend/scripts/dedup_questions.py --low-threshold 0.80 --exact-threshold 0.95
    uv run backend/scripts/dedup_questions.py --docx-novelty-threshold 0.90
    uv run backend/scripts/dedup_questions.py --dump-skipped
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

DATA_DIR = Path(__file__).resolve().parent.parent / "src" / "governance_intake" / "data"
ROSTER_PATH = DATA_DIR / "team_roster.json"
EXTRACTED_DIR = DATA_DIR / "extracted_questions"
EXTRACTED_XLSX_DIR = DATA_DIR / "extracted_questions_xlsx"
QUESTIONNAIRES_OUT = DATA_DIR / "questionnaires.json"
DEDUP_MAPPING_OUT = DATA_DIR / "dedup_mapping.json"

MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

# Paragraph is a candidate question if it ends in "?" or opens with one of these.
QUESTION_STARTERS = re.compile(
    r"^(what|how|why|when|where|who|which|will|would|does|do|did|is|are|was|were|"
    r"can|could|should|shall|has|have|had|please|describe|explain|list|identify|"
    r"provide|indicate|specify|confirm|summarize|state|name)\b",
    re.IGNORECASE,
)

DOCX_RUN_TAG = re.compile(r"<w:t[^>]*>")


def clean_question_text(raw: str) -> str:
    """Strip leaked docx run-XML (see module docstring) and normalize whitespace."""
    matches = list(DOCX_RUN_TAG.finditer(raw))
    text = raw[matches[-1].end():] if matches else raw
    text = text.replace("\u00a0", " ")
    return re.sub(r"\s+", " ", text).strip()


def is_question_like(text: str) -> bool:
    if not text:
        return False
    return text.rstrip().endswith("?") or bool(QUESTION_STARTERS.match(text.strip()))


def team_key_for(team: dict[str, Any]) -> str:
    """The identifier used consistently across trigger_rules.json / questionnaires.json /
    dedup_mapping.json sources -- trigger_rules_key when the team has one, else canonical_name."""
    return team.get("trigger_rules_key") or team["canonical_name"]


def extract_team_questions(
    slug: str, record: dict[str, Any], prefix: str, skipped: list[dict[str, str]]
) -> list[dict[str, str]]:
    questions = []
    n = 0
    for para in record.get("questionnaire_text", []):
        text = clean_question_text(para["text"])
        if is_question_like(text):
            n += 1
            questions.append({"id": f"{prefix}.{n}", "text": text, "required": True})
        else:
            skipped.append({"team": slug, "para_index": para["para_index"], "text": text})
    return questions


def load_xlsx_questions_by_docx_slug() -> dict[str, list[str]]:
    """docx slug -> ordered list of xlsx-extracted clean_text questions for that
    team, read from extracted_questions_xlsx/<output_slug>/record.json.

    Keyed by docx slug rather than by the xlsx output_slug because one xlsx
    sheet can map to several docx slugs (the FGS/FEP/WellPoint/NGS family
    all share one 'FGS-FEP-WellPoint' sheet -- see extract_xlsx_questions.py's
    docstring); each of those docx slugs gets an identical copy of that
    sheet's question list, mirroring how docx already repeats one shared
    questionnaire block across all 4 of that family's own record.json files."""
    by_docx_slug: dict[str, list[str]] = {}
    if not EXTRACTED_XLSX_DIR.is_dir():
        return by_docx_slug
    for sheet_dir in sorted(EXTRACTED_XLSX_DIR.iterdir()):
        if not sheet_dir.is_dir():
            continue
        record_path = sheet_dir / "record.json"
        if not record_path.exists():
            continue
        record = json.loads(record_path.read_text(encoding="utf-8"))
        if not record.get("structure_matched"):
            continue
        texts = [q["clean_text"] for q in record.get("questions", [])]
        for docx_slug in record.get("docx_slugs", []):
            by_docx_slug[docx_slug] = texts
    return by_docx_slug


def union_find_clusters(n: int, edges: list[tuple[int, int]]) -> list[list[int]]:
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for a, b in edges:
        union(a, b)

    groups: dict[int, list[int]] = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)
    return list(groups.values())


def slugify_canonical_id(text: str, used: set[str]) -> str:
    words = re.findall(r"[A-Za-z]+", text.upper())
    stop = {"THE", "A", "AN", "OF", "TO", "IS", "ARE", "WILL", "WHAT", "HOW", "DOES", "DO"}
    significant = [w for w in words if w not in stop][:3] or words[:2] or ["Q"]
    base = "DEDUP." + "_".join(significant)
    candidate = base
    i = 2
    while candidate in used:
        candidate = f"{base}_{i}"
        i += 1
    used.add(candidate)
    return candidate


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--low-threshold", type=float, default=0.85, help="cosine similarity to join a cluster")
    parser.add_argument("--exact-threshold", type=float, default=0.97, help="cosine similarity for match_type=exact")
    parser.add_argument(
        "--docx-novelty-threshold",
        type=float,
        default=0.85,
        help="cosine similarity above which a docx question is treated as already covered by "
        "an xlsx question from the same team, and dropped before clustering runs (see module "
        "docstring's 'xlsx-primary merge' design decision for how this default was calibrated)",
    )
    parser.add_argument("--dump-skipped", action="store_true", help="print every paragraph excluded as non-question")
    parser.add_argument("--dry-run", action="store_true", help="print the report but don't write output files")
    args = parser.parse_args()

    roster = json.loads(ROSTER_PATH.read_text(encoding="utf-8"))
    teams_by_canonical = {t["canonical_name"]: t for t in roster["teams"]}

    if not EXTRACTED_DIR.is_dir():
        sys.exit(f"Missing {EXTRACTED_DIR} -- run extract_questions.py first.")

    xlsx_questions_by_docx_slug = load_xlsx_questions_by_docx_slug()
    if not EXTRACTED_XLSX_DIR.is_dir():
        print(f"NOTE: {EXTRACTED_XLSX_DIR} missing -- run extract_xlsx_questions.py to enable the xlsx merge.")

    skipped: list[dict[str, str]] = []
    docx_questions_by_team_key: dict[str, list[dict[str, Any]]] = {}
    docx_meta_by_team_key: dict[str, tuple[str, str]] = {}  # team_key -> (docx_slug, question_id_prefix)

    for team_dir in sorted(EXTRACTED_DIR.iterdir()):
        if not team_dir.is_dir():
            continue
        record_path = team_dir / "record.json"
        if not record_path.exists():
            continue
        record = json.loads(record_path.read_text(encoding="utf-8"))
        canonical_name = record["canonical_name"]
        roster_entry = teams_by_canonical.get(canonical_name)
        if roster_entry is None:
            print(f"WARNING: {team_dir.name} canonical_name {canonical_name!r} not in team_roster.json, skipping")
            continue
        prefix = roster_entry["question_id_prefix"]
        team_key = team_key_for(roster_entry)

        questions = extract_team_questions(team_dir.name, record, prefix, skipped)
        docx_questions_by_team_key[team_key] = questions
        docx_meta_by_team_key[team_key] = (team_dir.name, prefix)

    print(f"Teams processed: {len(docx_questions_by_team_key)}")
    print(f"Candidate docx questions extracted: {sum(len(v) for v in docx_questions_by_team_key.values())}")
    print(f"Candidate xlsx questions extracted: {sum(len(v) for v in xlsx_questions_by_docx_slug.values())}")
    print(f"Paragraphs skipped as non-question: {len(skipped)}")
    if args.dump_skipped:
        for s in skipped:
            print(f"  SKIP [{s['team']}#{s['para_index']}] {s['text'][:100]!r}")

    if not any(docx_questions_by_team_key.values()) and not xlsx_questions_by_docx_slug:
        sys.exit("No candidate questions extracted -- nothing to embed.")

    from fastembed import TextEmbedding
    import numpy as np

    print(f"Loading {MODEL_NAME} ...")
    model = TextEmbedding(model_name=MODEL_NAME)

    # --- Stage 1: xlsx-primary merge, per team --------------------------
    # xlsx is the primary source of each team's questions (see module
    # docstring's "xlsx-primary merge" design decision). Every xlsx question
    # is kept unconditionally; a docx question is kept only if it's "new" --
    # not a near-duplicate (cosine >= --docx-novelty-threshold) of any xlsx
    # question for that SAME team. Teams with no xlsx match keep 100% of
    # their docx questions, unchanged from before this stage existed.
    per_team_questions: dict[str, list[dict[str, Any]]] = {}
    teams_merged = 0
    docx_kept_total = 0
    docx_dropped_total = 0

    for team_key, docx_questions in docx_questions_by_team_key.items():
        docx_slug, prefix = docx_meta_by_team_key[team_key]
        xlsx_texts = xlsx_questions_by_docx_slug.get(docx_slug, [])
        xlsx_questions = [
            {"id": f"{prefix}.X{i}", "text": t, "required": True} for i, t in enumerate(xlsx_texts, start=1)
        ]

        if xlsx_questions and docx_questions:
            teams_merged += 1
            texts = [q["text"] for q in docx_questions] + [q["text"] for q in xlsx_questions]
            pair_embeddings = np.array(list(model.embed(texts)))
            n_docx = len(docx_questions)
            docx_emb, xlsx_emb = pair_embeddings[:n_docx], pair_embeddings[n_docx:]
            max_sim_vs_xlsx = (docx_emb @ xlsx_emb.T).max(axis=1)
            novel_docx = [q for q, s in zip(docx_questions, max_sim_vs_xlsx) if s < args.docx_novelty_threshold]
            docx_kept_total += len(novel_docx)
            docx_dropped_total += n_docx - len(novel_docx)
            per_team_questions[team_key] = xlsx_questions + novel_docx
        else:
            # No xlsx counterpart for this team (or no docx questions to check) --
            # nothing to merge against, keep everything as-is.
            per_team_questions[team_key] = xlsx_questions + docx_questions

    zero_question_teams = [team for team, qs in per_team_questions.items() if not qs]

    print(f"Teams with both docx and xlsx sources merged: {teams_merged}")
    print(
        f"Docx questions kept as novel (below --docx-novelty-threshold {args.docx_novelty_threshold}): "
        f"{docx_kept_total}; dropped as already covered by xlsx: {docx_dropped_total}"
    )
    print(f"Teams with zero questions after merge: {zero_question_teams}")

    all_items: list[dict[str, str]] = []  # {team (key), question_id, text}
    for team_key, questions in per_team_questions.items():
        for q in questions:
            all_items.append({"team": team_key, "question_id": q["id"], "text": q["text"]})

    if not all_items:
        sys.exit("No candidate questions extracted -- nothing to embed.")

    texts = [item["text"] for item in all_items]
    embeddings = np.array(list(model.embed(texts)))
    # fastembed vectors are already L2-normalized; cosine == dot product.
    sim = embeddings @ embeddings.T

    n = len(all_items)
    edges = [(i, j) for i in range(n) for j in range(i + 1, n) if sim[i, j] >= args.low_threshold]
    clusters = [c for c in union_find_clusters(n, edges) if len(c) >= 2]

    print(f"Clusters found (size >= 2): {len(clusters)}")

    single_team_clusters = sum(1 for c in clusters if len({all_items[i]["team"] for i in c}) == 1)
    print(
        f"Same-team clusters (all sources from one team, i.e. an xlsx/docx or xlsx/xlsx dedup "
        f"within a single team rather than a cross-team match): {single_team_clusters} of {len(clusters)}"
    )

    used_ids: set[str] = set()
    canonical_questions = []
    chain_merge_warnings = 0

    for cluster in clusters:
        cluster = sorted(cluster, key=lambda i: (all_items[i]["team"], all_items[i]["question_id"]))
        # Flag single-linkage over-merge: any pair below threshold inside this cluster.
        min_pair = min(
            (sim[i, j] for a, i in enumerate(cluster) for j in cluster[a + 1 :]),
            default=1.0,
        )
        if min_pair < args.low_threshold:
            chain_merge_warnings += 1
            print(
                f"  WARNING: cluster {[all_items[i]['question_id'] for i in cluster]} "
                f"chain-merged -- weakest internal pair similarity {min_pair:.3f} < {args.low_threshold}"
            )

        canonical_idx = max(cluster, key=lambda i: len(all_items[i]["text"]))
        canonical_text = all_items[canonical_idx]["text"]
        canonical_id = slugify_canonical_id(canonical_text, used_ids)

        sources = []
        for i in cluster:
            match_type = "exact" if sim[i, canonical_idx] >= args.exact_threshold else "paraphrase"
            sources.append({"team": all_items[i]["team"], "question_id": all_items[i]["question_id"], "match_type": match_type})

        canonical_questions.append(
            {
                "canonical_id": canonical_id,
                "canonical_question": canonical_text,
                "category": "general",  # TODO: no categorization heuristic in this first draft
                "sources": sources,
            }
        )

    exact_count = sum(1 for c in canonical_questions for s in c["sources"] if s["match_type"] == "exact")
    paraphrase_count = sum(1 for c in canonical_questions for s in c["sources"] if s["match_type"] == "paraphrase")
    print(f"Canonical entries: {len(canonical_questions)} ({exact_count} exact sources, {paraphrase_count} paraphrase sources)")
    print(f"Chain-merge warnings: {chain_merge_warnings}")

    questionnaires = {
        "description": (
            "Per-team questionnaires. Each team has a list of questions identified by stable IDs. "
            "These IDs are referenced by dedup_mapping.json and by team form outputs. Generated by "
            "dedup_questions.py from extracted_questions/*/record.json (docx, questionnaire_text only; "
            "screenshot-derived content and trigger-logic fields excluded) merged with "
            "extracted_questions_xlsx/*/record.json (xlsx, primary source for questions -- every xlsx "
            "question is kept, docx questions are kept only if not a near-duplicate of one -- see script "
            "docstring's 'xlsx-primary merge' design decision). Question IDs use '<prefix>.<n>' for "
            "docx-sourced questions and '<prefix>.X<n>' for xlsx-sourced questions."
        ),
        "teams": {team: {"questions": qs} for team, qs in per_team_questions.items()},
    }

    dedup_mapping = {
        "description": (
            "Generated by dedup_questions.py (embedding clustering, all-MiniLM-L6-v2, "
            f"low_threshold={args.low_threshold}, exact_threshold={args.exact_threshold}, "
            f"docx_novelty_threshold={args.docx_novelty_threshold}) over the xlsx-primary-merged "
            "per-team question sets in questionnaires.json. Each canonical entry consolidates "
            "equivalent questions across teams (or, increasingly since the xlsx merge, within the "
            "same team -- see the run report's same-team-cluster count). category groups questions "
            "for batched presentation (not yet implemented -- always 'general' in this first draft). "
            "match_type per source: exact | paraphrase (see script docstring for 'distinct', which is "
            "not automated here). Source questions not listed here are treated as singleton canonicals "
            "by question_dedup.py."
        ),
        "canonical_questions": canonical_questions,
    }

    if args.dry_run:
        print("--dry-run set, not writing output files.")
        return

    QUESTIONNAIRES_OUT.write_text(json.dumps(questionnaires, indent=2) + "\n")
    DEDUP_MAPPING_OUT.write_text(json.dumps(dedup_mapping, indent=2) + "\n")
    print(f"Wrote {QUESTIONNAIRES_OUT}")
    print(f"Wrote {DEDUP_MAPPING_OUT}")


if __name__ == "__main__":
    main()
