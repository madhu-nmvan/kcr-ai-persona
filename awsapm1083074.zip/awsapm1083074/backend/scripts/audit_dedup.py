# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Dedup / corpus audit.

Cross-checks dedup_mapping.json against the xlsx-primary questionnaires.json
corpus and trigger_rules.json, and scans the corpus itself for extraction
defects. Read-only; prints a report and exits non-zero if any HARD check
fails (referential integrity, double-coverage). Heuristic findings (headings,
near-duplicates, contamination) are reported but never fail the run.

Usage:
    python backend/scripts/audit_dedup.py [--json OUT.json]
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

DATA = Path(__file__).resolve().parents[1] / "src" / "governance_intake" / "data"

# Verbs that open a legitimate imperative-style question ("Describe the ...").
IMPERATIVE_OPENERS = {
    "describe", "list", "provide", "explain", "identify", "attach", "confirm",
    "document", "specify", "indicate", "include", "detail", "enter", "upload",
    "submit", "name", "state", "define", "summarize", "summarise", "note",
    "give", "outline", "select", "check", "complete", "review", "answer",
}

# Phrases that are reviewer/source-doc commentary, not part of a question.
COMMENTARY_MARKERS = (
    "current state intake form",
    "we can carry over",
    "should be collected by",
    "covered in the",
    "in the rai vendor questionnaire",
    "shared with us",
)


def norm_text(s: str) -> str:
    s = unicodedata.normalize("NFKC", s).casefold()
    s = re.sub(r"[^\w\s]", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def is_heading_like(text: str) -> bool:
    """Heuristic: short, unpunctuated title lines that read as section headers."""
    t = text.strip()
    if "?" in t:
        return False
    words = t.split()
    if not words:
        return True
    first = re.sub(r"\W", "", words[0]).lower()
    if first in IMPERATIVE_OPENERS:
        return False
    if t.endswith((":", ".")) and len(words) > 8:
        return False
    # Headers are short noun phrases: "Downstream mapping", "Intake, ownership,
    # and threshold scoping".
    return len(words) <= 8 and not t.endswith(".")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", help="also write findings as JSON to this path")
    args = ap.parse_args()

    dm = json.loads((DATA / "dedup_mapping.json").read_text(encoding="utf-8"))
    qn = json.loads((DATA / "questionnaires.json").read_text(encoding="utf-8"))
    tr = json.loads((DATA / "trigger_rules.json").read_text(encoding="utf-8"))

    teams = qn["teams"]
    corpus = {
        (team, q["id"]): q["text"]
        for team, td in teams.items()
        for q in td.get("questions", [])
    }
    canonicals = dm["canonical_questions"]

    findings: dict = {}
    hard_failures = 0

    # ---- A. Referential integrity: every mapping source exists in the corpus.
    dangling = [
        (e["canonical_id"], s["team"], s["question_id"])
        for e in canonicals
        for s in e["sources"]
        if (s["team"], s["question_id"]) not in corpus
    ]
    findings["dangling_sources"] = dangling
    hard_failures += len(dangling)

    # ---- B. Double coverage: one (team, qid) claimed by 2+ canonicals.
    claims = Counter(
        (s["team"], s["question_id"]) for e in canonicals for s in e["sources"]
    )
    double = {f"{t}::{q}": n for (t, q), n in claims.items() if n > 1}
    findings["double_covered_sources"] = double
    hard_failures += len(double)

    # ---- C. Coverage / reduction over the full corpus.
    covered = set(claims)
    raw = len(corpus)
    n_canon = len(canonicals)
    singletons = raw - len(covered)
    consolidated = n_canon + singletons
    cross_team = [
        e for e in canonicals if len({s["team"] for s in e["sources"]}) > 1
    ]
    fanout = Counter(len(e["sources"]) for e in canonicals)
    mapping_teams = {s["team"] for e in canonicals for s in e["sources"]}
    findings["coverage"] = {
        "raw_questions": raw,
        "corpus_teams": len(teams),
        "canonical_entries": n_canon,
        "sources_covered_by_mapping": len(covered),
        "uncovered_singletons": singletons,
        "consolidated_total_all_teams": consolidated,
        "reduction_ratio_all_teams": round(1 - consolidated / raw, 4),
        "cross_team_canonicals": len(cross_team),
        "intra_team_only_canonicals": n_canon - len(cross_team),
        "max_fanout": max(fanout) if fanout else 0,
        "teams_in_mapping": sorted(mapping_teams),
        "teams_absent_from_mapping": sorted(set(teams) - mapping_teams),
    }

    # ---- D. Exact duplicates (normalized) the mapping fails to merge.
    by_text: dict[str, list] = defaultdict(list)
    for key, text in corpus.items():
        nt = norm_text(text)
        if nt:
            by_text[nt].append(key)
    missed_exact = []
    for keys in by_text.values():
        if len(keys) < 2:
            continue
        # merged iff every duplicate key sits in one shared canonical
        canon_ids = [
            {e["canonical_id"] for e in canonicals
             if any((s["team"], s["question_id"]) == k for s in e["sources"])}
            for k in keys
        ]
        shared = set.intersection(*canon_ids) if all(canon_ids) else set()
        if not shared:
            missed_exact.append({
                "text": corpus[keys[0]][:120],
                "keys": [f"{t}::{q}" for t, q in keys],
                "cross_team": len({t for t, _ in keys}) > 1,
            })
    findings["exact_duplicates_not_merged"] = {
        "count": len(missed_exact),
        "cross_team_count": sum(1 for m in missed_exact if m["cross_team"]),
        "examples": missed_exact[:25],
    }

    # ---- E. Heading-like "questions" per team (extraction defect signal).
    headings = defaultdict(list)
    for (team, qid), text in corpus.items():
        if is_heading_like(text):
            headings[team].append({"id": qid, "text": text})
    findings["heading_like_questions"] = {
        "per_team_counts": {t: len(v) for t, v in sorted(headings.items())},
        "total": sum(len(v) for v in headings.values()),
        "legaldgp_examples": headings.get("Legal - Data Governance & Privacy", [])[:20],
    }

    # ---- F. Commentary leaked into canonical question text.
    contaminated = [
        {"canonical_id": e["canonical_id"], "text": e["canonical_question"][:160]}
        for e in canonicals
        if any(m in e["canonical_question"].lower() for m in COMMENTARY_MARKERS)
    ]
    findings["contaminated_canonical_text"] = {
        "count": len(contaminated),
        "examples": contaminated[:15],
    }
    # Same scan over the raw corpus.
    corpus_commentary = [
        f"{t}::{q}" for (t, q), text in corpus.items()
        if any(m in text.lower() for m in COMMENTARY_MARKERS)
    ]
    findings["corpus_commentary_questions"] = {
        "count": len(corpus_commentary),
        "examples": corpus_commentary[:15],
    }

    # ---- G. Team-name joins: rules vs corpus vs mapping.
    rule_teams = {r["team"] for r in tr["rules"]}
    findings["team_name_joins"] = {
        "rule_teams_missing_questionnaire": sorted(rule_teams - set(teams)),
        "questionnaire_teams_with_no_rule": sorted(set(teams) - rule_teams),
        "mapping_teams_unknown_to_corpus": sorted(mapping_teams - set(teams)),
    }

    # ---- H. Contentless / tiny activated teams the UI must tolerate.
    findings["team_question_counts"] = {
        t: len(td.get("questions", [])) for t, td in sorted(teams.items())
    }

    # ---------------- report ----------------
    c = findings["coverage"]
    print("=== dedup audit ===")
    print(f"corpus: {c['raw_questions']} questions across {c['corpus_teams']} teams")
    print(f"mapping: {c['canonical_entries']} canonicals covering "
          f"{c['sources_covered_by_mapping']} sources "
          f"({c['cross_team_canonicals']} cross-team, max fan-out {c['max_fanout']})")
    print(f"all-teams consolidation: {c['raw_questions']} -> "
          f"{c['consolidated_total_all_teams']} "
          f"({c['reduction_ratio_all_teams']:.1%} reduction)")
    print(f"teams absent from mapping ({len(c['teams_absent_from_mapping'])}): "
          f"{', '.join(c['teams_absent_from_mapping'])}")
    print()
    print(f"[HARD] dangling mapping sources: {len(dangling)}")
    for cid, t, q in dangling[:10]:
        print(f"    {cid}: {t}::{q}")
    print(f"[HARD] sources claimed by 2+ canonicals: {len(double)}")
    for k, n in list(double.items())[:10]:
        print(f"    {k} x{n}")
    print()
    me = findings["exact_duplicates_not_merged"]
    print(f"exact-duplicate texts NOT merged by mapping: {me['count']} "
          f"({me['cross_team_count']} cross-team)")
    for m in me["examples"][:8]:
        print(f"    {m['keys']}  {m['text'][:80]!r}")
    print()
    h = findings["heading_like_questions"]
    print(f"heading-like 'questions' (heuristic): {h['total']} total")
    for t, n in h["per_team_counts"].items():
        print(f"    {n:4d}  {t}")
    print()
    print(f"canonicals with leaked commentary: "
          f"{findings['contaminated_canonical_text']['count']}")
    print(f"corpus questions with leaked commentary: "
          f"{findings['corpus_commentary_questions']['count']}")
    print()
    j = findings["team_name_joins"]
    print(f"rule teams with no questionnaire entry: "
          f"{j['rule_teams_missing_questionnaire'] or 'none'}")
    print(f"mapping teams unknown to corpus: "
          f"{j['mapping_teams_unknown_to_corpus'] or 'none'}")

    if args.json:
        Path(args.json).write_text(json.dumps(findings, indent=2))
        print(f"\nfindings written to {args.json}")

    print(f"\n{'FAIL' if hard_failures else 'OK'} "
          f"({hard_failures} hard integrity failure(s))")
    return 1 if hard_failures else 0


if __name__ == "__main__":
    sys.exit(main())
