#!/usr/bin/env python3
# Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
# or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.

"""
Deterministic, zero-LLM extractor for "Gov Team Reqs by Service Catalog
Types.xlsx" -- Tier-1 sibling of extract_questions.py.

Per [AWS]'s explicit direction (2026-07-13, relaying [Elevance]/Gan's review):
the docx remains the source for trigger logic, but the xlsx is the source for
each team's actual review QUESTIONS. This script pulls that question content
out of the workbook so dedup_questions.py can merge it with what
extract_questions.py already pulled from the docx (xlsx primary, docx-only
questions folded in -- see that script's docstring for the merge algorithm).

Ported from a scratch investigation (2026-07-13-docs-snapshot/scripts/
extract_xlsx_questions.py) that validated this extraction logic against the
real workbook and wrote up its findings in XLSX_RECONCILIATION.md. The
extraction logic below is unchanged from that validated version; only the
paths (this repo's team_roster.json / extracted_questions_xlsx output tree)
differ.

Workbook layout (confirmed by manual inspection, see the scratch investigation's
XLSX_RECONCILIATION.md):
  - 34 sheets total. 5 are not team content and are skipped: Instructions,
    Status, Raw Data (ticket-log dump), Current State SLAs Worksheet,
    TEMPLATE (blank structural template every team tab was cloned from).
  - Every remaining sheet ("real team sheet") shares one layout:
      * Rows 1-~12 ("Upper Section"): shared request-type taxonomy
        boilerplate (columns A-F) plus per-team SLA/engagement metadata
        (columns G-L). NOT question content - skipped, but its column
        headers are recorded for context.
      * A header row (row 15 or 16, varies slightly by sheet - detected by
        searching for the literal string "AI POC" in any cell of the row,
        not by a fixed row number) labelling columns starting at column B as
        one of 11 request-type categories (AI POC, AI Pilot, AI Production,
        Non-AI POC, Non-AI Pilot, Non-AI Production, Expansion of Data Use,
        Software (traditional non-AI), Software (AI models), Software Vendor
        Renewals, Commercialization).
      * Everything below that header row ("Lower Section") is the real
        per-team question list: column A = question text (often with
        leading bullet/numbering cruft), columns B onward = one cell per
        request-type category marking whether the question applies to it.

Sheet -> output-folder mapping comes from team_roster.json's xlsx_tab field
(stripping a trailing "(shared)"/"(shared, unconfirmed)" annotation to get
the literal sheet name). Three special cases:
  - Sheets that map to exactly one roster team use that team's slug directly,
    so extracted_questions_xlsx/<slug>/ lines up 1:1 with
    extracted_questions/<slug>/ for diffing/merging.
  - "FGS-FEP-WellPoint" maps to FOUR roster teams (Anthem FEP, FGS Home
    Office, NGS, WellPoint Federal) that all share one combined docx
    questionnaire heading. One output folder is written under the
    sheet-derived slug "fgs_fep_wellpoint"; record.json lists all 4 docx
    slugs it should be merged into (each gets the identical xlsx question
    set -- matches the docx side, which also repeats one shared block for
    all 4).
  - "Cloud Intake-Adoption NEXTGEN" has no roster mapping at all (flagged in
    team_roster.json's unmapped_xlsx_tabs). Output folder uses the
    sheet-derived slug "cloud_intake_adoption_nextgen"; record.json notes
    the absence of any docx counterpart, so dedup_questions.py has nowhere
    to merge it and it is written for completeness only.

Output per sheet, under extracted_questions_xlsx/<slug>/:
  - record.json     structured: sheet name, docx slug(s) it maps to (if
                     any), header row, category labels, and one entry per
                     question (raw_text, clean_text, applies_to, per-category
                     literal cell values, row index).
  - questions.txt    human-readable, one question's clean_text per line with
                     a trailing [applies_to: ...] bracket.

No LLM calls. Re-running against the same input file produces byte-identical
output (deterministic sheet iteration order, deterministic JSON encoding).

Usage: place the source .xlsx at backend/scripts/source/<filename>.xlsx and
run `uv run backend/scripts/extract_xlsx_questions.py`.
"""
import json
import re
from pathlib import Path

import openpyxl

SCRIPT_DIR = Path(__file__).resolve().parent
SOURCE_DIR = SCRIPT_DIR / "source"
DATA_DIR = SCRIPT_DIR.parent / "src" / "governance_intake" / "data"
ROSTER_PATH = DATA_DIR / "team_roster.json"
OUT_DIR = DATA_DIR / "extracted_questions_xlsx"

EXCLUDE_SHEETS = {
    "Instructions",
    "Status",
    "Raw Data",
    "Current State SLAs Worksheet",
    "TEMPLATE",
}

# Markers that mean "does not apply" to a given request-type category.
# Everything else non-blank counts as "applies" (per [AWS]/Flare's call:
# teams don't use a consistent marker - DUE uses "x", RAI uses "Yes"/"N/A" -
# so treat any non-empty, non-N/A, non-No cell as an applies signal and keep
# the literal value for review).
NOT_APPLIES = {"", "n/a", "na", "no", "no-artifact", "no-artifiact"}

HEADER_SEARCH_MAX_ROW = 80


def _find_xlsx() -> Path:
    candidates = sorted(SOURCE_DIR.glob("*.xlsx"))
    if not candidates:
        raise SystemExit(
            f"No .xlsx found in {SOURCE_DIR} -- drop the source workbook "
            "('Gov Team Reqs by Service Catalog Types.xlsx' or successor) there first."
        )
    if len(candidates) > 1:
        raise SystemExit(f"Multiple .xlsx files in {SOURCE_DIR}: {candidates} -- expected exactly one.")
    return candidates[0]


def slugify(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    return re.sub(r"_+", "_", s)


def clean_question_text(raw: str) -> str:
    """Strip leading bullet/numbering cruft; preserve meaningful question-ID
    prefixes like "AI.1", "I11.", "ES2.", "RA1.1" (letter-led, never stripped
    since the strip patterns below only match a bare leading digit or a
    bullet glyph)."""
    t = raw.replace("\xa0", " ")
    for _ in range(3):
        new = re.sub(r"^\s*o\s{2,}", "", t)  # Word "o" bullet + wide spacing
        new = re.sub(r"^\s*[\u2022\u25E6\u25AA\u2023\u00B7]\s*", "", new)  # bullet glyphs
        new = re.sub(r"^\s*\d{1,3}[.)]\s*", "", new)  # bare local numbering "1." "2)"
        if new == t:
            break
        t = new
    t = t.replace("\r", " ").replace("\n", " ")
    return re.sub(r"\s+", " ", t).strip()


def find_header_row(ws):
    for r, row in enumerate(ws.iter_rows(values_only=True), start=1):
        if r > HEADER_SEARCH_MAX_ROW:
            break
        if any(v is not None and "AI POC" in str(v) for v in row):
            return r, list(row)
    return None, None


def build_sheet_to_teams(roster: dict) -> dict:
    """sheet_name -> [{"slug", "canonical_name"}, ...] via xlsx_tab."""
    mapping: dict[str, list] = {}
    for team in roster["teams"]:
        tab = team.get("xlsx_tab")
        if not tab:
            continue
        # Strip a trailing "(shared)" / "(shared, unconfirmed)" annotation to
        # recover the literal sheet name.
        base = re.sub(r"\s*\([^)]*\)\s*$", "", tab).strip()
        mapping.setdefault(base, []).append(
            {"slug": slugify(team["canonical_name"]), "canonical_name": team["canonical_name"]}
        )
    return mapping


def output_slug_for_sheet(sheet_name: str, teams: list) -> str:
    if len(teams) == 1:
        return teams[0]["slug"]
    # 0 teams (unmapped) or >1 teams (shared sheet): derive from sheet name.
    return slugify(sheet_name)


def extract_sheet(ws, sheet_name: str) -> dict:
    header_row, header_vals = find_header_row(ws)
    if header_row is None:
        return {
            "sheet_name": sheet_name,
            "structure_matched": False,
            "note": "No row within the first %d rows contained \"AI POC\" - "
            "does not fit the standard team-sheet template." % HEADER_SEARCH_MAX_ROW,
            "max_row": ws.max_row,
        }

    categories = []  # [{"column": c, "label": "..."}]
    for c, v in enumerate(header_vals, start=1):
        if v is not None and str(v).strip():
            categories.append({"column": c, "label": str(v).strip()})

    upper_section_header = None
    for row in ws.iter_rows(min_row=1, max_row=1, values_only=True):
        upper_section_header = [v for v in row if v is not None]
        break

    questions = []
    for r, row in enumerate(ws.iter_rows(min_row=header_row + 1, values_only=True), start=header_row + 1):
        raw = row[0] if len(row) > 0 else None
        if raw is None or not str(raw).strip():
            continue
        raw_text = str(raw)
        clean_text = clean_question_text(raw_text)
        applies_to = []
        cell_values = {}
        for cat in categories:
            col = cat["column"]
            val = row[col - 1] if col - 1 < len(row) else None
            if val is None:
                continue
            sval = str(val).strip()
            cell_values[cat["label"]] = sval
            if sval.lower() not in NOT_APPLIES:
                applies_to.append(cat["label"])
        questions.append(
            {
                "row": r,
                "raw_text": raw_text,
                "clean_text": clean_text,
                "applies_to": applies_to,
                "cell_values": cell_values,
            }
        )

    return {
        "sheet_name": sheet_name,
        "structure_matched": True,
        "header_row": header_row,
        "category_labels": categories,
        "upper_section_header_row1": upper_section_header,
        "question_count": len(questions),
        "questions": questions,
    }


def write_outputs(slug: str, sheet_name: str, teams: list, record: dict):
    out_dir = OUT_DIR / slug
    out_dir.mkdir(parents=True, exist_ok=True)

    docx_slugs = [t["slug"] for t in teams]
    full_record = {
        "sheet_name": sheet_name,
        "output_slug": slug,
        "docx_slugs": docx_slugs,
        "canonical_names": [t["canonical_name"] for t in teams],
        **record,
    }
    (out_dir / "record.json").write_text(
        json.dumps(full_record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    lines = [f"# {sheet_name} (xlsx sheet)"]
    if docx_slugs:
        lines.append(f"Maps to docx slug(s): {', '.join(docx_slugs)}")
    else:
        lines.append("Maps to docx slug(s): none - unmapped in team_roster.json")

    if not record.get("structure_matched"):
        lines.append("")
        lines.append(f"STRUCTURE MISMATCH: {record.get('note')}")
        (out_dir / "questions.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
        return

    lines.append(f"Header row: {record['header_row']}; Question rows: {record['question_count']}")
    lines.append("")
    lines.append("## Questions (from xlsx question matrix, row order as in sheet)")
    for q in record["questions"]:
        applies = ", ".join(q["applies_to"]) if q["applies_to"] else "(none)"
        lines.append(f"- {q['clean_text']} [applies_to: {applies}]")
    lines.append("")
    (out_dir / "questions.txt").write_text("\n".join(lines), encoding="utf-8")


def main():
    xlsx_path = _find_xlsx()
    roster = json.loads(ROSTER_PATH.read_text(encoding="utf-8"))
    sheet_to_teams = build_sheet_to_teams(roster)

    wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
    summary = []
    for sheet_name in wb.sheetnames:
        if sheet_name in EXCLUDE_SHEETS:
            continue
        teams = sheet_to_teams.get(sheet_name, [])
        slug = output_slug_for_sheet(sheet_name, teams)
        ws = wb[sheet_name]
        record = extract_sheet(ws, sheet_name)
        write_outputs(slug, sheet_name, teams, record)
        summary.append(
            {
                "sheet_name": sheet_name,
                "slug": slug,
                "docx_slugs": [t["slug"] for t in teams],
                "structure_matched": record.get("structure_matched", False),
                "question_count": record.get("question_count", 0),
            }
        )
    wb.close()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUT_DIR / "extraction_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    total_q = sum(s["question_count"] for s in summary)
    print(f"Processed {len(summary)} sheets, {total_q} total questions extracted.")
    for s in summary:
        flag = "" if s["structure_matched"] else "  <-- STRUCTURE MISMATCH"
        print(f"  {s['sheet_name']!r} -> {s['slug']} : {s['question_count']} questions{flag}")


if __name__ == "__main__":
    main()
