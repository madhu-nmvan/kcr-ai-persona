/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import FormFillerSanityView from './FormFillerSanityView';
import './index.css';

// Sanity-integration views live behind a query param so they're reachable
// for manual verification without touching the production App render tree
// or its Phase 1 -> Phase 2 flow. See docs/form_filler_agent_contract.md.
const isFormFillerSanityView = new URLSearchParams(window.location.search).get('sanity') ===
  'formfiller';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {isFormFillerSanityView ? <FormFillerSanityView /> : <App />}
  </React.StrictMode>
);
