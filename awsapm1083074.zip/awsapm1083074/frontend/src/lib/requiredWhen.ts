/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { CollectedFields, RequiredWhenCondition } from '../types';

/**
 * Minimal client-side evaluator for intake_schema.json's required_when
 * conditions — only handles "equals", the only operator any field in the
 * current schema actually uses (see identify_vendors_to_PI). Used purely
 * to hide/show a conditionally-relevant field in the form; the backend's
 * full rule_engine DSL remains the source of truth for completion gating.
 */
export function evaluateRequiredWhen(
  cond: RequiredWhenCondition | undefined,
  fields: CollectedFields
): boolean {
  if (!cond) return true;
  const eq = cond.equals as [string, unknown] | undefined;
  if (Array.isArray(eq)) {
    const [key, expected] = eq;
    return fields[key] === expected;
  }
  // Unrecognized operator shape — default to showing the field rather than
  // silently hiding something the user might need to fill in.
  return true;
}
