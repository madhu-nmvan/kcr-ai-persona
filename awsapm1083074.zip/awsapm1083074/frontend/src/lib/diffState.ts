/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { SessionState } from '../types';

/**
 * Field names (collected_fields keys) and canonical_ids (pending_questions)
 * whose value differs between two state snapshots — used to briefly
 * highlight whatever the AI just filled in during a chat turn, as opposed
 * to a field the user just typed into themselves (which they can already
 * see they changed).
 */
export function diffChangedFieldKeys(prev: SessionState, next: SessionState): string[] {
  const changed: string[] = [];

  for (const key of Object.keys(next.collected_fields)) {
    if (JSON.stringify(prev.collected_fields[key]) !== JSON.stringify(next.collected_fields[key])) {
      changed.push(key);
    }
  }

  const prevAnswers = new Map(prev.pending_questions.map((q) => [q.canonical_id, q.answer]));
  for (const q of next.pending_questions) {
    if (prevAnswers.get(q.canonical_id) !== q.answer) {
      changed.push(q.canonical_id);
    }
  }

  return changed;
}
