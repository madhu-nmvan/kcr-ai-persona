/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { SessionState, WorkflowStep } from '../types';

/**
 * Steps = Phase 1 (routing fields) + one step per team in team_order +
 * Attachments + Submit, but ONLY while still in collecting_routing_info —
 * dynamic, computed from server state, mirroring backend/.../handler.py's
 * own phase model (PHASE_ROUTING -> PHASE_ASKING, one team at a time via
 * team_order/focus_team -> PHASE_ATTACHMENTS -> PHASE_COMPLETE).
 *
 * Once the session leaves collecting_routing_info, PostDedupDashboard
 * (App.tsx) takes over the entire remainder of the flow — WorkflowPanel's
 * per-team/attachments/submit steps are superseded, not one more item
 * alongside them, so they collapse into a single "Governance review" step
 * here (kept as a real WorkflowStep, not a special case, so
 * FormProgressList/liveStepIndex/stepStatus need no changes).
 */
export function computeSteps(state: SessionState): WorkflowStep[] {
  const steps: WorkflowStep[] = [
    { kind: 'routing', key: 'routing', label: 'Project Overview' },
  ];
  if (state.phase !== 'collecting_routing_info') {
    steps.push({ kind: 'submit', key: 'governance-review', label: 'Governance review' });
    return steps;
  }
  for (const team of state.team_order) {
    steps.push({ kind: 'team', key: `team:${team}`, label: team, team });
  }
  steps.push({ kind: 'attachments', key: 'attachments', label: 'Attachments' });
  steps.push({ kind: 'submit', key: 'submit', label: 'Submit' });
  return steps;
}

/** Which step the SERVER currently considers "live" (drives auto-advance). */
export function liveStepIndex(steps: WorkflowStep[], state: SessionState): number {
  if (state.ticket) return steps.length - 1;
  if (state.phase === 'collecting_routing_info') return 0;
  if (state.phase === 'asking_questions') {
    const idx = steps.findIndex((s) => s.kind === 'team' && s.team === state.focus_team);
    return idx === -1 ? Math.max(1, steps.length - 2) : idx;
  }
  if (state.phase === 'collecting_attachments') {
    const idx = steps.findIndex((s) => s.kind === 'attachments');
    return idx === -1 ? steps.length - 1 : idx;
  }
  return steps.length - 1;
}

export type StepStatus = 'done' | 'current' | 'locked';

/** Status for the FormProgressList row + whether a step's fields are
 * editable right now (a step can be "done" and still viewable/editable —
 * e.g. jumping back to a completed team's questions while phase is still
 * asking_questions — but never editable once the server has moved past the
 * phase it belongs to). */
export function stepStatus(
  idx: number,
  live: number,
  state: SessionState,
  steps: WorkflowStep[]
): StepStatus {
  const step = steps[idx];
  if (step.kind === 'team') {
    const teamDone = (state.pending_questions || [])
      .filter((q) => q.category === step.team)
      .every((q) => q.answered);
    if (teamDone && idx !== live) return 'done';
  }
  if (idx < live) return 'done';
  if (idx === live) return 'current';
  return 'locked';
}

/** Whether the fields belonging to this step can currently be written to
 * (matches the backend's phase gating on set_routing_field/set_answer). */
export function stepIsEditable(step: WorkflowStep, state: SessionState): boolean {
  if (step.kind === 'routing') return state.phase === 'collecting_routing_info';
  if (step.kind === 'team') return state.phase === 'asking_questions';
  if (step.kind === 'attachments') return state.phase === 'collecting_attachments';
  return false;
}
