/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { ActivatedTeam, PostDedupQuestion } from '../types';

export interface QuestionSection {
  /** "Shared · {category}" for cross-team canonicals, else the owning team. */
  key: string;
  shared: boolean;
  questions: PostDedupQuestion[];
}

/**
 * Sections preserve the server's implication-first order: cross-team
 * (shared) canonicals arrive first and group by category; singletons group
 * by their owning team. Section order = first appearance.
 */
export function buildSections(questions: PostDedupQuestion[]): QuestionSection[] {
  const sections: QuestionSection[] = [];
  const byKey = new Map<string, QuestionSection>();
  for (const q of questions) {
    const shared = (q.sources || []).length > 1;
    const key = shared
      ? `Shared · ${q.category || 'general'}`
      : q.source_teams?.[0] || 'Unassigned';
    let section = byKey.get(key);
    if (!section) {
      section = { key, shared, questions: [] };
      byKey.set(key, section);
      sections.push(section);
    }
    section.questions.push(q);
  }
  return sections;
}

/** Activated teams with no questions of their own in scope (delegated review). */
export function contentlessTeams(
  questions: PostDedupQuestion[],
  activatedTeams: ActivatedTeam[]
): string[] {
  const withContent = new Set<string>();
  for (const q of questions) {
    for (const t of q.source_teams || []) withContent.add(t);
  }
  return (activatedTeams || []).map((t) => t.team).filter((t) => !withContent.has(t));
}
