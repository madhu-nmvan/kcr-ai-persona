/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { TeamRoster } from '../types';

/**
 * team_order/activated_teams/pending_questions all use whatever "team"
 * string trigger_rules.json's rules were keyed with (e.g. "Security-InfoSec"),
 * which frequently does NOT match team_roster.json's canonical_name (e.g.
 * "Security – InfoSec Office") — team_roster's own trigger_rules_key field
 * exists specifically to bridge that gap, per its documented "status:
 * mapped/conflict" crosswalk. Build a lookup off THAT field rather than
 * guessing a fuzzy name match.
 */
export function buildTeamLabelMap(roster: TeamRoster | null): Record<string, string> {
  const map: Record<string, string> = {};
  if (!roster) return map;
  for (const t of roster.teams) {
    if (typeof t.trigger_rules_key === 'string' && t.trigger_rules_key) {
      map[t.trigger_rules_key] = t.canonical_name;
    }
    map[t.canonical_name] = t.canonical_name;
  }
  return map;
}

export function teamLabel(map: Record<string, string>, team: string): string {
  return map[team] || team;
}
