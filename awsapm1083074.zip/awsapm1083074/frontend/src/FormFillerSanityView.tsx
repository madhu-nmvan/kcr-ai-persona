/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useState } from 'react';
import { fillForm } from './api';
import type { FormFillerEnvelope, FormFillerItem } from './types';

/**
 * FormFillerAgent sanity-integration view.
 *
 * NOT the production UI Jaz specced (no team grouping, no collapse, no
 * source badges) — this exists only to let a human click a button and see
 * a real POST /api/formfiller/fill round-trip render, so the shared
 * FormFillerEnvelope contract (docs/form_filler_agent_contract.md) can be
 * validated end to end while the real backend agent and the real UI are
 * still being built separately.
 *
 * Mounted standalone via main.tsx (?sanity=formfiller) — never touched by
 * or touching the production App.tsx / handler.py Phase 1 -> Phase 2 flow.
 */
const FIXTURE_ENVELOPE: FormFillerEnvelope = {
  triggers: [
    {
      id: 'involves_ai_ml_llm',
      text: 'Does this solution involve AI/ML/LLM technology?',
      value: true,
      origin: 'user',
      confidence: null,
    },
    {
      id: 'processes_phi',
      text: 'Does this solution process PHI?',
      value: true,
      origin: 'agent',
      confidence: 5,
    },
    {
      id: 'deployment_environment',
      text: 'Which cloud tier will this deploy to?',
      value: null,
      origin: null,
      confidence: null,
    },
    {
      id: 'vendor_name',
      text: 'Which vendor(s) are involved, if any?',
      value: null,
      origin: null,
      confidence: null,
    },
  ],
  governance: [
    {
      id: 'DEDUP.AI_SOLUTION_BE',
      text: 'Describe the AI/ML approach used (model type, training data source).',
      value: 'Vendor-hosted LLM, no in-house training.',
      origin: 'user',
      confidence: null,
      sources: [
        { team: 'AI Governance', question_id: 'AIGOV.Q3' },
        { team: 'Security', question_id: 'SEC.Q11' },
      ],
    },
    {
      id: 'DEDUP.PHI_DATA_FLOW',
      text: 'Where does PHI flow through this solution?',
      value: null,
      origin: null,
      confidence: null,
      sources: [{ team: 'Privacy', question_id: 'PRIV.Q2' }],
    },
    {
      id: 'DEDUP.THIRD_PARTY_ACCESS',
      text: 'Does any third party have access to production data?',
      value: false,
      origin: 'agent',
      confidence: 4,
      sources: [{ team: 'Security', question_id: 'SEC.Q7' }],
    },
    {
      id: 'DEDUP.RETENTION_PERIOD',
      text: 'What is the data retention period for this solution?',
      value: null,
      origin: null,
      confidence: null,
      sources: [{ team: 'Privacy', question_id: 'PRIV.Q9' }],
    },
  ],
};

function ValueDisplay({ value }: { value: FormFillerItem['value'] }) {
  if (value === null || value === undefined) {
    return <span className="text-gray-400 italic">null (unanswered)</span>;
  }
  if (Array.isArray(value)) {
    return <span className="text-gray-800">{value.length ? value.join(', ') : '[]'}</span>;
  }
  return <span className="text-gray-800">{String(value)}</span>;
}

function ItemList({ title, items }: { title: string; items: unknown }) {
  // Defensive: don't assume the response actually has this key, or that
  // it's an array. Render what we got, not what we hoped for.
  const safeItems = Array.isArray(items) ? (items as FormFillerItem[]) : null;
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4">
      <h3 className="text-xs font-semibold text-gray-700 mb-3">
        {title}
        <span className="ml-2 text-gray-400 font-normal">
          {safeItems ? `${safeItems.length} item(s)` : 'missing/malformed in response'}
        </span>
      </h3>
      {!safeItems ? (
        <p className="text-xs text-red-500 italic">
          Response did not contain a "{title.toLowerCase()}" array — see raw JSON below.
        </p>
      ) : safeItems.length === 0 ? (
        <p className="text-xs text-gray-400 italic">(empty)</p>
      ) : (
        <ul className="space-y-2 text-xs">
          {safeItems.map((item, i) => (
            <li key={item?.id ?? i} className="border-b border-gray-100 pb-2 last:border-0">
              <div className="font-mono text-gray-500">{item?.id ?? '(no id)'}</div>
              <div className="text-gray-700">{item?.text ?? '(no text)'}</div>
              <div>
                value: <ValueDisplay value={item?.value} />
              </div>
              {item?.value !== null && item?.value !== undefined && (
                <div className="text-gray-500">
                  origin: <span className="font-medium">{String(item?.origin)}</span>
                  {item?.confidence !== null && item?.confidence !== undefined && (
                    <>
                      {' '}
                      · confidence: <span className="font-medium">{item.confidence}</span>
                    </>
                  )}
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default function FormFillerSanityView() {
  const [response, setResponse] = useState<FormFillerEnvelope | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleFill() {
    setLoading(true);
    setError(null);
    try {
      const r = await fillForm(FIXTURE_ENVELOPE);
      setResponse(r);
    } catch (e) {
      // Backend route may not exist yet, or the shape may not match what
      // we expect — either way, surface it instead of crashing.
      setError(e instanceof Error ? e.message : String(e));
      setResponse(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="bg-white border border-gray-200 rounded-xl p-4">
          <h1 className="text-sm font-semibold text-elevance-dark">
            FormFillerAgent sanity integration
          </h1>
          <p className="text-xs text-gray-500 mt-1">
            Sends a hardcoded fixture <code>FormFillerEnvelope</code> to{' '}
            <code>POST /api/formfiller/fill</code> and renders whatever comes back. Not the
            production UI — see docs/form_filler_agent_contract.md.
          </p>
          <button
            onClick={handleFill}
            disabled={loading}
            className="mt-3 px-3 py-2 text-xs font-medium bg-elevance-purple text-white rounded-lg hover:bg-elevance-purple/90 disabled:opacity-50 transition-colors"
          >
            {loading ? 'Calling /api/formfiller/fill…' : 'Send fixture envelope'}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-xs text-red-700">
            <strong>Request failed:</strong> {error}
            <p className="mt-1 text-red-500">
              Expected if the backend route hasn't landed yet — this just means we haven't
              round-tripped against a live server.
            </p>
          </div>
        )}

        {response && (
          <>
            <ItemList title="Triggers" items={response.triggers} />
            <ItemList title="Governance" items={response.governance} />
            <details className="text-xs text-gray-400">
              <summary className="cursor-pointer">raw response JSON</summary>
              <pre className="mt-2 whitespace-pre-wrap break-all bg-gray-100 rounded p-2">
                {JSON.stringify(response, null, 2)}
              </pre>
            </details>
          </>
        )}
      </div>
    </div>
  );
}
