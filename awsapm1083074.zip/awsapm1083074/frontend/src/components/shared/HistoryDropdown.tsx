/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useState } from 'react';
import { ChevronDown, History } from 'lucide-react';
import type { SessionSummary } from '../../types';
import { formatWhen } from '../../lib/format';

interface HistoryDropdownProps {
  sessions: SessionSummary[];
  currentSessionId: string | null;
  onPick: (sessionId: string) => void;
  onRefresh: () => void;
  disabled: boolean;
}

export default function HistoryDropdown({
  sessions,
  currentSessionId,
  onPick,
  onRefresh,
  disabled,
}: HistoryDropdownProps) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => {
          setOpen((v) => !v);
          if (!open) onRefresh?.();
        }}
        disabled={disabled}
        className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-elevance-purple disabled:opacity-50 px-2 py-1 rounded hover:bg-gray-100"
      >
        <History size={12} /> History <ChevronDown size={10} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 mt-1 w-96 max-h-96 overflow-y-auto bg-white border border-gray-200 rounded-xl shadow-lg z-20">
            <div className="px-3 py-2 border-b border-gray-100 text-[10px] uppercase tracking-wider text-gray-500">
              Recent sessions
            </div>
            {sessions.length === 0 ? (
              <div className="px-3 py-4 text-xs text-gray-400 italic">
                No saved sessions yet.
              </div>
            ) : (
              sessions.map((s) => (
                <button
                  key={s.session_id}
                  onClick={() => {
                    setOpen(false);
                    onPick?.(s.session_id);
                  }}
                  className={`w-full text-left px-3 py-2 hover:bg-gray-50 text-xs border-b border-gray-50 last:border-b-0 ${
                    s.session_id === currentSessionId ? 'bg-elevance-purple/5' : ''
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-gray-800 font-medium truncate flex-1">
                      {s.summary || '(new session)'}
                    </span>
                    <span className="text-[10px] text-gray-400 flex-shrink-0">
                      {formatWhen(s.updated_at)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] text-gray-400 font-mono">
                      {s.session_id}
                    </span>
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                        s.phase === 'complete'
                          ? 'bg-emerald-50 text-emerald-600'
                          : s.phase === 'asking_questions'
                          ? 'bg-amber-50 text-amber-600'
                          : 'bg-blue-50 text-blue-600'
                      }`}
                    >
                      {s.phase === 'complete'
                        ? 'complete'
                        : s.phase === 'asking_questions'
                        ? 'Q&A'
                        : 'routing'}
                    </span>
                  </div>
                </button>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}
