/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { Phase } from '../../types';

const PHASE_INFO: Record<string, { label: string; color: string }> = {
  collecting_routing_info: {
    label: 'Phase 1 — Routing',
    color: 'bg-blue-100 text-blue-700 border-blue-200',
  },
  asking_questions: {
    label: 'Phase 2 — Q&A',
    color: 'bg-amber-100 text-amber-700 border-amber-200',
  },
  collecting_attachments: {
    label: 'Phase 3 — Attachments',
    color: 'bg-purple-100 text-purple-700 border-purple-200',
  },
  complete: {
    label: 'Complete',
    color: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  },
};

export default function PhaseBadge({ phase }: { phase: Phase | string | undefined }) {
  const info = (phase && PHASE_INFO[phase]) || {
    label: phase || '—',
    color: 'bg-gray-100 text-gray-600 border-gray-200',
  };
  return (
    <span className={`text-xs px-2.5 py-1 rounded-full font-medium border ${info.color}`}>
      {info.label}
    </span>
  );
}
