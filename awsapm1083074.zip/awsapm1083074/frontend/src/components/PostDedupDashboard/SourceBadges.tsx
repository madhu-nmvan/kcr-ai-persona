/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { QuestionSource } from '../../types';
import { teamLabel } from '../../lib/teamLabels';

interface SourceBadgesProps {
  sources: QuestionSource[];
  teamLabelMap: Record<string, string>;
}

/**
 * Which team-form field(s) a deduped canonical question answers, plus a
 * "1 answer → N forms" badge when dedup collapsed multiple team questions
 * into this one.
 */
export default function SourceBadges({ sources, teamLabelMap }: SourceBadgesProps) {
  const byTeam = new Map<string, string[]>();
  for (const s of sources || []) {
    const ids = byTeam.get(s.team) ?? [];
    ids.push(s.question_id);
    byTeam.set(s.team, ids);
  }
  return (
    <span className="inline-flex flex-wrap gap-1 align-middle">
      {[...byTeam.entries()].map(([team, qids]) => (
        <span
          key={team}
          title={`Answers ${teamLabel(teamLabelMap, team)}: ${qids.join(', ')}`}
          className="text-[9px] px-1.5 py-0.5 rounded-full bg-elevance-purple/10 text-elevance-purple whitespace-nowrap cursor-help"
        >
          {teamLabel(teamLabelMap, team)}
          {qids.length > 1 ? ` ×${qids.length}` : ''}
        </span>
      ))}
      {(sources || []).length > 1 && (
        <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 whitespace-nowrap">
          1 answer → {(sources || []).length} forms
        </span>
      )}
    </span>
  );
}
