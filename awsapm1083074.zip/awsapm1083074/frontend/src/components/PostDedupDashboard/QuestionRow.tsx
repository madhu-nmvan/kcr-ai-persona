/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { memo, useEffect, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import type { PostDedupQuestion, PrefillDecision } from '../../types';
import SourceBadges from './SourceBadges';

interface QuestionRowProps {
  question: PostDedupQuestion;
  teamLabelMap: Record<string, string>;
  onSave: (canonicalId: string, answer: string) => void;
  onDecide: (decision: PrefillDecision) => void;
  busy: boolean;
}

/**
 * One deduped canonical question: free-text answer, source-team badges,
 * and — while a grounded pre-fill proposal is pending — an accept/edit/
 * dismiss card instead of the answer box. memo()'d because a section can
 * hold hundreds of these.
 */
const QuestionRow = memo(function QuestionRow({
  question: q,
  teamLabelMap,
  onSave,
  onDecide,
  busy,
}: QuestionRowProps) {
  const [draft, setDraft] = useState(q.answer ?? '');
  const [editingProposal, setEditingProposal] = useState(false);

  useEffect(() => {
    setDraft(q.answer ?? '');
  }, [q.answer]);

  const proposal = q.prefill && q.prefill.status === 'proposed' ? q.prefill : null;
  const prefilled = q.answered && q.answer_origin === 'prefill';

  function commit() {
    const value = draft.trim();
    if ((q.answer ?? '') === value || (!q.answered && value === '')) return;
    onSave(q.canonical_id, value);
  }

  return (
    <div className="border-b border-gray-100 last:border-b-0 px-4 py-3">
      <div className="flex items-start gap-2">
        {q.answered ? (
          <CheckCircle2 size={14} className="text-emerald-500 flex-shrink-0 mt-0.5" />
        ) : (
          <span className="w-3.5 h-3.5 rounded-full border border-gray-300 flex-shrink-0 mt-0.5" />
        )}
        <div className="flex-1 min-w-0">
          <p className="text-xs text-gray-700 mb-1.5">
            {q.text}{' '}
            <SourceBadges sources={q.sources} teamLabelMap={teamLabelMap} />
            {prefilled && (
              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-sky-100 text-sky-700 ml-1 whitespace-nowrap">
                pre-filled — review me
              </span>
            )}
          </p>

          {proposal && !editingProposal ? (
            <div className="bg-sky-50 border border-sky-200 rounded-lg p-2.5">
              <p className="text-xs text-sky-900">{proposal.answer}</p>
              <p className="text-[10px] text-sky-600 mt-1 italic truncate">
                From{' '}
                {proposal.provenance.kind === 'trigger_field'
                  ? `your intake answer "${proposal.provenance.ref}"`
                  : proposal.provenance.kind === 'prior_answer'
                    ? 'an earlier answer'
                    : 'your description'}
                : "{proposal.provenance.quote}"
              </p>
              <div className="flex gap-2 mt-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => onDecide({ accept: [q.canonical_id] })}
                  className="text-[10px] px-2 py-1 rounded bg-sky-600 text-white hover:bg-sky-700 disabled:opacity-50"
                >
                  Accept
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    setDraft(proposal.answer);
                    setEditingProposal(true);
                  }}
                  className="text-[10px] px-2 py-1 rounded border border-sky-300 text-sky-700 hover:bg-sky-100 disabled:opacity-50"
                >
                  Edit
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => onDecide({ dismiss: [q.canonical_id] })}
                  className="text-[10px] px-2 py-1 rounded border border-gray-200 text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  Dismiss
                </button>
              </div>
            </div>
          ) : (
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onBlur={() => {
                setEditingProposal(false);
                commit();
              }}
              rows={draft.length > 120 ? 3 : 1}
              placeholder="Your answer…"
              className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-2 focus:outline-none focus:ring-2 focus:ring-elevance-purple/20 focus:border-elevance-purple resize-y"
            />
          )}
        </div>
      </div>
    </div>
  );
});

export default QuestionRow;
