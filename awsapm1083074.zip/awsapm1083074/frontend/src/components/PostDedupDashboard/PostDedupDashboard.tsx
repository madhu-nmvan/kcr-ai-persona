/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  FileCheck2,
  Loader2,
  Sparkles,
  Wand2,
  X,
} from 'lucide-react';
import type {
  Attachment,
  PostDedupQuestion,
  PostDedupSessionView,
  PrefillDecision,
  QaConcern,
  Ticket,
} from '../../types';
import {
  decidePrefills,
  getPostDedupSession,
  runPrefill,
  runQaReview,
  saveAnswers,
  submitPostDedup,
} from '../../postDedupApi';
import { buildSections, contentlessTeams } from '../../lib/postDedupSections';
import { teamLabel } from '../../lib/teamLabels';
import StatsStrip from './StatsStrip';
import Section from './Section';
import DiagramUpload from './DiagramUpload';

type Filter = 'all' | 'open' | 'prefilled';

interface PostDedupDashboardProps {
  sessionId: string;
  teamLabelMap: Record<string, string>;
  /** Fires once the deterministic gate lets the session submit — App
   * mirrors the ticket (and the resulting phase='complete') onto its own
   * top-level SessionState, since this dashboard talks to a different
   * REST surface than the one that state came from. */
  onTicket: (ticket: Ticket) => void;
  onAttachmentsChange: (attachments: Attachment[]) => void;
}

/**
 * The consolidated, post-dedup Q&A experience: one deduped question set
 * grouped into collapsible sections, a before/after stats strip, an
 * LLM pre-fill pass with per-question accept/edit/dismiss, an advisory QA
 * review pass, inline diagram upload, and the submit bar with the
 * deterministic completeness gate.
 *
 * Replaces WorkflowPanel's per-team / attachments / submit steps entirely
 * once the session reaches asking_questions — see App.tsx. Fetches/mutates
 * via the SAME sessionId the ingestion phase already produced; never calls
 * POST /api/post-dedup/sessions (that would mint a second session id).
 */
export default function PostDedupDashboard({
  sessionId,
  teamLabelMap,
  onTicket,
  onAttachmentsChange,
}: PostDedupDashboardProps) {
  const [view, setView] = useState<PostDedupSessionView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState<Filter>('all');
  const [prefillNote, setPrefillNote] = useState<string | null>(null);
  const [qaConcerns, setQaConcerns] = useState<QaConcern[] | null>(null);

  const refresh = useCallback(async () => {
    try {
      setView(await getPostDedupSession(sessionId));
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    }
  }, [sessionId]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const questions = view?.state.governance.questions ?? [];

  const filtered = useMemo(() => {
    if (filter === 'open') return questions.filter((q) => !q.answered);
    if (filter === 'prefilled') {
      return questions.filter(
        (q) => (q.prefill && q.prefill.status === 'proposed') || q.answer_origin === 'prefill'
      );
    }
    return questions;
  }, [questions, filter]);

  const sections = useMemo(() => buildSections(filtered), [filtered]);
  const delegated = useMemo(
    () => (view ? contentlessTeams(questions, view.state.activated_teams) : []),
    [view, questions]
  );
  const proposedCount = useMemo(
    () => questions.filter((q: PostDedupQuestion) => q.prefill?.status === 'proposed').length,
    [questions]
  );

  const guard = useCallback(async (fn: () => Promise<void>) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }, []);

  const handleSave = useCallback(
    (canonicalId: string, answer: string) =>
      guard(async () => {
        setView(await saveAnswers(sessionId, [{ canonical_id: canonicalId, answer }]));
      }),
    [sessionId, guard]
  );

  const handleDecide = useCallback(
    (decision: PrefillDecision) =>
      guard(async () => {
        setView(await decidePrefills(sessionId, decision));
      }),
    [sessionId, guard]
  );

  async function handlePrefill() {
    await guard(async () => {
      const r = await runPrefill(sessionId);
      setView(r);
      const s = r.prefill_summary;
      setPrefillNote(
        `Pre-fill proposed ${s?.proposed ?? 0} answer(s)` +
          (s?.rejected ? ` — ${s.rejected} ungrounded proposal(s) discarded` : '') +
          '. Nothing is committed until you accept it.'
      );
    });
  }

  async function handleQaReview() {
    await guard(async () => {
      const r = await runQaReview(sessionId);
      setQaConcerns(r.concerns);
    });
  }

  async function handleSubmit() {
    await guard(async () => {
      const r = await submitPostDedup(sessionId);
      await refresh();
      onTicket(r.ticket);
    });
  }

  function handleDiagramUploaded(attachments: Attachment[]) {
    onAttachmentsChange(attachments);
    refresh();
  }

  if (!view) {
    return (
      <div className="h-full flex items-center justify-center">
        {error ? (
          <p className="text-sm text-red-600">{error}</p>
        ) : (
          <Loader2 size={24} className="animate-spin text-elevance-purple" />
        )}
      </div>
    );
  }

  const completeness = view.completeness;
  const ticket = view.ticket;
  const filterTabs: Array<[Filter, string]> = [
    ['all', `All (${questions.length})`],
    ['open', `Open (${questions.filter((q) => !q.answered).length})`],
    ['prefilled', 'Pre-filled'],
  ];

  return (
    <div className="h-full flex flex-col gap-3 min-h-0 p-5">
      <StatsStrip stats={view.stats} />

      {/* toolbar */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex rounded-lg border border-gray-200 overflow-hidden">
          {filterTabs.map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setFilter(key)}
              className={`text-[11px] px-3 py-1.5 ${
                filter === key
                  ? 'bg-elevance-purple text-white'
                  : 'bg-white text-gray-500 hover:bg-gray-50'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        {!ticket && (
          <>
            <button
              type="button"
              onClick={handlePrefill}
              disabled={busy}
              className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg bg-sky-600 text-white hover:bg-sky-700 disabled:opacity-50"
            >
              <Wand2 size={12} /> Pre-fill from my description
            </button>
            {proposedCount > 0 && (
              <button
                type="button"
                onClick={() => handleDecide({ acceptAll: true })}
                disabled={busy}
                className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border border-sky-300 text-sky-700 hover:bg-sky-50 disabled:opacity-50"
              >
                <CheckCircle2 size={12} /> Accept all {proposedCount} pre-fills
              </button>
            )}
            <button
              type="button"
              onClick={handleQaReview}
              disabled={busy}
              className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-600 hover:border-elevance-purple/40 disabled:opacity-50"
            >
              <Sparkles size={12} /> QA review
            </button>
          </>
        )}
        {busy && <Loader2 size={14} className="animate-spin text-elevance-purple" />}
      </div>

      {prefillNote && (
        <div className="flex items-start gap-2 bg-sky-50 border border-sky-200 rounded-xl px-3 py-2 text-xs text-sky-800">
          <Wand2 size={12} className="flex-shrink-0 mt-0.5" />
          <span className="flex-1">{prefillNote}</span>
          <button type="button" onClick={() => setPrefillNote(null)}>
            <X size={12} />
          </button>
        </div>
      )}

      {qaConcerns && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 text-xs text-amber-800">
          <div className="flex items-center gap-2 font-semibold mb-1">
            <Sparkles size={12} />
            QA review{' '}
            {qaConcerns.length === 0 ? '— no concerns' : `— ${qaConcerns.length} suggestion(s)`}
            <button type="button" className="ml-auto" onClick={() => setQaConcerns(null)}>
              <X size={12} />
            </button>
          </div>
          {qaConcerns.map((c) => (
            <p key={c.canonical_id} className="mb-1">
              <span className="font-medium">{c.concern}</span> — {c.clarifying_question}
            </p>
          ))}
        </div>
      )}

      {error && (
        <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-xl px-3 py-2 text-xs text-red-700">
          <AlertCircle size={12} className="flex-shrink-0 mt-0.5" />
          <span className="flex-1">{error}</span>
          <button type="button" onClick={() => setError(null)}>
            <X size={12} />
          </button>
        </div>
      )}

      {view.unknown_teams.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-3 py-2 text-xs text-amber-800">
          Unknown team name(s) in the incoming state (no questionnaire match):{' '}
          {view.unknown_teams.join(', ')}
        </div>
      )}

      {/* question sections */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1 min-h-0">
        {sections.map((section, i) => (
          <Section
            key={`${filter}:${section.key}`}
            section={section}
            defaultOpen={i === 0 || filter !== 'all'}
            teamLabelMap={teamLabelMap}
            onSave={handleSave}
            onDecide={handleDecide}
            busy={busy}
          />
        ))}
        {sections.length === 0 && (
          <p className="text-xs text-gray-400 italic px-2 py-6 text-center">
            No questions match this filter.
          </p>
        )}
        {delegated.length > 0 && (
          <div className="bg-white border border-gray-200 rounded-xl px-4 py-3">
            <p className="text-[11px] text-gray-500">
              Activated with no questions (delegated review):{' '}
              <span className="text-gray-700">
                {delegated.map((t) => teamLabel(teamLabelMap, t)).join(', ')}
              </span>
            </p>
          </div>
        )}
      </div>

      {/* submit bar */}
      {ticket ? (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 flex items-center gap-2">
          <FileCheck2 size={16} className="text-emerald-600" />
          <span className="text-sm text-emerald-800">
            Submitted as <span className="font-mono font-semibold">{ticket.ticket_id}</span> —
            answers fanned out to {Object.keys(ticket.team_forms ?? {}).length} team form(s).
          </span>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl px-4 py-3 flex items-center gap-3 flex-wrap">
          <DiagramUpload
            sessionId={sessionId}
            attachments={view.attachments}
            onUploaded={handleDiagramUploaded}
          />
          <div className="ml-auto flex items-center gap-3">
            {completeness && !completeness.complete && (
              <span className="text-[11px] text-gray-400">
                {completeness.unanswered_count} question(s) open
                {completeness.open_gaps.length
                  ? ` · ${completeness.open_gaps.length} required gap(s)`
                  : ''}
              </span>
            )}
            <button
              type="button"
              onClick={handleSubmit}
              disabled={busy || !completeness?.complete}
              title={
                completeness?.complete
                  ? 'Submit for governance review'
                  : 'All questions must be answered first (pre-fills count only once accepted)'
              }
              className="text-xs px-4 py-2 rounded-lg bg-elevance-purple text-white hover:bg-elevance-purple/90 disabled:opacity-40"
            >
              Submit for review
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
