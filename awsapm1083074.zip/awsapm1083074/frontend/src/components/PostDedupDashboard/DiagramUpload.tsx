/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useRef, useState } from 'react';
import { CheckCircle2, Loader2, Paperclip, Upload } from 'lucide-react';
import type { Attachment } from '../../types';
import { uploadPostDedupAttachment } from '../../postDedupApi';

const REQUIRED_EXTENSIONS = ['.pptx', '.ppt'];

interface DiagramUploadProps {
  sessionId: string;
  attachments: Attachment[];
  onUploaded: (attachments: Attachment[]) => void;
}

/**
 * The solution/data-flow diagram (.pptx) the deterministic submit gate
 * requires — collected inline here rather than through a separate
 * attachments step, since this dashboard replaces that step for this phase.
 */
export default function DiagramUpload({ sessionId, attachments, onUploaded }: DiagramUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const hasRequired = (attachments || []).some((a) =>
    REQUIRED_EXTENSIONS.some((ext) => (a.filename || '').toLowerCase().endsWith(ext))
  );

  return (
    <div className="flex items-center gap-2">
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          e.target.value = '';
          if (!file) return;
          setUploading(true);
          setError(null);
          try {
            const r = await uploadPostDedupAttachment(sessionId, file);
            onUploaded(r.attachments);
          } catch (err) {
            setError(err instanceof Error ? err.message : String(err));
          } finally {
            setUploading(false);
          }
        }}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={uploading}
        className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg border border-gray-200 text-gray-600 hover:border-elevance-purple/40 disabled:opacity-50"
      >
        {uploading ? (
          <Loader2 size={12} className="animate-spin" />
        ) : hasRequired ? (
          <CheckCircle2 size={12} className="text-emerald-500" />
        ) : (
          <Upload size={12} />
        )}
        {hasRequired ? 'Diagram attached' : 'Attach solution diagram (.pptx)'}
      </button>
      {(attachments || []).map((a) => (
        <span key={a.key || a.filename} className="text-[10px] text-gray-400 flex items-center gap-1">
          <Paperclip size={10} /> {a.filename}
        </span>
      ))}
      {error && <span className="text-[10px] text-red-600">{error}</span>}
    </div>
  );
}
