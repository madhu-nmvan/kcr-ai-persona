/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import type { PrefillDecision } from '../../types';
import type { QuestionSection } from '../../lib/postDedupSections';
import { teamLabel } from '../../lib/teamLabels';
import QuestionRow from './QuestionRow';

const CHUNK = 60; // rows mounted per lazy-render step inside a section

interface SectionProps {
  section: QuestionSection;
  defaultOpen: boolean;
  teamLabelMap: Record<string, string>;
  onSave: (canonicalId: string, answer: string) => void;
  onDecide: (decision: PrefillDecision) => void;
  busy: boolean;
}

/**
 * Collapsible group of deduped questions (shared-by-category, or
 * singleton-by-team). Lazily mounts rows CHUNK at a time via an
 * IntersectionObserver sentinel so a 700-question section never puts 700
 * rows in the DOM up front.
 */
export default function Section({
  section,
  defaultOpen,
  teamLabelMap,
  onSave,
  onDecide,
  busy,
}: SectionProps) {
  const [open, setOpen] = useState(defaultOpen);
  const [visible, setVisible] = useState(CHUNK);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const answered = section.questions.filter((q) => q.answered).length;
  const proposals = section.questions.filter(
    (q) => q.prefill && q.prefill.status === 'proposed'
  ).length;
  const total = section.questions.length;

  useEffect(() => {
    if (!open || visible >= total || !sentinelRef.current) return undefined;
    const obs = new IntersectionObserver(
      (entries) => entries[0].isIntersecting && setVisible((v) => v + CHUNK),
      { rootMargin: '400px' }
    );
    obs.observe(sentinelRef.current);
    return () => obs.disconnect();
  }, [open, visible, total]);

  const sectionLabel = section.shared ? section.key : teamLabel(teamLabelMap, section.key);

  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center gap-2 px-4 py-3 hover:bg-gray-50 text-left"
      >
        {open ? (
          <ChevronDown size={14} className="text-gray-400 flex-shrink-0" />
        ) : (
          <ChevronRight size={14} className="text-gray-400 flex-shrink-0" />
        )}
        <span className="text-xs font-semibold text-gray-700 truncate">{sectionLabel}</span>
        {section.shared && (
          <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 flex-shrink-0">
            deduplicated
          </span>
        )}
        <span className="ml-auto flex items-center gap-2 flex-shrink-0">
          {proposals > 0 && (
            <span className="text-[10px] text-sky-600">{proposals} pre-filled</span>
          )}
          <span
            className={`text-[10px] ${answered === total ? 'text-emerald-600' : 'text-gray-400'}`}
          >
            {answered}/{total}
          </span>
        </span>
      </button>
      {open && (
        <div>
          {section.questions.slice(0, visible).map((q) => (
            <QuestionRow
              key={q.canonical_id}
              question={q}
              teamLabelMap={teamLabelMap}
              onSave={onSave}
              onDecide={onDecide}
              busy={busy}
            />
          ))}
          {visible < total && (
            <div ref={sentinelRef} className="px-4 py-3 text-center">
              <span className="text-[10px] text-gray-400">
                Loading more… ({visible} of {total})
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
