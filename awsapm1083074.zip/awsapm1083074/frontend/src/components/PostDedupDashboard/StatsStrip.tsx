/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { PostDedupStats } from '../../types';

interface StatsStripProps {
  stats: PostDedupStats | null | undefined;
}

/** Before/after strip: raw team questions -> deduped -> pre-filled -> answered. */
export default function StatsStrip({ stats }: StatsStripProps) {
  if (!stats) return null;
  const items = [
    { label: 'raw team questions', value: stats.raw_question_count },
    { label: 'after dedup', value: stats.consolidated_question_count },
    {
      label: 'pre-filled',
      value: stats.answered_by_prefill_count + (stats.prefill?.proposed || 0),
    },
    { label: 'answered', value: stats.answered_count },
  ];
  return (
    <div className="flex items-stretch gap-2">
      {items.map((item, i) => (
        <div
          key={item.label}
          className="flex-1 bg-white border border-gray-200 rounded-xl px-3 py-2 text-center"
        >
          <div
            className={`text-lg font-bold ${i === 1 ? 'text-elevance-purple' : 'text-gray-800'}`}
          >
            {item.value}
          </div>
          <div className="text-[9px] uppercase tracking-wider text-gray-400">{item.label}</div>
        </div>
      ))}
    </div>
  );
}
