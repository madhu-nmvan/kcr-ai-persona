/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { CheckCircle2, ChevronRight, Lock } from 'lucide-react';
import type { SessionState, WorkflowStep } from '../../types';
import { stepStatus } from '../../lib/steps';

interface FormProgressListProps {
  steps: WorkflowStep[];
  liveIndex: number;
  viewIndex: number;
  state: SessionState;
  onEdit: (index: number) => void;
}

/**
 * Replaces the old chat-only sidebar's TeamsPanel/QaProgressPanel role —
 * one row per step (the same step list WorkflowPanel renders), so this
 * panel and the left column always agree on progress.
 */
export default function FormProgressList({
  steps,
  liveIndex,
  viewIndex,
  state,
  onEdit,
}: FormProgressListProps) {
  const doneCount = steps.filter(
    (_, i) => stepStatus(i, liveIndex, state, steps) === 'done'
  ).length;

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4">
      <h3 className="text-xs font-semibold text-gray-700 mb-1">Form Progress</h3>
      <p className="text-[11px] text-gray-400 mb-3">
        {doneCount} of {steps.length} completed
      </p>
      <div className="w-full h-1.5 bg-gray-100 rounded-full mb-3">
        <div
          className="h-full bg-elevance-purple rounded-full transition-all duration-300"
          style={{ width: `${(doneCount / steps.length) * 100}%` }}
        />
      </div>
      <ul className="space-y-1">
        {steps.map((step, i) => {
          const status = stepStatus(i, liveIndex, state, steps);
          const isViewing = i === viewIndex;
          return (
            <li
              key={step.key}
              className={`flex items-center gap-2 px-2 py-1.5 rounded-lg ${
                isViewing ? 'bg-elevance-purple/10' : ''
              }`}
            >
              {status === 'done' ? (
                <CheckCircle2 size={14} className="text-emerald-500 flex-shrink-0" />
              ) : status === 'current' ? (
                <ChevronRight size={14} className="text-elevance-purple flex-shrink-0" />
              ) : (
                <Lock size={12} className="text-gray-300 flex-shrink-0" />
              )}
              <div className="min-w-0 flex-1">
                <p
                  className={`text-xs truncate ${
                    isViewing
                      ? 'text-elevance-purple font-medium'
                      : status === 'locked'
                      ? 'text-gray-400'
                      : 'text-gray-700'
                  }`}
                >
                  {i + 1}. {step.label}
                </p>
                <p className="text-[10px] text-gray-400">
                  {status === 'done'
                    ? 'Completed'
                    : status === 'current'
                    ? 'In progress'
                    : 'Not started'}
                </p>
              </div>
              {status !== 'locked' &&
                !isViewing &&
                !(step.kind === 'routing' && state.phase !== 'collecting_routing_info') && (
                <button
                  onClick={() => onEdit(i)}
                  className="text-[11px] text-elevance-purple hover:underline flex-shrink-0"
                >
                  Edit
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
