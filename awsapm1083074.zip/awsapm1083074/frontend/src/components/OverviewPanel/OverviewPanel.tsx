/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { SessionState, WorkflowStep } from '../../types';
import SubmissionOverviewCard from './SubmissionOverviewCard';
import FormProgressList from './FormProgressList';
import HelpfulResourcesCard from './HelpfulResourcesCard';
import TicketPanel from './TicketPanel';

interface OverviewPanelProps {
  state: SessionState;
  steps: WorkflowStep[];
  liveIndex: number;
  viewIndex: number;
  onEditStep: (index: number) => void;
}

export default function OverviewPanel({
  state,
  steps,
  liveIndex,
  viewIndex,
  onEditStep,
}: OverviewPanelProps) {
  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      <SubmissionOverviewCard state={state} />
      <FormProgressList
        steps={steps}
        liveIndex={liveIndex}
        viewIndex={viewIndex}
        state={state}
        onEdit={onEditStep}
      />
      <HelpfulResourcesCard />
      <TicketPanel ticket={state.ticket} />
    </div>
  );
}
