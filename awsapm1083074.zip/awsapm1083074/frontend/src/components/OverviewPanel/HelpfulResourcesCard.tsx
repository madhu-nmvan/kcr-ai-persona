/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { ExternalLink } from 'lucide-react';

// Placeholder content — easy to wire to real links later.
const RESOURCES = ['Data Classification Guide', 'PHI Handling Standards', 'AI Governance Policy'];

export default function HelpfulResourcesCard() {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4">
      <h3 className="text-xs font-semibold text-gray-700 mb-3">Helpful Resources</h3>
      <ul className="space-y-2">
        {RESOURCES.map((label) => (
          <li key={label}>
            <span
              className="flex items-center gap-1.5 text-xs text-gray-400 cursor-not-allowed"
              title="Link not configured yet"
            >
              {label} <ExternalLink size={11} />
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
