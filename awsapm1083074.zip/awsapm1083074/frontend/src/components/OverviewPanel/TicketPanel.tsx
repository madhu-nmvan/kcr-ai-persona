/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { FileCheck2 } from 'lucide-react';
import type { Ticket } from '../../types';

export default function TicketPanel({ ticket }: { ticket: Ticket | null }) {
  if (!ticket) return null;
  const teamNames = (ticket.activated_teams || []).map((t) => t.team);
  const attachments = ticket.attachments || [];
  return (
    <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4">
      <h3 className="text-xs font-semibold text-emerald-800 mb-2 flex items-center gap-1.5">
        <FileCheck2 size={12} /> Ticket Submitted
      </h3>
      <p className="text-xs text-emerald-700 font-mono mb-1">{ticket.ticket_id}</p>
      <p className="text-xs text-emerald-700">
        Teams reviewed: <span className="font-medium">{teamNames.join(', ') || '—'}</span>
      </p>
      <p className="text-xs text-emerald-700 mt-1">
        {teamNames.length} team(s) identified,{' '}
        {ticket.answered_questions?.length || 0} Q&amp;A captured across {teamNames.length}{' '}
        team(s).
      </p>
      {!!attachments.length && (
        <p className="text-xs text-emerald-700 mt-1">
          {attachments.length} attachment(s): {attachments.map((a) => a.filename).join(', ')}
        </p>
      )}
    </div>
  );
}
