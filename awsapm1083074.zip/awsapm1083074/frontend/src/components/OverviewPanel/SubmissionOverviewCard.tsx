/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { ReactNode } from 'react';
import type { SessionState } from '../../types';
import { formatDateTime } from '../../lib/format';
import PhaseBadge from '../shared/PhaseBadge';

function Row({ label, value, mono }: { label: string; value: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <dt className="text-gray-400">{label}</dt>
      <dd className={`text-gray-700 font-medium ${mono ? 'font-mono' : ''}`}>{value}</dd>
    </div>
  );
}

export default function SubmissionOverviewCard({ state }: { state: SessionState }) {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4">
      <h3 className="text-xs font-semibold text-gray-700 mb-3">Submission Overview</h3>
      <dl className="space-y-2.5 text-xs">
        <Row label="Submission ID" value={state.display_id || '—'} mono />
        <Row label="Status" value={<PhaseBadge phase={state.phase} />} />
        <Row label="Created" value={formatDateTime(state.created_at)} />
        <Row label="Last Updated" value={formatDateTime(state.updated_at)} />
        <Row label="Owner" value={state.user_id || '—'} />
      </dl>
    </div>
  );
}
