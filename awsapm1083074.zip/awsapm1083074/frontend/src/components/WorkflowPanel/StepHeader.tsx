/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

interface StepHeaderProps {
  index: number;
  total: number;
  label: string;
  description?: string;
}

export default function StepHeader({ index, total, label, description }: StepHeaderProps) {
  const pct = total > 0 ? Math.round(((index + 1) / total) * 100) : 0;
  return (
    <div className="mb-5">
      <div className="flex items-center justify-between text-xs text-gray-500 mb-1.5">
        <span>
          Step {index + 1} of {total} • {label}
        </span>
        <span>{pct}%</span>
      </div>
      <div className="w-full h-1.5 bg-gray-100 rounded-full">
        <div
          className="h-full bg-elevance-purple rounded-full transition-all duration-300"
          style={{ width: `${pct}%` }}
        />
      </div>
      {description && <p className="text-xs text-gray-400 mt-2">{description}</p>}
    </div>
  );
}
