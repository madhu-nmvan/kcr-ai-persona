/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useEffect, useRef, useState } from 'react';
import { Sparkles } from 'lucide-react';
import type { SchemaField, RoutingFieldValue } from '../../types';

interface FieldControlProps {
  field: SchemaField;
  value: RoutingFieldValue;
  onChange: (value: RoutingFieldValue) => void;
  onFocusField: () => void;
  onBlurField: () => void;
  disabled: boolean;
  /** True for ~2s right after the AI (not the user) set this field's value. */
  highlighted?: boolean;
}

const inputClass =
  'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-elevance-purple/20 focus:border-elevance-purple disabled:bg-gray-50 disabled:text-gray-400';

const optionRowClass = (active: boolean, disabled: boolean) =>
  `flex items-center gap-2 px-3 py-2 text-sm border rounded-lg transition-colors ${
    active ? 'border-elevance-purple bg-elevance-purple/5' : 'border-gray-200 hover:border-elevance-purple/40'
  } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`;

function FieldLabel({ field, highlighted }: { field: SchemaField; highlighted?: boolean }) {
  return (
    <label
      htmlFor={`field-${field.name}`}
      className="flex flex-wrap items-center gap-1.5 text-sm font-medium text-gray-700 mb-1.5"
    >
      <span>
        {field.description || field.name}
        {field.required && <span className="text-red-500 ml-0.5">*</span>}
      </span>
      <span
        className={`flex items-center gap-1 text-[10px] text-elevance-purple transition-opacity duration-700 ${
          highlighted ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <Sparkles size={11} /> Updated by AI
      </span>
    </label>
  );
}

export default function FieldControl({
  field,
  value,
  onChange,
  onFocusField,
  onBlurField,
  disabled,
  highlighted,
}: FieldControlProps) {
  const id = `field-${field.name}`;

  if (field.type === 'bool') {
    const boolValue = typeof value === 'boolean' ? value : null;
    return (
      <div className="mb-5">
        <FieldLabel field={field} highlighted={highlighted} />
        <div className="flex gap-2">
          {([
            { v: true, l: 'Yes' },
            { v: false, l: 'No' },
          ] as const).map(({ v, l }) => (
            <button
              key={l}
              type="button"
              disabled={disabled}
              onFocus={onFocusField}
              onBlur={onBlurField}
              onClick={() => onChange(v)}
              className={`flex-1 px-3 py-2 text-sm rounded-lg border transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
                boolValue === v
                  ? 'border-elevance-purple bg-elevance-purple/10 text-elevance-purple font-medium'
                  : 'border-gray-200 text-gray-600 hover:border-elevance-purple/40'
              }`}
            >
              {l}
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (field.type === 'enum') {
    const opts = field.options || [];
    if (opts.length > 0 && opts.length <= 4) {
      return (
        <div className="mb-5">
          <FieldLabel field={field} highlighted={highlighted} />
          <div className="space-y-2">
            {opts.map((opt) => (
              <label key={opt} className={optionRowClass(value === opt, disabled)}>
                <input
                  type="radio"
                  name={id}
                  className="accent-elevance-purple"
                  checked={value === opt}
                  disabled={disabled}
                  onFocus={onFocusField}
                  onBlur={onBlurField}
                  onChange={() => onChange(opt)}
                />
                {opt}
              </label>
            ))}
          </div>
        </div>
      );
    }
    return (
      <div className="mb-5">
        <FieldLabel field={field} highlighted={highlighted} />
        <select
          id={id}
          className={inputClass}
          value={typeof value === 'string' ? value : ''}
          disabled={disabled}
          onFocus={onFocusField}
          onBlur={onBlurField}
          onChange={(e) => onChange(e.target.value || null)}
        >
          <option value="">Select…</option>
          {opts.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      </div>
    );
  }

  if (field.type === 'array') {
    const opts = field.items?.enums || [];
    const selected = Array.isArray(value) ? (value as string[]) : [];
    return (
      <div className="mb-5">
        <FieldLabel field={field} highlighted={highlighted} />
        <div className="space-y-2">
          {opts.map((opt) => (
            <label key={opt} className={optionRowClass(selected.includes(opt), disabled)}>
              <input
                type="checkbox"
                className="accent-elevance-purple"
                checked={selected.includes(opt)}
                disabled={disabled}
                onFocus={onFocusField}
                onBlur={onBlurField}
                onChange={(e) => {
                  const next = e.target.checked
                    ? [...selected, opt]
                    : selected.filter((v) => v !== opt);
                  onChange(next);
                }}
              />
              {opt}
            </label>
          ))}
        </div>
      </div>
    );
  }

  return (
    <StringFieldInput
      field={field}
      value={typeof value === 'string' ? value : ''}
      onChange={onChange}
      onFocusField={onFocusField}
      onBlurField={onBlurField}
      disabled={disabled}
      highlighted={highlighted}
    />
  );
}

/**
 * Free-text fields commit on blur rather than per-keystroke — avoids a PATCH
 * per character, and blur is also naturally when we want to clear the
 * chat's "focused field" context anyway. Local state syncs down from the
 * server-driven `value` prop only while NOT focused, so a value the LLM
 * fills in via chat while the user is elsewhere still shows up live without
 * clobbering active typing.
 */
function StringFieldInput({
  field,
  value,
  onChange,
  onFocusField,
  onBlurField,
  disabled,
  highlighted,
}: {
  field: SchemaField;
  value: string;
  onChange: (value: string) => void;
  onFocusField: () => void;
  onBlurField: () => void;
  disabled: boolean;
  highlighted?: boolean;
}) {
  const [local, setLocal] = useState(value);
  const focusedRef = useRef(false);
  const id = `field-${field.name}`;

  useEffect(() => {
    if (!focusedRef.current) setLocal(value);
  }, [value]);

  const isLong = /description|functionality/i.test(field.name);

  const shared = {
    id,
    className: inputClass,
    value: local,
    disabled,
    onFocus: () => {
      focusedRef.current = true;
      onFocusField();
    },
    onBlur: () => {
      focusedRef.current = false;
      onBlurField();
      if (local !== value) onChange(local);
    },
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setLocal(e.target.value),
  };

  return (
    <div className="mb-5">
      <FieldLabel field={field} highlighted={highlighted} />
      {isLong ? <textarea rows={3} {...shared} /> : <input type="text" {...shared} />}
    </div>
  );
}
