/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useRef, useState } from 'react';
import { AlertCircle, CheckCircle2, Loader2, Paperclip, Upload } from 'lucide-react';
import type { Attachment } from '../../types';
import { uploadAttachment } from '../../api';
import { formatBytes } from '../../lib/format';

const REQUIRED_EXTENSIONS = ['.pptx', '.ppt'];
const ALLOWED_EXTENSIONS = [
  '.pptx', '.ppt', '.pdf', '.docx', '.doc', '.xlsx', '.png', '.jpg', '.jpeg',
];
const MAX_ATTACHMENT_MB = 200;

function fileExt(name: string): string {
  const i = name.lastIndexOf('.');
  return i === -1 ? '' : name.slice(i).toLowerCase();
}

interface AttachmentStepProps {
  sessionId: string;
  attachments: Attachment[];
  onUploaded: (attachments: Attachment[]) => void;
  disabled: boolean;
}

/**
 * A PowerPoint (.pptx) solution/data-flow diagram is required before
 * submission — enforced server-side too, this is just UX guidance.
 */
export default function AttachmentStep({
  sessionId,
  attachments,
  onUploaded,
  disabled,
}: AttachmentStepProps) {
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const hasRequired = (attachments || []).some((a) =>
    REQUIRED_EXTENSIONS.includes(fileExt(a.filename || ''))
  );

  async function handleFiles(fileList: FileList | null) {
    const files = Array.from(fileList || []);
    if (files.length === 0) return;
    setError(null);

    for (const file of files) {
      const ext = fileExt(file.name);
      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        setError(
          `"${file.name}" has an unsupported type (${ext || 'unknown'}). ` +
            `Allowed: ${ALLOWED_EXTENSIONS.join(', ')}`
        );
        continue;
      }
      if (file.size > MAX_ATTACHMENT_MB * 1024 * 1024) {
        setError(`"${file.name}" exceeds the ${MAX_ATTACHMENT_MB} MB limit.`);
        continue;
      }
      setUploading(true);
      setProgress(0);
      try {
        const result = await uploadAttachment(sessionId, file, setProgress);
        onUploaded?.((result.attachments as Attachment[]) || attachments);
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e));
      } finally {
        setUploading(false);
        setProgress(0);
      }
    }
  }

  return (
    <div>
      <p className="text-xs text-gray-400 mb-3">
        A PowerPoint (.pptx) solution / data-flow diagram is{' '}
        <span className="font-medium text-gray-500">required</span>. Other supporting docs
        are optional.
      </p>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          if (!disabled) handleFiles(e.dataTransfer.files);
        }}
        onClick={() => !disabled && inputRef.current?.click()}
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
          disabled
            ? 'border-gray-100 bg-gray-50 cursor-not-allowed'
            : dragOver
            ? 'border-elevance-purple bg-elevance-purple/5'
            : 'border-gray-200 hover:border-elevance-purple/40'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={ALLOWED_EXTENSIONS.join(',')}
          className="hidden"
          disabled={disabled}
          onChange={(e) => {
            handleFiles(e.target.files);
            e.target.value = '';
          }}
        />
        {uploading ? (
          <div className="space-y-2">
            <Loader2 size={20} className="animate-spin text-elevance-purple mx-auto" />
            <div className="w-full h-1.5 bg-gray-100 rounded-full">
              <div
                className="h-full bg-elevance-purple rounded-full transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-[10px] text-gray-400">Uploading… {progress}%</p>
          </div>
        ) : (
          <div className="space-y-1">
            <Upload size={20} className="text-gray-400 mx-auto" />
            <p className="text-sm text-gray-500">
              Drag &amp; drop or <span className="text-elevance-purple">browse</span>
            </p>
            <p className="text-[10px] text-gray-400">
              PPTX, PDF, DOCX, XLSX, PNG, JPG — up to {MAX_ATTACHMENT_MB} MB
            </p>
          </div>
        )}
      </div>

      {error && (
        <p className="mt-2 text-[11px] text-red-600 flex items-start gap-1">
          <AlertCircle size={12} className="flex-shrink-0 mt-0.5" /> {error}
        </p>
      )}

      {!!(attachments || []).length && (
        <ul className="mt-3 space-y-1.5">
          {attachments.map((a) => {
            const required = REQUIRED_EXTENSIONS.includes(fileExt(a.filename || ''));
            return (
              <li
                key={a.key}
                className="flex items-center gap-2 text-xs bg-gray-50 rounded px-2 py-1.5"
              >
                <Paperclip size={11} className="text-gray-400 flex-shrink-0" />
                <span className="truncate flex-1 text-gray-700">{a.filename}</span>
                {required && (
                  <span className="text-[9px] px-1 py-0.5 rounded bg-emerald-100 text-emerald-700 flex-shrink-0">
                    required doc
                  </span>
                )}
                <span className="text-[10px] text-gray-400 flex-shrink-0">
                  {formatBytes(a.size)}
                </span>
              </li>
            );
          })}
        </ul>
      )}

      <div className="mt-3 flex items-center gap-1.5 text-[11px]">
        {hasRequired ? (
          <>
            <CheckCircle2 size={12} className="text-emerald-500" />
            <span className="text-emerald-600">
              Required diagram attached — say "done" in chat, or move to the next step, to
              submit.
            </span>
          </>
        ) : (
          <>
            <AlertCircle size={12} className="text-amber-500" />
            <span className="text-amber-600">
              Waiting on a .pptx/.ppt solution diagram before submission.
            </span>
          </>
        )}
      </div>
    </div>
  );
}
