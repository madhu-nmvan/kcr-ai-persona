/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type {
  Attachment,
  FocusedField,
  IntakeSchema,
  PendingQuestion,
  SchemaField,
  SessionState,
  WorkflowStep,
} from '../../types';
import { setAnswer, setRoutingField } from '../../api';
import { stepIsEditable } from '../../lib/steps';
import { Progress } from '../ui/progress';
import StepHeader from './StepHeader';
import SchemaFormStep from './SchemaFormStep';
import TeamQuestionsStep from './TeamQuestionsStep';
import AttachmentStep from './AttachmentStep';
import StepFooterNav from './StepFooterNav';

interface WorkflowPanelProps {
  sessionId: string;
  schema: IntakeSchema;
  state: SessionState;
  steps: WorkflowStep[];
  viewIndex: number;
  onViewIndexChange: (index: number) => void;
  onStateChange: (state: SessionState) => void;
  onAttachmentsChange: (attachments: Attachment[]) => void;
  onFocusField: (field: FocusedField | null) => void;
  /** True while a chat turn is in flight — shows the "AI is updating your
   * form" indicator. */
  aiWorking: boolean;
  /** Field names / canonical_ids the AI (not the user) just set. */
  highlightedKeys: Set<string>;
}

export default function WorkflowPanel({
  sessionId,
  schema,
  state,
  steps,
  viewIndex,
  onViewIndexChange,
  onStateChange,
  onAttachmentsChange,
  onFocusField,
  aiWorking,
  highlightedKeys,
}: WorkflowPanelProps) {
  const step = steps[viewIndex];
  if (!step) return null;

  const disabled = !stepIsEditable(step, state);

  async function handleFieldChange(name: string, value: unknown) {
    try {
      onStateChange(await setRoutingField(sessionId, name, value));
    } catch (e) {
      console.error('setRoutingField failed', e);
    }
  }

  async function handleAnswerChange(canonicalId: string, answer: string) {
    try {
      onStateChange(await setAnswer(sessionId, canonicalId, answer));
    } catch (e) {
      console.error('setAnswer failed', e);
    }
  }

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="px-5 pt-5 flex-shrink-0">
        <h2 className="text-base font-semibold text-elevance-dark mb-3">Intake Form</h2>
        {/* Fixed-height row (reserved whether or not it's showing anything)
            so the AI-is-working indicator popping in/out never shifts the
            form fields below it. */}
        <div className="h-5 mb-1 flex items-center gap-2">
          {aiWorking && (
            <>
              <Progress value={null} className="flex-1" />
              <span className="text-[10px] text-elevance-purple whitespace-nowrap flex-shrink-0">
                AI is updating your form…
              </span>
            </>
          )}
        </div>
        <StepHeader index={viewIndex} total={steps.length} label={step.label} />
      </div>

      <div className="flex-1 overflow-y-auto px-5">
        {step.kind === 'routing' && (
          <SchemaFormStep
            schema={schema}
            collectedFields={state.collected_fields}
            disabled={disabled}
            onFieldChange={handleFieldChange}
            onFocusField={(field: SchemaField) =>
              onFocusField({
                name: field.name,
                label: field.description || field.name,
                description: field.description,
              })
            }
            onBlurField={() => onFocusField(null)}
            highlightedKeys={highlightedKeys}
          />
        )}

        {step.kind === 'team' && step.team && (
          <TeamQuestionsStep
            team={step.label}
            questions={state.pending_questions.filter((q) => q.category === step.team)}
            disabled={disabled}
            onAnswerChange={handleAnswerChange}
            onFocusField={(q: PendingQuestion) =>
              onFocusField({ canonical_id: q.canonical_id, label: q.canonical_question })
            }
            onBlurField={() => onFocusField(null)}
            highlightedKeys={highlightedKeys}
          />
        )}

        {step.kind === 'attachments' && (
          <AttachmentStep
            sessionId={sessionId}
            attachments={state.attachments}
            onUploaded={onAttachmentsChange}
            disabled={disabled}
          />
        )}

        {step.kind === 'submit' && (
          <div className="text-sm text-gray-600 pb-4">
            {state.ticket ? (
              <p>
                This request has been submitted — see the ticket summary in the right
                panel.
              </p>
            ) : (
              <p>
                Complete the steps above, then upload the required attachment, to submit
                this request.
              </p>
            )}
          </div>
        )}
      </div>

      <div className="px-5 pb-5 flex-shrink-0">
        <StepFooterNav
          canGoPrev={viewIndex > 0}
          canGoNext={viewIndex < steps.length - 1}
          onPrev={() => onViewIndexChange(Math.max(0, viewIndex - 1))}
          onNext={() => onViewIndexChange(Math.min(steps.length - 1, viewIndex + 1))}
          isLastStep={viewIndex === steps.length - 1}
        />
      </div>
    </div>
  );
}
