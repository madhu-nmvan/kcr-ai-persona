/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useMemo } from 'react';
import type { CollectedFields, IntakeSchema, SchemaField } from '../../types';
import { evaluateRequiredWhen } from '../../lib/requiredWhen';
import FieldControl from './FieldControl';

interface SchemaFormStepProps {
  schema: IntakeSchema;
  collectedFields: CollectedFields;
  disabled: boolean;
  onFieldChange: (name: string, value: unknown) => void;
  onFocusField: (field: SchemaField) => void;
  onBlurField: () => void;
  highlightedKeys: Set<string>;
}

/**
 * Phase 1: intake_schema.json's ~40 fields grouped by their "group" key
 * into digestible sub-sections instead of one long scroll — the grouping
 * still lives in the schema (JSON-driven), not hardcoded here.
 */
export default function SchemaFormStep({
  schema,
  collectedFields,
  disabled,
  onFieldChange,
  onFocusField,
  onBlurField,
  highlightedKeys,
}: SchemaFormStepProps) {
  const groups = useMemo(() => {
    const order: string[] = [];
    const byGroup = new Map<string, SchemaField[]>();
    for (const field of schema.fields) {
      if (!evaluateRequiredWhen(field.required_when, collectedFields)) continue;
      const g = field.group || 'Other';
      if (!byGroup.has(g)) {
        byGroup.set(g, []);
        order.push(g);
      }
      byGroup.get(g)!.push(field);
    }
    return order.map((group) => ({ group, fields: byGroup.get(group)! }));
  }, [schema.fields, collectedFields]);

  return (
    <div>
      {groups.map(({ group, fields }) => (
        <section key={group} className="mb-6 last:mb-0">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-3">
            {group}
          </h3>
          {fields.map((field) => (
            <FieldControl
              key={field.name}
              field={field}
              value={collectedFields[field.name]}
              disabled={disabled}
              onChange={(v) => onFieldChange(field.name, v)}
              onFocusField={() => onFocusField(field)}
              onBlurField={onBlurField}
              highlighted={highlightedKeys.has(field.name)}
            />
          ))}
        </section>
      ))}
    </div>
  );
}
