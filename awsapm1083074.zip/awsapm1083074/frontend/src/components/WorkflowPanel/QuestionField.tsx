/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, Sparkles } from 'lucide-react';
import type { PendingQuestion } from '../../types';

interface QuestionFieldProps {
  question: PendingQuestion;
  disabled: boolean;
  onAnswerChange: (canonicalId: string, answer: string) => void;
  onFocusField: (question: PendingQuestion) => void;
  onBlurField: () => void;
  /** True for ~2s right after the AI (not the user) set this answer. */
  highlighted?: boolean;
}

/**
 * Free text — demo_team_questions.json's questions carry no type metadata
 * (unlike intake_schema.json's typed Phase-1 fields), so unlike
 * FieldControl this always renders a textarea. Same blur-commit pattern as
 * FieldControl's string fields.
 */
export default function QuestionField({
  question,
  disabled,
  onAnswerChange,
  onFocusField,
  onBlurField,
  highlighted,
}: QuestionFieldProps) {
  const [local, setLocal] = useState(question.answer || '');
  const focusedRef = useRef(false);

  useEffect(() => {
    if (!focusedRef.current) setLocal(question.answer || '');
  }, [question.answer]);

  return (
    <div className="mb-5">
      <label
        htmlFor={`question-${question.canonical_id}`}
        className="flex flex-wrap items-start gap-1.5 text-sm font-medium text-gray-700 mb-1.5"
      >
        {question.answered && (
          <CheckCircle2 size={14} className="text-emerald-500 flex-shrink-0 mt-0.5" />
        )}
        <span>{question.canonical_question}</span>
        <span
          className={`flex items-center gap-1 text-[10px] text-elevance-purple transition-opacity duration-700 ${
            highlighted ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <Sparkles size={11} /> Updated by AI
        </span>
      </label>
      <textarea
        id={`question-${question.canonical_id}`}
        rows={2}
        className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-elevance-purple/20 focus:border-elevance-purple disabled:bg-gray-50 disabled:text-gray-400"
        value={local}
        disabled={disabled}
        placeholder="Type an answer, or ask the assistant for help…"
        onFocus={() => {
          focusedRef.current = true;
          onFocusField(question);
        }}
        onBlur={() => {
          focusedRef.current = false;
          onBlurField();
          if (local !== (question.answer || '')) onAnswerChange(question.canonical_id, local);
        }}
        onChange={(e) => setLocal(e.target.value)}
      />
    </div>
  );
}
