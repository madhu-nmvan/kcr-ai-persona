/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { ArrowLeft, ArrowRight, Save } from 'lucide-react';

interface StepFooterNavProps {
  canGoPrev: boolean;
  canGoNext: boolean;
  onPrev: () => void;
  onNext: () => void;
  isLastStep: boolean;
}

export default function StepFooterNav({
  canGoPrev,
  canGoNext,
  onPrev,
  onNext,
  isLastStep,
}: StepFooterNavProps) {
  return (
    <div className="flex items-center justify-between pt-4 mt-2 border-t border-gray-100">
      <button
        type="button"
        onClick={onPrev}
        disabled={!canGoPrev}
        className="flex items-center gap-1.5 text-sm text-gray-600 disabled:opacity-40 disabled:cursor-not-allowed hover:text-elevance-purple"
      >
        <ArrowLeft size={14} /> Previous
      </button>
      <div className="flex items-center gap-1.5 text-[11px] text-gray-400">
        <Save size={12} /> Saved automatically
      </div>
      {!isLastStep ? (
        <button
          type="button"
          onClick={onNext}
          disabled={!canGoNext}
          className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg bg-elevance-purple text-white disabled:opacity-40 disabled:cursor-not-allowed hover:bg-elevance-purple/90 transition-colors"
        >
          Next <ArrowRight size={14} />
        </button>
      ) : (
        <span className="w-[76px]" />
      )}
    </div>
  );
}
