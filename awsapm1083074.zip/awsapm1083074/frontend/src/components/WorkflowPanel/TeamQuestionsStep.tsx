/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { PendingQuestion } from '../../types';
import QuestionField from './QuestionField';

interface TeamQuestionsStepProps {
  team: string;
  questions: PendingQuestion[];
  disabled: boolean;
  onAnswerChange: (canonicalId: string, answer: string) => void;
  onFocusField: (question: PendingQuestion) => void;
  onBlurField: () => void;
  highlightedKeys: Set<string>;
}

export default function TeamQuestionsStep({
  team,
  questions,
  disabled,
  onAnswerChange,
  onFocusField,
  onBlurField,
  highlightedKeys,
}: TeamQuestionsStepProps) {
  return (
    <div>
      <p className="text-xs text-gray-500 mb-4">
        Review questions from <span className="font-medium text-gray-700">{team}</span>.
      </p>
      {questions.map((q) => (
        <QuestionField
          key={q.canonical_id}
          question={q}
          disabled={disabled}
          onAnswerChange={onAnswerChange}
          onFocusField={onFocusField}
          onBlurField={onBlurField}
          highlighted={highlightedKeys.has(q.canonical_id)}
        />
      ))}
    </div>
  );
}
