/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type { Components } from 'react-markdown';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Bot, Loader2, User } from 'lucide-react';
import type { UIMessage } from '../../types';

/**
 * Markdown component overrides so agent replies render bullets, numbered
 * lists, bold, and headers with sane spacing inside a small chat bubble
 * (react-markdown's defaults use block-level margins sized for full pages).
 */
const markdownComponents: Components = {
  p: (props) => <p className="mb-2 last:mb-0" {...props} />,
  ul: (props) => <ul className="list-disc pl-5 mb-2 last:mb-0 space-y-0.5" {...props} />,
  ol: (props) => <ol className="list-decimal pl-5 mb-2 last:mb-0 space-y-0.5" {...props} />,
  li: (props) => <li {...props} />,
  strong: (props) => <strong className="font-semibold" {...props} />,
  h1: (props) => <h1 className="text-sm font-bold mb-1.5 mt-2" {...props} />,
  h2: (props) => <h2 className="text-sm font-bold mb-1.5 mt-2" {...props} />,
  h3: (props) => <h3 className="text-sm font-semibold mb-1 mt-2" {...props} />,
  code: ({ className, children, ...props }) => {
    const inline = !className?.includes('language-');
    return inline ? (
      <code className="bg-gray-100 rounded px-1 py-0.5 text-xs font-mono" {...props}>
        {children}
      </code>
    ) : (
      <code
        className="block bg-gray-100 rounded p-2 text-xs font-mono overflow-x-auto"
        {...props}
      >
        {children}
      </code>
    );
  },
  a: (props) => (
    <a className="underline text-elevance-purple" target="_blank" rel="noreferrer" {...props} />
  ),
  hr: () => <hr className="my-2 border-gray-200" />,
  table: (props) => (
    <div className="overflow-x-auto mb-2">
      <table className="text-xs border-collapse" {...props} />
    </div>
  ),
  th: (props) => (
    <th className="border border-gray-200 px-2 py-1 bg-gray-50 text-left" {...props} />
  ),
  td: (props) => <td className="border border-gray-200 px-2 py-1" {...props} />,
};

export default function MessageBubble({ message }: { message: UIMessage }) {
  const isAgent = message.role === 'agent';
  const isEmptyStreaming = isAgent && message.streaming && !message.content;
  return (
    <div className={`flex gap-3 ${isAgent ? '' : 'flex-row-reverse'}`}>
      <div
        className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
          isAgent ? 'bg-elevance-purple/10' : 'bg-gray-100'
        }`}
      >
        {isAgent ? (
          <Bot size={16} className="text-elevance-purple" />
        ) : (
          <User size={16} className="text-gray-600" />
        )}
      </div>
      <div
        className={`max-w-[75%] rounded-xl px-4 py-3 text-sm ${
          isAgent ? 'bg-white border border-gray-200' : 'bg-elevance-purple text-white'
        }`}
      >
        {isEmptyStreaming ? (
          <Loader2 size={16} className="animate-spin text-elevance-purple" />
        ) : isAgent ? (
          <div className="text-gray-700 [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
            <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents}>
              {message.content || ''}
            </ReactMarkdown>
            {message.streaming && (
              <span className="inline-block w-1.5 h-4 ml-0.5 bg-elevance-purple/60 align-middle animate-pulse" />
            )}
          </div>
        ) : (
          <div className="whitespace-pre-wrap text-white">{message.content || ''}</div>
        )}
      </div>
    </div>
  );
}
