/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useEffect, useRef, useState } from 'react';
import { Bot, Loader2, Send } from 'lucide-react';
import type { FocusedField, SessionState, UIMessage } from '../../types';
import { streamMessage } from '../../api';
import MessageBubble from './MessageBubble';

interface ChatPanelProps {
  sessionId: string | null;
  state: SessionState;
  messages: UIMessage[];
  setMessages: React.Dispatch<React.SetStateAction<UIMessage[]>>;
  onStateChange: (state: SessionState) => void;
  focusedField: FocusedField | null;
  onAfterSend?: () => void;
  /** Reports whether a turn is in flight, so the WorkflowPanel can show an
   * "AI is updating your form" indicator while a reply streams in. */
  onLoadingChange?: (loading: boolean) => void;
}

/**
 * Support-chat column. In the form-first model this is no longer the
 * primary way data gets entered — but chat-driven extraction still updates
 * the exact same session state a direct form edit would (see
 * handler.py's _public_state), so answering in chat keeps working exactly
 * as before, live-syncing with the left column.
 */
export default function ChatPanel({
  sessionId,
  state,
  messages,
  setMessages,
  onStateChange,
  focusedField,
  onAfterSend,
  onLoadingChange,
}: ChatPanelProps) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  async function handleSend() {
    if (!input.trim() || loading || !sessionId) return;
    const msg = input.trim();
    setInput('');
    setMessages((prev) => [
      ...prev,
      { role: 'user', content: msg },
      { role: 'agent', content: '', streaming: true },
    ]);
    setLoading(true);
    onLoadingChange?.(true);
    setError(null);

    await streamMessage(
      sessionId,
      msg,
      {
        onDelta: (text) => {
          setMessages((prev) => {
            const next = [...prev];
            const last = next[next.length - 1];
            if (last?.role === 'agent') {
              next[next.length - 1] = { ...last, content: (last.content || '') + text };
            }
            return next;
          });
        },
        onState: (s) => onStateChange(s),
        onError: (e) => setError(e.message || String(e)),
        onDone: () => {
          setMessages((prev) => {
            const next = [...prev];
            const last = next[next.length - 1];
            if (last?.role === 'agent') {
              next[next.length - 1] = { ...last, streaming: false };
            }
            return next;
          });
          setLoading(false);
          onLoadingChange?.(false);
          onAfterSend?.();
        },
      },
      focusedField
    );
  }

  const placeholder = state.ticket
    ? 'Session complete — start a new session to begin another request.'
    : state.phase === 'collecting_attachments'
    ? 'Upload your PPTX in the workflow panel, then type "done" here...'
    : focusedField
    ? `Ask about "${focusedField.label}"…`
    : 'Describe your project, or ask a question about the field you\'re on...';

  return (
    <div className="flex-1 flex flex-col bg-gray-50 h-full overflow-hidden">
      <div className="px-4 py-3 border-b border-gray-200 bg-white flex items-center gap-2 flex-shrink-0">
        <div className="w-8 h-8 rounded-lg bg-elevance-purple flex items-center justify-center flex-shrink-0">
          <Bot size={16} className="text-white" />
        </div>
        <div className="min-w-0">
          <h2 className="text-sm font-semibold text-elevance-dark">AI Intake Assistant</h2>
          <div className="flex items-center gap-1 text-[11px] text-emerald-600">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Online
          </div>
        </div>
        {focusedField && (
          <div className="ml-auto text-[11px] text-elevance-purple bg-elevance-purple/10 px-2 py-1 rounded-full max-w-[45%] truncate">
            Helping with: {focusedField.label}
          </div>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <MessageBubble key={i} message={msg} />
        ))}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
            <strong>Error:</strong> {error}
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="border-t border-gray-200 bg-white p-3 flex-shrink-0">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder={placeholder}
            disabled={loading || !!state.ticket}
            className="flex-1 px-3 py-2.5 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-elevance-purple/20 focus:border-elevance-purple disabled:bg-gray-50"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || loading || !!state.ticket}
            className="p-2.5 bg-elevance-purple text-white rounded-lg hover:bg-elevance-purple/90 disabled:opacity-50 transition-colors"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          </button>
        </div>
        <p className="text-center text-[10px] text-gray-400 mt-2">
          AI can make mistakes. Please review important information.
        </p>
      </div>
    </div>
  );
}
