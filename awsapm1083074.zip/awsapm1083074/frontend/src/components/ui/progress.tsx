/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import * as React from 'react';
import * as ProgressPrimitive from '@radix-ui/react-progress';
import { cn } from '../../lib/utils';

/**
 * shadcn/ui-style Progress, on top of Radix's Progress primitive (same
 * accessible ARIA progressbar semantics shadcn ships). Extended to render
 * an indeterminate sliding-bar state when `value` is omitted/null — Radix
 * itself already exposes `data-state="indeterminate"` for that case, this
 * just supplies the animation for it.
 */
const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>
>(({ className, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    value={value}
    className={cn('relative h-1 w-full overflow-hidden rounded-full bg-gray-100', className)}
    {...props}
  >
    {value == null ? (
      <div className="absolute inset-y-0 left-0 w-1/3 rounded-full bg-elevance-purple animate-indeterminate" />
    ) : (
      <ProgressPrimitive.Indicator
        className="h-full w-full flex-1 bg-elevance-purple transition-transform duration-300 ease-out"
        style={{ transform: `translateX(-${100 - value}%)` }}
      />
    )}
  </ProgressPrimitive.Root>
));
Progress.displayName = ProgressPrimitive.Root.displayName;

export { Progress };
