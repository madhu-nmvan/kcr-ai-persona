/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type {
  FocusedField,
  FormFillerEnvelope,
  FullSessionResponse,
  IntakeSchema,
  SessionState,
  SessionSummary,
  TeamRoster,
} from './types';

/**
 * API paths are RELATIVE (no leading slash) so they resolve relative to
 * wherever this page is actually served from — http://localhost:8000/,
 * or behind a path prefix like SageMaker's /proxy/8000/. In dev, Vite's
 * proxy below still intercepts anything under "api/".
 *
 * Do NOT change these back to "/api/..." — that breaks under any reverse
 * proxy that serves this app at a non-root path.
 */
function apiPath(path: string): string {
  return path.startsWith('/') ? path.slice(1) : path;
}

async function jsonFetch<T>(
  method: string,
  path: string,
  body?: unknown
): Promise<T> {
  const opts: RequestInit = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(apiPath(path), opts);
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const err = await res.json();
      detail = err.detail || detail;
    } catch {
      // response wasn't JSON — fall back to statusText
    }
    throw new Error(`${res.status} ${detail}`);
  }
  return res.json() as Promise<T>;
}

export function startSession(
  userId = 'demo@elevancehealth.com'
): Promise<FullSessionResponse> {
  return jsonFetch('POST', 'api/intake-agent/start', { user_id: userId });
}

export function listSessions(limit = 50): Promise<{ sessions: SessionSummary[] }> {
  return jsonFetch('GET', `api/intake-agent/sessions?limit=${limit}`);
}

export function loadSession(sessionId: string): Promise<FullSessionResponse> {
  return jsonFetch(
    'GET',
    `api/intake-agent/sessions/${encodeURIComponent(sessionId)}`
  );
}

/** intake_schema.json — drives the JSON-driven Phase-1 form. */
export function getSchema(): Promise<IntakeSchema> {
  return jsonFetch('GET', 'api/intake-agent/schema');
}

/** team_roster.json — display names for steps / overview. */
export function getTeams(): Promise<TeamRoster> {
  return jsonFetch('GET', 'api/intake-agent/teams');
}

/** Direct (non-chat) write to a Phase-1 routing field. */
export function setRoutingField(
  sessionId: string,
  fieldName: string,
  value: unknown
): Promise<SessionState> {
  return jsonFetch(
    'PATCH',
    `api/intake-agent/sessions/${encodeURIComponent(sessionId)}/fields/${encodeURIComponent(
      fieldName
    )}`,
    { value }
  );
}

/** Direct (non-chat) write to a Phase-2 question's answer. */
export function setAnswer(
  sessionId: string,
  canonicalId: string,
  answer: unknown
): Promise<SessionState> {
  return jsonFetch(
    'PATCH',
    `api/intake-agent/sessions/${encodeURIComponent(
      sessionId
    )}/answers/${encodeURIComponent(canonicalId)}`,
    { answer }
  );
}

/**
 * Non-streaming turn. Kept for fallback or debugging.
 */
export function sendMessage(
  sessionId: string,
  message: string,
  focusedField?: FocusedField | null
): Promise<SessionState & { reply: string }> {
  return jsonFetch('POST', 'api/intake-agent/message', {
    session_id: sessionId,
    message,
    focused_field: focusedField ?? undefined,
  });
}

export interface UploadAttachmentResult {
  attachment: unknown;
  attachments: unknown[];
}

/**
 * Attachment upload — single multipart POST straight to our server, which
 * saves the bytes (local disk by default) and records it on the session.
 *
 * onProgress(pct) is reported via XHR upload events (0-100) — fetch()
 * doesn't expose upload progress, so we use XMLHttpRequest here.
 *
 * Returns {attachment, attachments} on success (attachments = the full list
 * for the session, matching what the server tracks).
 */
export function uploadAttachment(
  sessionId: string,
  file: File,
  onProgress?: (pct: number) => void
): Promise<UploadAttachmentResult> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const url = apiPath(
      `api/intake-agent/attachments/upload?session_id=${encodeURIComponent(sessionId)}`
    );
    xhr.open('POST', url);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress?.(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText));
        } catch {
          reject(new Error('Upload succeeded but response was not valid JSON'));
        }
      } else {
        let detail = xhr.statusText;
        try {
          detail = JSON.parse(xhr.responseText).detail || detail;
        } catch {
          // ignore — fall back to statusText
        }
        reject(new Error(`Upload failed: ${xhr.status} ${detail}`));
      }
    };
    xhr.onerror = () => reject(new Error('Upload failed: network error'));

    const formData = new FormData();
    formData.append('file', file);
    xhr.send(formData);
  });
}

export interface StreamMessageCallbacks {
  onDelta?: (text: string) => void;
  onState?: (state: SessionState) => void;
  onError?: (err: Error) => void;
  onDone?: () => void;
}

/**
 * Streaming turn using Server-Sent Events over fetch.
 */
export async function streamMessage(
  sessionId: string,
  message: string,
  callbacks: StreamMessageCallbacks = {},
  focusedField?: FocusedField | null
): Promise<void> {
  const { onDelta, onState, onError, onDone } = callbacks;
  try {
    const res = await fetch(apiPath('api/intake-agent/message/stream'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
      body: JSON.stringify({
        session_id: sessionId,
        message,
        focused_field: focusedField ?? undefined,
      }),
    });
    if (!res.ok || !res.body) {
      throw new Error(`stream failed: ${res.status} ${res.statusText}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      let frameEnd: number;
      while ((frameEnd = buffer.indexOf('\n\n')) !== -1) {
        const frame = buffer.slice(0, frameEnd);
        buffer = buffer.slice(frameEnd + 2);

        const dataLines = frame
          .split('\n')
          .filter((l) => l.startsWith('data:'))
          .map((l) => l.slice(5).trimStart());
        if (dataLines.length === 0) continue;

        const payload = dataLines.join('\n');
        let event: { type?: string; text?: string; message?: string } & Partial<SessionState>;
        try {
          event = JSON.parse(payload);
        } catch {
          continue;
        }
        if (event.type === 'delta') onDelta?.(event.text || '');
        else if (event.type === 'state') onState?.(event as SessionState);
        else if (event.type === 'error')
          onError?.(new Error(event.message || 'server error'));
      }
    }
  } catch (err) {
    onError?.(err instanceof Error ? err : new Error(String(err)));
  } finally {
    onDone?.();
  }
}

/**
 * FormFillerAgent sanity integration -- POST an envelope, get the same
 * shape back with any blanks the agent was confident enough to fill.
 * See docs/form_filler_agent_contract.md.
 */
export function fillForm(envelope: FormFillerEnvelope): Promise<FormFillerEnvelope> {
  return jsonFetch<FormFillerEnvelope>('POST', 'api/formfiller/fill', envelope);
}
