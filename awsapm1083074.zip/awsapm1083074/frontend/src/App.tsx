/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { useCallback, useEffect, useMemo, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { Toaster, toast } from 'sonner';
import {
  getSchema,
  getTeams,
  listSessions,
  loadSession,
  startSession,
} from './api';
import type {
  Attachment,
  FocusedField,
  FullSessionResponse,
  IntakeSchema,
  SessionState,
  SessionSummary,
  TeamRoster,
  Ticket,
  UIMessage,
} from './types';
import { computeSteps, liveStepIndex } from './lib/steps';
import { buildTeamLabelMap, teamLabel } from './lib/teamLabels';
import { diffChangedFieldKeys } from './lib/diffState';
import PhaseBadge from './components/shared/PhaseBadge';
import HistoryDropdown from './components/shared/HistoryDropdown';
import WorkflowPanel from './components/WorkflowPanel/WorkflowPanel';
import PostDedupDashboard from './components/PostDedupDashboard/PostDedupDashboard';
import ChatPanel from './components/ChatPanel/ChatPanel';
import OverviewPanel from './components/OverviewPanel/OverviewPanel';

// How long a field stays visually flagged as "Updated by AI" after a turn.
const HIGHLIGHT_DURATION_MS = 2200;

const EMPTY_STATE: SessionState = {
  phase: 'collecting_routing_info',
  display_id: null,
  user_id: null,
  created_at: null,
  updated_at: null,
  collected_fields: {},
  activated_teams: [],
  focus_team: null,
  team_order: [],
  pending_questions: [],
  team_forms: {},
  attachments: [],
  ticket: null,
};

export default function App() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<UIMessage[]>([]);
  const [state, setState] = useState<SessionState>(EMPTY_STATE);
  const [schema, setSchema] = useState<IntakeSchema | null>(null);
  const [teamRoster, setTeamRoster] = useState<TeamRoster | null>(null);
  const [sessions, setSessions] = useState<SessionSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [focusedField, setFocusedField] = useState<FocusedField | null>(null);
  const [viewIndex, setViewIndex] = useState(0);
  const [aiWorking, setAiWorking] = useState(false);
  const [highlightedKeys, setHighlightedKeys] = useState<Set<string>>(new Set());

  const rawSteps = useMemo(() => computeSteps(state), [state]);
  const teamLabelMap = useMemo(() => buildTeamLabelMap(teamRoster), [teamRoster]);
  // Steps keep `team` as the raw trigger_rules.json key (used to filter
  // pending_questions by category) but get a prettified `label` from
  // team_roster.json's canonical_name where the crosswalk has one.
  const steps = useMemo(
    () =>
      rawSteps.map((s) =>
        s.kind === 'team' && s.team ? { ...s, label: teamLabel(teamLabelMap, s.team) } : s
      ),
    [rawSteps, teamLabelMap]
  );
  const liveIndex = useMemo(() => liveStepIndex(steps, state), [steps, state]);

  // Auto-advance the viewed step whenever the server-side "live" step moves
  // forward (phase change, team-to-team advance, or ticket issued) — but
  // don't fight the user browsing to an earlier step in between.
  useEffect(() => {
    setViewIndex(liveIndex);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.phase, state.focus_team, state.ticket, sessionId]);

  const refreshSessions = useCallback(async () => {
    try {
      const r = await listSessions(50);
      setSessions(r.sessions || []);
    } catch (e) {
      console.warn('listSessions failed', e);
    }
  }, []);

  useEffect(() => {
    getSchema()
      .then(setSchema)
      .catch((e) => console.warn('getSchema failed', e));
    getTeams()
      .then(setTeamRoster)
      .catch((e) => console.warn('getTeams failed', e));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function applyServerState(r: FullSessionResponse) {
    setSessionId(r.session_id);
    if (r.session_id) {
      try {
        localStorage.setItem('intake_session_id', r.session_id);
      } catch {
        // localStorage unavailable — resume-on-refresh just won't work
      }
    }
    setMessages(
      (r.ui_messages || []).map((m) => ({ role: m.role, content: m.content || '' }))
    );
    setState(r);
    setFocusedField(null);
    setHighlightedKeys(new Set());
  }

  /**
   * State updates arriving from chat (as opposed to a direct form write)
   * get diffed against the prior state so whatever the AI just filled in
   * gets a brief "Updated by AI" highlight — the field-level counterpart to
   * the top-of-form loading indicator.
   */
  function handleChatStateChange(next: SessionState) {
    const changed = diffChangedFieldKeys(state, next);
    if (changed.length > 0) {
      setHighlightedKeys((prev) => new Set([...prev, ...changed]));
      changed.forEach((key) => {
        setTimeout(() => {
          setHighlightedKeys((prev) => {
            const copy = new Set(prev);
            copy.delete(key);
            return copy;
          });
        }, HIGHLIGHT_DURATION_MS);
      });
      toast.success(`AI updated ${changed.length} field${changed.length === 1 ? '' : 's'}`, {
        duration: 2500,
      });
    }
    setState(next);
  }

  async function handleReset() {
    setLoading(true);
    setError(null);
    try {
      applyServerState(await startSession());
      refreshSessions();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  async function handlePickSession(id: string) {
    if (id === sessionId) return;
    setLoading(true);
    setError(null);
    try {
      applyServerState(await loadSession(id));
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    async function initSession() {
      let savedId: string | null = null;
      try {
        savedId = localStorage.getItem('intake_session_id');
      } catch {
        // ignore
      }

      if (savedId) {
        setLoading(true);
        try {
          applyServerState(await loadSession(savedId));
          return;
        } catch (e) {
          console.warn('resume failed for', savedId, e instanceof Error ? e.message : e);
          try {
            localStorage.removeItem('intake_session_id');
          } catch {
            // ignore
          }
        } finally {
          setLoading(false);
        }
      }
      await handleReset();
    }
    initSession();
    refreshSessions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleAttachmentsChange(attachments: Attachment[]) {
    setState((prev) => ({ ...prev, attachments }));
    refreshSessions();
  }

  /**
   * PostDedupDashboard talks to a different REST surface
   * (/api/post-dedup/*) than the one `state` came from, so its mutations
   * don't flow back through applyServerState/handleChatStateChange. Once
   * its deterministic gate lets a ticket through, mirror that onto the
   * top-level SessionState so the header PhaseBadge and OverviewPanel's
   * TicketPanel reflect it — submit() takes the session straight from
   * asking_questions to complete, same as the chat flow's own gate.
   */
  function handlePostDedupTicket(ticket: Ticket) {
    setState((prev) => ({ ...prev, ticket, phase: 'complete' }));
    refreshSessions();
  }

  const canRender = schema !== null;

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <header className="h-14 bg-white border-b flex items-center px-6 flex-shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-elevance-purple flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
            E
          </div>
          <span className="font-semibold text-elevance-dark text-lg">Elevance Health</span>
          <span className="text-gray-400">|</span>
          <span className="text-gray-500 text-sm">Governance Intake Agent</span>
          <PhaseBadge phase={state.phase} />
        </div>
        <div className="ml-auto flex items-center gap-3">
          <span className="text-[10px] text-gray-400 font-mono">{sessionId || ''}</span>
          <HistoryDropdown
            sessions={sessions}
            currentSessionId={sessionId}
            onPick={handlePickSession}
            onRefresh={refreshSessions}
            disabled={loading}
          />
          <button
            onClick={handleReset}
            disabled={loading}
            className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-elevance-purple disabled:opacity-50"
          >
            <RefreshCw size={12} /> New session
          </button>
        </div>
      </header>

      {error && (
        <div className="bg-red-50 border-b border-red-200 px-6 py-2 text-sm text-red-700">
          <strong>Error:</strong> {error}
        </div>
      )}

      {!canRender || !sessionId ? (
        <div className="flex-1 flex items-center justify-center text-sm text-gray-400">
          Loading…
        </div>
      ) : (
        <div className="flex-1 grid grid-cols-[380px_1fr_340px] overflow-hidden">
          <div className="border-r border-gray-200 overflow-hidden">
            {state.phase === 'collecting_routing_info' ? (
              <WorkflowPanel
                sessionId={sessionId}
                schema={schema}
                state={state}
                steps={steps}
                viewIndex={viewIndex}
                onViewIndexChange={setViewIndex}
                onStateChange={setState}
                onAttachmentsChange={handleAttachmentsChange}
                onFocusField={setFocusedField}
                aiWorking={aiWorking}
                highlightedKeys={highlightedKeys}
              />
            ) : (
              <PostDedupDashboard
                sessionId={sessionId}
                teamLabelMap={teamLabelMap}
                onTicket={handlePostDedupTicket}
                onAttachmentsChange={handleAttachmentsChange}
              />
            )}
          </div>

          <ChatPanel
            sessionId={sessionId}
            state={state}
            messages={messages}
            setMessages={setMessages}
            onStateChange={handleChatStateChange}
            focusedField={focusedField}
            onAfterSend={refreshSessions}
            onLoadingChange={setAiWorking}
          />

          <div className="border-l border-gray-200 overflow-hidden">
            <OverviewPanel
              state={state}
              steps={steps}
              liveIndex={liveIndex}
              viewIndex={viewIndex}
              onEditStep={setViewIndex}
            />
          </div>
        </div>
      )}
      <Toaster position="bottom-right" richColors closeButton />
    </div>
  );
}
