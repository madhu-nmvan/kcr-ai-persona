/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

/**
 * Shared frontend types, hand-kept in sync with the backend shapes they
 * mirror (same way intake_schema.json and intake_agent.py's RoutingFields
 * are hand-kept in sync today):
 *   - SchemaField / IntakeSchema  <-> backend/.../data/intake_schema.json
 *   - TeamRosterEntry / TeamRoster <-> backend/.../data/team_roster.json
 *   - SessionState                 <-> handler.py's _public_state()
 */

export type FieldType = 'string' | 'bool' | 'enum' | 'array';

export interface RequiredWhenCondition {
  // Small rule_engine DSL condition, e.g. {"equals": ["vendor_data_access", true]}.
  // Only ever inspected by the backend; the frontend just forwards it around
  // via the schema and doesn't evaluate it.
  [operator: string]: unknown;
}

export interface SchemaField {
  name: string;
  group: string;
  type: FieldType;
  description?: string;
  required: boolean;
  required_when?: RequiredWhenCondition;
  options?: string[];
  items?: { type: string; enums?: string[] };
  uniqueItems?: boolean;
}

export interface IntakeSchema {
  description?: string;
  fields: SchemaField[];
}

export interface TeamRosterEntry {
  canonical_name: string;
  status?: string;
  question_id_prefix?: string;
  notes?: string;
  [key: string]: unknown;
}

export interface TeamRoster {
  teams: TeamRosterEntry[];
  [key: string]: unknown;
}

export type RoutingFieldValue = string | boolean | string[] | null | undefined;

export type CollectedFields = Record<string, RoutingFieldValue>;

export interface QuestionSource {
  team: string;
  question_id: string;
}

export interface PendingQuestion {
  canonical_id: string;
  canonical_question: string;
  category: string; // team name
  sources: QuestionSource[];
  source_teams: string[];
  answered: boolean;
  answer: string | null;
}

export interface ActivatedTeam {
  team: string;
  review_phase?: number;
}

export type TeamForms = Record<string, Record<string, unknown>>;

export interface Attachment {
  key: string;
  filename: string;
  size: number;
  content_type: string;
  backend: string;
}

export interface Ticket {
  ticket_id: string;
  session_id?: string;
  submitter?: string;
  created_at?: string;
  status?: string;
  activated_teams?: ActivatedTeam[];
  team_forms?: TeamForms;
  attachments?: Attachment[];
  activated_teams_summary?: Array<{
    team: string;
    review_phase?: number;
    in_scope_for_demo?: boolean;
  }>;
  answered_questions?: Array<{
    canonical_id: string;
    canonical_question: string;
    answer: string | null;
    source_teams: string[];
  }>;
  [key: string]: unknown;
}

export type Phase =
  | 'collecting_routing_info'
  | 'asking_questions'
  | 'collecting_attachments'
  | 'complete';

/** Matches handler.py's _public_state() — the shape every state-bearing endpoint returns. */
export interface SessionState {
  phase: Phase;
  display_id?: string | null;
  user_id?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  collected_fields: CollectedFields;
  activated_teams: ActivatedTeam[];
  focus_team: string | null;
  team_order: string[];
  pending_questions: PendingQuestion[];
  team_forms: TeamForms;
  attachments: Attachment[];
  ticket: Ticket | null;
}

export interface UIMessage {
  role: 'user' | 'agent';
  content: string;
  streaming?: boolean;
}

/** Sent alongside a chat turn so the reply can be contextually relevant to
 * whatever workflow-form field the user currently has focused. */
export interface FocusedField {
  name?: string;
  canonical_id?: string;
  label: string;
  description?: string;
}

export interface SessionSummary {
  session_id: string;
  user_id: string;
  phase: Phase | string;
  updated_at: string;
  summary: string;
}

/** Full response from GET /api/intake-agent/sessions/{id} and /start. */
export interface FullSessionResponse extends SessionState {
  session_id: string;
  ui_messages: UIMessage[];
}

/** A single workflow step, computed client-side from phase + team_order. */
export type StepKind = 'routing' | 'team' | 'attachments' | 'submit';

export interface WorkflowStep {
  kind: StepKind;
  key: string;
  label: string;
  /** Present for kind === 'team' — the team this step's questions belong to. */
  team?: string;
}

/* ---------------------------------------------------------------------- */
/* Post-dedup dashboard (Phase 2+ consolidated Q&A experience)             */
/* Matches state_adapter.py's spec-\u00a75 STATE envelope (_question_to_envelope,
 * state_from_session) and postdedup_api.py's response bodies. Distinct
 * from PendingQuestion above — same underlying session data, reshaped with
 * the spec's field names (`text` not `canonical_question`, etc). */
/* ---------------------------------------------------------------------- */

export type PrefillStatus = 'proposed' | 'accepted' | 'dismissed';

export interface PrefillProvenance {
  kind: 'transcript' | 'trigger_field' | 'prior_answer';
  /** Trigger field name, 0-based user-message index, or a prior canonical_id. */
  ref: string;
  quote: string;
}

export interface Prefill {
  answer: string;
  provenance: PrefillProvenance;
  status: PrefillStatus;
}

export interface PostDedupQuestion {
  canonical_id: string;
  text: string;
  category: string;
  sources: QuestionSource[];
  source_teams: string[];
  answered: boolean;
  answer: string | null;
  answer_origin?: 'user' | 'prefill';
  prefill?: Prefill;
}

export interface PostDedupStats {
  raw_question_count: number;
  consolidated_question_count: number;
  reduction_ratio: number;
  answered_count: number;
  answered_by_prefill_count: number;
  prefill: {
    proposed: number;
    accepted: number;
    dismissed: number;
    rejected_ungrounded: number;
  };
}

/** Deterministic completeness snapshot — null outside asking_questions. */
export interface PostDedupCompleteness {
  complete: boolean;
  unanswered_count: number;
  unanswered_ids: string[];
  open_gaps: unknown[];
  activated_team_count: number;
}

/** Returned by POST .../prefill and .../answers (run_prefill: true). */
export interface PrefillSummary {
  proposed: number;
  rejected: number;
  eligible: number;
}

export interface QaConcern {
  canonical_id: string;
  concern: string;
  clarifying_question: string;
}

/** GET/POST /api/post-dedup/sessions/{id} response envelope (postdedup_api.py's `_view()`). */
export interface PostDedupSessionView {
  session_id: string;
  phase: Phase;
  state: {
    messages: UIMessage[];
    trigger: { fields: CollectedFields; complete: boolean };
    activated_teams: ActivatedTeam[];
    governance: { questions: PostDedupQuestion[]; complete: boolean };
  };
  completeness: PostDedupCompleteness | null;
  stats: PostDedupStats;
  unknown_teams: string[];
  attachments: Attachment[];
  ticket: Ticket | null;
  /** Only present on POST .../answers and POST .../prefill responses. */
  prefill_summary?: PrefillSummary | null;
}

export interface PostDedupAnswerEdit {
  canonical_id: string;
  answer: string | null;
}

export interface PrefillDecision {
  accept?: string[];
  dismiss?: string[];
  acceptAll?: boolean;
}

/**
 * FormFillerAgent envelope (see docs/form_filler_agent_contract.md and
 * backend/src/governance_intake/form_filler_agent.py). Used only by the
 * manual sanity-integration view (FormFillerSanityView.tsx) -- not part of
 * the production Phase 1 -> Phase 2 flow.
 */
export type FormFillerOrigin = 'user' | 'agent' | null;

export interface FormFillerItem {
  id: string;
  text: string;
  value: boolean | string | string[] | null;
  origin: FormFillerOrigin;
  confidence: number | null;
}

export interface FormFillerGovernanceQuestion extends FormFillerItem {
  sources: QuestionSource[];
}

export interface FormFillerEnvelope {
  triggers: FormFillerItem[];
  governance: FormFillerGovernanceQuestion[];
}
