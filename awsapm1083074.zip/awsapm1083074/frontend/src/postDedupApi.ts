/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import type {
  Attachment,
  PostDedupAnswerEdit,
  PostDedupSessionView,
  PrefillDecision,
  QaConcern,
  Ticket,
} from './types';

/**
 * Fetch helpers for backend/.../postdedup_api.py's /api/post-dedup/* surface
 * — a separate REST prefix from api.ts's /api/intake-agent/* chat/routing
 * surface, but the SAME backend SessionStore. Every call here takes the
 * CURRENT session id the ingestion phase already produced; nothing here
 * ever calls POST /api/post-dedup/sessions (that mints a second session id).
 *
 * Paths are RELATIVE for the same reverse-proxy reason as api.ts — see its
 * apiPath() comment. Do NOT change these back to "/api/...".
 */
function apiPath(path: string): string {
  return path.startsWith('/') ? path.slice(1) : path;
}

async function jsonFetch<T>(method: string, path: string, body?: unknown): Promise<T> {
  const opts: RequestInit = {
    method,
    headers: { 'Content-Type': 'application/json' },
  };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(apiPath(path), opts);
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const err = await res.json();
      detail = err.detail || detail;
    } catch {
      // response wasn't JSON — fall back to statusText
    }
    throw new Error(`${res.status} ${detail}`);
  }
  return res.json() as Promise<T>;
}

export function getPostDedupSession(sessionId: string): Promise<PostDedupSessionView> {
  return jsonFetch('GET', `api/post-dedup/sessions/${encodeURIComponent(sessionId)}`);
}

export function saveAnswers(
  sessionId: string,
  answers: PostDedupAnswerEdit[],
  runPrefillAfter = false
): Promise<PostDedupSessionView> {
  return jsonFetch('POST', `api/post-dedup/sessions/${encodeURIComponent(sessionId)}/answers`, {
    answers,
    run_prefill: runPrefillAfter,
  });
}

export function runPrefill(sessionId: string): Promise<PostDedupSessionView> {
  return jsonFetch('POST', `api/post-dedup/sessions/${encodeURIComponent(sessionId)}/prefill`);
}

export function decidePrefills(
  sessionId: string,
  decision: PrefillDecision
): Promise<PostDedupSessionView> {
  return jsonFetch(
    'POST',
    `api/post-dedup/sessions/${encodeURIComponent(sessionId)}/prefill/decisions`,
    {
      accept: decision.accept ?? [],
      dismiss: decision.dismiss ?? [],
      accept_all: decision.acceptAll ?? false,
    }
  );
}

export function runQaReview(sessionId: string): Promise<{ concerns: QaConcern[] }> {
  return jsonFetch('POST', `api/post-dedup/sessions/${encodeURIComponent(sessionId)}/qa-review`);
}

export function submitPostDedup(
  sessionId: string
): Promise<{ ticket: Ticket; phase: string }> {
  return jsonFetch('POST', `api/post-dedup/sessions/${encodeURIComponent(sessionId)}/submit`);
}

export interface UploadPostDedupAttachmentResult {
  attachment: Attachment;
  attachments: Attachment[];
}

/**
 * Diagram upload — XHR (not fetch) for upload progress events, mirroring
 * api.ts's uploadAttachment. This dashboard collects the required
 * solution/data-flow diagram inline instead of through a separate
 * attachments step.
 */
export function uploadPostDedupAttachment(
  sessionId: string,
  file: File,
  onProgress?: (pct: number) => void
): Promise<UploadPostDedupAttachmentResult> {
  const { promise, resolve, reject } =
    Promise.withResolvers<UploadPostDedupAttachmentResult>();

  const xhr = new XMLHttpRequest();
  const url = apiPath(
    `api/post-dedup/sessions/${encodeURIComponent(sessionId)}/attachments/upload`
  );
  xhr.open('POST', url);
  xhr.upload.onprogress = (e) => {
    if (e.lengthComputable) onProgress?.(Math.round((e.loaded / e.total) * 100));
  };
  xhr.onload = () => {
    if (xhr.status >= 200 && xhr.status < 300) {
      try {
        resolve(JSON.parse(xhr.responseText));
      } catch {
        reject(new Error('Upload succeeded but response was not valid JSON'));
      }
    } else {
      let detail = xhr.statusText;
      try {
        detail = JSON.parse(xhr.responseText).detail || detail;
      } catch {
        // ignore — fall back to statusText
      }
      reject(new Error(`Upload failed: ${xhr.status} ${detail}`));
    }
  };
  xhr.onerror = () => reject(new Error('Upload failed: network error'));

  const formData = new FormData();
  formData.append('file', file);
  xhr.send(formData);

  return promise;
}
