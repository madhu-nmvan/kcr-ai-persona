# Frontend — governance-intake UI

Node 18+ (React + Vite + Tailwind). Talks to the backend's `/api`.

This doc covers the frontend dev workflow: setup, running the dev server,
building for production/SageMaker, the sanity-view dev route, and
frontend-specific troubleshooting. For the app overview and the end-to-end
local/SageMaker walkthroughs, see the [root README](../README.md).

---

## Setup

In a PowerShell terminal (separate from the backend's):

```powershell
cd frontend
npm install
```

`frontend/` ships without `node_modules/` — `npm install` creates them (and
`package-lock.json`); versions are pinned in `package.json`.

---

## Run the dev server

The backend must already be running on port 8000 (see the
[backend README](../backend/README.md)).

```powershell
npm run dev
```

Vite prints `Local: http://localhost:5173/`. Open **http://localhost:5173**
(not :8000 — that's the API). The Vite dev server proxies `/api` to the backend
at `http://localhost:8000`, so both terminals must stay running.

---

## Build for production / SageMaker

```powershell
npm run build          # produces frontend/dist
```

The build uses a relative asset base, so the same `frontend/dist` works served
at the domain root or behind a path prefix (e.g. SageMaker's `/proxy/8000/`) —
no per-environment rebuild. For the full SageMaker flow (backend serves the
built UI on one port), see the [root README](../README.md).

---

## Sanity-integration view

Append `?sanity=formfiller` to reach the FormFillerAgent
sanity-integration view — a manual-verification harness, **not** the production
UI. It renders `FormFillerSanityView` instead of the normal `App`, bypassing
the Phase 1 → Phase 2 flow, so you can exercise the form-filler path in
isolation:

```
http://localhost:5173/?sanity=formfiller
```

Without the query param (or with any other value) you get the production `App`.

---

## Troubleshooting

| Symptom | Cause / Fix |
|---------|-------------|
| `npm install` → `SELF_SIGNED_CERT_IN_CHAIN` / `UNABLE_TO_GET_ISSUER_CERT` | Corporate TLS proxy. Set `$env:NODE_EXTRA_CA_CERTS` to the corporate root CA `.pem`, or `npm config set registry https://<internal-npm-mirror>`, then retry. |
| UI loads but `/api` calls fail | Backend not running, or you opened `:8000` in dev mode — use `:5173` when running `npm run dev`. |
