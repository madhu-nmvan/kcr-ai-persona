/*
 * Copyright Amazon.com, Inc. or its affiliates. This material is AWS Content under the AWS Enterprise Agreement
 * or AWS Customer Agreement (as applicable) and is provided under the AWS Intellectual Property License.
 */

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // Relative base so the built index.html references assets as
  // "./assets/..." instead of "/assets/...". This lets the SAME build work
  // whether it's served at the domain root (local dev / plain server) or
  // behind a path prefix like SageMaker's /proxy/8000/ notebook proxy —
  // no per-environment rebuild needed.
  base: './',
  server: {
    port: 5173,
    // Proxy /api calls to the FastAPI server so we avoid CORS in dev.
    proxy: {
      '/api': 'http://localhost:8000',
    },
  },
});
